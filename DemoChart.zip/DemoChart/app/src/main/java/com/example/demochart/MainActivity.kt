package com.example.demochart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    lateinit var edt_num1: EditText
    lateinit var submit: Button
    val arrayList = ArrayList<String>()
    lateinit var listspinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        edt_num1 = findViewById(R.id.edttxt)
        submit = findViewById(R.id.button)
        listspinner = findViewById(R.id.listspinner)
        val list: ListView = findViewById(R.id.list)


        arrayList.add("Hello")
        arrayList.add("Hello")
        arrayList.add("Hello")
        arrayList.add("Hello")
        arrayList.add("Hello")

        val adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList)
        list.adapter = adapter
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        listspinner.adapter = adapter

//
//        list.setOnItemClickListener { adapterView: AdapterView<*>, view1: View, i: Int, l: Long ->
//
//            Toast.makeText(applicationContext, "" + list.getItemAtPosition(i), Toast.LENGTH_LONG)
//                .show()
//        }
        list.onItemClickListener = object : AdapterView.OnItemClickListener {
            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
            Toast.makeText(applicationContext, "" + list.getItemAtPosition(position), Toast.LENGTH_LONG)
                .show()            }

        }

        // Set an on item selected listener for spinner object
        listspinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Toast.makeText(
                    this@MainActivity,
                    "" + list.getItemAtPosition(position),
                    Toast.LENGTH_LONG
                ).show()
            }

        }


        submit.setOnClickListener {

            Toast.makeText(applicationContext, "Click event" + edt_num1.text, Toast.LENGTH_LONG)
                .show()

        }


    }
}
