package com.acumengroup.ui.adapter;

/**
 * Created by Arcadia
 */
@Deprecated
public class CommonRowData {

    private Object details;
    private Object subDetails;

    private String head1 = "";
    private String head2 = "";
    private String head3 = "";
    private String head4 = "";
    private String head5 = "";
    private String head6 = "";
    private String head7 = "";

    private String subHead1 = "";
    private String subHead2 = "";
    private String subHead3 = "";
    private String subHead4 = "";
    private String subHead5 = "";

    //For High Convection Ideas
    private String token; //symbol
    private String MODE;
    private String SCRIP_NAME;
    private String BSE_CODE;
    private String NSE_CODE;
    private String Target_Price;
    private String Stop_Loss;
    private String reco_price;
    private String cmp;
    private String cmp_original;
    private Double cmpPer;
    private String reco_time;
    private String assetType;
    private String reco_date;
    private String bseToken;
    private String nseToken;
    private String newsDetails;


    private String scriptPrice;

    public String getHead7() {
        return head7;
    }

    public void setHead7(String head7) {
        this.head7 = head7;
    }

    public String getHead5() {
        return head5;
    }

    public void setHead5(String head5) {
        this.head5 = head5;
    }

    public String getHead6() {
        return head6;
    }

    public void setHead6(String head6) {
        this.head6 = head6;
    }

    public String getScriptPrice() {
        return scriptPrice;
    }

    public void setScriptPrice(String scriptPrice) {
        this.scriptPrice = scriptPrice;
    }

    public String getBseToken() {
        return bseToken;
    }

    public void setBseToken(String bseToken) {
        this.bseToken = bseToken;
    }

    public String getNseToken() {
        return nseToken;
    }

    public void setNseToken(String nseToken) {
        this.nseToken = nseToken;
    }

    public String getNewsDetails() {
        return newsDetails;
    }

    public void setNewsDetails(String newsDetails) {
        this.newsDetails = newsDetails;
    }

    public String getReco_date() {
        return reco_date;

    }

    public void setReco_date(String reco_date) {
        this.reco_date = reco_date;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMODE() {
        return MODE;
    }

    public void setMODE(String MODE) {
        this.MODE = MODE;
    }

    public String getSCRIP_NAME() {
        return SCRIP_NAME;
    }

    public void setSCRIP_NAME(String SCRIP_NAME) {
        this.SCRIP_NAME = SCRIP_NAME;
    }

    public String getBSE_CODE() {
        return BSE_CODE;
    }

    public void setBSE_CODE(String BSE_CODE) {
        this.BSE_CODE = BSE_CODE;
    }

    public String getNSE_CODE() {
        return NSE_CODE;
    }

    public void setNSE_CODE(String NSE_CODE) {
        this.NSE_CODE = NSE_CODE;
    }

    public String getTarget_Price() {
        return Target_Price;
    }

    public void setTarget_Price(String target_Price) {
        Target_Price = target_Price;
    }

    public String getStop_Loss() {
        return Stop_Loss;
    }

    public void setStop_Loss(String stop_Loss) {
        Stop_Loss = stop_Loss;
    }

    public String getReco_price() {
        return reco_price;
    }

    public void setReco_price(String reco_price) {
        this.reco_price = reco_price;
    }

    public String getCmp() {
        return cmp;
    }

    public void setCmp(String cmp) {
        this.cmp = cmp;
    }

    public String getCmp_original() {
        return cmp_original;
    }

    public void setCmp_original(String cmp_original) {
        this.cmp_original = cmp_original;
    }

    public Double getCmpPer() {
        return cmpPer;
    }

    public void setCmpPer(Double cmpPer) {
        this.cmpPer = cmpPer;
    }

    public String getReco_time() {
        return reco_time;
    }

    public void setReco_time(String reco_time) {
        this.reco_time = reco_time;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public Object getDetails() {
        return this.details;
    }

    public void setDetails(Object details) {
        this.details = details;
    }

    public String getHead1() {
        return this.head1;
    }

    public void setHead1(String head1) {
        this.head1 = head1;
    }

    public String getHead2() {
        return this.head2;
    }

    public void setHead2(String head2) {
        this.head2 = head2;
    }

    public String getHead3() {
        return this.head3;
    }

    public void setHead3(String head3) {
        this.head3 = head3;
    }

    public String getSubHead1() {
        return this.subHead1;
    }

    public void setSubHead1(String subHead1) {
        this.subHead1 = subHead1;
    }

    public String getSubHead2() {
        return this.subHead2;
    }

    public void setSubHead2(String subHead2) {
        this.subHead2 = subHead2;
    }

    public String getSubHead3() {
        return this.subHead3;
    }

    public void setSubHead3(String subHead3) {
        this.subHead3 = subHead3;
    }

    public String getHead4() {
        return head4;
    }

    public void setHead4(String head4) {
        this.head4 = head4;
    }

    public String getSubHead4() {
        return subHead4;
    }

    public void setSubHead4(String subHead4) {
        this.subHead4 = subHead4;
    }

    public Object getSubDetails() {
        return subDetails;
    }

    public void setSubDetails(Object subDetails) {
        this.subDetails = subDetails;
    }

}
