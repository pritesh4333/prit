package com.acumengroup.mobile.tablefixheader.custom;

import android.database.DataSetObserver;

/**
 * Created by Arcadia
 */
public class CustomDataSetObserver extends DataSetObserver {
    public void onChangeAt(int index) {
    }

}
