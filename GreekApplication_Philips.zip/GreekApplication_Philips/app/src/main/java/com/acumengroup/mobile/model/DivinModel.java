package com.acumengroup.mobile.model;

public class DivinModel {
    String S_NAME;
    String RECORDDATE;
    String dividentRs;

    public String getS_NAME() {
        return S_NAME;
    }

    public void setS_NAME(String s_NAME) {
        S_NAME = s_NAME;
    }

    public String getRECORDDATE() {
        return RECORDDATE;
    }

    public void setRECORDDATE(String RECORDDATE) {
        this.RECORDDATE = RECORDDATE;
    }

    public String getDividentRs() {
        return dividentRs;
    }

    public void setDividentRs(String dividentRs) {
        this.dividentRs = dividentRs;
    }
}
