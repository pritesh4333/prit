package com.acumengroup.mobile.BottomTabScreens.adapter;

public class OptionChainhashData {

    String lOurToken_call;
    String lOpenInterest_call;
    String lPrevOpenInterest_call;
    String lVolume_call;
    String dLtp_call;
    String dNetChange_call;
    String lBidQty_call;
    String lBidPrice_call;
    String lAskQty_call;
    String AskPrice_call;
    String lClosingPrice_call;
    String callput_call;


    String lOurToken_put;
    String lOpenInterest_put;
    String lPrevOpenInterest_put;
    String lVolume_put;
    String dLtp_put;
    String dNetChange_put;
    String lBidQty_put;
    String lBidPrice_put;
    String lAskQty_put;
    String AskPrice_put;
    String lClosingPrice_put;
    String callput_put;

    String strike;
    String color_call;
    String color_put;


    public String getColor_put() {
        return color_put;
    }

    public void setColor_put(String color_put) {
        this.color_put = color_put;
    }

    public String getColor_call() {
        return color_call;
    }

    public void setColor_call(String color_call) {
        this.color_call = color_call;
    }

    public String getlOurToken_call() {
        return lOurToken_call;
    }

    public void setlOurToken_call(String lOurToken_call) {
        this.lOurToken_call = lOurToken_call;
    }

    public String getlOpenInterest_call() {
        return lOpenInterest_call;
    }

    public void setlOpenInterest_call(String lOpenInterest_call) {
        this.lOpenInterest_call = lOpenInterest_call;
    }

    public String getlPrevOpenInterest_call() {
        return lPrevOpenInterest_call;
    }

    public void setlPrevOpenInterest_call(String lPrevOpenInterest_call) {
        this.lPrevOpenInterest_call = lPrevOpenInterest_call;
    }

    public String getlVolume_call() {
        return lVolume_call;
    }

    public void setlVolume_call(String lVolume_call) {
        this.lVolume_call = lVolume_call;
    }

    public String getdLtp_call() {
        return dLtp_call;
    }

    public void setdLtp_call(String dLtp_call) {
        this.dLtp_call = dLtp_call;
    }

    public String getdNetChange_call() {
        return dNetChange_call;
    }

    public void setdNetChange_call(String dNetChange_call) {
        this.dNetChange_call = dNetChange_call;
    }

    public String getlBidQty_call() {
        return lBidQty_call;
    }

    public void setlBidQty_call(String lBidQty_call) {
        this.lBidQty_call = lBidQty_call;
    }

    public String getlBidPrice_call() {
        return lBidPrice_call;
    }

    public void setlBidPrice_call(String lBidPrice_call) {
        this.lBidPrice_call = lBidPrice_call;
    }

    public String getlAskQty_call() {
        return lAskQty_call;
    }

    public void setlAskQty_call(String lAskQty_call) {
        this.lAskQty_call = lAskQty_call;
    }

    public String getAskPrice_call() {
        return AskPrice_call;
    }

    public void setAskPrice_call(String askPrice_call) {
        AskPrice_call = askPrice_call;
    }

    public String getlClosingPrice_call() {
        return lClosingPrice_call;
    }

    public void setlClosingPrice_call(String lClosingPrice_call) {
        this.lClosingPrice_call = lClosingPrice_call;
    }

    public String getCallput_call() {
        return callput_call;
    }

    public void setCallput_call(String callput_call) {
        this.callput_call = callput_call;
    }

    public String getlOurToken_put() {
        return lOurToken_put;
    }

    public void setlOurToken_put(String lOurToken_put) {
        this.lOurToken_put = lOurToken_put;
    }

    public String getlOpenInterest_put() {
        return lOpenInterest_put;
    }

    public void setlOpenInterest_put(String lOpenInterest_put) {
        this.lOpenInterest_put = lOpenInterest_put;
    }

    public String getlPrevOpenInterest_put() {
        return lPrevOpenInterest_put;
    }

    public void setlPrevOpenInterest_put(String lPrevOpenInterest_put) {
        this.lPrevOpenInterest_put = lPrevOpenInterest_put;
    }

    public String getlVolume_put() {
        return lVolume_put;
    }

    public void setlVolume_put(String lVolume_put) {
        this.lVolume_put = lVolume_put;
    }

    public String getdLtp_put() {
        return dLtp_put;
    }

    public void setdLtp_put(String dLtp_put) {
        this.dLtp_put = dLtp_put;
    }

    public String getdNetChange_put() {
        return dNetChange_put;
    }

    public void setdNetChange_put(String dNetChange_put) {
        this.dNetChange_put = dNetChange_put;
    }

    public String getlBidQty_put() {
        return lBidQty_put;
    }

    public void setlBidQty_put(String lBidQty_put) {
        this.lBidQty_put = lBidQty_put;
    }

    public String getlBidPrice_put() {
        return lBidPrice_put;
    }

    public void setlBidPrice_put(String lBidPrice_put) {
        this.lBidPrice_put = lBidPrice_put;
    }

    public String getlAskQty_put() {
        return lAskQty_put;
    }

    public void setlAskQty_put(String lAskQty_put) {
        this.lAskQty_put = lAskQty_put;
    }

    public String getAskPrice_put() {
        return AskPrice_put;
    }

    public void setAskPrice_put(String askPrice_put) {
        AskPrice_put = askPrice_put;
    }

    public String getlClosingPrice_put() {
        return lClosingPrice_put;
    }

    public void setlClosingPrice_put(String lClosingPrice_put) {
        this.lClosingPrice_put = lClosingPrice_put;
    }

    public String getCallput_put() {
        return callput_put;
    }

    public void setCallput_put(String callput_put) {
        this.callput_put = callput_put;
    }

    public String getStrike() {
        return strike;
    }

    public void setStrike(String strike) {
        this.strike = strike;
    }
}

