package com.acumengroup.mobile.model;

/**
 * Created by srv_admin on 9/12/2015.
 */
public class GlobalMarketModel {
    private String name;
    private String date;
    private String close;
    private String change;
    private String perChange;
    private String country;

    public GlobalMarketModel(String name, String date, String close, String change, String perChange, String country) {
        this.name = name;
        this.date = date;
        this.close = close;
        this.change = change;
        this.perChange = perChange;
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClose() {
        return close;
    }

    public void setClose(String close) {
        this.close = close;
    }

    public String getChange() {
        return change;
    }

    public void setChange(String change) {
        this.change = change;
    }

    public String getPerChange() {
        return perChange;
    }

    public void setPerChange(String perChange) {
        this.perChange = perChange;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
