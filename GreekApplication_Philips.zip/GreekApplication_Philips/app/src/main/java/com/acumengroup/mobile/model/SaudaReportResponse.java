package com.acumengroup.mobile.model;

import com.acumengroup.core.model.GreekRequestModel;
import com.acumengroup.core.model.GreekResponseModel;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SaudaReportResponse implements GreekRequestModel, GreekResponseModel {
    private List<Data> saudaResponse = new ArrayList();


    public List<Data> getSaudaResponse() {
        return saudaResponse;
    }

    public void setSaudaResponse(List<Data> saudaResponse) {
        this.saudaResponse = saudaResponse;
    }


    @Override
    public JSONObject toJSONObject() throws JSONException {
        JSONObject jo = new JSONObject();


        JSONArray ja1 = new JSONArray();
        Iterator iterator = this.saudaResponse.iterator();
        while (iterator.hasNext()) {
            Object o = iterator.next();
            if ((o instanceof GreekRequestModel)) {
                ja1.put(((GreekRequestModel) o).toJSONObject());
            } else {
                ja1.put(o);
            }
        }
        return  jo;
    }

    @Override
    public GreekResponseModel fromJSON(JSONObject jo) throws JSONException {

        if(jo.optJSONArray("data") !=null) {
            JSONArray ja1 = jo.getJSONArray("data");
            this.saudaResponse = new ArrayList(ja1.length());
            for (int i = 0; i < ja1.length(); i++) {
                Object o = ja1.get(i);
                if ((o instanceof JSONObject)) {
                    Data data = new Data();
                    data.fromJSON((JSONObject) o);
                    this.saudaResponse.add(data);
                } else {
                    this.saudaResponse.add((Data) o);
                }
            }
        }


        return this;
    }

}