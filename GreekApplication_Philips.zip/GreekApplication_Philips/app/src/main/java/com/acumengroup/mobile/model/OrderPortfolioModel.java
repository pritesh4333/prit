package com.acumengroup.mobile.model;

/**
 * Created by Arcadia
 */
public class OrderPortfolioModel {
    private String clientCode;
    private String segment;
    private String openOrders;
    private String openOrderValue;
    private String totalOpenOrder;
    private String totalOpenOrderValue;


    public String getTotalOpenOrder() {
        return totalOpenOrder;
    }

    public void setTotalOpenOrder(String totalOpenOrder) {
        this.totalOpenOrder = totalOpenOrder;
    }

    public String getTotalOpenOrderValue() {
        return totalOpenOrderValue;
    }

    public void setTotalOpenOrderValue(String totalOpenOrderValue) {
        this.totalOpenOrderValue = totalOpenOrderValue;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getOpenOrders() {
        return openOrders;
    }

    public void setOpenOrders(String openOrders) {
        this.openOrders = openOrders;
    }

    public String getOpenOrderValue() {
        return openOrderValue;
    }

    public void setOpenOrderValue(String openOrderValue) {
        this.openOrderValue = openOrderValue;
    }
}
