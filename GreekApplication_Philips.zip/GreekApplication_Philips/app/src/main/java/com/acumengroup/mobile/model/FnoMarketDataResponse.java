package com.acumengroup.mobile.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FnoMarketDataResponse {
    private ArrayList<MarketDataModel> futureMarketDataModelList = new ArrayList<>();
//    private List<MarketDataModel> indexMarketDataModelList = new ArrayList<>();
//    private List<MarketDataModel> stockMarketDataModelList = new ArrayList<>();

    public FnoMarketDataResponse() {
    }

    public List<MarketDataModel> getFutureMarketDataModelList() {
        return futureMarketDataModelList;
    }

    public void setFutureMarketDataModelList(ArrayList<MarketDataModel> futureMarketDataModelList) {
        this.futureMarketDataModelList = futureMarketDataModelList;
    }
//
//    public List<MarketDataModel> getIndexMarketDataModelList() {
//        return indexMarketDataModelList;
//    }
//
//    public void setIndexMarketDataModelList(List<MarketDataModel> indexMarketDataModelList) {
//        this.indexMarketDataModelList = indexMarketDataModelList;
//    }
//
//    public List<MarketDataModel> getStockMarketDataModelList() {
//        return stockMarketDataModelList;
//    }
//
//    public void setStockMarketDataModelList(List<MarketDataModel> stockMarketDataModelList) {
//        this.stockMarketDataModelList = stockMarketDataModelList;
//    }

//    public void fromJSON(JSONArray jo) throws JSONException {
//        if (jo.has("future")) {
//            JSONArray ja1 = jo.getJSONArray("future");
//            this.futureMarketDataModelList = new ArrayList(ja1.length());
//
//            for (int i = 0; i < ja1.length(); ++i) {
//                Object o = ja1.get(i);
//                if (o instanceof JSONObject) {
//                    MarketDataModel data = new MarketDataModel();
//                    data.fromJSON((JSONObject) o);
//                    this.futureMarketDataModelList.add(data);
//                } else {
//                    this.futureMarketDataModelList.add((MarketDataModel) o);
//                }
//            }
//        }

//        if (jo.has("option_stock")) {
//            JSONArray ja1 = jo.getJSONArray("option_stock");
//            this.stockMarketDataModelList = new ArrayList(ja1.length());
//
//            for (int i = 0; i < ja1.length(); ++i) {
//                Object o = ja1.get(i);
//                if (o instanceof JSONObject) {
//                    MarketDataModel data = new MarketDataModel();
//                    data.fromJSON((JSONObject) o);
//                    this.stockMarketDataModelList.add(data);
//                } else {
//                    this.stockMarketDataModelList.add((MarketDataModel) o);
//                }
//            }
//        }
//
//        if (jo.has("option_index")) {
//            JSONArray ja1 = jo.getJSONArray("option_index");
//            this.indexMarketDataModelList = new ArrayList(ja1.length());
//
//            for (int i = 0; i < ja1.length(); ++i) {
//                Object o = ja1.get(i);
//                if (o instanceof JSONObject) {
//                    MarketDataModel data = new MarketDataModel();
//                    data.fromJSON((JSONObject) o);
//                    this.indexMarketDataModelList.add(data);
//                } else {
//                    this.indexMarketDataModelList.add((MarketDataModel) o);
//                }
//            }
//        }
//    }
}