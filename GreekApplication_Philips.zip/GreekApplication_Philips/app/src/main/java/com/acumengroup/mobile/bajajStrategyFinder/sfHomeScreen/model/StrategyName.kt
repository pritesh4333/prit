package com.acumengroup.mobile.bajajStrategyFinder.sfHomeScreen.model

data class StrategyName(var StrategyId: String,var StrategyCheck: Boolean,var StrategyName: String)