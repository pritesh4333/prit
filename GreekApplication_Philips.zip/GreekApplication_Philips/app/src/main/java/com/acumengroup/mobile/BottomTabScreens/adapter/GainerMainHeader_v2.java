package com.acumengroup.mobile.BottomTabScreens.adapter;


import com.acumengroup.mobile.model.SubHeader_v2;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.ArrayList;


public class GainerMainHeader_v2 extends ExpandableGroup<SubHeader_v2> {


   private String marketType;
   private ArrayList<SubHeader_v2> childList;

    public GainerMainHeader_v2(ArrayList<SubHeader_v2> items, String marketType) {
        super(marketType,items);
        this.childList=items;

    }

    public String getMarketType() {
        return marketType;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;
    }

    public ArrayList<SubHeader_v2> getChildList() {
        return childList;
    }

    public void setChildList(ArrayList<SubHeader_v2> childList) {
        this.childList = childList;
    }
}
