package com.acumengroup.mobile.reports;


/**
 * Created by Sushant on 9/8/2016.
 */
public abstract class BitWiseComparasion extends OrderBookDetailsFragment{
     short		iAON=(short)1;//1118
     short		iIOC=(short)1;//1192
     short		iGTC=(short)1;//1191
     short		iDay=(short)1;//1190
     short		iMIT=(short)1;//1189
     short		iSL=(short)1;//1188
     short		iMarket=(short)1;//1187
     short		iATO=(short)1;//1186
     short		iFrozen=(short)1;//1198
     short		iModified=(short)1;//1197
     short		iTraded=(short)1;//1196
     short		iMatchedInd=(short)1;//1195
     short		iMF=(short)1;//1194
     short		iPreOpen=(short)1;//1536
}

