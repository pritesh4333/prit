package com.acumengroup.mobile.BottomTabScreens;

import android.view.View;

/**
 * Created by Rohit on 1/5/2018.
 */

public interface ClickListener {

    void onClick(View view, int position);

    void onLongClick(View view, int position);
}
