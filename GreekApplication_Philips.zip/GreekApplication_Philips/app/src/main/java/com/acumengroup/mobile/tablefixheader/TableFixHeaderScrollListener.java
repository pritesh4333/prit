package com.acumengroup.mobile.tablefixheader;

/**
 * Created by Arcadia
 */

public interface TableFixHeaderScrollListener {
    void onTableScrollData(int scrollState, int firstVisibleItem, int totalVisible);
}