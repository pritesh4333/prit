package com.assignment.project.ViewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.assignment.project.Model.DominosList
 import com.assignment.project.Repository.MainRepository
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainViewModel(private val repository: MainRepository) : ViewModel() {

    var dataList = MutableLiveData<DominosList>()
    val errorMessage = MutableLiveData<String>()

    fun getAllMovies(s: String, s1: String, s2: String, s3: String, s4: String) {
        val response = repository.getDominosList(s,s1,s2,s3,s4)
            .enqueue(object :Callback<DominosList>
            {
                override fun onResponse(call: Call<DominosList>, response: Response<DominosList>) {
                    Log.e("response sucess", Gson().toJson(response.body()))
//                    movieList=MutableLiveData<sample1>();
                    dataList.value =response.body();

                }
                override fun onFailure(call: Call<DominosList>, t: Throwable) {
                    Log.e("response Fail",t.message.toString())
                    errorMessage.value=t.message.toString()
                }
            }
            )

    }

}