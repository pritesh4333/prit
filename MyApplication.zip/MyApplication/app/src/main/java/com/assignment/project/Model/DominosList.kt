package com.assignment.project.Model

data class DominosList(
    val businesses: Array<Businesses>,
    val region: Region,
    val total: Number
)

data class Region(val center: Center)

data class Businesses(
    val alias: String,
    val categories: Array<Categories>,
    val coordinates: Coordinates,
    val display_phone: String,
    val distance: Number,
    val id: String,
    val image_url: String,
    val is_closed: Boolean,
    val location: Location,
    val name: String,
    val phone: String,
    val price: String,
    val rating: Number,
    val review_count: Number,
    val transactions: Array<String>,
    val url: String
)

data class Center(val latitude: Number, val longitude: Number)

data class Coordinates(val latitude: Number, val longitude: Number)

data class Location(
    val address1: String,
    val address2: String,
    val address3: String,
    val city: String,
    val country: String,
    val display_address: Array<String>,
    val state: String,
    val zip_code: String
)

data class Categories(val alias: String, val title: String)