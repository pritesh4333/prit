package com.assignment.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


import android.util.Log
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.assignment.project.Adpter.MainAdapter
import com.assignment.project.Model.DominosList
 import com.assignment.project.Network.RetrofitService
import com.assignment.project.Repository.MainRepository
import com.assignment.project.ViewModel.MainViewModel
import com.assignment.project.ViewModel.MyViewModelFactory
import com.assignment.project.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    private lateinit var binding: ActivityMainBinding

    lateinit var viewModel: MainViewModel

    private val retrofitService = RetrofitService.getInstance()
    val adapter = MainAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //get viewmodel instance using MyViewModelFactory
        viewModel =
            ViewModelProvider(this, MyViewModelFactory(MainRepository(retrofitService))).get(
                MainViewModel::class.java
            )

        binding.seekBar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar,
                                           progress: Int, fromUser: Boolean) {
                // write custom code for progress is changed
            }

            override fun onStartTrackingTouch(seek: SeekBar) {
                // write custom code for progress is started
            }

            override fun onStopTrackingTouch(seek: SeekBar) {
                // write custom code for progress is stopped
//                Toast.makeText(this@MainActivity,
//                    "Progress is: " + seek.progress + "%",
//                    Toast.LENGTH_SHORT).show()
                binding.progressBar.visibility=View.VISIBLE
                binding.emptyView.visibility= View.GONE
                binding.recyclerview.visibility= View.GONE
                viewModel.getAllMovies("restaurants","NYC",seek.progress.toString(),"distance","15")
            }
        })

        //set recyclerview adapter

        viewModel.dataList.observe(this, Observer {

            Log.d(TAG, "movieList: $it")

            if( it==null ){
                binding.emptyView.visibility= View.VISIBLE

            }else {
                var samplelist: DominosList = it;
                if ( samplelist.businesses.isEmpty()) {
                    binding.progressBar.visibility = View.GONE
                    binding.emptyView.visibility = View.VISIBLE

                } else {
                    binding.progressBar.visibility = View.GONE
                    binding.emptyView.visibility = View.GONE
                    binding.recyclerview.visibility = View.VISIBLE
                    binding.recyclerview.adapter = adapter
                    adapter.setMovieList(it)
                }
            }

        })

        viewModel.errorMessage.observe(this, Observer {
            Log.d(TAG, "errorMessage: $it")
        })
        binding.progressBar.visibility=View.VISIBLE
        binding.emptyView.visibility= View.GONE
        binding.recyclerview.visibility= View.GONE
        viewModel.getAllMovies("restaurants","NYC","500","distance","15")
    }
}