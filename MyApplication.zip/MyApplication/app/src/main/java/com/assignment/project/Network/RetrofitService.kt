package com.assignment.project.Network

import com.assignment.project.Model.DominosList
 import okhttp3.Interceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response


interface RetrofitService {

    @GET("/v3/businesses/search?")
    fun getDominosList(@Query("term") s: String,@Query("location")  s1: String, @Query("radius")
    s2: String,@Query("sort_by") s3: String,@Query("limit") s4: String): Call<DominosList>

    companion object {

        var retrofitService: RetrofitService? = null

        var client = OkHttpClient.Builder().addInterceptor(object : Interceptor {
            override fun intercept(chain: Interceptor.Chain): Response? {
                val newRequest: Request = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer XPFgzKwZGK1yqRxHi0d5xsARFOLpXIvccQj5jekqTnysweGyoIfVUHcH2tPfGq5Oc9kwKHPkcOjk2d1Xobn7aTjOFeop8x41IUfVvg2Y27KiINjYPADcE7Qza0RkX3Yx")
                    .build()
                return chain.proceed(newRequest)
            }
        }).build()

        //Create the Retrofit service instance using the retrofit.
        fun getInstance(): RetrofitService {

            if (retrofitService == null) {
                val retrofit = Retrofit.Builder()
                    .client(client)
                    .baseUrl("https://api.yelp.com")
                    .addConverterFactory(GsonConverterFactory.create())

                    .build()

                retrofitService = retrofit.create(RetrofitService::class.java)

            }
            return retrofitService!!
        }
    }
}