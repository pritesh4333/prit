package com.assignment.project.Adpter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.assignment.project.Model.DominosList
 import com.assignment.project.R
import com.bumptech.glide.Glide
import com.assignment.project.databinding.LayoutRvItemBinding;
import kotlinx.android.synthetic.main.layout_rv_item.view.*
 import kotlin.math.log

class MainAdapter : RecyclerView.Adapter<MainViewHolder>() {
    private lateinit var datalist: DominosList;

    fun setMovieList(it: DominosList) {
        this.datalist=it
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        val binding = LayoutRvItemBinding.inflate(inflater, parent, false)
        return MainViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val List = datalist
        holder.binding.movieTitle.text = List.businesses[position].name
        if(List.businesses[position].is_closed){
            holder.binding.currenlyStatus.text ="Currently Open"
            holder.binding.currenlyStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.green));

        }else{
            holder.binding.currenlyStatus.text ="Currently Close"
            holder.binding.currenlyStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.red));


        }
        holder.binding.ratting.text = List.businesses[position].rating.toString()
        val double1: Double? = List.businesses[position].distance.toDouble()
        holder.binding.state.text = double1.toString().substringBefore(".") +"m " +List.businesses[position].location.display_address[0]
        Glide.with(holder.itemView.context).load(List.businesses.get(position).image_url).placeholder(R.drawable.ic_launcher_background)
            .into(holder.binding.moviePoster)


    }

    override fun getItemCount(): Int {

        return this.datalist.businesses.size


    }


}

class MainViewHolder(val binding: LayoutRvItemBinding) : RecyclerView.ViewHolder(binding.root) {}