
import 'dart:html';

void openNewTab(String url){
  window.open(url, "_blank");
}