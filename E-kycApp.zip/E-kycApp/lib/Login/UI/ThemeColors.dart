import 'package:flutter/cupertino.dart';



// class ThemeColors2 {
//   static const kButtonBackgroundColor = Color(0xFF242525);
//   static const kDarkHeader = Color(0xFF333333);
//   static const kTextColorBlack = Color(0xFF333333);
//   static const kBlueTextColor = Color(0xFF0066CC);
//   static const kHintTextColor = Color(0xFF9B9B9B);
//   static const black = Color(0xFF000000);
//   static const yellow = Color(0xFFFAB804);
//   static const white = Color(0xFFFFFFFF);
//   static const kButtonBackgroundColor2 = Color(0XFFCCCCCC);
//   static const kSpinnerBackgroundColor = Color(0XFFEBEBEB);
//   static const kMenuSelectionBackgroundColor = Color(0XFF4d9ed6);
//   static var red = 0XFFff0000;
// }
