
var express = require('express');
var http = require('http');
var bodyParser = require('body-parser');
var async = require("async");
var fs = require("fs");
var dal = require('./router/dal');
var config = require("./router/config");
var https = require('https');
var configString = config.loadconfigFile();
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


var router = express.Router();
app.use('/', router);

app.use(function (req, res, next) {
    res.setHeader('Access-control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS,PUT,PATCH,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);

    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    //res.header('Access-Control-Allow-Methods','GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});



app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);
app.use(express.static('public'));

require('./router/main')(app);

//console.log(iniString);
//console.log( " *************** Creating Secure server *****************");
if (configString.isSecure == "true") {
    // var keyData, certData, ca1Data, ca2Data;

    // try {
    //     keyData = fs.readFileSync(configString.ssl_key_Path, 'utf8');
    // }
    // catch (err) {
    //     console.log("Key File Not Found : " + err);
    // }

    // try {
    //     certData = fs.readFileSync(configString.ssl_cert_Path, 'utf8');
    // }
    // catch (err1) {
    //     console.log("Certificate Key file not Found " + err1);
    // }

    // try {
    //     ca1Data = fs.readFileSync(configString.intermediate_one_path);
    // }
    // catch (err2) {
    //     console.log("Intermediate1 file not Found " + err2);
    // }

    // try {
    //     ca2Data = fs.readFileSync(configString.intermediate_two_path);
    // }
    // catch (err3) {
    //     console.log("Intermediate1 file not Found " + err3);
    // }

    var https_options = {

        key: fs.readFileSync(configString.ssl_key),

        cert: fs.readFileSync(configString.ssl_cert_Path),


    };
    https.createServer(https_options, app).listen((configString.port == "undefined" || configString.port == "") ? 3000 : configString.port, function (err) {
        if (err) {
            console.log("******************************************************************");
            console.log("Error Creating Server : " + err);
            console.log("******************************************************************");
        }
        else {
            var port = (configString.port == "undefined" || configString.port == "") ? "3000" : configString.port;
            console.log("******************************************************************");
            console.log("Secure(https) Server Started on PORT : " + port);
            console.log("******************************************************************");
            dal.createEkycTable(function (err, rows) {

                console.log("create table reponse" + err);
            });
        }
    });
} else {
    app.listen(configString.port, function (err) {
        if (err) {
            console.log("******************************************************************");
            console.log("Error Creating Server : " + err);
            console.log("******************************************************************");
        }
        else {

            console.log("******************************************************************");
            console.log("Server Started on PORT : " + configString.port);
            console.log("******************************************************************");
            dal.createEkycTable(function (err, rows) {

                console.log("create table reponse" + err);
            });
        }

    });
}