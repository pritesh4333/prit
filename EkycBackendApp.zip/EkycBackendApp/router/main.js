var dal = require('./dal');
var util = require('util');
const multer = require('multer');
const path = require('path');
var fs = require("fs");
var config = require("./config");
var configString = config.loadconfigFile();
const { Console } = require('console');


var storagePath = configString.storagePath;

module.exports = function (app) {


    app.get("/index.html", function (req, res) {
        res.render('index.html');
    });
    app.get("/RetunResponsePage.html", function (req, res) {
        res.render('RetunResponsePage.html');
    });
    app.get("/RetunResponsePageFail.html", function (req, res) {
        res.render('RetunResponsePageFail.html');
    });

    app.get("/", function (req, res) {
        res.render('index.html');
    });

    app.get("/pdfMerger", function (req, res) {
        console.log("****** Request Called pdfMerger GET *******");
        var bank_proof = req.query.bank_proof;
        var income_proof = req.query.income_proof;
        var pan = req.query.pan;

        dal.pdfmerger(bank_proof, income_proof, pan, storagePath, function (err, rows) {
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });

    });

    app.get("/getTokenDetails", function (req, res) {
        console.log("****** Request Called getTokenDetails GET *******");
        var token = req.query.token;
        dal.getContractsInfo(token, function (err, rows) {
            if (err == 0)
                res.end(JSON.stringify(rows));
            else
                res.end("Error Occured ");
        });

    });

    app.post("/postTokenDetails", function (req, res) {
        console.log("****** Request Called postTokenDetails POST TOEKM *******");
        console.log(util.inspect(req.body));
        var token = req.body.token;


        dal.getContractsInfo(token, function (err, rows) {
            res.end(JSON.stringify(rows));
        });
    });

    app.get("/getEkycUserDetails", function (req, res) {

        console.log("****** Request Called getEkycUserDetails GET *******");
        var email_id = req.query.email_id;
        var mobile_no = req.query.mobile_no;
        var full_name = req.query.full_name;
        dal.getEkycUserDetails(email_id, mobile_no, function (err, rows) {
            console.log(rows + ' EKYC ERROR CODE ' + err);

            var obj;
            if (err == 0) {

                obj = responseUserDetailsModelObject("0", rows);
            } else if (err == 1) {
                obj = responseUserDetailsModelObject("1", rows);
                dal.insertUsersData(email_id, mobile_no, full_name, function (err, rows) {

                });
            } else if (err == 2) {
                obj = responseUserDetailsModelObject("2", rows);
                dal.insertUsersData(email_id, mobile_no, full_name, function (err, rows) {

                });
            }
            else if (err == 3) {
                obj = responseUserDetailsModelObject("3", rows);
                dal.insertUsersData(email_id, mobile_no, full_name, function (err, rows) {

                });
            }
            res.setHeader("Content-Type", "application/json");
            console.log(JSON.stringify(obj));
            res.end(JSON.stringify(obj));

        });

    });

    app.post("/SaveEkycLoginDetails", function (req, res) {
        console.log("****** Request Called SaveEkycLoginDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var full_name = datat1.full_name;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;
        var client_code = datat1.client_code;
        var mobile_otp = datat1.mobile_otp;
        var email_otp = datat1.email_otp;

        dal.saveEkycLoginDetails(full_name, email_id, mobile_no, client_code, mobile_otp, email_otp, function (err, rows) {
            var obj;
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });

    app.post("/SavePanDetails", function (req, res) {
        console.log("****** Request Called SavePanDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;
        var pan = datat1.pan;
        var panfullname = datat1.panfullname;
        var dob = datat1.dob;


        dal.SavePanDetails(email_id, mobile_no, pan, panfullname, dob, function (err, rows) {


            /// 0 means success 3 means  no data 
            var obj;
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "INVALID PAN NUMBER");
            } else if (err == 2) {

                obj = responseModelObject("2", "INVALID PAN NAME");

            } else if (err == 3) {

                obj = responseModelObject("3", "INVALID PAN DOB");

            }
            else if (err == 4) {

                obj = responseModelObject("4", "NO DATA FOUND");

            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });

    app.post("/SaveBankDetails", function (req, res) {
        console.log("****** Request Called SaveBankDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;
        var ifsccode = datat1.ifsccode;
        var accountnumber = datat1.accountnumber;
        var bankname = datat1.bankname;



        dal.SaveBankDetails(email_id, mobile_no, ifsccode, accountnumber, bankname, function (err, rows) {



            if (rows != null && err != 0) {
                if (err != 2) {
                    var objData = JSON.parse(rows);
                }
            }


            var obj;
            if (err == 0) {

                obj = responseBankDetailsObject("0", "success", "", "", "");
            } else if (err == 1) {

                obj = responseBankDetailsObject("1", "failed", objData.details, objData.code, objData.message);
            } else if (err == 2) {

                obj = responseBankDetailsObject("2", "Please try again", rows.details, rows.code, rows.message);
            }

            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });

    app.post("/saveEKYCPersonalDetails", function (req, res) {
        console.log("****** Request Called saveEKYCPersonalDetails POST *******");

        console.log(req.body);
        var data1 = req.body.data;
        var email_id = data1.email_id;
        var mobile_no = data1.mobile_no;
        var nseCash = data1.nse_cash;
        var nsefo = data1.nse_fo;
        var nseCurrency = data1.nse_currency;
        var bseCash = data1.bse_cash;
        var bsefo = data1.bse_fo;
        var bseCurrency = data1.bse_currency;
        var mcxCommodity = data1.mcx_commodity;
        var ncdexCommodity = data1.ncdex_commodity;
        var res_addr_1 = data1.res_addr_1;
        var res_addr_2 = data1.res_addr_2;
        var res_addr_state = data1.res_addr_state;
        var res_addr_city = data1.res_addr_city;
        var res_addr_pincode = data1.res_addr_pincode;
        var parm_addr_1 = data1.parm_addr_1;
        var parm_addr_2 = data1.parm_addr_2;
        var parm_addr_state = data1.parm_addr_state;
        var parm_addr_city = data1.parm_addr_city;
        var parm_addr_pincode = data1.parm_addr_pincode;
        var nationality = data1.nationality;
        var gender = data1.gender;
        var firstname1 = data1.firstname1;
        var middlename1 = data1.middlename1;
        var lastname1 = data1.lastname1;
        var maritalstatus = data1.maritalstatus;
        var fatherspouse = data1.fatherspouse;
        var firstname2 = data1.firstname2;
        var middlename2 = data1.middlename2;
        var lastname2 = data1.lastname2;
        var incomerange = data1.incomerange;
        var occupation = data1.occupation;
        var action = data1.action;
        var perextra1 = data1.perextra1;
        var perextra2 = data1.perextra2;

        dal.saveEKYCPersonalDetails(email_id, mobile_no, nseCash,
            nsefo,
            nseCurrency,
            bseCash,
            bsefo,
            bseCurrency,
            mcxCommodity,
            ncdexCommodity,
            res_addr_1,
            res_addr_2,
            res_addr_state,
            res_addr_city,
            res_addr_pincode,
            parm_addr_1,
            parm_addr_2,
            parm_addr_state,
            parm_addr_city,
            parm_addr_pincode,
            nationality,
            gender,
            firstname1,
            middlename1,
            lastname1,
            maritalstatus,
            fatherspouse,
            firstname2,
            middlename2,
            lastname2,
            incomerange,
            occupation,
            action,
            perextra1,
            perextra2,
            function (err, rows) {
                var obj;
                if (err == 0) {

                    obj = responseModelObject("0", "success");
                } else if (err == 1) {

                    obj = responseModelObject("1", "failed");
                }
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));
            }
        );

    });

    app.post("/SavePaymentDetails", function (req, res) {
        console.log("****** Request Called SavePaymentDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;
        var pack = datat1.pack;




        dal.SavePaymentDetails(email_id, mobile_no, pack, function (err, rows) {
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });

    app.post("/SaveDocumentDetails", function (req, res) {
        console.log("****** Request Called SaveDocumentDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;

        dal.SaveDocumDetails(email_id, mobile_no, function (err, rows) {
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });

    app.post("/SaveIpvDetails", function (req, res) {
        console.log("****** Request Called SaveIpvDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;

        dal.SaveIpvDetails(email_id, mobile_no, function (err, rows) {
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });

    app.post("/SaveEsignDetails", function (req, res) {
        console.log("****** Request Called SaveEsignDetails POST *******");

        console.log(req.body);
        var datat1 = req.body.data;
        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;
        var esign = datat1.esign;

        dal.SaveEsignDetails(email_id, mobile_no, esign, function (err, rows) {
            if (err == 0) {

                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });
    });
    app.post("/SendEmailOtp", function (req, res) {
        console.log("****** Request Called SendEmailOtp POST *******");

        console.log(req.body);
        var datat1 = req.body.data;

        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;


        dal.SendEmailOtp(email_id, mobile_no, function (err, email_otp) {
            console.log(err);

            if (err == 0) {



                console.log("Email OTP Send and OTP is :-" + email_otp);
                obj = responseModelObject("0", "" + email_otp);
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));


            } else {

                obj = responseModelObject("1", "failed");
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));
            }

        });
    });
    app.post("/SendMobileOtp", function (req, res) {
        console.log("****** Request Called SendMobileOtp POST *******");

        console.log(req.body);
        var datat1 = req.body.data;

        var email_id = datat1.email_id;
        var mobile_no = datat1.mobile_no;


        dal.SendMobileOtp(email_id, mobile_no, function (err, mobile_otp) {

            if (err == 0) {



                console.log("Mobile OTP Send and OTP is :-" + mobile_otp);
                obj = responseModelObject("0", "" + mobile_otp);
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));


            } else {

                obj = responseModelObject("1", "failed");
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));
            }

        });
    });

    const imageStorage = multer.diskStorage({
        // Destination to store image     
        destination: storagePath,
        filename: (req, file, cb) => {

            cb(null, req.body.imageName + req.body.extension)
            // file.fieldname is name of the field (image)
            // path.extname get the uploaded file extension
        }
    });
    const pdfStorage = multer.diskStorage({
        // Destination to store image     
        destination: storagePath,
        filename: (req, file, cb) => {

            cb(null, req.body.imageName + ".pdf")
            // file.fieldname is name of the field (image)
            // path.extname get the uploaded file extension
        }
    });
    const imageUpload = multer({
        storage: imageStorage,
        // limits: {
        //     fileSize: 10000000 // 1000000 Bytes = 1 MB
        // },
        fileFilter(req, file, cb) {
            console.log("body print " + req.body.imageName);
            if (!file.originalname.match(/\.(png|jpg|jpeg|PNG|JPG|JPEG|pdf)$/)) {
                // upload only png and jpg format
                return cb(new Error('Please upload a Image'))
            }
            cb(undefined, true)
        }
    })
    const pdfUpload = multer({
        storage: pdfStorage,

        fileFilter(req, file, cb) {
            console.log("body print " + req.body.imageName);
            if (!file.originalname.match(/\.(png|jpg|jpeg|PNG|JPG|JPEG|pdf|PDF)$/)) {
                // upload only png and jpg format
                return cb(new Error('Please upload a PDF'))
            }
            cb(undefined, true)
        }
    })
    // For Single image upload
    app.post('/uploadDocuments', imageUpload.single('image_path'), (req, res) => {

        console.log(req.body);
        var email_id = req.body.email_id;
        var mobile_no = req.body.mobile_no;
        var type = req.body.type;
        var prooftype = req.body.prooftype;
        var imageName = req.body.imageName;
        var extension = req.body.extension;
        var imagePath = imageName + extension;



        dal.SaveDocumentDetails(email_id, mobile_no, type, imageName, imagePath, prooftype, function (err, rows) {
            if (err == 0) {
                //res.send(req.file)
                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });



    }, (error, req, res, next) => {
        res.status(400).send({ error: error.message })
    })
    app.post('/uploadpdfFile', pdfUpload.single('pdf_path'), (req, res) => {

        console.log(req.body);
        var email_id = req.body.email_id;
        var mobile_no = req.body.mobile_no;
        var name = req.body.name;
        var imageName = req.body.imageName;
        var imagePath = storagePath + "/" + imageName + ".pdf";



        dal.pdfupload(email_id, mobile_no, imagePath, name, function (err, response) {


            /// 0 means success 3 means  no data 
            var obj;
            if (err == 0) {

                obj = response;
            } else if (err == 1) {
                obj = response;

            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });



    }, (error, req, res, next) => {
        res.status(400).send({ error: error.message })
    })
    app.post('/uploadKYCPdFFile', pdfUpload.single('pdf_path'), (req, res) => {

        console.log(req.body);
        var email_id = req.body.email_id;
        var mobile_no = req.body.mobile_no;
        var imageName = req.body.imageName;
        var imagePath = storagePath + "/" + imageName + ".pdf";



        dal.SaveKycPDfFilePath(email_id, mobile_no, imagePath, function (err, response) {


            /// 0 means success 3 means  no data 
            var obj;
            if (err == 0) {
                //res.send(req.file)
                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });



    }, (error, req, res, next) => {
        res.status(400).send({ error: error.message })
    })
    app.get("/digioReturResponse", function (req, res) {
        console.log("************ digioReturResponse **************");
        //res.render('/about.html');

        //     if (req.query.status == 'success' || req.query.status == 'SUCCESS'
        //     && req.query.message == 'Signing Success' || req.query.message == 'SIGNING SUCCESS' 
        //     && req.query.message == 'Signed Successfully' || req.query.message == 'SIGNED SCUCCESSFULLY' ) {
        //     console.log("************ digioReturResponse  SUCCESS**************");
        //     dal.digioReturResponse("success", req.query.emailId, function (err, rows) {
        //         if (err == 0)
        //             res.render('RetunResponsePage.html');
        //         else {

        //             res.render('RetunResponsePageFail.html');
        //         }
        //     });

        // } else {
        //     console.log("************ digioReturResponse  Failed**************");
        //     res.render('RetunResponsePageFail.html');
        // }
        if (req.query.message == 'Signing Success' || req.query.message == 'SIGNING SUCCESS'
            || req.query.message == 'Signed Successfully' || req.query.message == 'SIGNED SCUCCESSFULLY') {
            console.log("************ digioReturResponse  SUCCESS**************");
            dal.digioReturResponse("success", req.query.emailId, function (err, rows) {
                if (err == 0)
                    res.render('RetunResponsePage.html');
                else {

                    res.render('RetunResponsePageFail.html');
                }
            });

        } else {
            console.log("************ digioReturResponse  Failed**************");
            res.render('RetunResponsePageFail.html');
        }

    });
    // For multiple image upload
    app.post('/uploadBulkImage', imageUpload.array('images', 4), (req, res) => {
        res.send(req.files)
    }, (error, req, res, next) => {
        res.status(400).send({ error: error.message })
    })
    // video upload 
    const videoStorage = multer.diskStorage({
        // Destination to store image     
        destination: storagePath,

        filename: (req, file, cb) => {
            console.log("ipv body print " + req.body.imageName);
            cb(null, req.body.imageName + ".mp4")
            // file.fieldname is name of the field (image)
            // path.extname get the uploaded file extension
        }
    });
    const videoUpload = multer({
        storage: videoStorage,

        fileFilter(req, file, cb) {
            // upload only mp4 and mkv format
            if (!file.originalname.match(/\.(mp4|MPEG-4|mkv)$/)) {
                return cb(new Error('Please upload a video'))
            }
            cb(undefined, true)
        }
    })
    app.post('/uploadIpvVideo', videoUpload.single('video'), (req, res) => {
        console.log("********************* uploadIpvVideo **********************");

        console.log(req.body);
        var email_id = req.body.email_id;
        var mobile_no = req.body.mobile_no;
        var imageName = req.body.imageName;
        var imagePath = storagePath + "/" + imageName + ".mp4";



        dal.SaveIpvDetails(email_id, mobile_no, imageName, function (err, rows) {
            if (err == 0) {
                //res.send(req.file)uploadIpvVideo
                obj = responseModelObject("0", "success");
            } else if (err == 1) {

                obj = responseModelObject("1", "failed");
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        });

    }, (error, req, res, next) => {
        console.log("error.message :- " + error.message);
        res.status(400).send({ error: error.message })
    })

    // get image 

    app.get("/viewDocuments", function (req, res) {

        console.log("********************* viewDocuments **********************");


        var email_id = req.query.email_id;
        var mobile_no = req.query.mobile_no;
        var type = req.query.type;



        dal.getDocuments(email_id, mobile_no, type, function (err, rows) {
            var rowsdata;
            if (type == "pancard") {
                rowsdata = rows[0].pancard;
            } else if (type == "signature") {
                rowsdata = rows[0].signature;
            } else if (type == "bankproof") {
                rowsdata = rows[0].bankproof;
            } else if (type == "addressproof") {
                rowsdata = rows[0].addressproof;
            } else if (type == "incomeproof") {
                rowsdata = rows[0].incomeproof;
            } else if (type == "photograph") {
                rowsdata = rows[0].photograph;
            }
            var obj;
            if (err == 0) {

                fs.readFile(rowsdata, function (err, data) {

                    if (!err) {
                        res.contentType("image/png");
                        res.send(data);
                    }
                    else {
                        fs.readFile(storagePath + "/" + rowsdata, function (err1, data1) {
                            res.contentType("image/png");
                            res.send(data1);
                        });
                    }

                });
                //obj = responseModelObject("0", rows[0].pancard);
            } else if (err == 1) {
                console.log("error send image");
                obj = responseModelObject("1", "failed");
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));
            }

        });



    });

    // get Video  

    app.get("/downloadFileVideo", function (req, res) {

        console.log("********************* downloadFileVideo **********************");

        fs.readFile(storagePath + req.query.videopath, function (err, data) {
            console.log(err);
            if (!err) {
                res.contentType("video/mp4");
                res.send(data);
            }
            else {
                console.log("loaction++" + storagePath + "/" + req.query.videopath + ".mp4");
                fs.readFile(storagePath + req.query.videopath + ".mp4", function (err1, data1) {
                    res.contentType("video/mp4");
                    res.send(data1);
                });
                // const path = destination + req.query.videopath + ".mp4";
                // fs.stat(path, (err, stat) => {

                //     // Handle file not found
                //     if (err !== null && err.code === 'ENOENT') {
                //         res.sendStatus(404);
                //     }

                //     const fileSize = stat.size
                //     const range = req.headers.range

                //     if (range) {

                //         const parts = range.replace(/bytes=/, "").split("-");

                //         const start = parseInt(parts[0], 10);
                //         const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

                //         const chunksize = (end - start) + 1;
                //         const file = fs.createReadStream(path, { start, end });
                //         const head = {
                //             'Content-Range': `bytes ${start}-${end}/${fileSize}`,
                //             'Accept-Ranges': 'bytes',
                //             'Content-Length': chunksize,
                //             'Content-Type': 'video/mp4',
                //         }

                //         res.writeHead(206, head);
                //         file.pipe(res);
                //     } else {
                //         const head = {
                //             'Content-Length': fileSize,
                //             'Content-Type': 'video/mp4',
                //         }

                //         res.writeHead(200, head);
                //         fs.createReadStream(path).pipe(res);
                //     }
                // });

            }

        });
    });



    function responseModelObject(err, message) {
        var obj = {
            "response": {
                "error_code": err,
                "data": {
                    "message": message
                }
            }
        };
        return obj;
    }

    function responseUserDetailsModelObject(err, message) {
        var obj;
        if (err != 0) {
            obj = {
                response: {
                    error_code: err,
                    data: {
                        message: [
                            {
                                unique_id: "",
                                stage: "",
                                full_name: "",
                                email_id: "",
                                mobile_no: "",
                                client_code: "",
                                mobile_otp: "",
                                email_otp: "",
                                lextra1: "",
                                lextra2: "",
                                pan: "",
                                panfullname: "",
                                dob: "",
                                pextra1: "",
                                pextra2: "",
                                nse_cash: "",
                                nse_fo: "",
                                nse_currency: "",
                                mcx_commodty: "",
                                bse_cash: "",
                                bse_fo: "",
                                bse_currency: "",
                                ncdex_commodty: "",
                                res_addr_1: "",
                                res_addr_2: "",
                                res_addr_state: "",
                                res_addr_city: "",
                                res_addr_pincode: "",
                                parm_addr_1: "",
                                parm_addr_2: "",
                                parm_addr_state: "",
                                parm_addr_city: "",
                                parm_addr_pincode: "",
                                nationality: "",
                                gender: "",
                                firstname1: "",
                                middlename1: "",
                                lastname1: "",
                                maritalstatus: "",
                                fatherspouse: "",
                                firstname2: "",
                                middlename2: "",
                                lastname2: "",
                                incomerange: "",
                                occupation: "",
                                action: "",
                                perextra1: "",
                                perextra2: "",
                                ifsccode: "",
                                accountnumber: "",
                                bankname: "",
                                verified_id: "",
                                beneficiary_name_with_bank: "",
                                verified_at: "",
                                bextra1: "",
                                bextra2: "",
                                pack: "",
                                payextra1: "",
                                payextra2: "",
                                pancard: "",
                                signature: "",
                                bankproof: "",
                                bankprooftype: "",
                                addressproof: "",
                                addressprooftype: "",
                                incomeproof: "",
                                incomeprooftype: "",
                                photograph: "",
                                uextra1: "",
                                uextra2: "",
                                ipv: "",
                                iextra1: "",
                                iextra2: "",
                                esign: "",
                                esignaddhar: "",
                                ekycdocument: ""
                            }
                        ]
                    }
                }
            };

        } else {
            console.log("inique id " + message[0].unique_id);

            obj = {
                response: {
                    error_code: err,
                    data: {
                        message: [
                            {
                                unique_id: "" + message[0].unique_id,
                                stage: message[0].stage,
                                full_name: message[0].full_name,
                                email_id: message[0].email_id,
                                mobile_no: message[0].mobile_no,
                                client_code: message[0].client_code,
                                mobile_otp: message[0].mobile_otp,
                                email_otp: message[0].email_otp,
                                lextra1: message[0].lextra1,
                                lextra2: message[0].lextra2,
                                pan: message[0].pan,
                                panfullname: message[0].panfullname,
                                dob: message[0].dob,
                                pextra1: message[0].pextra1,
                                pextra2: message[0].pextra2,
                                nse_cash: message[0].nse_cash,
                                nse_fo: message[0].nse_fo,
                                nse_currency: message[0].nse_currency,
                                mcx_commodty: message[0].mcx_commodty,
                                bse_cash: message[0].bse_cash,
                                bse_fo: message[0].bse_fo,
                                bse_currency: message[0].bse_currency,
                                ncdex_commodty: message[0].ncdex_commodty,
                                res_addr_1: message[0].res_addr_1,
                                res_addr_2: message[0].res_addr_2,
                                res_addr_state: message[0].res_addr_state,
                                res_addr_city: message[0].res_addr_city,
                                res_addr_pincode: message[0].res_addr_pincode,
                                parm_addr_1: message[0].parm_addr_1,
                                parm_addr_2: message[0].parm_addr_2,
                                parm_addr_state: message[0].parm_addr_state,
                                parm_addr_city: message[0].parm_addr_city,
                                parm_addr_pincode: message[0].parm_addr_pincode,
                                nationality: message[0].nationality,
                                gender: message[0].gender,
                                firstname1: message[0].firstname1,
                                middlename1: message[0].middlename1,
                                lastname1: message[0].lastname1,
                                maritalstatus: message[0].maritalstatus,
                                fatherspouse: message[0].fatherspouse,
                                firstname2: message[0].firstname2,
                                middlename2: message[0].middlename2,
                                lastname2: message[0].lastname2,
                                incomerange: message[0].incomerange,
                                occupation: message[0].occupation,
                                action: message[0].action,
                                perextra1: message[0].perextra1,
                                perextra2: message[0].perextra2,
                                ifsccode: message[0].ifsccode,
                                accountnumber: message[0].accountnumber,
                                bankname: message[0].bankname,
                                verified_id: message[0].verified_id,
                                beneficiary_name_with_bank: message[0].beneficiary_name_with_bank,
                                verified_at: message[0].verified_at,
                                bextra1: message[0].bextra1,
                                bextra2: message[0].bextra2,
                                pack: message[0].pack,
                                payextra1: message[0].payextra1,
                                payextra2: message[0].payextra2,
                                pancard: message[0].pancard,
                                signature: message[0].signature,
                                bankproof: message[0].bankproof,
                                bankprooftype: message[0].bankprooftype,
                                addressproof: message[0].addressproof,
                                addressprooftype: message[0].addressprooftype,
                                incomeproof: message[0].incomeproof,
                                incomeprooftype: message[0].incomeprooftype,
                                photograph: message[0].photograph,
                                uextra1: message[0].uextra1,
                                uextra2: message[0].uextra2,
                                ipv: message[0].ipv,
                                iextra1: message[0].iextra1,
                                iextra2: message[0].iextra2,
                                esign: message[0].esign,
                                esignaddhar: message[0].esignaddhar,
                                ekycdocument: message[0].ekycdocument
                            }
                        ]
                    }
                }
            };
        }
        return obj;
    }

    function responseBankDetailsObject(err, status, details, code, message) {
        var obj = {
            "response": {
                "error_code": err,
                "data": {
                    "status": status,
                    "details": details,
                    "code": code,
                    "message": message
                }
            }
        };
        return obj;

    }
}