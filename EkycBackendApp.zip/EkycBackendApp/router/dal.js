var nodemailer = require("nodemailer");
var smtpTransport = require("nodemailer-smtp-transport");
var config = require("./config");
var mysql = require('mysql');
var request = require("request");
var myDbString = config.loadMyDBConfig();
var Client = require('node-rest-client').Client;
var crypto = require('crypto');
console.log("IP : " + myDbString.host);
var configString = config.loadconfigFile();
const PDFDocument = require('pdf-lib').PDFDocument
var fs = require("fs");



var digioDevURL = 'https://ext.digio.in:444';
var digioProdURL = 'https://api.digio.in';

var devAuthKey = 'Basic QUlPOE9TTVE3VVFHTFpGQkU0WVJBQ0ZIVE9PS0VQOUI6NDhMR1BYNVpJUFdOVVExRjUyUFNHUUE5V1ZER1FENFI='
var prodAuthKey = 'Basic QUlJVkM0QzQ3MVNBMkM3Qk9aUUxaRUlYTDRRRlQyNzM6SVFKMUFOV1VFUjJFT0Y0WUgzSVpBSDJTMTMyNVVTNE0='

var enviromentKey = prodAuthKey;
var digioURL = digioProdURL;

if (configString.is_production == 'false') {
    digioURL = digioDevURL;
    enviromentKey = devAuthKey;
}

var digioPANVerifyAPIName = digioURL + '/v3/client/kyc/pan/verify';
var digioDocumentUpload = digioURL + '/v2/client/document/upload';
var digioBankVerify = digioURL + '/client/verify/bank_account';

var pool = mysql.createPool({
    connectionLimit: 100,
    host: myDbString.host,//
    user: myDbString.user,//
    password: myDbString.password,//
    database: myDbString.db,//
    debug: false
});

exports.dalResult = dalResult = {
    success: 0,
    connectionError: 1,
    queryError: 2,
    noResult: 3
}

if (pool) { // mysql is started && connected successfully.
    console.log('Connection Success');

} else {
    console.log('Cant connect to db, Check ur db connection');
}

function query(query, func) {
    pool.getConnection(function (err, connection) {
        if (err) {
            // connection.release();
            console.log('SQLITE DB Slave: ERR 1 == ' + err);
            func(dalResult.connectionError, 0);
            return;
        }

        //console.log('connection as id ' + connection.threadid);
        connection.query(query, function (err, rows) {
            //console.getPasswordlog("queried!");
            connection.release();
            if (!err) {
                if (rows.length == 0) {
                    func(dalResult.noResult, 0);
                    return;
                }
                else {
                    //console.log(rows);

                    // process rows (there should be a single row);
                    func(dalResult.success, rows);
                    return;
                }
            }
            else {
                func(dalResult.queryError, 0);// Added By Pravin Pasi for returning query error
                console.log('SQLITE DB Slave: ERR 2 == ' + err);
                return;
            }
        });

        connection.on('error', function (err) {
            connection.release();
            console.log('Error in on error : ' + err);
            console.log('SQLITE DB Slave: ERR 3');
            func(dalResult.connectionError, 0);
            return;
        });
    });
}

function bulkquery(query, myArray, func) {
    console.log("QUERY=" + query);

    pool.getConnection(function (err, connection) {
        if (err) {
            // connection.release();
            console.log('SQLITE DB: ERR 1 == ' + err);
            func(dalResult.connectionError, 0);
            return;
        }
        //console.log('connection as id ' + connection.threadid);
        connection.query(query, [myArray], function (err, rows) {
            //console.getPasswordlog("queried!");
            connection.release();
            if (!err) {
                if (rows.length == 0) {
                    func(dalResult.noResult, 0);
                    return;
                }
                else {
                    func(dalResult.success, rows);
                    return;
                }
            }
            else {
                func(dalResult.queryError, 0);// Added By Pravin Pasi for returning query error
                console.log('SQLITE DB: ERR 2 == ' + err);
                return;
            }
        });

        connection.on('error', function (err) {
            connection.release();
            console.log('Error in on error : ' + err);
            console.log('SQLITE DB: ERR 3');
            func(dalResult.connectionError, 0);
            return;
        });
    });
}
exports.createEkycTable = function (func) {
    query("CREATE TABLE IF NOT EXISTS `ekyc` ( `unique_id` int(11) NOT NULL AUTO_INCREMENT, `stage` varchar(50) NOT NULL, `full_name` varchar(45) NOT NULL, `email_id` varchar(45) NOT NULL, `mobile_no` varchar(45) NOT NULL, `client_code` varchar(45) NOT NULL, `mobile_otp` varchar(45) NOT NULL, `email_otp` varchar(45) NOT NULL, `lextra1` varchar(45) NOT NULL, `lextra2` varchar(45) NOT NULL, `pan` varchar(45) NOT NULL, `panfullname` varchar(45) NOT NULL, `dob` varchar(45) NOT NULL, `pextra1` varchar(45) NOT NULL, `pextra2` varchar(45) NOT NULL, `nse_cash` varchar(45) NOT NULL, `nse_fo` varchar(45) NOT NULL, `nse_currency` varchar(45) NOT NULL, `mcx_commodty` varchar(45) NOT NULL, `bse_cash` varchar(45) NOT NULL, `bse_fo` varchar(45) NOT NULL, `bse_currency` varchar(45) NOT NULL, `ncdex_commodty` varchar(45) NOT NULL, `res_addr_1` varchar(45) NOT NULL, `res_addr_2` varchar(45) NOT NULL, `res_addr_state` varchar(45) NOT NUll, `res_addr_city` varchar(45) NOT NUll, `res_addr_pincode` varchar(45) NOT NUll, `parm_addr_1` varchar(45) NOT NULL, `parm_addr_2` varchar(45) NOT NULL, `parm_addr_state` varchar(45) NOT NUll, `parm_addr_city` varchar(45) NOT NUll, `parm_addr_pincode` varchar(45) NOT NUll, `nationality` varchar(45) NOT NULL, `gender` varchar(45) NOT NULL, `firstname1` varchar(45) NOT NULL, `middlename1` varchar(45) NOT NULL, `lastname1` varchar(45) NOT NULL, `maritalstatus` varchar(45) NOT NULL, `fatherspouse` varchar(45) NOT NULL, `firstname2` varchar(45) NOT NULL, `middlename2` varchar(45) NOT NULL, `lastname2` varchar(45) NOT NULL, `incomerange` varchar(45) NOT NULL, `occupation` varchar(45) NOT NULL, `action` varchar(45) NOT NULL, `perextra1` varchar(45) NOT NULL, `perextra2` varchar(45) NOT NULL, `ifsccode` varchar(45) NOT NULL, `accountnumber` varchar(45) NOT NULL, `bankname` varchar(45) NOT NULL, `verified_id` varchar(45) NOT NULL, `beneficiary_name_with_bank` varchar(45) NOT NULL, `verified_at` varchar(45) NOT NULL, `bextra1` varchar(45) NOT NULL, `bextra2` varchar(45) NOT NULL, `pack` varchar(45) NOT NULL, `payextra1` varchar(45) NOT NULL, `payextra2` varchar(45) NOT NULL, `pancard` varchar(100) NOT NULL, `signature` varchar(100) NOT NULL, `bankproof` varchar(100) NOT NULL, `bankprooftype` varchar(100) NOT NULL, `addressproof` varchar(100) NOT NULL, `addressprooftype` varchar(100) NOT NULL, `incomeproof` varchar(100) NOT NULL, `incomeprooftype` varchar(100) NOT NULL, `photograph` varchar(100) NOT NULL, `uextra1` varchar(45) NOT NULL, `uextra2` varchar(45) NOT NULL, `ipv` varchar(100) NOT NULL, `iextra1` varchar(45) NOT NULL, `iextra2` varchar(45) NOT NULL, `esign` varchar(45) NOT NULL, `esignaddhar` varchar(100) NOT NULL, `ekycdocument` varchar(250) NOT NULL, PRIMARY KEY (`unique_id`,`email_id`,`mobile_no`) USING BTREE ) ENGINE=InnoDB DEFAULT CHARSET=latin1;", func)
}

exports.pdfmerger = async function (bank_proof, income_proof, pan, storagePath, func) {
    console.log('pdfmerger call', 'success');
    //bank proof and income proof pdf file merge start 
    var bank_proof = fs.readFileSync(storagePath + "/" + bank_proof);
    var income_proof = fs.readFileSync(storagePath + "/" + income_proof);

    var pdfsToMerge = [bank_proof, income_proof]

    const mergedPdf = await PDFDocument.create();
    for (const pdfBytes of pdfsToMerge) {
        const pdf = await PDFDocument.load(pdfBytes);
        const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach((page) => {
            mergedPdf.addPage(page);
        });
    }

    const buf = await mergedPdf.save();        // Uint8Array

    let path = storagePath + "/" + pan + 'merge.pdf';
    fs.open(path, 'w', function (err, fd) {
        fs.write(fd, buf, 0, buf.length, null, function (err) {
            fs.close(fd, function () {
                console.log('merge first file successfully');
                megeFialPdf(storagePath, pan, path, func);
            });
        });
    });
    //bank proof and income proof pdf file merge done 


}
async function megeFialPdf(storagePath, pan, path, func) {
    // merge file and kyc docment pdf merge start

    var KycDocument = fs.readFileSync(storagePath + "/" + pan + "KycDocument.pdf");
    var mergepath = fs.readFileSync(path);
    var pdfsToMerges = [KycDocument, mergepath]

    const mergedPdfs = await PDFDocument.create();
    for (const pdfBytes of pdfsToMerges) {
        const pdf = await PDFDocument.load(pdfBytes);
        const copiedPages = await mergedPdfs.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach((page) => {
            mergedPdfs.addPage(page);
        });
    }

    const bufs = await mergedPdfs.save();        // Uint8Array

    let paths = storagePath + "/" + pan + 'FinalEKycDocument.pdf';
    fs.open(paths, 'w', function (err, fd) {
        fs.write(fd, bufs, 0, bufs.length, null, function (err) {
            fs.close(fd, function () {
                console.log('merge second file successfully');
                // removeing merge files
                fs.unlinkSync(storagePath + "/" + pan + "KycDocument.pdf");
                fs.unlinkSync(path);
                func(0, paths);
            });
        });
    });

    // merge file and kyc docment pdf merge Done
}

exports.getContractsInfo = function (token, func) {
    query("Select * from contracts where lourtoken = '" + token + "'", func)
}
exports.digioReturResponse = function (success, email_id, func) {
    console.log('INSIDE EKYC', success, email_id);

    var arr = email_id.split('?');


    query("UPDATE ekyc SET stage = 7, esign = 0 WHERE email_id = '" + arr[0] + "';", func)
}
exports.getEkycUserDetails = function (email_id, mobile_no, func) {
    console.log('INSIDE EKYC');
    query("SELECT * FROM ekyc WHERE email_id='" + email_id + "' and mobile_no='" + mobile_no + "'", func)
}

exports.saveEkycLoginDetails = function (full_name, email_id, mobile_no, client_code, mobile_otp, email_otp, func) {
    console.log('INSIDE EKYC');
    query("SELECT * FROM ekyc WHERE email_id='" + email_id + "' and mobile_no='" + mobile_no + "'", function (err, rows) {

        if (err == 0) {
            if (rows.length > 0) {
                console.log("no need to insert only update");
                query("UPDATE ekyc SET stage = 0, full_name='" + full_name + "', client_code='" + client_code + "', mobile_otp='" + mobile_otp + "', email_otp='" + email_otp + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
            } else {
                query("INSERT INTO ekyc (stage ,full_name, email_id, mobile_no, client_code, mobile_otp, email_otp) VALUES ('0','" + full_name + "', '" + email_id + "'," + mobile_no + "," + client_code + "," + mobile_otp + "," + email_otp + ");", func)
            }
        } else {
            query("INSERT INTO ekyc (stage ,full_name, email_id, mobile_no, client_code, mobile_otp, email_otp) VALUES ('0','" + full_name + "', '" + email_id + "'," + mobile_no + "," + client_code + "," + mobile_otp + "," + email_otp + ");", func)
        }
    });
}

exports.SavePanDetails = function (email_id, mobile_no, pan, panfullname, dob, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, pan, panfullname, dob);


    var Request = require('request');
    var options = {
        'method': 'POST',
        'url': digioPANVerifyAPIName,
        'headers': {
            'Authorization': enviromentKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "pan_no": pan,
            "full_name": panfullname,
            "date_of_birth": dob
        })

    };
    request(options, function (error, response) {
        if (error) {
            console.log("Digio Pan validate error" + error);
            func(4, 0);
        } else {
            console.log("Digio Pan validate" + response.body);
            try {


                var objData = JSON.parse(response.body);

                console.log(objData.is_pan_dob_valid);
                console.log(objData.name_matched);
                var panvalidate = false;

                if (objData.is_pan_dob_valid) {
                    panvalidate = true;

                    if (objData.name_matched) {

                        panvalidate = true;
                    } else if (objData.error_message != null) {

                        console.log("INVLAID " + objData.error_message);
                        func(1, 0);
                    }
                    else {
                        panvalidate = false;
                        console.log("INVALID PAN NAME");
                        func(2, 0);
                    }
                } else {
                    panvalidate = false;
                    console.log("INVALID PAN DOB");
                    func(3, 0);
                }

                if (panvalidate) {
                    console.log("Digio Pan panvalidate true" + response.body);
                    query("UPDATE ekyc SET stage = 1, pan='" + pan + "',panfullname='" + panfullname + "', dob='" + dob + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)

                }
            } catch (e) {
                func(4, 0);
            }

        }
    });


}
exports.SavePDfFilePath = SavePDfFilePath;
function SavePDfFilePath(email_id, mobile_no, pdfpath, name, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, pdfpath, name);
    query("UPDATE ekyc SET esignaddhar = '" + pdfpath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

        if (err == 0) {
            func(0, 0);
        } else {
            func(1, 0);
        }
    });
}

exports.SaveKycPDfFilePath = function (email_id, mobile_no, pdfpath, func) {
    console.log('INSIDE SaveKycPDfFilePath', email_id, mobile_no, pdfpath);
    query("UPDATE ekyc SET ekycdocument = '" + pdfpath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)

}

exports.pdfupload = function (email_id, mobile_no, imagePath, name, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, imagePath, name);

    SavePDfFilePath(email_id, mobile_no, imagePath, name, function (err, rows) {

        if (err == 0) {
            var request = require('request');
            var fs = require('fs');
            var options = {
                'method': 'POST',
                'url': digioDocumentUpload,
                'headers': {
                    'Authorization': enviromentKey
                },
                formData: {
                    'file': {
                        'value': fs.createReadStream(imagePath),
                        'options': {
                            'filename': imagePath,
                            'contentType': null
                        }
                    },
                    'request': '{"signers":[{"identifier":"' + email_id + '","name":"' + name + '","sign_type":"aadhaar","reason":"Loan Agreement"}],"expire_in_days":10,"display_on_page":"all"}'
                }
            };
            request(options, function (error, response) {
                if (error) {
                    console.log(error);
                    func(1, error);
                } else {
                    func(0, response);
                    console.log(response.body);
                }


            });
        } else {
            func(1, 0);
        }

    });

}
exports.saveEKYCPersonalDetails = function (email_id, mobile_no, nseCash,
    nsefo,
    nseCurrency,
    bseCash,
    bsefo,
    bseCurrency,
    mcxCommodity,
    ncdexCommodity,
    res_addr_1,
    res_addr_2,
    res_addr_state,
    res_addr_city,
    res_addr_pincode,
    parm_addr_1,
    parm_addr_2,
    parm_addr_state,
    parm_addr_city,
    parm_addr_pincode,
    nationality,
    gender,
    firstname1,
    middlename1,
    lastname1,
    maritalstatus,
    fatherspouse,
    firstname2,
    middlename2,
    lastname2,
    incomerange,
    occupation,
    action,
    perextra1,
    perextra2,
    func) {

    console.log('Inside EKYC Personal Details');
    console.log('INSIDE EKYC', email_id, mobile_no, nseCash, nsefo, nseCurrency, bseCash, bsefo, bseCurrency, mcxCommodity, ncdexCommodity, res_addr_1, res_addr_2, res_addr_state, res_addr_city, res_addr_pincode, parm_addr_1, parm_addr_2, parm_addr_state, parm_addr_city, parm_addr_pincode, nationality, gender, firstname1, middlename1, lastname1, maritalstatus, fatherspouse, firstname2, middlename2, lastname2, incomerange, occupation, action, perextra1, perextra2);
    query("UPDATE ekyc SET stage = 2, nse_cash='" + nseCash + "', nse_fo='" + nsefo + "', nse_currency='" + nseCurrency + "', bse_cash='" + bseCash + "', bse_fo='" + bsefo + "', bse_currency='" + bseCurrency + "', mcx_commodty='" + mcxCommodity + "', ncdex_commodty='" + ncdexCommodity + "', res_addr_1='" + res_addr_1 + "', res_addr_2='" + res_addr_2 + "', res_addr_state='" + res_addr_state + "', res_addr_city='" + res_addr_city + "', res_addr_pincode='" + res_addr_pincode + "', parm_addr_1='" + parm_addr_1 + "', parm_addr_2='" + parm_addr_2 + "', parm_addr_state='" + parm_addr_state + "', parm_addr_city='" + parm_addr_city + "', parm_addr_pincode='" + parm_addr_pincode + "', nationality='" + nationality + "', gender='" + gender + "', firstname1='" + firstname1 + "', middlename1='" + middlename1 + "', lastname1='" + lastname1 + "', maritalstatus='" + maritalstatus + "', fatherspouse='" + fatherspouse + "', firstname2='" + firstname2 + "', middlename2='" + middlename2 + "', lastname2='" + lastname2 + "', incomerange='" + incomerange + "', occupation='" + occupation + "', action='" + action + "', perextra1='" + perextra1 + "', perextra2='" + perextra2 + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
}

exports.SaveBankDetails = function (email_id, mobile_no, ifsccode, accountnumber, bankname, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, ifsccode, accountnumber, bankname);


    var request = require('request');
    var options = {
        'method': 'POST',
        'url': digioBankVerify,
        'headers': {
            'Authorization': enviromentKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "beneficiary_account_no": accountnumber,
            "beneficiary_ifsc": ifsccode
        })

    };
    request(options, function (error, response) {
        if (error) {
            console.log("Digio Pan validate error" + error);
            func(2, 0); // error code 2 from digio service if not work  
        } else {
            try {


                console.log("Digio bank  response" + response.body);
                var objData = JSON.parse(response.body);


                if (objData.verified != null) {
                    query("UPDATE ekyc SET stage = 3, ifsccode='" + ifsccode + "', accountnumber='" + accountnumber + "', bankname='" + bankname + "', verified_id='" + objData.id + "', beneficiary_name_with_bank='" + objData.beneficiary_name_with_bank + "', verified_at='" + objData.verified_at + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
                } else {
                    if (objData.error_code != null) {

                        var code = "";
                        var message = "";

                        if (objData.error_code == "es405" || objData.error_code == "405") {
                            code = "es405";
                            message = "Some error message";
                        } else if (objData.error_code == "ns:E402" || objData.error_code == "402") {
                            code = "ns:E402";
                            message = "Insufficient Balance in debit account, payment required";
                        } else if (objData.error_code == "ns:E405" || objData.error_code == "E405") {
                            code = "ns:E405";
                            message = "Invalid Transfer Type";
                        } else if (objData.error_code == "ns:E429" || objData.error_code == "E429") {
                            code = "ns:E429";
                            message = "(Limit Daily/transaction/rate) exceeded";
                        } else if (objData.error_code == "ns:E406" || objData.error_code == "E406") {
                            code = "ns:E406";
                            message = "Beneficiary not acceptable";
                        } else if (objData.error_code == "ns:E502" || objData.error_code == "E502") {
                            code = "E502";
                            message = "Bad Gateway";
                        } else if (objData.error_code == "ns:E1001" || objData.error_code == "E1001") {
                            code = "ns:E1001";
                            message = "The transaction amount exceeds the maximum amount for IMPS";
                        } else if (objData.error_code == "ns:E1002" || objData.error_code == "E1002") {
                            code = "ns:E1002";
                            message = "The transfer currency is not supported. Supported currency is INR";
                        } else if (objData.error_code == "ns:E1003" || objData.error_code == "E1003") {
                            code = "ns:E1003";
                            message = "The transaction amount should be multiples of Re 1 for RTGS";
                        } else if (objData.error_code == "ns:E1004" || objData.error_code == "E1004") {
                            code = "ns:E1004";
                            message = "Transfer Amount is less than the minimum amount for RTGS";
                        } else if (objData.error_code == "ns:E6000" || objData.error_code == "E6000") {
                            code = "ns:E6000";
                            message = "Purpose Code not found";
                        } else if (objData.error_code == "ns:E6001" || objData.error_code == "E6001") {
                            code = "ns:E6001";
                            message = "Only registered beneficiaries are allowed for this purpose code";
                        } else if (objData.error_code == "ns:E6002" || objData.error_code == "E6002") {
                            code = "ns:E6002";
                            message = "Purpose Code is required for this customer";
                        } else if (objData.error_code == "ns:E8000" || objData.error_code == "E8000") {
                            code = "ns:E8000";
                            message = "A transaction with the same reference number is already processed or under processing";
                        } else if (objData.error_code == "ns:E6003" || objData.error_code == "E6003") {
                            code = "ns:E6003";
                            message = "Invalid Debit Account for Customer";
                        } else if (objData.error_code == "flex:E18" || objData.error_code == "E18") {
                            code = "flex:E18";
                            message = "Hold Funds Present - Refer to Drawer ( Account would Overdraw )";
                        } else if (objData.error_code == "flex:E404" || objData.error_code == "E404") {
                            code = "flex:E404";
                            message = "No Relationship Exists with the debit Account {AccountNo} and partner";
                        } else if (objData.error_code == "flex:E8036" || objData.error_code == "E8036") {
                            code = "flex:E8036";
                            message = "NEFT - Both Customer Mobile and Email is not valid.";
                        } else if (objData.error_code == "flex:E8087" || objData.error_code == "E8087") {
                            code = "flex:E8087";
                            message = "To Account Number is Invalid";
                        } else if (objData.error_code == "flex:E9072" || objData.error_code == "E9072") {
                            code = "flex:E9072";
                            message = "Invalid IFSC Code";
                        } else if (objData.error_code == "npci:E08" || objData.error_code == "E08") {
                            code = "npci:E08";
                            message = "Acquiring Bank CBS or node offline";
                        } else if (objData.error_code == "npci:EM1" || objData.error_code == "EM1") {
                            code = "npci:EM1";
                            message = "Invalid Beneficiary MMID/Mobile Number";
                        } else if (objData.error_code == "npci:EM2" || objData.error_code == "EM2") {
                            code = "npci:EM2";
                            message = "Amount limit exceeded";
                        } else if (objData.error_code == "npci:EM3" || objData.error_code == "EM3") {
                            code = "npci:EM3";
                            message = "Account blocked/frozen";
                        } else if (objData.error_code == "npci:EM4" || objData.error_code == "EM4") {
                            code = "npci:EM4";
                            message = "Beneficiary Bank is not enabled for Foreign Inward Remittance";
                        } else if (objData.error_code == "npci:EM5" || objData.error_code == "EM5") {
                            code = "npci:EM5";
                            message = "Account closed";
                        } else if (objData.error_code == "atom:E404" || objData.error_code == "E404") {
                            code = "atom:E404";
                            message = "No Relationship Exists with the debit Account {AccountNo} and partner";
                        } else if (objData.error_code == "sfms:E62" || objData.error_code == "E62") {
                            code = "sfms:E62";
                            message = "Transaction accepted by RBI but beneficiary bank rejected it";
                        } else if (objData.error_code == "sfms:E99" || objData.error_code == "E99") {
                            code = "sfms:E99";
                            message = "Manually Marked in Error";
                        } else if (objData.error_code == "sfms:E70" || objData.error_code == "E70") {
                            code = "sfms:E70";
                            message = "Outward Transaction Rejected";
                        } else if (objData.error_code == "sfms:E18" || objData.error_code == "E18") {
                            code = "sfms:E18";
                            message = "Rejected by SFMS";
                        } else if (objData.error_code == "R000") {
                            code = "R000";
                            message = "Remittance transactions has been successfully processed";
                        } else {
                            code = "0000";
                            message = "error.";
                        }

                        var obj = {
                            "details": objData.details,
                            "code": code,
                            "message": message
                        };
                        func(2, obj)
                        // 2 means handle below response {
                        //   "id": "FTI1809111232556634TGAOUXJM5LLUY",
                        //   "verified": false,
                        //   "error_code": "es405", 
                        //   "error_message": "Some error message" }

                    } else {
                        func(1, response.body)
                        // 1 means handle below response{
                        //     "details": "EX211005102732146PMZ",
                        //     "code": "REQUEST_VALIDATION_FAILED",
                        //     "message": "Please provide the user's account IFSC code. Invalid IFSC code. "
                        // }
                    }
                }
            } catch (e) {
                func(2, 0); // error code 2 from digio service if not work  
            }
        }



    });






}

exports.SavePaymentDetails = function (email_id, mobile_no, pack, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, pack);
    query("UPDATE ekyc SET stage = 4, pack='" + pack + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
}

exports.SaveDocumDetails = function (email_id, mobile_no, func) {
    console.log('INSIDE EKYC', email_id, mobile_no);
    query("UPDATE ekyc SET stage = 5 WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
}

exports.SaveIpvDetails = function (email_id, mobile_no, imageName, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, imageName);
    query("UPDATE ekyc SET stage = 6 ipv = '" + imageName + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
}

exports.SaveEsignDetails = function (email_id, mobile_no, esign, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, esign);
    query("UPDATE ekyc SET stage = 7, esign='" + esign + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
}

exports.SaveDocumentDetails = function (email_id, mobile_no, type, imageName, imagePath, prooftype, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, type, imageName, imagePath);
    if (type == "pancard") {
        query("UPDATE ekyc SET  pancard='" + imagePath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

            if (err == 0) {
                func(0, 0);
                checkAllimageuploaded(email_id, mobile_no);
            } else {
                func(1, 0);
            }
        });
    } else if (type == "signature") {
        query("UPDATE ekyc SET signature='" + imagePath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

            if (err == 0) {
                func(0, 0);
                checkAllimageuploaded(email_id, mobile_no);
            } else {
                func(1, 0);
            }
        });
    } else if (type == "bankproof") {
        query("UPDATE ekyc SET  bankproof='" + imagePath + "' , bankprooftype='" + prooftype + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

            if (err == 0) {
                func(0, 0);
                checkAllimageuploaded(email_id, mobile_no);
            } else {
                func(1, 0);
            }
        });
    } else if (type == "addressproof") {
        query("UPDATE ekyc SET  addressproof='" + imagePath + "' , addressprooftype='" + prooftype + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

            if (err == 0) {
                func(0, 0);
                checkAllimageuploaded(email_id, mobile_no);
            } else {
                func(1, 0);
            }
        });
    } else if (type == "incomeproof") {
        query("UPDATE ekyc SET  incomeproof='" + imagePath + "' , incomeprooftype='" + prooftype + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

            if (err == 0) {
                func(0, 0);
                checkAllimageuploaded(email_id, mobile_no);
            } else {
                func(1, 0);
            }
        });
    } else if (type == "photograph") {
        query("UPDATE ekyc SET  photograph='" + imagePath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

            if (err == 0) {
                func(0, 0);
                checkAllimageuploaded(email_id, mobile_no);
            } else {

            }
        });
    }

}
exports.checkAllimageuploaded = checkAllimageuploaded;
function checkAllimageuploaded(email_id, mobile_no) {
    console.log('INSIDE EKYC', email_id, mobile_no);
    query("SELECT pancard,signature,bankproof,addressproof,incomeproof,photograph  FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "' IS NOT NULL;", function (err, rows) {

        if (err == 0) {
            console.log(rows);
            if (rows[0].pancard != "" && rows[0].signature != "" && rows[0].bankproof != "" && rows[0].addressproof != "" && rows[0].incomeproof != "" && rows[0].photograph != "") {
                console.log("all images stored now update stage");
                query("UPDATE ekyc SET stage = 5  WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {
                    if (err == 0) {
                        console.log(err);
                    } else {
                        console.log(err);
                    }
                });
            } else {
                console.log("Some images still pending");
            }
        } else {
            console.log(rows);
        }
    });
}
exports.SaveIpvDetails = function (email_id, mobile_no, imagePath, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, imagePath);

    query("UPDATE ekyc SET stage = 6, ipv='" + imagePath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)

}

exports.getDocuments = function (email_id, mobile_no, type, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, type);
    if (type == "pancard") {
        query("SELECT pancard FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
    } else if (type == "signature") {
        query("SELECT signature FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
    } else if (type == "bankproof") {
        query("SELECT bankproof FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
    } else if (type == "addressproof") {
        query("SELECT addressproof FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
    } else if (type == "incomeproof") {
        query("SELECT incomeproof FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
    } else if (type == "photograph") {
        query("SELECT photograph FROM ekyc WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
    }
}
exports.insertUsersData = function (email_id, mobile_no, full_name, func) {
    console.log('INSIDE EKYC', email_id, mobile_no, full_name);
    query("INSERT INTO ekyc (stage ,full_name,email_id, mobile_no) VALUES ('0', '" + full_name + "','" + email_id + "'," + mobile_no + ");", func)
}
exports.SaveEmailOTP = SaveEmailOTP;
function SaveEmailOTP(emaild_otp, email_id, mobile_no, func) {
    console.log('INSIDE EKYC', emaild_otp, email_id, mobile_no);
    query("UPDATE ekyc SET email_otp = '" + emaild_otp + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

        if (err == 0) {
            func(0, 0);
        } else {
            func(1, 0);
        }
    });
}

exports.SaveMobileOTP = SaveMobileOTP;
function SaveMobileOTP(mobile_otp, email_id, mobile_no, func) {
    console.log('INSIDE EKYC', mobile_otp, email_id, mobile_no);
    query("UPDATE ekyc SET mobile_otp = '" + mobile_otp + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", function (err, rows) {

        if (err == 0) {
            func(0, 0);
        } else {
            func(1, 0);
        }
    });
}

exports.SendEmailOtp = function (email, mobile_no, func) {
    console.log('INSIDE EKYC', email, mobile_no);

    var transporter = nodemailer.createTransport(smtpTransport({
        host: "192.168.206.150",
        port: "25",
        //secure:(iniString.isSecureSMTP == "true")?true:false,
        auth: {
            user: "pritesh.parmar@greeksoft.co.in",
            pass: "Passw0rd"
        },
        tls: {
            rejectUnauthorized: false
        }
    }));




    var pass = "";
    var mailText;
    var maxBytes = 2;
    var maxDec = 65536;
    var mimimum = 100000;
    var maximum = 999999;

    var randombytes = parseInt(crypto.randomBytes(maxBytes).toString('hex'), 16);
    var result = Math.floor(randombytes / maxDec * (maximum - mimimum + 1) + mimimum);
    pass = result;

    mailText = "Dear Sir/Madam,\n\nYour One Time Password is  " + pass + ". Please use the password to complete the Process. Please do not share this with any one.\n\nRegards,\nSupport Team"




    var mailOption = {
        from: "pritesh.parmar@greeksoft.co.in",
        to: email,
        subject: "One Time Password",
        text: mailText
    };

    transporter.sendMail(mailOption, function (err, info) {
        if (err) {
            console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            console.log(err);
            console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            func(1, 0);
        }
        else {
            console.log("----------------------------------------------------------------------------------");
            console.log("Message Sent" + info.response);
            console.log("----------------------------------------------------------------------------------");
            console.log(err);
            //SaveEmailOTP(result, email, mobile_no, function (err, rows) {
            func(0, pass);
            //   });
        }
    });

}


exports.SendMobileOtp = function (email, mobile_no, func) {
    console.log('INSIDE EKYC');



    var maxBytes = 2;
    var maxDec = 65536;
    var mimimum = 100000;

    var maximum = 999999;

    var randombytes = parseInt(crypto.randomBytes(maxBytes).toString('hex'), 16);
    var result = Math.floor(randombytes / maxDec * (maximum - mimimum + 1) + mimimum);



    var msgData = result + " is your OTP for resetting your TradingApp. Vishwas Fincap Services Pvt. Ltd.";
    var client = new Client();
    client.get("https://apps.vibgyortel.in/client/api/sendmessage?apikey=02fac732fa750cd6&mobiles=" + mobile_no + "&sms=" + msgData + "&senderid=VishEq&schedule=No&unicode=no&messagetype=sms", function (data, response) {
        // SaveMobileOTP(result, email, mobile_no, function (err, rows) {
        func(0, result);
        console.log("Response From Send SMS :" + response);
        // });
    })
        .on('error', function (err) {
            console.log("Something went wrong on the request : " + err);
            func(1, 0);
        });

    client.on('error', function (err) {
        console.log("Something went wrong on the Client : " + err);
        func(1, 0);
    });

}



exports.readIndexFile = function (indexname, filepath, func) {
    let stream = fs.createReadStream(filepath);
    let myArray = [];
    var _date = parseInt(Date.now() / 1000);
    let csvstream = csv
        .parse()
        .on("data", (data) => {
            var sData = '';

            sData = [data[0], data[1], data[2], data[3], data[4], indexname, _date.toString()];
            console.log(sData);

            myArray.push(sData);
        })
        .on("end", function () {
            myArray.shift();

            let _query = "INSERT INTO IndexScripData(cCompanyName,cIndustry,cSymbol,cSeries,cISINCode,datakey,last_updated_time) 					    Values ?";
            bulkquery(_query, myArray, function (err, rows) {
                func(err);
            });
        });
    stream.pipe(csvstream);
}
exports.insertImage = function (email_id, mobile_no, pancardpath, func) {
    querymaster("UPDATE ekyc SET stage = 5, pancard='" + pancardpath + "' WHERE email_id = '" + email_id + "' and mobile_no = '" + mobile_no + "';", func)
}

function querymaster(query, func) {




    console.log("QUERY=" + query);
    writeToLogFile("QueryMaster", query + "\n");
    /*poolmaster.getConnection(function(err, connection)*/
    poolCluster.getConnection('MASTER', function (err, connection) {
        // console.log(pool);

        if (err) {
            // connection.release();

            console.log('SQLITE DB Master: ERR 1 == ' + err);
            writeToLogFile("QueryMaster", "Inside Error" + "\n");
            func(dalResult.connectionError, 0);
            return;
        }
        /*connection.changeUser({database : 'greekdb'}, function(err) {
          if (err) throw err;
        });*/

        //console.log('connection as id ' + connection.threadid);
        connection.query(query, function (err, rows) {
            //console.getPasswordlog("queried!");
            writeToLogFile("QueryMaster", "Connection Release Start " + "\n");
            connection.release();
            writeToLogFile("QueryMaster", "Connection Release End" + "\n");
            if (!err) {
                if (rows.length == 0) {
                    writeToLogFile("QueryMaster", "Row Length =0" + "\n");
                    func(dalResult.noResult, 0);
                    return;
                }
                else {
                    //console.log(rows);
                    writeToLogFile("QueryMaster", "All the Row Set" + "\n");
                    // process rows (there should be a single row);
                    func(dalResult.success, rows);
                    return;
                }
            }
            else {
                writeToLogFile("QueryMaster", "No Record Found" + "\n");
                func(dalResult.queryError, 0);// Added By Pravin Pasi for returning query error
                console.log('SQLITE DB Master: ERR 2 == ' + err);
                return;
            }
        });

        connection.on('error', function (err) {
            writeToLogFile("QueryMaster", "Connection Error" + "\n");
            connection.release();
            console.log('Error in on error : ' + err);
            console.log('SQLITE DB Master: ERR 3');
            func(dalResult.connectionError, 0);
            return;
        });
    });
}
