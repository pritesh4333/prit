var express = require('express');
var bodyParser = require('body-parser');
var dal = require('./router/dal');
var config = require("./router/config");
var crypto = require("crypto");
var configString = config.loadconfigFile();
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var router = express.Router();

app.use('/', router);

app.use(function (req, res, next) {

    res.setHeader('Access-control-Allow-Origin', '*');

    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS,PUT,PATCH,DELETE');

    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    res.setHeader('Access-Control-Allow-Credentials', true);

    res.header('Access-Control-Allow-Origin', '*');

    res.header('Access-Control-Allow-Headers', 'Content-Type');

    //res.header('Access-Control-Allow-Methods','GET,PUT,POST,DELETE');

    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');

    next();

});

app.set('views', __dirname + '/views');

app.use(express.static('public'));

require('./router/main')(app);

app.listen(configString.port, function (err) {
    if (err) {
        console.log("******************************************************************");
        console.log("Error Creating Server : " + err);
        console.log("******************************************************************");
    }
    else {
        var result = crypto.randomBytes(5).toString('hex');
        console.log(result);
        console.log("******************************************************************");
        console.log("Server Started on PORT : " + configString.port);
        console.log("******************************************************************");
        dal.createUserInfoTable(function (err, rows) {
            console.log("create table reponse" + err);


        });
    }
});

