var dal = require('./dal');
var util = require('util');

module.exports = function (app) {

    app.post("/UserLogin", function (req, res) {
        console.log("****** Request Called UserLogin GET *******");
        console.log(util.inspect(req.body));

        var emailId = req.body.emailId;
        var password = req.body.password;
        var obj;
        var error = 0;
        if (emailId == undefined || emailId == '' || emailId == null) {
            obj = responseModelObject("1", "Please provide Email id");
            error = 1;
        } else if (password == undefined || password == '' || password == null) {
            obj = responseModelObject("1", "Please provide Password");
            error = 1;
        } else {
            dal.UserLogin(emailId, password, function (err, rows) {
                if (err == 0) {

                    obj = responseModelObject("0", "Login Scuccess");
                } else {

                    obj = responseModelObject("1", "Login failed");
                }
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj));
            });

        }
        if (error == 1) {
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        }


    });

    app.post("/UserRegister", function (req, res) {
        console.log("****** Request Called UserRegister POST  *******");
        console.log(util.inspect(req.body));
        var name = req.body.name;
        var emailId = req.body.emailId;
        var mobileNo = req.body.mobileNo;
        var city = req.body.city;
        var state = req.body.state;
        var password = req.body.password;
        var obj;
        var error = 0;
        if (name == undefined || name == '' || name == null) {
            obj = responseModelObject("1", "Please provide Name");
            error = 1;
        } else if (emailId == undefined || emailId == '' || emailId == null) {
            obj = responseModelObject("1", "Please provide Email id");
            error = 1;
        } else if (mobileNo == undefined || mobileNo == '' || mobileNo == null) {
            obj = responseModelObject("1", "Please provide MobileNo");
            error = 1;
        } else if (city == undefined || city == '' || city == null) {
            obj = responseModelObject("1", "Please provide City");
            error = 1;
        } else if (state == undefined || state == '' || state == null) {
            obj = responseModelObject("1", "Please provide State");
            error = 1;
        } else if (password == undefined || password == '' || password == null) {
            obj = responseModelObject("1", "Please provide Password");
            error = 1;
        } else {
            dal.registerUser(name, emailId, mobileNo, city, state, password, function (err, rows) {
                var obj1;
                if (err == 0) {

                    obj1 = responseModelObject("0", "success");
                } else if (err == 3) {
                    obj1 = responseModelObject("1", "Record already exists");
                } else {
                    obj1 = responseModelObject("1", "failed");
                }
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(obj1));
            });
        }
        if (error == 1) {
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(obj));
        }



    });
    function responseModelObject(err, message) {
        var obj = {
            "response": {
                "error_code": err,
                "data": {
                    "message": message
                }
            }
        };
        return obj;
    }

}