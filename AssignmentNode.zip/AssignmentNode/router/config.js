var fs = require('fs');

exports.loadMyDBConfig = function () {

	var fileCSV = '\n';
	fileCSV += fs.readFileSync("./mydbconfig.txt").toString('utf8');


	var json = "";
	var ignore = false;
	var started = false;
	for (var i = 0, len = fileCSV.length; i < len; i++) {
		if (fileCSV[i] == '#') {
			ignore = true;
		} else if (fileCSV[i] == '\n' || fileCSV[i] == '\r') {
			ignore = false;
			if (started == false) {
				json += '"';
				started = true;
			} else {
				json += '","';
			}
		} else if (ignore == false && fileCSV[i] != ' ' && fileCSV[i] != '\t') {
			if (fileCSV[i] == '=')
				json = json += '":"';
			else
				json = json + fileCSV[i];
		}
	}

	var temp = json; json = '';
	for (var i = 0, len = temp.length - 2; i < len; i++) {
		if (temp[i] == ',' && temp[i + 1] == '"' && temp[i + 2] == '"')
			i += 2;
		else
			json += temp[i];
	}


	if (json.substr(0, 3) == '"",')
		json = json.substr(3);

	json = "{" + json + "}";

	var config = JSON.parse(json);
	return config;


}


exports.loadconfigFile = function () {

	var fileCSV = '\n';
	fileCSV += fs.readFileSync("./config.txt").toString('utf8');


	var json = "";
	var ignore = false;
	var started = false;
	for (var i = 0, len = fileCSV.length; i < len; i++) {
		if (fileCSV[i] == '#') {
			ignore = true;
		} else if (fileCSV[i] == '\n' || fileCSV[i] == '\r') {
			ignore = false;
			if (started == false) {
				json += '"';
				started = true;
			} else {
				json += '","';
			}
		} else if (ignore == false && fileCSV[i] != ' ' && fileCSV[i] != '\t') {
			if (fileCSV[i] == '=')
				json = json += '":"';
			else
				json = json + fileCSV[i];
		}
	}

	var temp = json; json = '';
	for (var i = 0, len = temp.length - 2; i < len; i++) {
		if (temp[i] == ',' && temp[i + 1] == '"' && temp[i + 2] == '"')
			i += 2;
		else
			json += temp[i];
	}


	if (json.substr(0, 3) == '"",')
		json = json.substr(3);

	json = "{" + json + "}";

	var config = JSON.parse(json);
	return config;


}