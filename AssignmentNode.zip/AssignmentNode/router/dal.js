var config = require("./config");
var mysql = require('mysql');
var myDbString = config.loadMyDBConfig();
console.log("IP : " + myDbString.host);


var pool = mysql.createPool({
    connectionLimit: 100,
    host: myDbString.host,//
    user: myDbString.user,//
    password: myDbString.password,//
    database: myDbString.db,//
    debug: false
});

exports.dalResult = dalResult = {
    success: 0,
    connectionError: 1,
    queryError: 2,
    noResult: 3
}

if (pool) { // mysql is started && connected successfully.
    console.log('Connection Success');

} else {
    console.log('Cant connect to db, Check ur db connection');
}

function query(query, func) {
    pool.getConnection(function (err, connection) {
        if (err) {
            // connection.release();
            console.log('SQLITE DB Slave: ERR 1 == ' + err);
            func(dalResult.connectionError, 0);
            return;
        }

        //console.log('connection as id ' + connection.threadid);
        connection.query(query, function (err, rows) {
            //console.getPasswordlog("queried!");
            connection.release();
            if (!err) {
                if (rows.length == 0) {
                    func(dalResult.noResult, 0);
                    return;
                }
                else {
                    //console.log(rows);

                    // process rows (there should be a single row);
                    func(dalResult.success, rows);
                    return;
                }
            }
            else {
                func(dalResult.queryError, 0);// Added By Pravin Pasi for returning query error
                console.log('SQLITE DB Slave: ERR 2 == ' + err);
                return;
            }
        });
        connection.on('error', function (err) {

            connection.release();
            console.log('Error in on error : ' + err);
            console.log('SQLITE DB Slave: ERR 3');
            func(dalResult.connectionError, 0);
            return;
        });
    });
}

function bulkquery(query, myArray, func) {
    console.log("QUERY=" + query);

    pool.getConnection(function (err, connection) {
        if (err) {
            // connection.release();
            console.log('SQLITE DB: ERR 1 == ' + err);
            func(dalResult.connectionError, 0);
            return;
        }
        //console.log('connection as id ' + connection.threadid);
        connection.query(query, [myArray], function (err, rows) {
            //console.getPasswordlog("queried!");
            connection.release();
            if (!err) {
                if (rows.length == 0) {
                    func(dalResult.noResult, 0);
                    return;
                }
                else {
                    func(dalResult.success, rows);
                    return;
                }
            }
            else {
                func(dalResult.queryError, 0);// Added By Pravin Pasi for returning query error
                console.log('SQLITE DB: ERR 2 == ' + err);
                return;
            }
        });

        connection.on('error', function (err) {
            connection.release();
            console.log('Error in on error : ' + err);
            console.log('SQLITE DB: ERR 3');
            func(dalResult.connectionError, 0);
            return;
        });
    });
}
exports.createUserInfoTable = function (func) {
    query("CREATE TABLE IF NOT EXISTS `userInfo` ( `unique_id` int(11) NOT NULL AUTO_INCREMENT, `name` varchar(45) NOT NULL, `email_id` varchar(45) NOT NULL, `mobile_no` varchar(45) NOT NULL, `city` varchar(45) NOT NULL, `state` varchar(45) NOT NULL, `password` varchar(45) NOT NULL, PRIMARY KEY (`unique_id`,`email_id`,`password`) USING BTREE ) ENGINE=InnoDB DEFAULT CHARSET=latin1;", func)
}

exports.registerUser = function (name, emailId, mobileNo, city, state, password, func) {
    query("SELECT * FROM userInfo WHERE email_id='" + emailId + "' ", function (err, rows) {

        if (err == 0) {
            if (rows.length > 0) {
                func(3, 1);
            }
        } else {
            query("INSERT INTO userInfo (name ,email_id,mobile_no,city,state,password) VALUES ('" + name + "', '" + emailId + "','" + mobileNo + "','" + city + "','" + state + "','" + password + "');", func)
        }
    });
}
exports.UserLogin = function (emailId, password, func) {
    query("SELECT * FROM userInfo WHERE email_id='" + emailId + "' and password='" + password + "'", func)
}










