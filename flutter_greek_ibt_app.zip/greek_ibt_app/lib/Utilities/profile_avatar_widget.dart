import 'dart:io';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';

class ProfileAvatar extends StatelessWidget {
  File? imageFile;

  ProfileAvatar(this.imageFile, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      clipBehavior: Clip.none,
      children: [
        CircleAvatar(
          backgroundColor: Colors.white,
          radius: 35,
          child: CircleAvatar(
            radius: 33,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Image.network(
                AppConfig().getProfileUrl(),
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/user_icon.png');
                },
              ),
            ),
            backgroundColor: const Color(0xFF96C2DA),
          ),
        ),
        Visibility(
          visible: false,
          child: Positioned(
            bottom: 7,
            right: -3,
            child: Container(
              decoration: BoxDecoration(color: const Color(0xFFF5F6F9), borderRadius: BorderRadius.circular(30)),
              height: 20,
              width: 20,
              child: const Center(
                child: Icon(
                  Icons.camera_alt_outlined,
                  color: Colors.blue,
                  size: 15,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
