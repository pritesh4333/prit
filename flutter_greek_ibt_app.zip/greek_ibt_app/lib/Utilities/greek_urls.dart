// ignore_for_file: constant_identifier_names, unused_field

import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:tuple/tuple.dart';

/// # Server Info data structure
///
/// ## Store example
///
/// 1. bool   - For set secure or not
/// 2. String - For set URL
/// 3. int    - For set Server Port
/// 4. int    - For set Socket-IO Port may be null
/// 5. bool   - For set Request or Response is Base64 Encrypted or not
///
///
/// ## Usage example
///
/// 1. item1(bool)    - For secure or not
/// 2. item2(String)  - For URL
/// 3. item3(int)     - For Server Port
/// 4. item4(int?)    - For Socket-IO Port
/// 5. item5(bool)    - For Request or Response is Base64 Encrypted or not
///

class GreekURLs {
  static String eKycUrl = AppFlagConstant().eKycSignUpUrl + ':' + AppFlagConstant().eKycSignUpPort;

  static const _greek_tester_server_secure = Tuple5<bool, String, int, int?, bool>(true, 'tester.greeksoft.in', 0, null, true);
  static const _greek_tester_server_non_secure = Tuple5<bool, String, int, int?, bool>(false, 'tester.greeksoft.in', 0, null, true);
  static const _greek_silverstream_server_non_secure = Tuple5<bool, String, int, int?, bool>(false, 'trading.silverstream.co.in', 0, 4000, true);
  static const _greek_silverstream_server_secure = Tuple5<bool, String, int, int?, bool>(true, 'trading.silverstream.co.in', 0, 4000, true);
  /* static const _greek_dynu_server =] Tuple5<bool, String, int, int?, bool>(
      true, 'greeksoft.dynu.com', 0, 4000, true); */
  static const _greek_dynu_server = Tuple5<bool, String, int, int?, bool>(true, 'greeksoft.dynu.com', 0, 4000, true);
  static const _flutter_server_secure = Tuple5<bool, String, int, int?, bool>(true, 'flutter.greeksoft.in', 3000, 4000, true);
  static const _flutter_server_secure_ip = Tuple5<bool, String, int, int?, bool>(true, '192.168.209.176', 3000, 4000, true);

  static const _flutterServer_non_secure = Tuple5<bool, String, int, int?, bool>(false, '192.168.209.176', 3000, 4000, true);
  static const _apmosys_server = Tuple5<bool, String, int, int?, bool>(false, '192.168.238.101', 3000, null, false);
  static const _developer_server_secure = Tuple5<bool, String, int, int?, bool>(true, 'developer.greeksoft.in', 0, 4000, true);

  static const _apmosys_server_secure = Tuple5<bool, String, int, int?, bool>(true, 'apmosys.greeksoft.in', 0, 4000, true);

  static const _satendra_non_secure = Tuple5<bool, String, int, int?, bool>(false, '192.168.209.116', 3000, 4000, true);

  static const currentServerInfo = _greek_tester_server_secure;
}
