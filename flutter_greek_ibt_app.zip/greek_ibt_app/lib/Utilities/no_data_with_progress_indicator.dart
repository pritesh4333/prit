import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';

class NoDatWithProgressIndicator extends StatelessWidget {
  const NoDatWithProgressIndicator({
    Key? key,
    required this.topSpace,
    required this.showHide,
    required this.message,
  }) : super(key: key);

  final double topSpace;
  final bool showHide;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: topSpace / 1.6),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              showHide ? const CircularProgressIndicator() : const SizedBox.shrink(),
              showHide ? const SizedBox(width: 14) : const SizedBox.shrink(),
              Container(child: message.isNotEmpty ? GreekBase().noDataAvailableView(msg: message) : GreekBase().noDataAvailableView()),
            ],
          ),
        ],
      ),
    );
  }
}
