import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';

class GreekThemeUtility {
  // static const _fontFamily = 'CenturyGothic';
  static const _fontFamilyRoboto = 'Roboto';

  // static const _font9 = 9.0;
  static const _font10 = 10.0;
  // static const _font11 = 11.0;
  static const _font12 = 12.0;
  static const _font13 = 13.0;
  // static const _font14 = 14.0;
  static const _font15 = 15.0;
  // static const _font16 = 16.0;
  // static const _font17 = 17.0;
  static const _font18 = 18.0;
  // static const _font20 = 20.0;
  // static const _font21 = 21.0;
  // static const _font22 = 22.0;
  static const _font25 = 25.0;

  static final lightTheme = ThemeData(
    scaffoldBackgroundColor: ConstantColors.scaffoldBackgroundColor,
    primaryColor: ConstantColors.primaryColor,
    colorScheme: const ColorScheme.light(
      primary: ConstantColors.colorsSchemePrimary,
      onPrimary: ConstantColors.onPrimary,
      primaryContainer: ConstantColors.primaryVariant,
      secondary: ConstantColors.secondary,
    ),
    cardTheme: const CardTheme(
      color: ConstantColors.cardTheme,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: ConstantColors.primaryColorLight,
      iconTheme: IconThemeData(color: Colors.red),
      titleTextStyle: TextStyle(color: Colors.lightBlueAccent),
      actionsIconTheme: IconThemeData(color: Colors.amber),
    ),
    iconTheme: const IconThemeData(color: Colors.blueAccent, opacity: 0.8),
    // primaryColorBrightness: Brightness.light,
    primaryColorLight: ConstantColors.primaryColorLight,
    primaryColorDark: ConstantColors.primaryColorDark,
    canvasColor: ConstantColors.canvasColor,
    bottomAppBarColor: ConstantColors.bottomAppBarColor,
    cardColor: ConstantColors.cardColor,
    dividerColor: ConstantColors.dividerColor,
    focusColor: ConstantColors.focusColor,
    brightness: Brightness.light,
    hoverColor: const Color(0xffDEC29B),
    highlightColor: const Color(0xff936F3E),
    splashColor: const Color(0xff457BE0),
    selectedRowColor: Colors.grey,
    unselectedWidgetColor: Colors.grey.shade400,
    disabledColor: Colors.grey.shade200,
    // buttonColor: Color(0xff936F3E),
    secondaryHeaderColor: Colors.grey,
    // textSelectionColor: Color(0xffB5BFD3),
    // cursorColor: Color(0xff936F3E),
    // textSelectionHandleColor: Color(0xff936F3E),
    backgroundColor: const Color(0xff457BE0),
    dialogBackgroundColor: Colors.white,
    indicatorColor: const Color(0xff457BE0),
    hintColor: Colors.grey,
    errorColor: Colors.red,
    toggleableActiveColor: const Color(0xff6D42CE),
    textTheme: const TextTheme(
      headline1: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: _font15,
      ),
      headline2: TextStyle(
        fontWeight: FontWeight.bold,
        color: ConstantColors.black,
        fontFamily: _fontFamilyRoboto,
        fontSize: _font18,
      ),
      headline3: TextStyle(
        color: ConstantColors.black,
        fontFamily: _fontFamilyRoboto,
        fontSize: _font25,
      ),
      headline4: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: _font12,
      ),
      headline5: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: _font10,
      ),
      headline6: TextStyle(
        fontFamily: _fontFamilyRoboto,
        fontSize: _font13,
        color: ConstantColors.black,
        fontWeight: FontWeight.w500,
      ),
      subtitle1: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: 12,
      ),
      subtitle2: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: 10,
      ),
      bodyText1: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: Colors.blueAccent,
        fontSize: 14,
      ),
      bodyText2: TextStyle(
        fontWeight: FontWeight.bold,
        color: ConstantColors.black,
        fontFamily: _fontFamilyRoboto,
        fontSize: 20,
      ),
      button: TextStyle(
        fontFamily: _fontFamilyRoboto,
        fontWeight: FontWeight.bold,
        color: ConstantColors.white,
        fontSize: 18,
      ),
      caption: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: 25,
      ),
      overline: TextStyle(
        fontFamily: _fontFamilyRoboto,
        color: ConstantColors.black,
        fontSize: 25,
      ),
    ),
  );

// black theme======================================================================================================================================

  static final darkTheme = ThemeData(
    scaffoldBackgroundColor: Colors.grey.shade900,
    primaryColor: ConstantColors.black,
    colorScheme: const ColorScheme.light(
      primary: ConstantColors.black,
      onPrimary: ConstantColors.black,
      primaryContainer: Colors.black12,
      secondary: Colors.red,
    ),
    cardTheme: const CardTheme(
      color: Colors.teal,
    ),
    iconTheme: const IconThemeData(
      color: Colors.purple,
      opacity: 0.8,
    ),
    // primaryColorBrightness: Brightness.dark,
    primaryColorLight: const Color(0x1a311F06),
    primaryColorDark: const Color(0xff936F3E),
    canvasColor: const Color(0xffE09E45),
    bottomAppBarColor: const Color(0xff6D42CE),
    cardColor: const Color(0xaa311F06),
    dividerColor: const Color(0x1f6D42CE),
    focusColor: const Color(0x1a311F06),
    textTheme: ThemeData.dark().textTheme.copyWith(
          headline1: const TextStyle(
            fontFamily: _fontFamilyRoboto,
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 32,
          ),
          headline2: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontFamily: _fontFamilyRoboto,
            fontSize: 25,
          ),
          headline3: const TextStyle(
            color: Colors.white,
            fontFamily: _fontFamilyRoboto,
            fontSize: 20,
          ),
          headline4: const TextStyle(
            color: Colors.white,
            fontFamily: _fontFamilyRoboto,
            fontSize: 18,
          ),
          headline5: const TextStyle(
            color: Colors.white,
            fontFamily: _fontFamilyRoboto,
            fontSize: 16,
          ),
          headline6: const TextStyle(
            color: Colors.white,
            fontFamily: _fontFamilyRoboto,
            fontSize: 14,
          ),
          subtitle1: const TextStyle(
            fontFamily: 'white',
            color: ConstantColors.black,
            fontSize: 12,
          ),
          subtitle2: const TextStyle(
            fontFamily: 'white',
            color: ConstantColors.black,
            fontSize: 10,
          ),
          bodyText1: const TextStyle(
            fontFamily: 'white',
            color: Colors.blueAccent,
            fontSize: 15,
          ),
          bodyText2: const TextStyle(
            color: Colors.blueAccent,
            fontFamily: _fontFamilyRoboto,
            fontSize: 15,
          ),
          button: const TextStyle(
            fontFamily: _fontFamilyRoboto,
            color: Colors.white,
            fontSize: 15,
          ),
          caption: const TextStyle(
            fontFamily: _fontFamilyRoboto,
            color: Colors.white,
            fontSize: 25,
          ),
          overline: const TextStyle(
            fontFamily: _fontFamilyRoboto,
            color: Colors.white,
            fontSize: 25,
          ),
        ),
  );
}
