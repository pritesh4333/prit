// ignore_for_file: prefer_const_constructors, non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';

class GreekTextStyle {
  // static const _fontFamilyCenturyGothic = 'CenturyGothic';
  static const _fontFamilyRoboto = 'Roboto';
  // static const _fontFamilyRobotoLight = 'Roboto Light';
  // static const _fontFamilyRobotoMedium = 'Roboto Medium';

  // static const _fontFamilyLato = 'Lato';

  // static const _font9 = 9.0;
  static const _font10 = 10.0;
  static const _font11 = 11.0;
  static const _font12 = 12.0;
  static const _font13 = 13.0;
  static const _font14 = 14.0;
  static const _font15 = 15.0;
  static const _font16 = 16.0;
  static const _font17 = 17.0;
  static const _font18 = 18.0;
  static const _font20 = 20.0;
  static const _font21 = 21.0;
  // static const _font22 = 22.0;
  static const _font24 = 24.0;
  static const _font25 = 25.0;

  static final mpinTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font16,
    letterSpacing: 10.0,
  );

  static final marketmapIndices = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontSize: _font16,
  );
  static final marketmapIndices_change_green = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: ConstantColors.buyColor,
    fontSize: _font15,
  );
  static final marketmapIndices_change_red = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: ConstantColors.sellColor,
    fontSize: _font15,
  );
  static final marketmapnewsheader = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontWeight: FontWeight.bold,
    fontSize: 16,
  );
  static final marketmapnewsdata = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontWeight: FontWeight.normal,
    fontSize: 13,
  );

  static final marketmapportfolioheader = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontWeight: FontWeight.bold,
    fontSize: 16,
  );
  static final marketmapportfolioAddfund = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0098FE),
    fontWeight: FontWeight.bold,
    fontSize: 16,
  );
  static final marketmapportfoliodata = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontWeight: FontWeight.normal,
    fontSize: 13,
  );
  static final marketmapportfoliomorebtn = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0098FE),
    fontWeight: FontWeight.normal,
    fontSize: 13,
  );
  static final marketStatisticsDropdownTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font13,
  );
  static final headline1 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font15,
  );

  static final optionchainsetting = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font15,
  );

  static final optionchainsettingStrike = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font13,
  );

  static final addfundpress = TextStyle(
      color: Colors.black,
      fontSize: 18.0,
      fontWeight: FontWeight.bold,
      fontFamily: _fontFamilyRoboto);

  static final addfund = TextStyle(
      color: Colors.black,
      fontSize: 18.0,
      fontWeight: FontWeight.bold,
      fontFamily: _fontFamilyRoboto);

  static final withdrawpress = TextStyle(
      color: Colors.black,
      fontSize: 18.0,
      fontWeight: FontWeight.bold,
      fontFamily: _fontFamilyRoboto);
  static final withdraw = TextStyle(
      color: Colors.black,
      fontSize: 18.0,
      fontWeight: FontWeight.bold,
      fontFamily: _fontFamilyRoboto);

  static final headline2 = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
  );

  static final mpinwecometext = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
  );

  static final headlines2 = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font20,
  );

  static final headline2normal = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
  );

  static final headlinwwithdraw = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
  );

  static final fundtextheadingstyle = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font17,
  );
  static final fundtextvaluestyle = TextStyle(
    fontWeight: FontWeight.bold,
    color: Color.fromARGB(255, 20, 20, 20),
    fontFamily: _fontFamilyRoboto,
    fontSize: _font17,
  );

  static final headline30 = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font16,
  );
  static final headline12 = TextStyle(
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
  );
  static final order_app_title_textstyle = TextStyle(
    fontWeight: FontWeight.normal,
    color: Color(0xFF616161),
    fontFamily: _fontFamilyRoboto,
    fontSize: _font20,
  );
  static final headline3 = TextStyle(
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font25,
  );
  static final headline4 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font12,
  );
  static final marketText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: ConstantColors.marketText,
    fontSize: _font12,
  );
  static final watchlistText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.w700,
    color: ConstantColors.watchlistText,
    fontSize: _font15,
  );
  static final watchlistSubText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.watchlistText,
    fontWeight: FontWeight.normal,
    fontSize: _font13,
  );

  static final headline5 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font11,
  );
  static final headline6 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.black,
    fontWeight: FontWeight.w500,
  );

  static final headline7 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    color: ConstantColors.black,
    fontWeight: FontWeight.w500,
  );

  static final headlineAppName20 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font20,
    color: ConstantColors.black,
    fontWeight: FontWeight.w500,
  );
  static final order_qty_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: Color(0xFF333333),
    fontWeight: FontWeight.bold,
  );
  static final order_buy_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.buyColor,
    fontWeight: FontWeight.bold,
  );

  static final order_buybutton_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.white,
    fontWeight: FontWeight.bold,
  );

  static final order_tab_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: Color(0xFF33CC33),
    fontWeight: FontWeight.bold,
    // decoration: BoxDecoration(),
  );
  static final order_tab_click_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.white,
    fontWeight: FontWeight.bold,
    // decoration: BoxDecoration(),
  );

  static final order_sell_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.sellColor,
    fontWeight: FontWeight.bold,
  );
  static final nse_button_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font10,
    color: ConstantColors.black,
    fontWeight: FontWeight.bold,
    // decoration: BoxDecoration(),
  );
  static final nse_button_click_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font10,
    color: ConstantColors.white,
    fontWeight: FontWeight.bold,
    // decoration: BoxDecoration(),
  );

  static final optionChainStrikeDispaly = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
    color: ConstantColors.white,
    fontWeight: FontWeight.bold,
    // decoration: BoxDecoration(),
  );

  static final optionChainStrikecallputText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
    color: Color(0xFF127FBA),
    fontWeight: FontWeight.bold,
    // decoration: BoxDecoration(),
  );

  static final bse_button_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font10,
    color: ConstantColors.black,
    fontWeight: FontWeight.bold,
  );
  static final bse_button_click_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font10,
    color: ConstantColors.white,
    fontWeight: FontWeight.bold,
  );
  static final order_sellbutton_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.sellColor,
    fontWeight: FontWeight.bold,
  );
  static final order_sellbutton_click_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.white,
    fontWeight: FontWeight.bold,
  );
  static final heading7 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font12,
  );
  static final placeOrderAppbarHeading14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );
  static final marketDepthTotal = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font15,
  );
  static final searchSymbolTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.searchSymbolPlaceHolderColor,
    fontSize: _font14,
  );
  static final heading4 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorDark,
    fontWeight: FontWeight.bold,
    fontSize: _font18,
  );

  static final heading5 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorVitt,
    fontWeight: FontWeight.bold,
    fontSize: _font18,
  );

  static final heading9 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorDark,
    fontSize: _font14,
  );

  static final optionChainStrike = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font14,
  );

  static final optionChainsettingStrikeno = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font15,
  );

  static final optionChainsettingStrikenoclick = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorVitt,
    fontSize: _font15,
  );

  static final heading10 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorVitt,
    fontSize: _font16,
  );

  static final optionchainCallPut = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font16,
  );

  static final heading11 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: const Color(0xFF000000),
    fontSize: _font15,
  );

  static final ordersubmit = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: ConstantColors.white,
    fontSize: _font18,
  );

  static final ordertabheading = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: const Color(0xFF000000),
    fontSize: _font18,
  );
  static final ordertabheading_2 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: const Color(0xFF000000),
    fontSize: _font18,
  );
  static final heading16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.white,
    fontSize: _font20,
  );
  static final PlaceOrderheading16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.white,
    fontSize: _font20,
    fontWeight: FontWeight.bold,
  );
  static final PlaceOrderheading17 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.dividerColor,
    fontSize: _font13,
    fontWeight: FontWeight.w600,
  );

  static final PlaceOrderheadingsmall = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.dividerColor,
    fontSize: _font13,
    fontWeight: FontWeight.w600,
  );

  static final heading18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
    fontSize: _font16,
  );
  static final heading19 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontSize: _font15,
  );

  static final optionChainHeading = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: ConstantColors.white,
    fontSize: _font15,
  );

  static final heading22 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: const Color(0xFF707070),
    fontSize: _font12,
  );
  static final headline20 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: const Color(0xFF3E3E3E),
    fontWeight: FontWeight.bold,
    fontSize: _font15,
  );

  static final headline22 = TextStyle(
    fontSize: _font17,
    fontWeight: FontWeight.w400,
  );
  static final headline21 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: Colors.black,
    fontSize: _font15,
  );
  static final headline25 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.w300,
    color: Colors.black,
    fontSize: _font20,
  );

  static final orderExchangeColor = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
    fontSize: _font18,
  );
  static final order_description_ltp_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: Color(0xFF333333),
    fontSize: _font15,
  );
  static final order_status_textstyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.normal,
    color: Color(0xFF999999),
    fontSize: _font11,
  );
  static final headline23 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font12,
    fontWeight: FontWeight.bold,
  );

  static final overview_depth_infoValue = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font15,
    fontWeight: FontWeight.normal,
  );
  static final overview_depth_info = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font15,
    fontWeight: FontWeight.normal,
  );

  static final overview_stockdetails_info = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font14,
    fontWeight: FontWeight.normal,
  );
  static final overview_stockdetails_infoValue = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );

  static final headingLTPGreen = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: ConstantColors.buyColor,
  );
  static final headingLTPRed = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: ConstantColors.sellColor,
  );
  static final headingWatchlistLTPGreen = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    fontSize: _font13,
    color: ConstantColors.buyColor,
  );
  static final headingWatchlistLTPRed = TextStyle(
    fontWeight: FontWeight.bold,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    color: ConstantColors.sellColor,
  );
  static final PlaceOrderheadingLTPGreen = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    fontWeight: FontWeight.bold,
    color: ConstantColors.buyColor,
  );

  static final PlaceOrderheadingLTPRed = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    fontWeight: FontWeight.bold,
    color: ConstantColors.sellColor,
  );
  static final headingPortfolioGreen = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    fontWeight: FontWeight.bold,
    color: ConstantColors.buyColor,
  );
  static final optionchainlist = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.normal,
    color: ConstantColors.black,
  );

  static final headingPortfolioRed = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    fontWeight: FontWeight.bold,
    color: ConstantColors.sellColor,
  );
  static final watchlistFilterText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font21,
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
  );
  static final watchlistActionText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font21,
    color: ConstantColors.watchlistText,
  );
  static final watchlistFilterText_blue = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font21,
    fontWeight: FontWeight.bold,
    color: Colors.blue,
  );
  static final placeOrderAppbarHeading = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font12,
    letterSpacing: 1.2,
  );

  static final loginTextHeading = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorVitt,
    fontSize: 12,
    letterSpacing: 1,
  );

  static final loginButtonText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.white,
    fontSize: 18,
    letterSpacing: 1,
  );

  static final loginText1 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.primaryColorVitt,
    fontSize: 12,
    letterSpacing: 1,
  );

  static final placeOrderAppbarHeading1 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.white,
    fontSize: _font12,
    letterSpacing: 1.2,
  );

  static final placeOrderoptionchaindata = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontSize: _font14,
  );

  static final placeOrderBuyButtonSelectedTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    fontWeight: FontWeight.bold,
    color: ConstantColors.buyColor,
  );
  static final placeOrderSellButtonSelectedTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    fontWeight: FontWeight.bold,
    color: ConstantColors.sellColor,
  );

  static final optionchainChangepositive = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: ConstantColors.buyColor,
  );
  static final optionchainChangenegative = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: ConstantColors.sellColor,
  );

  static final placeOrderActionButtonUnselectedTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
    color: Color(0xFFA4A4A4),
  );

  static final selected_tab_label_blue = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.primaryColorLight,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
  );
  static final unselected_tab_label_blue = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
  );
  static final selected_portfolio_tab_label_blue = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.primaryColorLight,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
  );
  static final unselected_portfolio_tab_label_blue = TextStyle(
    fontWeight: FontWeight.bold,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
  );
  static final market_depth_heading_text_style = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.white,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
  );
  static final market_depth_row_text_style = TextStyle(
    fontWeight: FontWeight.w500,
    color: ConstantColors.black,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
  );
  static final market_depth_row_text_style2 = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.textBuyColor,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
  );
  static final market_depth_row_text_style1 = TextStyle(
    fontWeight: FontWeight.normal,
    color: ConstantColors.textSellColor,
    fontFamily: _fontFamilyRoboto,
    fontSize: _font15,
  );
  static final position_row_text_style = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.black,
    fontWeight: FontWeight.normal,
    fontSize: _font15,
  );
  static final placeOrderExchangeSelected = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF58220),
    fontSize: _font12,
    fontWeight: FontWeight.bold,
  );
  static final placeOrderExchangeUnselected = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF9F9F9F),
    fontSize: _font12,
    fontWeight: FontWeight.bold,
  );
  static final OrderViewProductSelectedTxt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: Color(0xFF000000),
    fontSize: _font18,
  );
  static final OrderViewProductUnselectedTxt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: Color(0xFF909090),
    fontSize: _font18,
  );
  static final OverviewTitleTxt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF616161),
    fontWeight: FontWeight.bold,
    fontSize: _font24,
  );
  static final edisprocced = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.edisheader,
    fontSize: _font16,
  );
}
