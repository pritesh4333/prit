// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/getedis_authorization_responsemobile_cdsl.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/update_authorization_status_request_model.dart';
import 'package:greek_ibt_app/Screens/Edis/bloc/edis_dashboard_bloc.dart';
import 'package:greek_ibt_app/Screens/Edis/bloc/edis_margin_pledge_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/option_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/ui/marketoptionsetting.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/bloc/option_chain_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/order_details_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/portfolio_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/np_details_response_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/optionchain_setting.dart';
import 'package:greek_ibt_app/Screens/Portfolio/ui/watchlist_filter_dialog.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/required_function.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_response_data_new_model.dart'
    as holding;
import 'package:greek_ibt_app/Screens/Edis/Model/edis_authorization_response.dart'
    as edis_authorizeholding;
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_model.dart'
    as sendauthstockdetails;
import 'package:tuple/tuple.dart';

class GreekDialogPopupView {
  static BuildContext? oldOrderDialogContext;

  //=====================================================================
  ///
  /// Show Dialog with custome message
  //
  /// message - Custome message
  ///
  //=====================================================================
  static messageDialog(BuildContext context, String msg) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              alignment: Alignment.center,
              height: 300.0,
              padding: const EdgeInsets.only(top: 20.0, bottom: 10.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 10),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: Text(
                      AppConfig().appName,
                      style: GreekTextStyle.headlineAppName20,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Flexible(
                    fit: FlexFit.loose,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Text(
                          msg,
                          style: GreekTextStyle.heading19,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    height: 40.0,
                    width: MediaQuery.of(buildcontext).size.width / 1.5,
                    //  padding: const EdgeInsets.only(left: 30.0, right: 30.0),
                    child: TextButton(
                      onPressed: () =>
                          GreekNavigator.pop(context: buildcontext),
                      child: Text(
                        'Ok',
                        style: GreekTextStyle.heading4,
                      ),
                      style: TextButton.styleFrom(
                        backgroundColor: ConstantColors.white,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

//=====================================================================
  ///
  /// Show Dialog with custome message Disclaimer
  //
  /// message - Custome message
  ///
  //=====================================================================
  static messageDialogDisclaimer(BuildContext context, String msg) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              alignment: Alignment.center,
              height: MediaQuery.of(context).size.height / 1,
              padding: const EdgeInsets.only(top: 20.0, bottom: 10.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 5),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: Text(
                      AppConfig().appName,
                      style: GreekTextStyle.headlineAppName20,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Flexible(
                    fit: FlexFit.loose,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Text(
                          msg,
                          style: GreekTextStyle.heading19,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    height: 40.0,
                    width: MediaQuery.of(buildcontext).size.width / 1.5,
                    //  padding: const EdgeInsets.only(left: 30.0, right: 30.0),
                    child: TextButton(
                      onPressed: () =>
                          GreekNavigator.pop(context: buildcontext),
                      child: Text(
                        'Ok',
                        style: GreekTextStyle.heading4,
                      ),
                      style: TextButton.styleFrom(
                        backgroundColor: ConstantColors.white,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  static messageDialogWatchlistRename(BuildContext context, String msg) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              height: 250.0,
              padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 10),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      AppConfig().appName,
                      style: GreekTextStyle.headlineAppName20,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Flexible(
                    fit: FlexFit.loose,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Text(
                          msg,
                          style: GreekTextStyle.headline20,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 40.0,
                    width: MediaQuery.of(buildcontext).size.width / 1.5,
                    //  padding: const EdgeInsets.only(left: 30.0, right: 30.0),
                    child: TextButton(
                      onPressed: () =>
                          GreekNavigator.pop(context: buildcontext),
                      child: Text(
                        'Ok',
                        style: GreekTextStyle.heading4,
                      ),
                      style: TextButton.styleFrom(
                        backgroundColor: ConstantColors.white,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  //=====================================================================
  static messageDialogCDSLPledge(BuildContext context, String msg) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              height: 330.0,
              padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 10),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      AppConfig().appName,
                      style: GreekTextStyle.headline6,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Flexible(
                    fit: FlexFit.loose,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Text(
                          msg,
                          style: GreekTextStyle.headline20,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 40.0,
                    width: MediaQuery.of(buildcontext).size.width / 1.5,
                    //  padding: const EdgeInsets.only(left: 30.0, right: 30.0),
                    child: TextButton(
                      onPressed: () =>
                          GreekNavigator.pop(context: buildcontext),
                      child: Text(
                        'Ok',
                        style: GreekTextStyle.heading4,
                      ),
                      style: TextButton.styleFrom(
                        backgroundColor: ConstantColors.white,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  //=====================================================================
  ///
  /// Show Dialog with custome message
  //
  /// message - Custome message
  ///
  //=====================================================================
  static confirmLogOutDialog(BuildContext context) {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (dialogContext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: dialogContext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              height: 200.0,
              padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 10),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      AppConfig().appName,
                      style: GreekTextStyle.headlineAppName20,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Flexible(
                    fit: FlexFit.loose,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Text(
                          'Do you want to logout?',
                          style: GreekTextStyle.headline20,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: 40.0,
                        width: 100,
                        child: TextButton(
                          onPressed: () {
                            GreekNavigator.pop(context: dialogContext);
                            GreekBase().logoutApp(logoffContext: dialogContext);
                          },
                          child: Text(
                            'Confirm',
                            style: GreekTextStyle.heading4,
                          ),
                          style: TextButton.styleFrom(
                            backgroundColor: ConstantColors.white,
                            padding: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(color: Colors.grey),
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 40.0,
                        width: 100,
                        child: TextButton(
                          onPressed: () =>
                              GreekNavigator.pop(context: dialogContext),
                          child: Text(
                            'Cancel',
                            style: GreekTextStyle.heading4,
                          ),
                          style: TextButton.styleFrom(
                            backgroundColor: ConstantColors.white,
                            padding: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(color: Colors.grey),
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  //=====================================================================

  //=====================================================================
  ///
  /// Show Dialog with custome message or custome call back
  ///
  /// message - Custome message
  ///
  /// onPressed - The callback that is called when the button is tapped or otherwise activated
  ///
  //=====================================================================
  static customeCallBackDialog({
    required BuildContext context,
    required String message,
    required ValueChanged<BuildContext> onPressed,
    String buttonTitle = ConstantMessages.GREEK_OK,
  }) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (dialogContext) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          elevation: 0,
          backgroundColor: Colors.transparent,
          child: Container(
            height: 250.0,
            padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
            decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                color: ConstantColors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.grey, offset: Offset(0, 8), blurRadius: 10),
                ]),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    AppConfig().appName,
                    style: GreekTextStyle.headlineAppName20,
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Flexible(
                  fit: FlexFit.loose,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                      child: Text(
                        message,
                        style: GreekTextStyle.heading19,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  height: 40.0,
                  width: MediaQuery.of(dialogContext).size.width / 1.5,
                  child: TextButton(
                    onPressed: () => onPressed(dialogContext),
                    child: Text(
                      buttonTitle,
                      style: GreekTextStyle.heading4,
                    ),
                    style: TextButton.styleFrom(
                      backgroundColor: ConstantColors.white,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                        side: const BorderSide(color: Colors.grey),
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  //=====================================================================

  //=====================================================================
  ///
  /// Show Dialog with custome message or custome call back
  ///
  /// message - Custome message
  ///
  /// onPressed - The callback that is called when the button is tapped or otherwise activated
  ///
  //=====================================================================
  static customeCallBackWithCancelButtonDialog({
    required BuildContext context,
    required String message,
    required ValueChanged<BuildContext> onPressed,
    String buttonTitle = ConstantMessages.GREEK_OK,
    Color buttonTitleColor = ConstantColors.black,
  }) {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0)), //this right here
        child: SizedBox(
          height: 180.0,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding:
                    const EdgeInsets.only(left: 20.0, bottom: 8.0, top: 18.0),
                child: Text(
                  AppConfig().appName,
                  textAlign: TextAlign.start,
                  style: GreekTextStyle.headlineAppName20,
                ),
              ),
              const Divider(
                color: Colors.grey,
                height: 2,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 50,
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                        child: Text(
                          message,
                          textAlign: TextAlign.start,
                          style: GreekTextStyle.headline1,
                        ),
                      ),
                    ),
                    const Divider(
                      color: Colors.grey,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () =>
                                GreekNavigator.pop(context: dialogContext),
                            child: const Text(
                              'Cancel',
                              style: TextStyle(color: ConstantColors.black),
                            ),
                          ),
                        ),
                        const SizedBox(
                            height: 45.0,
                            child: VerticalDivider(color: Colors.grey)),
                        Expanded(
                          child: TextButton(
                            onPressed: () => onPressed(dialogContext),
                            child: Text(
                              buttonTitle,
                              style: TextStyle(
                                color: buttonTitleColor,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  //=====================================================================

  //=====================================================================
  ///
  /// Show Dialog with custome textfield
  ///
  /// title - Dialog Title name
  ///
  /// child - Custome textfield widget
  ///
  /// confirmPress - The callback that is called when the button is tapped or otherwise activated
  ///
  /// cancelTitle - Cancel Button Title
  ///
  /// confirmTitle - Confirm Button Title
  ///
  //=====================================================================
  static textfieldDialog(
      {required BuildContext context,
      required String title,
      required Widget child,
      required ValueChanged<BuildContext> confirmPressed,
      String cancelTitle = ConstantMessages.GREEK_CANCEL,
      String confirmTitle = ConstantMessages.CP_CONFIRM_BTN}) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0)), //this right here
        child: WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: context);
            return true;
          },
          child: SizedBox(
            height: 200.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.only(left: 20.0, bottom: 8.0, top: 18.0),
                  child: Text(
                    title,
                    textAlign: TextAlign.start,
                    style: GreekTextStyle.headline22,
                  ),
                ),
                const Divider(
                  color: Colors.grey,
                  height: 2,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(child: child),
                      ),
                      const Divider(
                        color: Colors.grey,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: TextButton(
                              onPressed: () =>
                                  GreekNavigator.pop(context: dialogContext),
                              child: Text(
                                cancelTitle,
                                style: const TextStyle(
                                  color: ConstantColors.black,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 45,
                            child: VerticalDivider(
                              color: ConstantColors.dividerColor,
                            ),
                          ),
                          Expanded(
                            child: TextButton(
                              onPressed: () => confirmPressed(dialogContext),
                              child: Text(
                                confirmTitle,
                                style: const TextStyle(
                                  color: ConstantColors.black,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //=====================================================================
  ///
  /// Show Dialog with custome textfield
  ///
  /// title - Dialog Title name
  ///
  /// child - Custome textfield widget
  ///
  /// confirmPress - The callback that is called when the button is tapped or otherwise activated
  ///
  /// cancelTitle - Cancel Button Title
  ///
  /// confirmTitle - Confirm Button Title
  ///
  //=====================================================================
  static textfieldDialogRename(
      {required BuildContext context,
      required String title,
      required Widget child,
      required ValueChanged<BuildContext> confirmPressed,
      String cancelTitle = ConstantMessages.GREEK_CANCEL,
      String confirmTitle = ConstantMessages.CP_CONFIRM_BTN}) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0)), //this right here
        child: WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: context);
            return true;
          },
          child: SizedBox(
            height: 200.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.only(left: 20.0, bottom: 8.0, top: 18.0),
                  child: Text(
                    title,
                    textAlign: TextAlign.start,
                    style: GreekTextStyle.headline22,
                  ),
                ),
                const Divider(
                  color: Colors.grey,
                  height: 2,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(child: child),
                      ),
                      const Divider(
                        color: Colors.grey,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: TextButton(
                              onPressed: () =>
                                  GreekNavigator.pop(context: dialogContext),
                              child: Text(
                                cancelTitle,
                                style: const TextStyle(
                                  color: ConstantColors.black,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 45,
                            child: VerticalDivider(
                              color: ConstantColors.dividerColor,
                            ),
                          ),
                          Expanded(
                            child: TextButton(
                              onPressed: () => confirmPressed(dialogContext),
                              child: Text(
                                confirmTitle,
                                style: const TextStyle(
                                  color: ConstantColors.black,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //=====================================================================

  //=====================================================================
  ///
  /// Show Dialog for OTP
  ///
  /// title - Dialog Title name
  ///
  /// child - Custome textfield widget
  ///
  /// sendPressed - The send callback that is called when the button is tapped or otherwise activated
  ///
  /// resendPressed - The Resend callback that is called when the button is tapped or otherwise activated
  ///
  //=====================================================================
  static otpDialog({
    required BuildContext context,
    required Widget child,
    required ValueChanged<BuildContext> sendPressed,
    required ValueChanged<BuildContext> resendPressed,
  }) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (dialogContext) => Dialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: context);
            return true;
          },
          child: SizedBox(
            height: 290,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.only(left: 20.0, bottom: 8.0, top: 18.0),
                  child: Text(
                    'Enter OTP',
                    textAlign: TextAlign.start,
                    style: GreekTextStyle.headline22,
                  ),
                ),
                const Divider(
                  color: ConstantColors.dividerColor,
                  height: 2,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(child: child),
                      ),
                      const Divider(
                        color: ConstantColors.dividerColor,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: TextButton(
                              onPressed: () => resendPressed(dialogContext),
                              child: const Text(
                                ConstantMessages.GREEK_RESEND,
                                style: TextStyle(
                                  color: ConstantColors.black,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 45.0,
                            child: VerticalDivider(
                              color: ConstantColors.dividerColor,
                            ),
                          ),
                          Expanded(
                            child: TextButton(
                              onPressed: () => sendPressed(dialogContext),
                              child: const Text(
                                ConstantMessages.GREEK_SEND,
                                style: TextStyle(
                                  color: ConstantColors.black,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(
                        color: ConstantColors.dividerColor,
                      ),
                      Center(
                        child: TextButton(
                          onPressed: () =>
                              GreekNavigator.pop(context: dialogContext),
                          child: const Text(
                            ConstantMessages.GREEK_CANCEL,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: ConstantColors.black),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //=====================================================================

  //=====================================================================
  ///
  /// Show Model Bottom Sheet for Watchlist Group Name
  ///
  /// userAction - A callback function for perform user action like delete, select or create group
  ///
  //=====================================================================
  static showBottomShhetForWatchList({
    required BuildContext context,
    required List<String> groups,
  }) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
        ),
      ),
      backgroundColor: ConstantColors.primaryColor,
      builder: (sheetContext) {
        return SizedBox(
          height: 350.0,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              10.0,
              21.0,
              10.0,
              10.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Material(
                  child: Container(
                    color: ConstantColors.primaryColor,
                    height: 50,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          ConstantMessages.GREEK_CREATE_NEW_WATCHLIST_TXT,
                          style: GreekTextStyle.headline2,
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.edit,
                            size: 20.0,
                          ),
                          alignment: Alignment.centerLeft,
                          onPressed: () {
                            GreekNavigator.pop(context: sheetContext);

                            if (groups.length < 5) {
                              GreekBase()
                                  .userActionForWatchListCreateObserver
                                  .sink
                                  .add(true);
                            } else {
                              GreekDialogPopupView.messageDialog(
                                sheetContext,
                                ConstantMessages.GREEK_CREATE_WATCHLIST_MSG,
                              );
                            }
                          },
                        ),
                        Expanded(
                          child: IconButton(
                            icon: const Icon(
                              Icons.close,
                              size: 20.0,
                            ),
                            alignment: Alignment.centerRight,
                            onPressed: () {
                              GreekNavigator.pop(context: context);
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  color: ConstantColors.dividerColor,
                  height: 8,
                ),
                Expanded(
                  child: Material(
                    child: Container(
                      color: ConstantColors.primaryColor,
                      child: ListView.builder(
                        itemCount: groups.length,
                        itemBuilder: (context, index) {
                          return SizedBox(
                            height: 40.0,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: InkWell(
                                    /* splashColor: Colors.transparent,
                                    highlightColor: Colors.transparent, */
                                    onTap: () {
                                      GreekNavigator.pop(context: sheetContext);
                                      GreekBase()
                                          .userActionForWatchListSelectObserver
                                          .sink
                                          .add(index);
                                    },
                                    child: Row(
                                      children: [
                                        Text(
                                          groups[index],
                                          textAlign: TextAlign.start,
                                          style: const TextStyle(
                                            color: ConstantColors.black,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.delete_outline_outlined,
                                    size: 20.0,
                                  ),
                                  alignment: Alignment.centerRight,
                                  onPressed: () {
                                    GreekNavigator.pop(context: sheetContext);

                                    GreekBase()
                                        .userActionForWatchListDeleteObserver
                                        .sink
                                        .add(index);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  //=====================================================================
  ///
  /// Dismiss/Hide Old Dialog Popup
  ///
  //=====================================================================
  static void dismissOldDialogPopup() {
    if (oldOrderDialogContext != null) {
      GreekNavigator.pop(context: oldOrderDialogContext!);
    }
    oldOrderDialogContext = null;
  }

  //=====================================================================

  //=====================================================================
  ///
  /// Show Dialog for Confirm Logout
  ///
  ///
  //=====================================================================
  static confirmOrderDialog({
    required BuildContext context,
    required OrderDetailsModel obj,
    required OrderMode orderMode,
  }) {
    final confirmMap = obj.toConfirmDialog();
    final keyArray = confirmMap.keys.toList();

    // if (oldOrderDialogContext != null) {
    //   dismissOldDialogPopup();
    // }

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (dialogContext) {
        oldOrderDialogContext = dialogContext;

        return WillPopScope(
          onWillPop: () async {
            dismissOldDialogPopup();
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0)), //this right here
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(bottom: 15.0),
                    child: Text(
                      "Order Preview",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 24.0),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        obj.tradeSymbol ?? '',
                        style: const TextStyle(
                            fontSize: 16.0, color: Colors.black),
                      ),
                    ),
                  ),
                  Flexible(
                    fit: FlexFit.loose,
                    child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemCount: keyArray.length,
                      itemBuilder: (context, index) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: 120.0,
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10.0),
                                  child: Text(
                                    keyArray[index],
                                    style: const TextStyle(
                                      fontSize: 15.0,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: SizedBox(
                                  height: 30,
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 10.0),
                                    child: Text(
                                      ' -  ' + confirmMap[keyArray[index]],
                                      style: const TextStyle(
                                        fontSize: 15.0,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: 50.0,
                    child: Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.only(top: 5.0, bottom: 5.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 20.0, right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(5),
                                boxShadow: const <BoxShadow>[
                                  BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 8,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: const MaterialButton(
                                onPressed: dismissOldDialogPopup,
                                child: Text('Cancel'),
                              ),
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 10.0, right: 20.0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: const <BoxShadow>[
                                  BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 8,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: MaterialButton(
                                onPressed: () {
                                  dismissOldDialogPopup();
                                  GreekNavigator.pop(context: context);
                                  switch (orderMode) {
                                    case OrderMode.squareoffOrder:
                                      SocketIOManager().placeNewOrder(
                                        data: obj.toNewOrder(),
                                      );
                                      break;
                                    case OrderMode.newOrder:
                                      SocketIOManager().placeNewOrder(
                                        data: obj.toNewOrder(),
                                      );
                                      break;
                                    case OrderMode.modiftyOrder:
                                      SocketIOManager().placeModifyOrder(
                                        data: obj.toModifyOrder(),
                                      );
                                      break;
                                  }
                                },
                                child: const Text(
                                  'Confirm',
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

//=====================================================================

  //=====================================================================
  ///
  /// Show Dialog for selecting Exchange for holding
  ///
  /// obj - Show order info and send request
  ///
  //=====================================================================
  static selectExchangeForHolding(
      BuildContext context,
      AsyncSnapshot<holding.StockDetails> snapshot,
      DismissDirection direction) {
    showModalBottomSheet(
      context: context,
      useRootNavigator: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
        ),
      ),
      backgroundColor: ConstantColors.primaryColor,
      builder: (sheetContext) {
        return SizedBox(
          height: 200.0,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              10.0,
              21.0,
              10.0,
              10.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Material(
                  child: Container(
                    color: ConstantColors.primaryColor,
                    height: 30,
                    alignment: Alignment.center,
                    child: Text(
                      'Select Exchange',
                      style: GreekTextStyle.headline2,
                    ),
                  ),
                ),
                const Divider(
                  color: ConstantColors.dividerColor,
                  height: 8,
                ),
                const SizedBox(height: 20.0),
                InkWell(
                  onTap: () async {
                    GreekNavigator.pop(context: context);

                    await GreekNavigator.pushNamed(
                      context: context,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.nSEToken ?? '0'),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );
                  },
                  child: Container(
                    height: 40.0,
                    alignment: Alignment.center,
                    child: Text(
                      'NSE',
                      style: GreekTextStyle.headline20,
                    ),
                  ),
                ),
                const SizedBox(height: 10.0),
                InkWell(
                  onTap: () async {
                    GreekNavigator.pop(context: context);
                    await GreekNavigator.pushNamed(
                      context: context,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.bSEToken ?? '0'),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );
                  },
                  child: Container(
                    height: 40.0,
                    alignment: Alignment.center,
                    child: Text(
                      'BSE',
                      style: GreekTextStyle.headline20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

//=====================================================================

  //=====================================================================
  ///
  /// Show Dialog for selecting Exchange for holding
  ///
  /// obj - Show order info and send request
  ///
  //=====================================================================
  static selectExchangeForPosition(BuildContext context,
      AsyncSnapshot<StockDetailss> snapshot, DismissDirection direction) {
    showModalBottomSheet(
      context: context,
      useRootNavigator: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
        ),
      ),
      backgroundColor: ConstantColors.primaryColor,
      builder: (sheetContext) {
        return SizedBox(
          height: 200.0,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              10.0,
              21.0,
              10.0,
              10.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Material(
                  child: Container(
                    color: ConstantColors.primaryColor,
                    height: 30,
                    alignment: Alignment.center,
                    child: Text(
                      'Select Exchange',
                      style: GreekTextStyle.headline2,
                    ),
                  ),
                ),
                const Divider(
                  color: ConstantColors.dividerColor,
                  height: 8,
                ),
                const SizedBox(height: 20.0),
                InkWell(
                  onTap: () async {
                    GreekNavigator.pop(context: context);

                    await GreekNavigator.pushNamed(
                      context: context,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.nSEToken ?? '0'),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );
                  },
                  child: Container(
                    height: 40.0,
                    alignment: Alignment.center,
                    child: Text(
                      'NSE',
                      style: GreekTextStyle.headline20,
                    ),
                  ),
                ),
                const SizedBox(height: 10.0),
                InkWell(
                  onTap: () async {
                    GreekNavigator.pop(context: context);
                    await GreekNavigator.pushNamed(
                      context: context,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.bSEToken ?? '0'),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );
                  },
                  child: Container(
                    height: 40.0,
                    alignment: Alignment.center,
                    child: Text(
                      'BSE',
                      style: GreekTextStyle.headline20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

//=====================================================================

  //=====================================================================
  ///
  /// Show Dialog for Order Response
  ///
  /// obj - Show order info and send request
  ///
  //=====================================================================
  static orderResponseDialog({
    required BuildContext? popContext,
    required Map<String, dynamic> response,
    required ValueChanged<OrderScreenState> onPressed,
    required IrisResponseStreamingType irisResponseStreamingType,
  }) {
    if (popContext != null) {
      OrderScreenState orderStatus = OrderScreenState.unknown;
      final orderResponseMap = <String, String>{};

      switch (irisResponseStreamingType) {
        // For Order Confirm, Pending or Price Confirm
        case IrisResponseStreamingType.OrderResponse:
          orderStatus = OrderScreenState.pending;

          int orderState =
              int.parse(response['order_state']?.toString() ?? '-1');

          switch (orderState) {
            case 0:
              orderResponseMap['State'] = 'Order Confirm';
              break;

            case 1:
              orderResponseMap['State'] = 'Modify Confirm';
              break;

            case 2:
              orderStatus = OrderScreenState.canceled;
              orderResponseMap['State'] = 'Order Cancelled';
              break;

            case 3:
              orderResponseMap['State'] = 'Order Triggered';
              break;

            default:
              orderResponseMap['State'] = '';
              break;
          }

          orderResponseMap['Exchange'] =
              int.parse(response['gtoken']).toExchange().toUpperCase();
          orderResponseMap['Mkt.Segment'] = response['instrument'];
          orderResponseMap['Ref. No'] = response['gorderid'];
          orderResponseMap['Exchange Order No'] = response['eorderid'];
          orderResponseMap['Product'] = GreekBase()
              .getProductNameFromProductToken(
                  int.parse(response['product'].toString()));
          orderResponseMap['Price'] = response['price'];
          orderResponseMap['Qty'] = response['qty'];
          orderResponseMap['Pending Quantity'] = response['pending_qty'];
          orderResponseMap['Order Type'] = GreekBase()
              .getOrderNameFromOrderToken(
                  int.parse(response['order_type']?.toString() ?? ''));
          orderResponseMap['Trigger Price'] =
              response['trigger_price'].toString();

          response['side'] == '1'
              ? orderResponseMap['Action'] = 'BUY'
              : orderResponseMap['Action'] = 'SELL';

          int goodTillDate =
              int.parse(response['goodTillDate']?.toString() ?? '-1');
          int validity = int.parse(response['validity']?.toString() ?? '-1');
          orderResponseMap['Validity'] = GreekBase()
              .getValidityFromBitwiseOprater(
                  goodTillDate: goodTillDate, validity: validity);

          orderResponseMap['Order Status'] = response['order_status'];
          break;

        // For Order Trigger
        case IrisResponseStreamingType.TriggerResponse:
          orderStatus = OrderScreenState.pending;

          String confirmSymbol = response["symbol"]?.toString() ?? '';
          orderResponseMap['Order Status'] =
              confirmSymbol + response['order_status'];
          orderResponseMap['Exchange'] =
              int.parse(response['gtoken']).toExchange();
          orderResponseMap['Mkt.Segment'] = response['instrument'];
          orderResponseMap['Ref. No'] = response['gorderid'];
          orderResponseMap['Exchange Order No'] = response['eorderid'];
          orderResponseMap['Product'] = GreekBase()
              .getProductNameFromProductToken(
                  int.parse(response['product'].toString()));

          response['side'] == '1'
              ? orderResponseMap['Action'] = 'BUY'
              : orderResponseMap['Action'] = 'SELL';
          orderResponseMap['Traded Qty'] = response['traded_qty'];

          if (response['order_type'] == '3' || response['order_type'] == '4') {
            orderResponseMap['Trigger Price'] =
                response['trigger_price'].toString();
          }

          if (int.parse(response['gtoken']).toAssetType().toLowerCase() ==
              "currency") {
            /*  orderResponseMap['Trigger Price'] =
                double.parse(response['trigger_price'])
                    .toStringAsExponential(4); */
            orderResponseMap['Trigger Price'] = response['trigger_price'];
          } else {
            /* orderResponseMap['Trigger Price'] =
                double.parse(response['trigger_price'])
                    .toStringAsExponential(2); */
            orderResponseMap['Trigger Price'] = response['trigger_price'];
          }

          // if (int.parse(response['gtoken']).toAssetType().toLowerCase() == "currency") {
          // orderResponseMap['Traded Price'] = response['price'];
          // double.parse(response['price']).toStringAsExponential(4);
          // } else {
          // orderResponseMap['Traded Price'] = response['price'];
          // double.parse(response['price']).toStringAsExponential(2);
          // }
          orderResponseMap['Pending Qty'] = response['pending_qty'];
          orderResponseMap['Total Order Qty'] = response['qty'];
          break;

        // For Order Rejected
        case IrisResponseStreamingType.OrderRejectionResponse:
          orderStatus = OrderScreenState.rejected;

          String statusCode = '';
          String getQty = '';
          String getPendingQty = '';

          if (int.parse(response['gtoken']).toExchange().toUpperCase() ==
                  "MCX" ||
              int.parse(response['gtoken']).toExchange().toUpperCase() ==
                  "NCDEX") {
            getQty =
                '${(int.parse(response['qty']) / (int.parse(response['regular_lot'])))}';
            getPendingQty =
                '${(int.parse(response['pending_qty']) / (int.parse(response['regular_lot'])))}';
          } else {
            getQty = response['qty'];
            getPendingQty = response['pending_qty'];
          }

          if (response['code'] == '0' ||
              response['code'] == '201' ||
              response['code'] == '202' ||
              response['code'] == '101' ||
              response['code'] == '102' ||
              response['code'] == '502' ||
              response['code'] == '1302' ||
              response['code'] == '1301') {
            statusCode = "Success";
          } else if (int.parse(response['gtoken']).toExchange().toUpperCase() ==
              "NCDEX") {
            statusCode = "Error Code : " +
                response['code'] +
                "\n Reason : " +
                response['reason'];
          } else {
            statusCode = RequiredFunction().getErrorMessage(
                RequiredFunction().getMarketId(response['gtoken']),
                response['code']);
          }

          orderResponseMap['Order Status'] =
              response['order_status'] + " Order Rejected";
          orderResponseMap['Exchange'] =
              int.parse(response['gtoken']).toExchange().toUpperCase();
          orderResponseMap['Mkt.Segment'] = response['instrument'];
          orderResponseMap['Ref. No'] = response['gorderid'];
          orderResponseMap['Exchange Order No'] = response['eorderid'];
          orderResponseMap['Product'] = GreekBase()
              .getProductNameFromProductToken(
                  int.parse(response['product'].toString()));
          orderResponseMap['Price'] = response['price'];
          orderResponseMap['Qty'] = getQty;
          orderResponseMap['Pending Quantity'] = getPendingQty;
          orderResponseMap['Order Type'] = GreekBase()
              .getOrderNameFromOrderToken(
                  int.parse(response['order_type']?.toString() ?? ''));
          response['side'] == '1'
              ? orderResponseMap['Side'] = 'BUY'
              : orderResponseMap['Side'] = 'SELL';

          int goodTillDate =
              int.parse(response['goodTillDate']?.toString() ?? '-1');
          int validity = int.parse(response['validity']?.toString() ?? '-1');
          orderResponseMap['Validity'] = GreekBase()
              .getValidityFromBitwiseOprater(
                  goodTillDate: goodTillDate, validity: validity);
          orderResponseMap['Reason'] = statusCode;
          break;

        // For Order Execution or Partial Execution
        // multiple time code done dont know why.. need to change in both the code
        case IrisResponseStreamingType.TradeResponse:
          orderStatus = OrderScreenState.tradeed;

          orderResponseMap['Order Status'] = response['order_status'];
          orderResponseMap['Exchange'] =
              int.parse(response['gtoken']).toExchange();
          orderResponseMap['Mkt.Segment'] = response['instrument'];
          orderResponseMap['Ref. No'] = response['gorderid'];
          orderResponseMap['Exchange Order No'] = response['eorderid'];
          orderResponseMap['Trade No'] =
              response['tradeid']; //=====================
          if (int.parse(response['expiryDate'].toString()) != 0) {
            orderResponseMap['Expiry Date'] = RequiredFunction()
                .getDateFromTimeStamp(int.parse(response['expiryDate'] ?? ''));
          } else {
            orderResponseMap['Expiry Date'] = "";
          }

          orderResponseMap['Product'] = GreekBase()
              .getProductNameFromProductToken(
                  int.parse(response['product'].toString()));

          response['side'] == '1'
              ? orderResponseMap['Action'] = 'BUY'
              : orderResponseMap['Action'] = 'SELL';
          orderResponseMap['Traded Qty'] = response['traded_qty'];

          if (response['order_type'] == '3' || response['order_type'] == '4') {
            orderResponseMap['Trigger Price'] =
                response['trigger_price'].toString();
          }

          var tradePrice = '';
          if (response['traded_price'] != null) {
            tradePrice = response['traded_price'].toString();
          }
          orderResponseMap['Traded Price'] = tradePrice;

          var pendingQty = '';
          if (response['pendingQty'] != null) {
            pendingQty = response['pendingQty'];
          } else if (response['pending_qty'] != null) {
            pendingQty = response['pending_qty'];
          }
          orderResponseMap['Pending Qty'] = pendingQty.toString();
          orderResponseMap['Total Order Qty'] = response['qty'];
          break;

        // For RMS Rejected
        case IrisResponseStreamingType.RmsRejectionResponse:
          orderStatus = OrderScreenState.rejected;

          orderResponseMap['Order Status'] = response['order_status'];
          orderResponseMap['Mkt.Segment'] = response['instrument'];
          orderResponseMap['Ref. No'] = response['gorderid'];
          orderResponseMap['Reason'] = response['reason'];
          break;

        default:
          break;
      }

      final keyArray = orderResponseMap.keys.toList();
      var globalContext = GreekBase().drawerKey.currentState?.context;
      if (AppFlagConstant().orderResponseDialogcounter > 0 &&
          globalContext != null) {
        do {
          GreekNavigator.pop(context: globalContext);
          AppFlagConstant().orderResponseDialogcounter--;
        } while (AppFlagConstant().orderResponseDialogcounter > 0);
      } else {
        if (IrisResponseStreamingType.TriggerResponse ==
                irisResponseStreamingType &&
            globalContext != null) {
          GreekNavigator.pop(context: globalContext);
          AppFlagConstant().orderResponseDialogcounter--;
        }
      }
      if (AppFlagConstant().orderResponseDialogcounter == 0) {
        oldOrderDialogContext = null;
      }

      AppFlagConstant().orderResponseDialogcounter++;
      /* Fluttertoast.showToast(
        msg: "Order Pop Called",
        toastLength: Toast.LENGTH_LONG,
      ); */
      showDialog(
        barrierDismissible: true,
        barrierColor: Colors.transparent,
        context: popContext,
        builder: (BuildContext dialogContext) {
          oldOrderDialogContext = dialogContext;

          return WillPopScope(
            onWillPop: () async {
              dismissOldDialogPopup();
              return true;
            },
            child: Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ), //this right here
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 15.0),
                      child: Text(
                        AppConfig().appName,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 24.0),
                      ),
                    ),
                    const SizedBox(
                      height: 10.0,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 15.0),
                      child: Text(
                        response['symbol'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 24.0),
                      ),
                    ),
                    const SizedBox(
                      height: 10.0,
                    ),
                    Flexible(
                      // height: 500,
                      fit: FlexFit.loose,
                      child: ListView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemCount: keyArray.length,
                        itemBuilder: (context, index) {
                          return Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: (keyArray[index]
                                            .toUpperCase()
                                            .compareTo('REASON') ==
                                        0)
                                    ? CrossAxisAlignment.start
                                    : CrossAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 100.0,
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 10.0),
                                        child: Text(
                                          keyArray[index],
                                          style: const TextStyle(
                                            fontSize: 15.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 20.0,
                                    child: Text(
                                      ' -  ',
                                      style: TextStyle(
                                        fontSize: 15.0,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: SizedBox(
                                        //height: 30,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 10.0),
                                          child: (keyArray[index]
                                                      .toUpperCase()
                                                      .compareTo('REASON') ==
                                                  0)
                                              ? const Text('')
                                              : Text(
                                                  orderResponseMap[
                                                          keyArray[index]] ??
                                                      '',
                                                  style: TextStyle(
                                                    fontSize: 15.0,
                                                    fontWeight: (keyArray[index]
                                                                .toLowerCase()
                                                                .compareTo(
                                                                    'state') ==
                                                            0)
                                                        ? FontWeight.bold
                                                        : FontWeight.normal,
                                                  ),
                                                ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              (keyArray[index]
                                          .toUpperCase()
                                          .compareTo('REASON') ==
                                      0)
                                  ? Text(
                                      orderResponseMap[keyArray[index]] ?? '',
                                      style: TextStyle(
                                        fontSize: 15.0,
                                        fontWeight: (keyArray[index]
                                                    .toLowerCase()
                                                    .compareTo('state') ==
                                                0)
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    )
                                  : const Text('')
                            ],
                          );
                        },
                      ),
                    ),
                    SizedBox(
                      height: 50.0,
                      child: Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.only(top: 5.0, bottom: 5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 20.0, right: 10.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5),
                                  // boxShadow: const <BoxShadow>[
                                  //   BoxShadow(
                                  //     color: Colors.grey,
                                  //     blurRadius: 8,
                                  //     offset: Offset(0, 0),
                                  //   ),
                                  // ],
                                ),
                                child: MaterialButton(
                                  onPressed: () {
                                    if (AppFlagConstant()
                                            .orderResponseDialogcounter >
                                        0) {
                                      do {
                                        GreekNavigator.pop(
                                            context: dialogContext);
                                        AppFlagConstant()
                                            .orderResponseDialogcounter--;
                                      } while (AppFlagConstant()
                                              .orderResponseDialogcounter >
                                          0);
                                    }

                                    onPressed(orderStatus);
                                  },
                                  child: const Text('OK'),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    }
  }
//=====================================================================

  //=====================================================================
  ///
  /// Show Dialog Trade Order Response
  ///
  //=====================================================================

/*
  static showTradeOrderDialog({
    required BuildContext buildContext,
    required Map<String, dynamic> response,
    required IrisResponseStreamingType irisResponseStreamingType,
    required ValueChanged<OrderScreenState> onPressed,
  })
   {
    OrderScreenState orderStatus = OrderScreenState.unknown;
    final orderResponseMap = <String, String>{};

    switch (irisResponseStreamingType) {
      // For Order Confirm, Pending or Price Confirm
      case IrisResponseStreamingType.OrderResponse:
        // orderStatus = OrderScreenState.pending;

        int orderState = int.parse(response['order_state']?.toString() ?? '-1');

        switch (orderState) {
          case 0:
            orderResponseMap['State'] = 'Order Confirm';
            break;

          case 1:
            orderResponseMap['State'] = 'Modify Confirm';
            break;

          case 2:
            orderStatus = OrderScreenState.canceled;
            orderResponseMap['State'] = 'Order Cancelled';
            break;

          case 3:
            orderResponseMap['State'] = 'Order Triggered';
            break;

          default:
            orderResponseMap['State'] = '';
            break;
        }

        orderResponseMap['Exchange'] = int.parse(response['gtoken']).toExchange().toUpperCase();
        orderResponseMap['Mkt.Segment'] = response['instrument'];
        orderResponseMap['Ref. No'] = response['gorderid'];
        orderResponseMap['Exchange Order No'] = response['eorderid'];
        orderResponseMap['Product'] = GreekBase().getProductNameFromProductToken(int.parse(response['product'].toString()));
        orderResponseMap['Price'] = response['price'];
        orderResponseMap['Qty'] = response['qty'];
        orderResponseMap['Pending Quantity'] = response['pending_qty'];
        orderResponseMap['Order Type'] = GreekBase().getOrderNameFromOrderToken(int.parse(response['order_type']?.toString() ?? ''));
        orderResponseMap['Trigger Price'] = response['trigger_price'].toString();

        response['side'] == '1' ? orderResponseMap['Action'] = 'BUY' : orderResponseMap['Action'] = 'SELL';

        int goodTillDate = int.parse(response['goodTillDate']?.toString() ?? '-1');
        int validity = int.parse(response['validity']?.toString() ?? '-1');
        orderResponseMap['Validity'] = GreekBase().getValidityFromBitwiseOprater(goodTillDate: goodTillDate, validity: validity);

        orderResponseMap['Order Status'] = response['order_status'];
        break;

// For Order Trigger
      case IrisResponseStreamingType.TriggerResponse:
        orderStatus = OrderScreenState.tradeed;

        String confirmSymbol = response["symbol"]?.toString() ?? '';
        orderResponseMap['Order Status'] = confirmSymbol + response['order_status'];
        orderResponseMap['Exchange'] = int.parse(response['gtoken']).toExchange();
        orderResponseMap['Mkt.Segment'] = response['instrument'];
        orderResponseMap['Ref. No'] = response['gorderid'];
        orderResponseMap['Exchange Order No'] = response['eorderid'];
        orderResponseMap['Product'] = GreekBase().getProductNameFromProductToken(int.parse(response['product'].toString()));

        response['side'] == '1' ? orderResponseMap['Action'] = 'BUY' : orderResponseMap['Action'] = 'SELL';
        orderResponseMap['Traded Qty'] = response['traded_qty'];

        if (response['order_type'] == '3' || response['order_type'] == '4') {
          orderResponseMap['Trigger Price'] = response['trigger_price'].toString();
        }

        if (int.parse(response['gtoken']).toAssetType().toLowerCase() == "currency") {
          /*  orderResponseMap['Trigger Price'] =
                double.parse(response['trigger_price'])
                    .toStringAsExponential(4); */
          orderResponseMap['Trigger Price'] = response['trigger_price'];
        } else {
          /* orderResponseMap['Trigger Price'] =
                double.parse(response['trigger_price'])
                    .toStringAsExponential(2); */
          orderResponseMap['Trigger Price'] = response['trigger_price'];
        }

        // if (int.parse(response['gtoken']).toAssetType().toLowerCase() == "currency") {
        //   orderResponseMap['Traded Price'] = response['price'];
        //   // double.parse(response['price']).toStringAsExponential(4);
        // } else {
        //   orderResponseMap['Traded Price'] = response['price'];
        //   // double.parse(response['price']).toStringAsExponential(2);
        // }
        orderResponseMap['Pending Qty'] = response['pendingQty'];
        orderResponseMap['Total Order Qty'] = response['qty'];
        break;

      // For Order Rejected
      case IrisResponseStreamingType.OrderRejectionResponse:
        orderStatus = OrderScreenState.rejected;

        String statusCode = '';
        String getQty = '';
        String getPendingQty = '';

        if (int.parse(response['gtoken']).toExchange().toUpperCase() == "MCX" || int.parse(response['gtoken']).toExchange().toUpperCase() == "NCDEX") {
          getQty = '${(int.parse(response['qty']) / (int.parse(response['regular_lot'])))}';
          getPendingQty = '${(int.parse(response['pending_qty']) / (int.parse(response['regular_lot'])))}';
        } else {
          getQty = response['qty'];
          getPendingQty = response['pending_qty'];
        }

        if (response['code'] == '0' || response['code'] == '201' || response['code'] == '202' || response['code'] == '101' || response['code'] == '102' || response['code'] == '502' || response['code'] == '1302' || response['code'] == '1301') {
          statusCode = "Success";
        } else if (int.parse(response['gtoken']).toExchange().toUpperCase() == "NCDEX") {
          statusCode = "Error Code : " + response['code'] + "\n Reason : " + response['reason'];
        } else {
          statusCode = RequiredFunction().getErrorMessage(RequiredFunction().getMarketId(response['gtoken']), response['code']);
        }

        orderResponseMap['Order Status'] = response['order_status'] + " Order Rejected";
        orderResponseMap['Exchange'] = int.parse(response['gtoken']).toExchange().toUpperCase();
        orderResponseMap['Mkt.Segment'] = response['instrument'];
        orderResponseMap['Ref. No'] = response['gorderid'];
        orderResponseMap['Exchange Order No'] = response['eorderid'];
        orderResponseMap['Product'] = GreekBase().getProductNameFromProductToken(int.parse(response['product'].toString()));
        orderResponseMap['Price'] = response['price'];
        orderResponseMap['Qty'] = getQty;
        orderResponseMap['Pending Quantity'] = getPendingQty;
        orderResponseMap['Order Type'] = GreekBase().getOrderNameFromOrderToken(int.parse(response['order_type']?.toString() ?? ''));
        response['side'] == '1' ? orderResponseMap['Side'] = 'BUY' : orderResponseMap['Side'] = 'SELL';

        int goodTillDate = int.parse(response['goodTillDate']?.toString() ?? '-1');
        int validity = int.parse(response['validity']?.toString() ?? '-1');
        orderResponseMap['Validity'] = GreekBase().getValidityFromBitwiseOprater(goodTillDate: goodTillDate, validity: validity);
        orderResponseMap['Reason'] = statusCode;
        break;

      // For Order Execution or Partial Execution
      // multiple time code done dont know why.. need to change in both the code
      case IrisResponseStreamingType.TradeResponse:
        orderStatus = OrderScreenState.tradeed;

        orderResponseMap['Order Status'] = response['order_status'];
        orderResponseMap['Exchange'] = int.parse(response['gtoken']).toExchange();
        orderResponseMap['Mkt.Segment'] = response['instrument'];
        orderResponseMap['Ref. No'] = response['gorderid'];
        orderResponseMap['Exchange Order No'] = response['eorderid'];
        orderResponseMap['Trade No'] = response['tradeid'];
        if (int.parse(response['expiryDate'].toString()) != 0) {
          orderResponseMap['Expiry Date'] = RequiredFunction().getDateFromTimeStamp(int.parse(response['expiryDate'] ?? ''));
        } else {
          orderResponseMap['Expiry Date'] = "";
        }
        orderResponseMap['Product'] = GreekBase().getProductNameFromProductToken(int.parse(response['product'].toString()));

        response['side'] == '1' ? orderResponseMap['Action'] = 'BUY' : orderResponseMap['Action'] = 'SELL';
        orderResponseMap['Traded Qty'] = response['traded_qty'];

        if (response['order_type'] == '3' || response['order_type'] == '4') {
          orderResponseMap['Trigger Price'] = response['trigger_price'].toString();
        }

        var tradePrice = '';
        if (response['traded_price'] != null) {
          tradePrice = response['traded_price'].toString();
        }
        orderResponseMap['Traded Price'] = tradePrice;

        var pendingQty = '';
        if (response['pendingQty'] != null) {
          pendingQty = response['pendingQty'];
        } else if (response['pending_qty'] != null) {
          pendingQty = response['pending_qty'];
        }
        orderResponseMap['Pending Qty'] = pendingQty.toString();
        orderResponseMap['Total Order Qty'] = response['qty'];
        break;

      // For RMS Rejected
      case IrisResponseStreamingType.RmsRejectionResponse:
        orderStatus = OrderScreenState.rejected;

        orderResponseMap['Order Status'] = response['order_status'];
        orderResponseMap['Mkt.Segment'] = response['instrument'];
        orderResponseMap['Ref. No'] = response['gorderid'];
        orderResponseMap['Reason'] = response['reason'];
        break;

      default:
        break;
    }

    final keyArray = orderResponseMap.keys.toList();

    showDialog(
      barrierDismissible: true,
      context: buildContext,
      builder: (BuildContext dialogContext) {
        // _oldOrderDialogContext = dialogContext;

        return WillPopScope(
          onWillPop: () async {
            // dismissOldDialogPopup();
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.0),
            ), //this right here
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 15.0),
                    child: Text(
                      AppConfig().appName,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0),
                    ),
                  ),
                  const SizedBox(
                    height: 10.0,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 15.0),
                    child: Text(
                      response['symbol'],
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0),
                    ),
                  ),
                  const SizedBox(
                    height: 10.0,
                  ),
                  Flexible(
                    // height: 500,
                    fit: FlexFit.loose,
                    child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemCount: keyArray.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: (keyArray[index].toUpperCase().compareTo('REASON') == 0) ? CrossAxisAlignment.start : CrossAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 100.0,
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: const EdgeInsets.only(bottom: 10.0),
                                      child: Text(
                                        keyArray[index],
                                        style: const TextStyle(
                                          fontSize: 15.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  width: 20.0,
                                  child: Text(
                                    ' -  ',
                                    style: TextStyle(
                                      fontSize: 15.0,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: SizedBox(
                                      //height: 30,
                                      child: Padding(
                                        padding: const EdgeInsets.only(bottom: 10.0),
                                        child: (keyArray[index].toUpperCase().compareTo('REASON') == 0)
                                            ? const Text('')
                                            : Text(
                                                orderResponseMap[keyArray[index]] ?? '',
                                                style: TextStyle(
                                                  fontSize: 15.0,
                                                  fontWeight: (keyArray[index].toLowerCase().compareTo('state') == 0) ? FontWeight.bold : FontWeight.normal,
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            (keyArray[index].toUpperCase().compareTo('REASON') == 0)
                                ? Text(
                                    orderResponseMap[keyArray[index]] ?? '',
                                    style: TextStyle(
                                      fontSize: 15.0,
                                      fontWeight: (keyArray[index].toLowerCase().compareTo('state') == 0) ? FontWeight.bold : FontWeight.normal,
                                    ),
                                  )
                                : const Text('')
                          ],
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: 50.0,
                    child: Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.only(top: 5.0, bottom: 5.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(5),
                                boxShadow: const <BoxShadow>[
                                  BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 8,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: MaterialButton(
                                onPressed: () {
                                  GreekNavigator.pop(context: dialogContext);
                                  AppFlagConstant().isOrderConfirmDialog = 'false';
                                  AppFlagConstant().isOrderTradeDialog = 'false';
                                  onPressed(orderStatus);
                                },
                                child: const Text('OK'),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  */

  static optionChainSettingDialog({
    required BuildContext? popContext,
    required var ordermode,
    required var action,
    required var token,
    required OptionChainBloc? optionChainBloc,
  }) async {
    if (popContext != null) {
      // if (oldOrderDialogContext != null) {
      //   dismissOldDialogPopup();
      // }

      // final confirmMap = obj.toCancelOrder();
      // final keyArray = confirmMap.keys.toList();
      return await showDialog(
        barrierDismissible: false,
        context: popContext,
        builder: (dialogContext) {
          oldOrderDialogContext = dialogContext;

          return WillPopScope(
              onWillPop: () async {
                dismissOldDialogPopup();
                return true;
              },
              child: Dialog(
                shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(20.0)), //this right here
                child: OptionchainSettingScreen(
                  optionChainBloc: optionChainBloc,
                ),
              ));
        },
      );
    }
  }

  static marketoptionChainSettingDialog({
    required BuildContext? popContext,
    required OptionBloc? optionChainBloc,
  }) async {
    if (popContext != null) {
      // if (oldOrderDialogContext != null) {
      //   dismissOldDialogPopup();
      // }

      // final confirmMap = obj.toCancelOrder();
      // final keyArray = confirmMap.keys.toList();
      return await showDialog(
        barrierDismissible: false,
        context: popContext,
        builder: (dialogContext) {
          oldOrderDialogContext = dialogContext;

          return WillPopScope(
              onWillPop: () async {
                dismissOldDialogPopup();
                return true;
              },
              child: Dialog(
                shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(20.0)), //this right here
                child: MarketOptionchainSettingScreen(
                  optionChainBloc: optionChainBloc,
                ),
              ));
        },
      );
    }
  }

  static watchListFilterPoup({
    required BuildContext? popContext,
    WatchListBloc? watchlistBloc,
  }) async {
    if (popContext != null) {
      // if (oldOrderDialogContext != null) {
      //   dismissOldDialogPopup();
      // }

      // final confirmMap = obj.toCancelOrder();
      // final keyArray = confirmMap.keys.toList();
      return await showDialog(
        barrierDismissible: true,
        context: popContext,
        builder: (dialogContext) {
          oldOrderDialogContext = dialogContext;

          return WillPopScope(
              onWillPop: () async {
                dismissOldDialogPopup();
                return true;
              },
              child: Dialog(
                shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(20.0)), //this right here
                child: WatchlistFilterDialog(popContext, watchlistBloc!),
              ));
        },
      );
    }
  }

//=====================================================================
  ///
  /// Show Dialog for Cancel Order
  ///
  /// obj - Show order info and send request
  ///
  //=====================================================================
  static cancelOrderDialog({
    required BuildContext? popContext,
    required OrderDetailsModel obj,
  }) {
    if (popContext != null) {
      // if (oldOrderDialogContext != null) {
      //   dismissOldDialogPopup();
      // }

      final confirmMap = obj.toCancelOrder();
      // final keyArray = confirmMap.keys.toList();
      showDialog(
        barrierDismissible: false,
        context: popContext,
        builder: (dialogContext) {
          oldOrderDialogContext = dialogContext;

          return WillPopScope(
            onWillPop: () async {
              dismissOldDialogPopup();
              return true;
            },
            child: Dialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0)), //this right here
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(bottom: 15.0),
                      child: Text(
                        "Cancel Order Preview",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 24.0),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          obj.tradeSymbol ?? '',
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                        ),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(bottom: 8.0),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          'Are you sure you want to cancel order?',
                          style: TextStyle(fontSize: 14.0, color: Colors.black),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 50.0,
                      child: Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.only(top: 5.0, bottom: 5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 20.0, right: 10.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5),
                                  boxShadow: const <BoxShadow>[
                                    BoxShadow(
                                      color: Colors.grey,
                                      blurRadius: 8,
                                      offset: Offset(0, 0),
                                    ),
                                  ],
                                ),
                                child: MaterialButton(
                                  onPressed: () {
                                    GreekNavigator.pop(context: dialogContext);
                                    SocketIOManager().placeCancelOrder(
                                      data: confirmMap,
                                    );
                                  },
                                  child: const Text('Yes'),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 10.0, right: 20.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  boxShadow: const <BoxShadow>[
                                    BoxShadow(
                                      color: Colors.grey,
                                      blurRadius: 8,
                                      offset: Offset(0, 0),
                                    ),
                                  ],
                                ),
                                child: MaterialButton(
                                  onPressed: () {
                                    dismissOldDialogPopup();
                                  },
                                  child: const Text(
                                    'NO',
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    }
  }

  //  Show Dailog for EDIS Response form NSDL and CDSL
  static Future<bool> edisTransactionStatusDialog(
      {required BuildContext context,
      EDISAuthorizationResponsemobileCDSL? obj}) async {
    // var obj = edisAuthorizationResponsemobileCDSL;
    var stckdetails = obj?.response!.data!.stockDetails;
    List<AuthSymbols>? symbolelist = [];
    for (var i = 0; i < stckdetails!.length; i++) {
      if (stckdetails[i].status == "Success") {
        AuthSymbols? symbols = AuthSymbols();
        symbols.token = stckdetails[i].token.toString();
        symbols.qty = stckdetails[i].quantity.toString();
        symbols.isin = stckdetails[i].iSIN;
        symbols.status = stckdetails[i].status;
        symbols.reqType = stckdetails[i].reqType;
        symbols.reqIdentifier = stckdetails[i].reqIdentifier;
        symbols.txnId = stckdetails[i].txnId;
        symbolelist.add(symbols);
      }
    }

    final object = {"symbols": symbolelist};
    SocketIOManager().updateAuthorizationStatus(object);

    final result = await showDialog<bool>(
      barrierDismissible: false,
      context: context,
      builder: (dialogContext) {
        oldOrderDialogContext = dialogContext;

        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: context);
            return true;
          },
          child: Dialog(
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.all(10),
                  child: const Text(
                    "Authorize Sell Transaction Status",
                    textAlign: TextAlign.center,
                    style:
                        TextStyle(fontWeight: FontWeight.w600, fontSize: 12.0),
                  ),
                ),
                Container(
                  height: 30,
                  width: MediaQuery.of(context).size.width,
                  color: ConstantColors.edisheader,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 3,
                        child: Container(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Instrument",
                            style: GreekTextStyle.placeOrderAppbarHeading,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "Qty",
                            style: GreekTextStyle.placeOrderAppbarHeading,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "Status",
                            style: GreekTextStyle.placeOrderAppbarHeading,
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  fit: FlexFit.tight,
                  child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: obj?.response!.data!.stockDetails!.length,
                      itemBuilder: (context, index) {
                        if (obj?.response?.data?.stockDetails?.isNotEmpty ??
                            false) {
                          return Padding(
                            padding: const EdgeInsets.all(0.0),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      flex: 3,
                                      child: Container(
                                        width: 187.5,
                                        height: 40,
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          " ${obj?.response!.data!.stockDetails?[index].symbol ?? '0'}",
                                          style: const TextStyle(
                                            fontSize: 12.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(
                                        width: 37.5,
                                        height: 40,
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          " ${obj?.response!.data!.stockDetails?[index].quantity}",
                                          style: const TextStyle(
                                            fontSize: 12.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(
                                        width: 75,
                                        height: 40,
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          " ${obj?.response!.data!.stockDetails?[index].status ?? ''}",
                                          style: const TextStyle(
                                            fontSize: 12.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const Divider(
                                  thickness: 1,
                                )
                              ],
                            ),
                          );
                        } else {
                          return Container(
                              height: MediaQuery.of(context).size.height - 240,
                              padding: const EdgeInsets.only(left: 300),
                              child: GreekBase().noDataAvailableView());
                        }
                      }),
                ),
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  height: 40,
                  width: 150,
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pop(true);
                      // GreekNavigator.pop(context: dialogContext, popArguments: true);
                    },
                    child: Text(
                      'Done',
                      style: GreekTextStyle.edisprocced,
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: ConstantColors.primaryColor,
                    borderRadius: BorderRadius.circular(8.0),
                    border: Border.all(
                      color: ConstantColors.primaryColorLight,
                      width: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    return result ?? false;
  }

  //  Show Dailog for EDIS Response form NSDL and CDSL

//=====================================================================
  static showPoaPopup(
    BuildContext popContext,
    ValueChanged<
            Tuple5<String, String, String, String,
                List<sendauthstockdetails.StockDetails>>>
        callback,
  ) {
    String msg;

    if (AppFlagConstant().dpType == "NSDL") {
      msg = ConstantMessages.EDIS_POAPOPUP_NSDL_TEXT;
    } else {
      msg = ConstantMessages.EDIS_POAPOPUP_CDSL_TEXT;
    }
    showDialog(
      barrierDismissible: false,
      context: popContext,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 10),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(right: 10),
                    alignment: Alignment.center,
                    color: Colors.white,
                    child: Image.asset(
                      'assets/images/icon.png',
                      fit: BoxFit.fitWidth,
                      width: 50,
                      height: 50,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                    child: Text(
                      msg,
                      style: GreekTextStyle.headline6,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        alignment: Alignment.center,
                        child: const Text(
                          "Learn More",
                          style: TextStyle(
                            fontFamily: "CenturyGothic",
                            fontSize: 13.0,
                            color: Colors.blue,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        child: TextButton(
                          onPressed: () {
                            GreekNavigator.pop(context: buildcontext);
                            showAuthorizePopup(popContext, callback);
                          },
                          child: Text(
                            ConstantMessages.EDIS_PROCEED_TXT,
                            textScaleFactor: 1.0,
                            style: GreekTextStyle.heading11,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: ConstantColors.primaryColorLight,
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      Container(
                        child: TextButton(
                          onPressed: () {
                            GreekNavigator.pop(context: buildcontext);
                          },
                          child: Text(
                            ConstantMessages.GREEK_CANCEL,
                            textScaleFactor: 1.0,
                            style: GreekTextStyle.heading4,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: ConstantColors.primaryColor,
                          borderRadius: BorderRadius.circular(20.0),
                          border: Border.all(
                            color: ConstantColors.primaryColorDark,
                            width: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  static showAuthorizePopup(
    BuildContext authorizecontext,
    ValueChanged<
            Tuple5<String, String, String, String,
                List<sendauthstockdetails.StockDetails>>>
        callback,
  ) {
    String msg;
    String logo;

    if (AppFlagConstant().dpType == "NSDL") {
      msg = ConstantMessages.EDIS_AUTHORIZE_NSDL_TXT;
      logo = "assets/images/nsdl.png";
    } else {
      msg = ConstantMessages.EDIS_AUTHORIZE_CDSL_TXT;
      logo = "assets/images/cdsl.png";
    }
    showDialog(
      barrierDismissible: false,
      context: authorizecontext,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
              decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: ConstantColors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.grey,
                        offset: Offset(0, 8),
                        blurRadius: 10),
                  ]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(right: 0),
                        alignment: Alignment.center,
                        color: Colors.white,
                        child: Image.asset(
                          logo,
                          fit: BoxFit.fitWidth,
                          width: 50,
                          height: 50,
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(right: 0),
                        alignment: Alignment.center,
                        color: Colors.white,
                        child: Row(
                          children: [
                            Container(
                              margin: const EdgeInsets.only(right: 0),
                              alignment: Alignment.center,
                              color: Colors.white,
                              child: Image.asset(
                                'assets/images/user_profile.png',
                                fit: BoxFit.fitWidth,
                                width: 50,
                                height: 50,
                              ),
                            ),
                            Column(
                              children: [
                                Text(
                                  AppConfig().gscid,
                                  style: GreekTextStyle.headline6,
                                  textAlign: TextAlign.center,
                                ),
                                Text(
                                  AppConfig().clientName,
                                  style: GreekTextStyle.headline6,
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                    child: Text(
                      ConstantMessages.EDIS_AUTHORIZE_TXT,
                      style: GreekTextStyle.headline7,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                    child: Text(
                      msg,
                      style: GreekTextStyle.headline6,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 15),
                    child: TextButton(
                      onPressed: () {
                        GreekNavigator.pop(context: buildcontext);
                        showAuthorizeTransectionPopup(
                            authorizecontext, callback);
                      },
                      child: Text(
                        ConstantMessages.EDIS_MANAGE_AUTHO_TXT,
                        textScaleFactor: 1.0,
                        style: GreekTextStyle.heading11,
                      ),
                    ),
                    decoration: BoxDecoration(
                      color: ConstantColors.primaryColorLight,
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        child: TextButton(
                          onPressed: () {
                            GreekNavigator.pop(context: buildcontext);
                          },
                          child: Text(
                            ConstantMessages.EDIS_GENRATE_TPIN_TXT,
                            textScaleFactor: 1.0,
                            style: GreekTextStyle.heading11,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: ConstantColors.primaryColorLight,
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        child: TextButton(
                          onPressed: () {
                            GreekNavigator.pop(context: buildcontext);
                          },
                          child: Text(
                            ConstantMessages.EDIS_FORGOT_TPIN_TXT,
                            textScaleFactor: 1.0,
                            style: GreekTextStyle.heading11,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: ConstantColors.primaryColorLight,
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  static showMarginPledgeNSDLStatusPopup(BuildContext buildContext) {
    final EdisMarginPledgeBloc _edisMarginPledgebloc =
        EdisMarginPledgeBloc(context: buildContext);

    SocketIOManager().getEDISHoldingInfo();
    showDialog(
      barrierDismissible: false,
      context: buildContext,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: SingleChildScrollView(
            child: StatefulBuilder(
              builder: (dialogContext, setState) {
                return Dialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
                    decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: ConstantColors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: const [
                          BoxShadow(
                              color: Colors.grey,
                              offset: Offset(0, 8),
                              blurRadius: 10),
                        ]),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          // crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 150,
                              height: 35,
                              child: Center(
                                child: Text(
                                  "Instrument",
                                  style: GreekTextStyle.marketDepthTotal,
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                            Container(
                              alignment: Alignment.centerRight,
                              width: 50,
                              height: 35,
                              child: Text(
                                "Qty",
                                style: GreekTextStyle.marketDepthTotal,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(
                              width: 120,
                              height: 35,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    top: 10.0, right: 10.0),
                                child: Text(
                                  "Status",
                                  style: GreekTextStyle.marketDepthTotal,
                                  textAlign: TextAlign.right,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        // listview builder start
                        StreamBuilder<bool>(
                          stream: _edisMarginPledgebloc
                              .marginPledgeNSDLAuthorizeStream.stream,
                          builder: (context, snapshot) {
                            if (snapshot.hasData == true) {
                              if (_edisMarginPledgebloc
                                  .pledgeAuthNSDLList.isNotEmpty) {
                                return Flexible(
                                  fit: FlexFit.loose,
                                  child: SizedBox(
                                    height: MediaQuery.of(context).size.height -
                                        350,
                                    width: 500,
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: _edisMarginPledgebloc
                                          .pledgeAuthNSDLList.length,
                                      itemBuilder: (context, index) {
                                        return Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    width: 150,
                                                    height: 35,
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Text(
                                                      " ${_edisMarginPledgebloc.pledgeAuthNSDLList[index].symbol ?? ''}",
                                                      style: const TextStyle(
                                                        fontFamily:
                                                            "CenturyGothic",
                                                        color: ConstantColors
                                                            .black,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontSize: 11.0,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 50,
                                                    height: 35,
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: Text(
                                                      " ${_edisMarginPledgebloc.pledgeAuthNSDLList[index].quantity}",
                                                      style: const TextStyle(
                                                        fontFamily:
                                                            "CenturyGothic",
                                                        color: ConstantColors
                                                            .black,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontSize: 11.0,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 120,
                                                    height: 35,
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: Text(
                                                      " ${_edisMarginPledgebloc.pledgeAuthNSDLList[index].status}",
                                                      textAlign:
                                                          TextAlign.right,
                                                      style: const TextStyle(
                                                        fontFamily:
                                                            "CenturyGothic",
                                                        color: ConstantColors
                                                            .black,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontSize: 11.0,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const Divider(
                                                thickness: 1,
                                              )
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                );
                              } else {
                                return SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height / 2,
                                  child: Center(
                                      child: GreekBase().noDataAvailableView()),
                                );
                              }
                            } else {
                              return SizedBox(
                                height: MediaQuery.of(context).size.height / 2,
                                child: Center(
                                    child: GreekBase().noDataAvailableView()),
                              );
                            }
                          },
                        ),

                        // listview builder close
                        const SizedBox(
                          height: 10,
                        ),

                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SizedBox(
                              height: 50.0,
                              width: 150.0,
                              child: TextButton(
                                onPressed: () => GreekNavigator.pop(
                                  context: dialogContext,
                                  popArguments: true,
                                ),
                                child: Text(
                                  'Done',
                                  style: GreekTextStyle.edisprocced,
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  static showAuthorizeTransectionPopup(
    BuildContext authorizecontext,
    ValueChanged<
            Tuple5<String, String, String, String,
                List<sendauthstockdetails.StockDetails>>>
        callback,
  ) {
    String msg;

    final PortfolioBloc _portfolioBloc = PortfolioBloc();

    List<TextEditingController> sellMarketRequest = [];
    sellMarketRequest.clear();

    if (AppFlagConstant().dpType == "NSDL") {
      msg = ConstantMessages.EDIS_PROCEED_TO_NSDL_TXT;
    } else {
      msg = ConstantMessages.EDIS_PROCEED_TO_CDSL_TXT;
    }
    SocketIOManager().getEDISHoldingInfo();

    showDialog(
      barrierDismissible: false,
      context: authorizecontext,
      builder: (buildcontext) {
        return WillPopScope(
          onWillPop: () async {
            GreekNavigator.pop(context: buildcontext);
            return true;
          },
          child: SingleChildScrollView(
            child: StatefulBuilder(
              builder: (context, setState) {
                return Dialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
                    decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: ConstantColors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: const [
                          BoxShadow(
                              color: Colors.grey,
                              offset: Offset(0, 8),
                              blurRadius: 10),
                        ]),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                          child: Text(
                            ConstantMessages.EDIS_AUTHORIZE_SELL_TXT,
                            style: GreekTextStyle.headline7,
                            textAlign: TextAlign.center,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            SizedBox(
                              width: 150,
                              child: Text(
                                "Instrument",
                                style: GreekTextStyle.headline5,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(
                              width: 40,
                              child: Text(
                                "Balance\nQty",
                                style: GreekTextStyle.headline5,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(
                              width: 40,
                              child: Text(
                                "Free\nQty",
                                style: GreekTextStyle.headline5,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(
                              width: 40,
                              child: Text(
                                "Qty to\nAuthorize",
                                style: GreekTextStyle.headline5,
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        // listview builder start
                        StreamBuilder<bool>(
                          stream:
                              _portfolioBloc.edisAuthorizationmainStream.stream,
                          builder: (context, snapshot) {
                            if (snapshot.hasData == true) {
                              if (_portfolioBloc
                                  .edisactualHoldingDataList.isNotEmpty) {
                                sellMarketRequest = List.generate(
                                    (_portfolioBloc
                                        .edisactualHoldingDataList.length),
                                    (index) => TextEditingController(
                                        text: _portfolioBloc
                                            .edisactualHoldingDataList[index]
                                            .autAdittextQty
                                            .toString()));

                                return Flexible(
                                  fit: FlexFit.loose,
                                  child: SizedBox(
                                    height: MediaQuery.of(context).size.height -
                                        350,
                                    width: 500,
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: _portfolioBloc
                                          .edisactualHoldingDataList.length,
                                      itemBuilder: (context, index) {
                                        return Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                    width: 80,
                                                    height: 20,
                                                    child: Checkbox(
                                                      value: _portfolioBloc
                                                          .edisactualHoldingDataList[
                                                              index]
                                                          .isChecked,
                                                      onChanged:
                                                          (bool? newValue) {
                                                        setState(() {
                                                          _portfolioBloc
                                                                  .edisactualHoldingDataList[
                                                                      index]
                                                                  .isChecked =
                                                              newValue ?? false;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 80,
                                                    height: 30,
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Text(
                                                      " ${_portfolioBloc.edisactualHoldingDataList[index].symbol ?? ''}",
                                                      style: GreekTextStyle
                                                          .headline5,
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 40,
                                                    height: 20,
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: Text(
                                                      " ${_portfolioBloc.edisactualHoldingDataList[index].balanceqty}",
                                                      style: GreekTextStyle
                                                          .headline5,
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 40,
                                                    height: 20,
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: Text(
                                                      " ${_portfolioBloc.edisactualHoldingDataList[index].freeqty}",
                                                      style: const TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 11.0,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 40,
                                                    height: 20,
                                                    alignment:
                                                        Alignment.centerRight,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 10),
                                                    child: TextField(
                                                      controller:
                                                          sellMarketRequest[
                                                              index],
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: GreekTextStyle
                                                          .headline5,
                                                      keyboardType:
                                                          TextInputType.number,
                                                      onChanged: (string) {
                                                        //sellMarketRequest[index].text = string;
                                                        _portfolioBloc
                                                            .edisactualHoldingDataList[
                                                                index]
                                                            .autAdittextQty = string;
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const Divider(
                                                thickness: 1,
                                              )
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                );
                              } else {
                                return SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height / 2,
                                  child: Center(
                                      child: GreekBase().noDataAvailableView()),
                                );
                              }
                            } else {
                              return SizedBox(
                                height: MediaQuery.of(context).size.height / 2,
                                child: Center(
                                    child: GreekBase().noDataAvailableView()),
                              );
                            }
                          },
                        ),

                        // listview builder close
                        const SizedBox(
                          height: 10,
                        ),

                        Container(
                          margin: const EdgeInsets.only(top: 15),
                          child: TextButton(
                            onPressed: () => prcd_btn(
                                buildcontext,
                                sellMarketRequest,
                                _portfolioBloc.edisactualHoldingDataList,
                                callback),
                            child: Text(
                              msg,
                              textScaleFactor: 1.0,
                              style: GreekTextStyle.heading11,
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: ConstantColors.primaryColorLight,
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                          child: Text(
                            "Tick on stocks which you wish to Authorize to sell",
                            style: GreekTextStyle.headline7,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  static prcd_btn(
    BuildContext context,
    List<TextEditingController> sellMarketRequest,
    List<edis_authorizeholding.StockDetails> edisactualHoldingDataList,
    ValueChanged<
            Tuple5<String, String, String, String,
                List<sendauthstockdetails.StockDetails>>>
        callback,
  ) {
    FocusScope.of(context).unfocus();
    List<edis_authorizeholding.StockDetails> selectedList = [];
    selectedList = [];
    var Validation = true, ValidationMassage = "";
    if (edisactualHoldingDataList.isNotEmpty) {
      final filterList =
          edisactualHoldingDataList.where((element) => element.isChecked);
      if (filterList.isNotEmpty) {
        for (var item in filterList) {
          if (item.autAdittextQty.toString().isEmpty) {
            Validation = false;
            ValidationMassage =
                "Enter quantity should be between one to free available quantity for selected contract";
            break;
          } else if (int.parse(item.autAdittextQty.toString()) <= 0) {
            Validation = false;
            ValidationMassage =
                "Enter quantity should be between one to free available quantity for selected contract";
            break;
          } else if (int.parse(item.autAdittextQty.toString()) >
              int.parse(item.hQty.toString())) {
            Validation = false;
            ValidationMassage =
                "Enter quantity should be between one to free available quantity for selected contract";
            break;
          } else {
            Validation = true;
            selectedList.add(item);
          }
        }
      }

      if (!Validation) {
        GreekDialogPopupView.messageDialog(
          context,
          ValidationMassage,
        );
      }

      if (selectedList.isNotEmpty) {
        if (selectedList.length > 50) {
          GreekDialogPopupView.messageDialog(
            context,
            "Selection of more then 50 stock not allowed in single request",
          );
        } else {
          if (Validation) {
            for (int j = 0; j < selectedList.length; j++) {
              if (double.parse(selectedList[j].lotSize ?? "0") > 1) {
                if (double.parse(sellMarketRequest[j].text) %
                        double.parse(selectedList[j].lotSize ?? "0.00") !=
                    0) {
                  var lotsize = selectedList[j].lotSize ?? "0.00";
                  var symbols = selectedList[j].symbol;
                  GreekDialogPopupView.messageDialog(
                      context,
                      "Entered Quantity is not in a multiple of Lot Size (" +
                          lotsize +
                          ") For " +
                          symbols.toString());
                  return;
                }
              }
            }

            if (AppFlagConstant().dpType == "NSDL") {
              sendAuthorizationRequestNSDL(selectedList, context, callback);
            } else {
              sendAuthorizationRequestCDSL(selectedList, context, callback);
            }
          } else {
            GreekDialogPopupView.messageDialog(
              context,
              ValidationMassage,
            );
          }
        }
      } else {}
    }
  }

  static Future<void> sendAuthorizationRequestNSDL(
      List<edis_authorizeholding.StockDetails> selecteddatalist,
      BuildContext context,
      ValueChanged<
              Tuple5<String, String, String, String,
                  List<sendauthstockdetails.StockDetails>>>
          callback) async {
    List<sendauthstockdetails.StockDetails> stockdetailslist = [];
    for (var i = 0; i < selecteddatalist.length; i++) {
      sendauthstockdetails.StockDetails details =
          sendauthstockdetails.StockDetails();
      details.iSIN = selecteddatalist[i].isin;
      details.quantity = selecteddatalist[i].autAdittextQty.toString();
      details.token = selecteddatalist[i].token;
      var freeqty = int.parse(selecteddatalist[i].openAuthQty ?? "0") +
          int.parse(selecteddatalist[i].todayAuthQty ?? "0");
      details.freeQty =
          int.parse(selecteddatalist[i].openAuthQty ?? "0") - freeqty;
      details.description = selecteddatalist[i].symbol;
      details.instrument = selecteddatalist[i].instrument;
      stockdetailslist.add(details);
    }

    if (EdisDashboardBloc.dPId.isNotEmpty) {
      GreekNavigator.pop(context: context);
      final returnValues = Tuple5(
          AppConfig().gscid,
          AppFlagConstant().dpType,
          NetworkManager().baseURL + "getEDISAuthorizationResponseMobile",
          EdisDashboardBloc.dPId,
          stockdetailslist);
      callback(returnValues);
    }
  }

  static Future<void> sendAuthorizationRequestCDSL(
      List<edis_authorizeholding.StockDetails> selecteddatalist,
      BuildContext context,
      ValueChanged<
              Tuple5<String, String, String, String,
                  List<sendauthstockdetails.StockDetails>>>
          callback) async {
    List<sendauthstockdetails.StockDetails> stockdetailslist = [];
    for (var i = 0; i < selecteddatalist.length; i++) {
      sendauthstockdetails.StockDetails details =
          sendauthstockdetails.StockDetails();
      details.iSIN = selecteddatalist[i].isin;
      details.quantity = selecteddatalist[i].autAdittextQty.toString();
      details.token = selecteddatalist[i].token;
      var freeqty = int.parse(selecteddatalist[i].openAuthQty ?? "0") +
          int.parse(selecteddatalist[i].todayAuthQty ?? "0");
      details.freeQty = int.parse(selecteddatalist[i].hQty ?? "0") - freeqty;
      details.description = selecteddatalist[i].symbol;
      details.instrument = selecteddatalist[i].instrument;
      stockdetailslist.add(details);
    }

    if (EdisDashboardBloc.dPId.isNotEmpty) {
      GreekNavigator.pop(context: context);
      final returnValues = Tuple5(
          AppConfig().gscid,
          AppFlagConstant().dpType,
          NetworkManager().baseURL + "getEDISAuthorizationResponseMobile",
          EdisDashboardBloc.dPId,
          stockdetailslist);
      callback(returnValues);
    }
  }
}
