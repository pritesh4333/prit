import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';

extension ExtensionParsing on String {
  APIName get apiName {
    for (var item in APIName.values) {
      if (item.toStringValue() == this) return item;
    }

    return APIName.unknown;
  }

  ApolloRequestStreamingType get apolloRequestStreamingType {
    for (var item in ApolloRequestStreamingType.values) {
      if (this == 'index') {
        return ApolloRequestStreamingType.indexStream;
      } else if (item.toStringValue() == this) {
        return item;
      }
    }

    return ApolloRequestStreamingType.unknown;
  }

  IrisRequestStreamingType get irisRequestStreamingType {
    for (var item in IrisRequestStreamingType.values) {
      if (item.toStringValue() == this) return item;
    }

    return IrisRequestStreamingType.unknown;
  }

  ApolloResponseStreamingType get apolloResponseStreamingType {
    for (var item in ApolloResponseStreamingType.values) {
      if (this == 'index') {
        return ApolloResponseStreamingType.indexStream;
      } else if (item.toStringValue() == this) {
        return item;
      }
    }

    return ApolloResponseStreamingType.unknown;
  }

  IrisResponseStreamingType get irisResponseStreamingType {
    for (var item in IrisResponseStreamingType.values) {
      if (item.toStringValue() == this) return item;
    }

    return IrisResponseStreamingType.unknown;
  }

  UserAuthenticationCode get userAuthenticationCode {
    for (var item in UserAuthenticationCode.values) {
      if (item.toStringValue() == this) return item;
    }

    return UserAuthenticationCode.unknown;
  }
}
