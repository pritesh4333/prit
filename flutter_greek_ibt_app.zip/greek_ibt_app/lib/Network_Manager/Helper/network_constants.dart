import 'package:tuple/tuple.dart';

class NetworkConstants {
  static bool isBase64Encoding = true;

  static Tuple3<bool, String, int> socketIOServerInfo =
      const Tuple3(false, '', 0);
}
