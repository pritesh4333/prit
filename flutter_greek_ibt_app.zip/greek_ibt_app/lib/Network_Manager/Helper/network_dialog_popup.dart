import 'package:flutter/material.dart';

class NetworkDialogPopup {
  final BuildContext _context;
  NetworkDialogPopup.of(BuildContext context) : _context = context;

  void showNetworkErrorPopup() {
    showDialog(
      context: _context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          elevation: 0,
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
            decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.grey, offset: Offset(0, 8), blurRadius: 10),
                ]),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    '', //AppConfig().appName,
                    //style: GreekTextStyle.heading6,
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                const Flexible(
                  fit: FlexFit.loose,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Padding(
                      padding: EdgeInsets.only(left: 8.0, right: 8.0),
                      child: Text(
                        '', //msg,
                        //style: GreekTextStyle.heading20,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  height: 40.0,
                  width: MediaQuery.of(context).size.width / 1.5,
                  //  padding: EdgeInsets.only(left: 30.0, right: 30.0),
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text(
                      'Ok',
                      //style: GreekTextStyle.heading4,
                    ),
                    style: TextButton.styleFrom(
                      backgroundColor: Colors.white, //ConstantColors.white,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                        side: const BorderSide(color: Colors.grey),
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
