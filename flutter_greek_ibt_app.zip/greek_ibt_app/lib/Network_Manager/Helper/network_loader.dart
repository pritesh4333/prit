import 'package:flutter/material.dart';

class NetworkLoader {
  static void showLoader({required BuildContext context}) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: const [
              CircularProgressIndicator(),
            ],
          ),
        );
      },
    );
  }

  static void hideLoader(BuildContext context) {
    // if (_loaderContext != null) {
    Navigator.of(context).pop();
    // }
  }
}
