import 'dart:convert';
import 'dart:developer' as log;
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_constants.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_loader.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/api_request_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/api_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_request_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_response_model.dart';
import "package:http/http.dart" as http;
import 'package:tuple/tuple.dart';

class NetworkManager {
  static final NetworkManager _networkManager = NetworkManager._internal();

  factory NetworkManager() => _networkManager;

  NetworkManager._internal();

  String baseURL = "";

  void setupNetwork({
    required Tuple5<bool, String, int, int?, bool> serverInfo,
  }) {
    NetworkConstants.isBase64Encoding = serverInfo.item5;

    NetworkConstants.socketIOServerInfo =
        Tuple3(serverInfo.item1, serverInfo.item2, serverInfo.item4 ?? 4000);

    final protocoal = (serverInfo.item1) ? "https://" : "http://";
    if (serverInfo.item3 > 0) {
      baseURL = protocoal + serverInfo.item2 + ":${serverInfo.item3}/";
    } else {
      baseURL = protocoal + serverInfo.item2 + "/";
    }
  }

  Future<int?> networkHartbeat({
    required String gscid,
    required String sessionId,
  }) async {
    const apiName = APIName.jheartbeat;

    final postBody = {
      'gscid': gscid,
      'sessionId': sessionId,
    };

    final postAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        "\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    final body = APIRequestModel.JSONFrom(
        apiNo: apiNo, bodyData: postBody, apiName: apiName);

    final response = await postAPIClient.post(
      Uri.parse(mainURL),
      body: body.base64Body(),
    );
    postAPIClient.close();

    if (response.statusCode == 200) {
      final obj = APIResponseModel.fromBase64(
          apiNo: apiNo, base64BodyData: response.body);

      return obj.response.errorCode;
    }

    return null;
  }

  Future<Object?> searchSymbolAPI({
    required String symbolName,
  }) async {
    const apiName = APIName.searchsymbol;
    final postAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        "\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    final body = APIRequestModel.JSONFrom(
      apiNo: apiNo,
      apiName: apiName,
      bodyData: {
        'symbolCode': symbolName,
      },
    );

    final response = await postAPIClient.post(
      Uri.parse(mainURL),
      body: body.base64Body(),
    );
    postAPIClient.close();

    if (response.statusCode == 200) {
      final obj = APIResponseModel.fromBase64(
          apiNo: apiNo, base64BodyData: response.body);

      if (obj.response.errorCode == 0) return obj.response.data;
    }

    return null;
  }

  Future<Object?> getAPIEncrypted({
    BuildContext? context,
    required APIName apiName,
    required String query,
  }) async {
    final getAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);

    final base64Query = (NetworkConstants.isBase64Encoding)
        ? base64.encode(utf8.encode(query))
        : query;

    final mainURL = baseURL +
        apiName.toStringValue() +
        ((base64Query.isEmpty) ? '' : '?$base64Query');

    log.log(
        "\n------------------------------------$apiNo. Request------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await getAPIClient.get(
      Uri.parse(mainURL),
    );
    getAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (response.statusCode == 200) {
      final responseData = json.decode(
        utf8.decode(
          base64.decode(
            response.body,
          ),
        ),
      );

      if (apiName != APIName.get_all_contracts_table_data) {
        log.log(
            "\n------------------------------------$apiNo. Response------------------------------------\n${responseData.toString()}\n------------------------------------------------------------------------");
      }

      final errorCode = int.parse("${responseData["ErrorCode"]}");
      if (errorCode == 0) return responseData["data"];
    }

    return null;
  }

//Only for ATOM Bank List [Getting the Bank List and send it back in json string format]
  Future<String> getAPINonEncryptedForATOMBankList({
    BuildContext? context,
    required APIName apiName,
    required String query,
  }) async {
    final getAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);

    final mainURL =
        AppFlagConstant().ftLink + '/${apiName.toStringValue()}' + '?$query';

    log.log(
        "\n------------------------------------$apiNo. Request------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await getAPIClient.get(Uri.parse(mainURL));
    getAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (apiName != APIName.get_all_contracts_table_data) {
      log.log(
          "\n------------------------------------$apiNo. Response------------------------------------\n${response.body}\n------------------------------------------------------------------------");
    }

    return response.body;
  }

  Future<int?> getAPIEncryptedOnlyForErrorCode({
    BuildContext? context,
    required APIName apiName,
    required String query,
  }) async {
    final getAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);

    final base64Query = (NetworkConstants.isBase64Encoding)
        ? base64.encode(utf8.encode(query))
        : query;

    final mainURL = baseURL +
        apiName.toStringValue() +
        ((base64Query.isEmpty) ? '' : '?$base64Query');

    log.log(
        "\n------------------------------------$apiNo. Request------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await getAPIClient.get(
      Uri.parse(mainURL),
    );
    getAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (response.statusCode == 200) {
      final responseData = json.decode(
        utf8.decode(
          base64.decode(
            response.body,
          ),
        ),
      );

      log.log(
          "\n------------------------------------$apiNo. Response------------------------------------\n${responseData.toString()}\n------------------------------------------------------------------------");

      final errorCode = int.parse("${responseData["ErrorCode"]}");
      return errorCode;
    }

    return null;
  }

  Future<Object?> postAPIEncrypted({
    BuildContext? context,
    required APIName apiName,
    required Map<String, Object> postBody,
  }) async {
    final postAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        "\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    final body = APIRequestModel.JSONFrom(
        apiNo: apiNo, bodyData: postBody, apiName: apiName);
    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await postAPIClient.post(
      Uri.parse(mainURL),
      body: body.base64Body(),
    );
    postAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (response.statusCode == 200) {
      final obj = APIResponseModel.fromBase64(
          apiNo: apiNo, base64BodyData: response.body);

      if (obj.response.errorCode == 0) return obj.response.data;
    }

    return null;
  }

//return all response
  Future<LoginResponseModel> postAPIEncryptedwithallresponse({
    BuildContext? context,
    required APIName apiName,
    required Map<String, Object> postBody,
  }) async {
    final postAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        "\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    final body = APIRequestModel.JSONFrom(
        apiNo: apiNo, bodyData: postBody, apiName: apiName);
    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await postAPIClient.post(
      Uri.parse(mainURL),
      body: body.base64Body(),
    );
    postAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    /*  if (response.statusCode == 200) {
      final obj = APIResponseModel.fromBase64(
          apiNo: apiNo, base64BodyData: response.body);

      if (obj.response.errorCode == 0) return obj.response;
    } */

    if (response.statusCode == 200) {
      if (!NetworkConstants.isBase64Encoding) {
        final base64Response = utf8.decode(
          base64.decode(response.body),
        );
        final obj = APIResponseModel.fromBase64(
            apiNo: apiNo, base64BodyData: base64Response);
        final loginResponseObj =
            LoginResponseModel.fromJson((obj.response.data! as Map));
        loginResponseObj.sessionID = obj.response.sessionId;
        return loginResponseObj;
      } else {
        final obj = APIResponseModel.fromBase64(
            apiNo: apiNo, base64BodyData: response.body);
        final loginResponseObj =
            LoginResponseModel.fromJson((obj.response.data! as Map));
        loginResponseObj.sessionID = obj.response.sessionId;
        return loginResponseObj;
      }
    }

    return LoginResponseModel(
        errorCode: UserAuthenticationCode.unknown, errorResone: "");

    //return null;
  }

  Future<int?> postAPIEncryptedOnlyForErrorCode({
    BuildContext? context,
    required APIName apiName,
    required Map<String, Object> postBody,
  }) async {
    final postAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        "\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    final body = APIRequestModel.JSONFrom(
        apiNo: apiNo, bodyData: postBody, apiName: apiName);

    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await postAPIClient.post(
      Uri.parse(mainURL),
      body: body.base64Body(),
    );
    postAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (response.statusCode == 200) {
      final obj = APIResponseModel.fromBase64(
          apiNo: apiNo, base64BodyData: response.body);
      return obj.response.errorCode;
    }

    return null;
  }

  Future<Object?> postAPIEncryptedForIndianIndices({
    BuildContext? context,
    required APIName apiName,
    String? gscid,
    required String assetType,
  }) async {
    final postAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        "\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------");

    final body = APIRequestModel.JSONFrom(
      apiNo: apiNo,
      bodyData: {},
      apiName: apiName,
      gscid: gscid,
      assetType: assetType,
    );

    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await postAPIClient.post(
      Uri.parse(mainURL),
      body: body.base64Body(),
    );
    postAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (response.statusCode == 200) {
      final obj = APIResponseModel.fromBase64(
          apiNo: apiNo, base64BodyData: response.body);

      if (obj.response.errorCode == 0) return obj.response.data;
    }

    return null;
  }

  Future<LoginResponseModel> authenticateUser({
    BuildContext? context,
    required String versionNo,
    required String gscid,
    required String pass,
    required String deviceDetails,
    required String deviceId,
    required String transPass,
  }) async {
    final loginAPIClient = http.Client();
    var apiNo = Random().nextInt(5001);
    const apiName = APIName.jloginNew;
    final mainURL = baseURL + apiName.toStringValue();
    log.log(
        '\n------------------------------------$apiNo. URL------------------------------------\n$mainURL\n------------------------------------------------------------------------');

    final loginRequestObj = LoginRequestModel(
        versionNo, gscid, pass, deviceDetails, deviceId, transPass);

    final body = APIRequestModel.JSONFrom(
        apiNo: apiNo, bodyData: loginRequestObj.toJson(), apiName: apiName);

    String bodyData = body.base64Body();
    if (!NetworkConstants.isBase64Encoding) {
      bodyData = base64.encode(utf8.encode(body.base64Body()));
    }

    if (context != null) {
      NetworkLoader.showLoader(context: context);
    }

    final response = await loginAPIClient.post(
      Uri.parse(mainURL),
      body: bodyData,
    );
    loginAPIClient.close();

    if (context != null) {
      NetworkLoader.hideLoader(context);
    }

    if (response.statusCode == 200) {
      if (!NetworkConstants.isBase64Encoding) {
        final base64Response = utf8.decode(
          base64.decode(response.body),
        );
        final obj = APIResponseModel.fromBase64(
            apiNo: apiNo, base64BodyData: base64Response);
        final loginResponseObj =
            LoginResponseModel.fromJson((obj.response.data! as Map));
        loginResponseObj.sessionID = obj.response.sessionId;
        return loginResponseObj;
      } else {
        final obj = APIResponseModel.fromBase64(
            apiNo: apiNo, base64BodyData: response.body);
        final loginResponseObj =
            LoginResponseModel.fromJson((obj.response.data! as Map));
        loginResponseObj.sessionID = obj.response.sessionId;
        return loginResponseObj;
      }
    }

    return LoginResponseModel(
        errorCode: UserAuthenticationCode.unknown, errorResone: "");
  }
}
