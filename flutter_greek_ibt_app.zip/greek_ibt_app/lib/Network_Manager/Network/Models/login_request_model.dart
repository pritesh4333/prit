class LoginRequestModel {
  final String versionNo;

  final passType = 0;
  final brokerid = 1;
  final userType = "Customer";
  final encryptionType = 1;
  final deviceType = "2";
  final panDOB = "01/01/1901";

  final String gscid;
  final String pass;
  final String deviceDetails;
  final String deviceId;
  final String transPass;

  LoginRequestModel(
    this.versionNo,
    this.gscid,
    this.pass,
    this.deviceDetails,
    this.deviceId,
    this.transPass,
  );

  Map<String, Object> toJson() => {
        "version_no": versionNo,
        "passType": passType,
        "brokerid": brokerid,
        "userType": userType,
        "encryptionType": encryptionType,
        "deviceType": deviceType,
        "pan_dob": panDOB,
        "gscid": gscid,
        "pass": pass,
        "deviceDetails": deviceDetails,
        "deviceId": deviceId,
        "transPass": transPass,
      };
}
