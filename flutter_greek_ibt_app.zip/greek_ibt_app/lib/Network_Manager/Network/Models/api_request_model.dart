import 'dart:convert';
import 'dart:developer';
import 'package:greek_ibt_app/Network_Manager/Helper/network_constants.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';

class APIRequestModel {
  // ignore: unused_field
  final Request _request;

  // ignore: non_constant_identifier_names
  factory APIRequestModel.JSONFrom({
    required int apiNo,
    required Map<String, Object> bodyData,
    required APIName apiName,
    String? gscid,
    String? assetType,
  }) {
    final obj = APIRequestModel(
      Request(
        svcName: apiName,
        data: bodyData,
        gscid: gscid,
        assetType: assetType,
      ),
    );
    log("\n------------------------------------$apiNo. Request------------------------------------\n${obj.jsonString()}\n------------------------------------------------------------------------");
    return obj;
  }

  APIRequestModel(this._request);

  Map<String, Object> toJson() => {
        "request": _request.toJson(),
      };

  String jsonString() {
    final s1 = json.encode(toJson());
    return s1;
  }

  String base64Body() {
    if (NetworkConstants.isBase64Encoding) {
      return base64.encode(utf8.encode(jsonString()));
    } else {
      return jsonString();
    }
  }
}

class Request {
  final String svcVersion = "1.0.0";
  final String svcGroup = "";
  final APIName svcName;
  final Object data;
  String? gscid;
  String? assetType;

  Request({
    required this.svcName,
    required this.data,
    required this.gscid,
    required this.assetType,
  });

  Map<String, Object> toJson() {
    final dic = {
      "svcVersion": svcVersion,
      "svcGroup": svcGroup,
      "svcName": svcName.toStringValue(),
      "gscid": gscid ?? '',
      "assetType": assetType ?? '',
      "data": data,
    };

    dic.removeWhere(
      (key, value) {
        if ((gscid == null) &&
            (gscid?.isEmpty ?? false) &&
            (key.toLowerCase().compareTo('gscid') == 0)) {
          return true;
        } else if ((assetType == null) &&
            (assetType?.isEmpty ?? false) &&
            (key.toLowerCase().compareTo('assettype') == 0)) {
          return true;
        } else {
          return false;
        }
      },
    );

    return dic;
  }
}
