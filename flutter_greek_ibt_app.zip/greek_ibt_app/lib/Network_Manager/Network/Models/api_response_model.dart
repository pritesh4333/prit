import 'dart:convert';
import 'dart:developer';
import 'package:greek_ibt_app/Network_Manager/Helper/network_constants.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';

class APIResponseModel {
  Response response;

  APIResponseModel({required this.response});

  factory APIResponseModel.fromBase64(
      {required int apiNo, required String base64BodyData}) {
    String base64DecodedData;

    if (NetworkConstants.isBase64Encoding) {
      base64DecodedData = utf8.decode(
        base64.decode(base64BodyData),
      );
    } else {
      base64DecodedData = base64BodyData;
    }

    log("\n------------------------------------$apiNo. Response------------------------------------\n${base64DecodedData.toString()}\n------------------------------------------------------------------------");

    final jsonObj = json.decode(base64DecodedData.toString());
    if (jsonObj is Map) {
      if (jsonObj.containsKey('response')) {
        final responseResult = jsonObj["response"];
        return APIResponseModel(
          response: Response.fromJSON(responseResult),
        );
      } else if (jsonObj.containsKey('data')) {
        final errorCode =
            int.tryParse(jsonObj['ErrorCode']?.toString() ?? '0') ?? 0;

        final dataResponse = Response(
            svcName: APIName.getNewsData,
            sessionId: '',
            errorCode: errorCode,
            data: jsonObj['data']);
        return APIResponseModel(
          response: dataResponse,
        );
      }
    }

    final responseResult = jsonObj["response"];
    return APIResponseModel(
      response: Response.fromJSON(responseResult),
    );
  }
}

class Response {
  APIName svcName;
  String? sessionId;
  int? errorCode;
  Object? data;

  Response({
    required this.svcName,
    required this.sessionId,
    required this.errorCode,
    required this.data,
  });

  //factory Response.fromJSON(Map<String, Object> json) {
  factory Response.fromJSON(Map json) {
    return Response(
      svcName: json["svcName"]?.toString().apiName ?? APIName.unknown,
      sessionId: json["sessionId"]?.toString() ?? '',
      //errorCode: json["ErrorCode"] as int?,
      errorCode: int.tryParse(json["ErrorCode"]?.toString() ?? '0') ?? 0,
      data: json["data"],
    );
  }
}
