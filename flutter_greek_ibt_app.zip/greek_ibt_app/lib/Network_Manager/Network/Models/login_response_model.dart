import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';

class LoginResponseModel {
  String? sessionID;
  int? clientCode;
  int? executioncode;
  UserAuthenticationCode errorCode = UserAuthenticationCode.unknown;
  String errorResone = "";
  String? orderTime;
  String? theme;
  List<AllowedMarket>? allowedMarket;
  String? defaultProduct;
  String? holdingFlag;
  String? validate2FA;
  String? validateTransaction;
  String? cCategory;
  int? mandateId;
  int? userType;
  String? panNo;
  String? kYCStatus;
  String? dob;
  String? gscid;
  String? quote;
  String? clientName;
  String? arachneIP;
  String? apolloIP;
  String? irisIP;
  int? arachnePort;
  int? orderSenderPort;
  int? broadcastSenderPort;
  int? irisPort;
  int? apolloPort;
  String? chartSetting;
  String? isStrategyProduct;
  String? isEDISProduct;
  String? isSameDevice;
  String? isValidateSecondary;
  String? isRedisEnabled;
  String? isMPINSet;
  String? isBOReport;
  String? isStrategyLogin;

  bool? isSecure;
  int? socketPort;

  bool? secondaryDomainisSecure;
  String? secondaryDomainName;
  int? secondaryDomainPort;

  LoginResponseModel({
    this.sessionID,
    this.clientCode,
    this.executioncode,
    required this.errorResone,
    required this.errorCode,
    this.orderTime,
    this.theme,
    this.allowedMarket,
    this.defaultProduct,
    this.holdingFlag,
    this.validate2FA,
    this.validateTransaction,
    this.cCategory,
    this.mandateId,
    this.userType,
    this.panNo,
    this.kYCStatus,
    this.dob,
    this.gscid,
    this.quote,
    this.clientName,
    this.arachneIP,
    this.apolloIP,
    this.irisIP,
    this.arachnePort,
    this.orderSenderPort,
    this.broadcastSenderPort,
    this.irisPort,
    this.apolloPort,
    this.chartSetting,
    this.isStrategyProduct,
    this.isEDISProduct,
    this.isSameDevice,
    this.isValidateSecondary,
    this.isRedisEnabled,
    this.isMPINSet,
    this.isBOReport,
    this.isStrategyLogin,
  });

  LoginResponseModel.fromJson(Map json) {
    final errorCode = int.parse(json["ErrorCode"]?.toString() ?? '-123');
    this.errorCode = UserAuthenticationCode.unknown;
    errorResone = "unknown";
    //final int passErrorCode = json["PassType"] ?? -1;

    switch (errorCode) {
      case 0:
        this.errorCode = UserAuthenticationCode.success;
        errorResone = "Successfull Login";

        clientCode = int.parse(json["ClientCode"]?.toString() ?? '0');
        executioncode = int.parse(json["Executioncode"]?.toString() ?? '0');
        orderTime = json["OrderTime"].toString();
        theme = json["Theme"].toString();

        if ((json["AllowedMarket"] != null) &&
            (json["AllowedMarket"] is List)) {
          allowedMarket = <AllowedMarket>[];
          for (var v in (json["AllowedMarket"] as List)) {
            allowedMarket!.add(AllowedMarket.fromJson(v));
          }
        }

        defaultProduct = json["defaultProduct"].toString();
        holdingFlag = json["holdingFlag"].toString();
        validate2FA = json["validate2FA"].toString();
        validateTransaction = json["validateTransaction"].toString();
        cCategory = json["cCategory"].toString();
        mandateId = int.parse(json["mandateId"]?.toString() ?? '0');
        userType = int.parse(json["userType"]?.toString() ?? '0');
        panNo = json["panNo"].toString();
        kYCStatus = json["KYCStatus"].toString();
        dob = json["dob"].toString();
        gscid = json["gscid"].toString();
        quote = json["quote"].toString();
        clientName = json["clientName"].toString();
        arachneIP = json["Arachne_IP"].toString();
        apolloIP = json["Apollo_IP"].toString();
        irisIP = json["Iris_IP"].toString();
        arachnePort = int.parse(json["Arachne_Port"]?.toString() ?? '3000');
        orderSenderPort =
            int.parse(json["OrderSender_Port"]?.toString() ?? '8081');
        broadcastSenderPort =
            int.parse(json["BroadcastSender_Port"]?.toString() ?? '8082');
        irisPort = int.parse(json["Iris_Port"]?.toString() ?? '4246');
        apolloPort = int.parse(json["Apollo_Port"]?.toString() ?? '4447');
        chartSetting = json["ChartSetting"].toString();
        isStrategyProduct = json["IsStrategyProduct"].toString();
        isEDISProduct = json["IsEDISProduct"].toString();
        isSameDevice = json["IsSameDevice"].toString();
        isValidateSecondary = json["IsValidateSecondary"].toString();
        isRedisEnabled = json["IsRedisEnabled"].toString();
        isMPINSet = json["isMPINSet"].toString();
        isBOReport = json["IsBOReport"].toString();
        isStrategyLogin = json["isStrategyLogin"].toString();

        isSecure = (json['isSecure'] != null)
            ? (json['isSecure'].toString().toLowerCase().compareTo('true') == 0)
            : true;
        socketPort = (json["Socket_IO_Port"] != null)
            ? int.parse(json["Socket_IO_Port"].toString())
            : 4000;
        break;

      case 21:
        this.errorCode = UserAuthenticationCode.domainError;
        errorResone = "Use Secondary Domain";

        secondaryDomainisSecure =
            (json["isSecure"].toString().toLowerCase().compareTo('true') == 0);
        secondaryDomainName = json["domainName"].toString();
        secondaryDomainPort =
            int.parse(json["domainPort"]?.toString() ?? '3001');
        break;

      case 1:
        this.errorCode = UserAuthenticationCode.loginPasswordExpiredError;
        errorResone = "Password Expired";
        break;

      case 2:
        this.errorCode = UserAuthenticationCode.incorrectLoginPasswordError;
        errorResone = "Incorrect Password";
        break;

      case 3:
        this.errorCode = UserAuthenticationCode.failureError;
        errorResone = "Failure";
        break;

      case 4:
        this.errorCode = UserAuthenticationCode.duplicatePassword;
        errorResone = "Duplicate Password";
        break;

      case 5:
        this.errorCode = UserAuthenticationCode.loginMaxAttemptsError;
        errorResone = "Max Attempts";
        break;

      case 6:
        this.errorCode = UserAuthenticationCode.invalidSessionError;
        errorResone = "Invalid Session";
        break;

      case 7:
        this.errorCode = UserAuthenticationCode.usrSuspenedError;
        errorResone = "Use Suspened, Please Contact admin";
        break;

      case 13:
        this.errorCode = UserAuthenticationCode.retailerNotExistError;
        errorResone = "Retailer Not Exist";
        break;

      case 14:
        this.errorCode = UserAuthenticationCode.versionMissMatchError;
        errorResone = "Version miss match";
        break;

      case 17:
        this.errorCode = UserAuthenticationCode.accountLockedError;
        errorResone = "Account Locked, Please Contact admin & Change password.";
        break;
    }
  }
}

class AllowedMarket {
  int? marketId;

  AllowedMarket({this.marketId});

  AllowedMarket.fromJson(Map json) {
    marketId = int.parse(json["market_id"]?.toString() ?? '-123');
  }
}
