// ignore_for_file: constant_identifier_names

enum SocketRequestType {
  subscribe,
  unsubscribe,
}

extension SocketRequestTypeExtension on SocketRequestType {
  String toStringValue() => toString().split(".").last;
}

enum ApolloRequestStreamingType {
  unknown,
  logoff,
  login,
  HeartBeat,
  MarketStatus,
  indexStream,
  ltpinfo,
  marketPicture,
  topgainers,
  toplosers,
  marketmovers,
  marketmoversByValue,
  touchline,
  UserAlert,
}

extension ApolloStreamingTypeExtension on ApolloRequestStreamingType {
  String toStringValue() {
    if (this == ApolloRequestStreamingType.indexStream) return 'index';

    return toString().split(".").last;
  }
}

enum IrisRequestStreamingType {
  unknown,
  logoff,
  login,
  HeartBeat,
  NewOrderRequest,
  ModifyOrderRequest,
  CancelOrderRequest,
  MarketStatus,
  MarginDetailRequest,
  HoldingDetailsInfo,
  HoldingScripPositionInfo,
  HoldingValueInfo,
  NPDetailRequest,
  SymbolVarMarginRequest,
  AvailablePayOutRequest,
  FundPayOutRequest,
  FundTransferDetails,
  getEDISHoldingInfo,
  updateAuthorizationStatus,
  EPledgeHoldingInfo,
  ProductChangeRequest,
  FundPayOutResponse,
}

extension IrisStreamingTypeExtension on IrisRequestStreamingType {
  String toStringValue() => toString().split(".").last;
}

enum ApolloResponseStreamingType {
  unknown,
  LoginResponse,
  HeartBeat,
  indexStream,
  MarketStatus,
  ltpinfo,
  marketPicture,
  TopGainersResponse,
  TopLosersResponse,
  MarketMoversResponse,
  MarketMoversByValueResponse,
  OpenInterest,
  touchline,
  AlertResponse,
  AlertExecuted,
}

extension ApolloResponseStreamingTypeExtension on ApolloResponseStreamingType {
  String toStringValue() => toString().split(".").last;
}

enum IrisResponseStreamingType {
  unknown,
  LoginResponse,
  HeartBeat,
  OrderResponse,
  TriggerResponse,
  OrderRejectionResponse,
  TradeResponse,
  RmsRejectionResponse,
  MarketStatus,
  MarginDetailResponse,
  HoldingValueInfoResp,
  HoldingDetailsInfoResp,
  HoldingScripPositionInfoResp,
  NPDetailResponse,
  EDISHoldingInfoResponse,
  EPledgeHoldingResponse,
  UpdateNSDLAuthorizationResponse,
  SymbolVarMarginResponse,
  AvailablePayOutResponse,
  UpdateNSDLPledgeAuthorizationResponse,
  ProductChangeResponse,
  FundPayOutResponse,
  AdminMessages,
}

extension IrisResponseStreamingTypeExtension on IrisResponseStreamingType {
  String toStringValue() => toString().split(".").last;
}
