import 'dart:convert';
import 'dart:developer';
import 'package:greek_ibt_app/Network_Manager/Helper/network_constants.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';

class IrisResponsetModel {
  final Response response;

  IrisResponsetModel(this.response);

  factory IrisResponsetModel.fromBase64Data(base64BodyData) {
    Object base64DecodedData;

    if (NetworkConstants.isBase64Encoding) {
      base64DecodedData = utf8.decode(
        base64.decode(base64BodyData),
      );
    } else {
      base64DecodedData = base64BodyData;
    }

    log("\n------------------------------------Iris Response------------------------------------\n${base64DecodedData.toString()}\n------------------------------------------------------------------------");

    final jsonObj = json.decode(
      base64DecodedData.toString(),
    );
    final responseResult = jsonObj["response"];

    return IrisResponsetModel(
      Response.fromJson(
        responseResult,
      ),
    );
  }
}

class Response {
  final IrisResponseStreamingType streamingType;
  final dynamic data;

  Response({
    required this.streamingType,
    required this.data,
  });

  factory Response.fromJson(json) {
    final streamingType =
        (json["streaming_type"] as String).irisResponseStreamingType;
    final data = json["data"];

    return Response(streamingType: streamingType, data: data);
  }
}
