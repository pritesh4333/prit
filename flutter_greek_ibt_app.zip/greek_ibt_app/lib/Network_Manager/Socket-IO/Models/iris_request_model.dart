import 'dart:convert';
import 'dart:developer';
import 'package:greek_ibt_app/Network_Manager/Helper/network_constants.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';

class IRISRequestModel {
  late final Request? request;
  late final IrisLoginRequest? loginRequest;

  // ignore: non_constant_identifier_names
  factory IRISRequestModel.JSONFrom({
    required String sessionId,
    required SocketRequestType requestType,
    required IrisRequestStreamingType streamingType,
    required String? gscid,
    required String? gcid,
    required Map<String, dynamic> data,
  }) {
    if (streamingType == IrisRequestStreamingType.login) {
      return IRISRequestModel(
          IrisLoginRequest(
            requestType: requestType,
            streamingType: streamingType,
            data: data,
          ),
          null);
    } else {
      return IRISRequestModel(
        null,
        Request(
          sessionId: sessionId,
          requestType: requestType,
          streamingType: streamingType,
          gscid: gscid,
          gcid: gcid,
          data: data,
        ),
      );
    }
  }

  IRISRequestModel(this.loginRequest, this.request);

  Map<String, dynamic> _toJson() => {
        "request":
            (loginRequest != null) ? loginRequest!.toJson() : request!.toJson()
      };

  String _jsonString() {
    final s1 = json.encode(_toJson());

    log("\n------------------------------------IRIS Request------------------------------------\n$s1\n------------------------------------------------------------------------");

    return s1;
  }

  String toBase64() {
    if (NetworkConstants.isBase64Encoding) {
      final jsonString = _jsonString();
      return base64.encode(utf8.encode(jsonString));
    } else {
      final jsonString = '${_jsonString()}\n';
      return jsonString;
    }
  }
}

class IrisLoginRequest {
  final SocketRequestType requestType;
  final IrisRequestStreamingType streamingType;
  final Map<String, dynamic> data;

  IrisLoginRequest({
    required this.requestType,
    required this.streamingType,
    required this.data,
  });

  Map<String, dynamic> toJson() => {
        "response_format": "json",
        "request_type": requestType.toStringValue(),
        "streaming_type": streamingType.toStringValue(),
        "data": data,
      };
}

class Request {
  final String sessionId;
  final SocketRequestType requestType;
  final IrisRequestStreamingType streamingType;
  final Map<String, dynamic> data;

  final String? gscid;
  final String? gcid;

  Request({
    required this.sessionId,
    required this.requestType,
    required this.streamingType,
    required this.gscid,
    required this.gcid,
    required this.data,
  });

  Map<String, dynamic> toJson() {
    final dic = {
      "data": data,
      "response_format": "json",
      "gscid": gscid,
      "gcid": gcid,
      "sessionId": sessionId,
      "request_type": requestType.toStringValue(),
      "streaming_type": streamingType.toStringValue(),
    };

    dic.removeWhere(
      (key, value) => (value == null),
    );

    return dic;
  }
}
