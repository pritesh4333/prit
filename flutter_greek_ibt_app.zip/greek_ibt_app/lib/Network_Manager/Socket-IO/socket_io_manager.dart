import 'dart:async';
import 'dart:developer';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_constants.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Models/apollo_request_model.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Models/apollo_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Models/iris_request_model.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Models/iris_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Screens/Alerts/ui/stock_alert_screen.dart';
import 'package:rxdart/rxdart.dart';
import 'package:socket_io_client/socket_io_client.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/product_change_request.dart';

class SocketIOManager {
  static final SocketIOManager _socketIOManager = SocketIOManager._internal();

  factory SocketIOManager() => _socketIOManager;

  SocketIOManager._internal();

  var _isSocketIOConnected = false;
  var _isApolloConnected = false;
  var _isApolloReconnected = false;
  var _isIrisConnected = false;
  var _isIrisReconnected = false;

  String? _loginApolloRequest;
  var _isApolloLoginRequestProcessing = false;
  var _isApolloLoginSucessfull = false;

  String? _loginIrisRequest;
  var _isIrisLoginRequestProcessing = false;
  var _isIrisLoginSucessfull = false;

  var marketmapNumber = 0;
  List<String?> _pendingApolloRequest = <String?>[];
  List<String?> _pendingIrisRequest = <String?>[];

  String _socketURL = "";

  Socket? _socketIO;

  BehaviorSubject<Map<String, dynamic>?>? _apolloBrodcastResponseSubject =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get brodcastResponseObservable =>
      _apolloBrodcastResponseSubject?.stream;

  BehaviorSubject<Map<String, dynamic>?>? _apolloAlertDeleteResponseSubject =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get brodcastAlertDeleteResponseObservable =>
      _apolloAlertDeleteResponseSubject?.stream;

  BehaviorSubject<Map<String, dynamic>?>? _irisOrderResponseSubject =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get orderResponseObservable =>
      _irisOrderResponseSubject?.stream;
  BehaviorSubject<Map<String, dynamic>?>? _irisAdminMessageResponseSubject =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get adminMessageResponseObservable =>
      _irisAdminMessageResponseSubject?.stream;

  BehaviorSubject<Object?>? _apolloTopGainersSubject =
      BehaviorSubject<Object?>();
  Stream<Object?>? get topGainersObservable => _apolloTopGainersSubject?.stream;
  BehaviorSubject<Object?>? _apolloTopLoosersSubject =
      BehaviorSubject<Object?>();
  Stream<Object?>? get topLoosersObservable => _apolloTopLoosersSubject?.stream;
  BehaviorSubject<Object?>? _apolloMaketMoversSubject =
      BehaviorSubject<Object?>();
  Stream<Object?>? get marketMOversObservable =>
      _apolloMaketMoversSubject?.stream;
  BehaviorSubject<Object?>? _apolloMarketMoversByValueSubject =
      BehaviorSubject<Object?>();
  Stream<Object?>? get marketMoverByValueObservable =>
      _apolloMarketMoversByValueSubject?.stream;

  BehaviorSubject<List<bool>>? _reconnectStatusSubject =
      BehaviorSubject<List<bool>>.seeded([false, false]);
  Stream<List<bool>>? get reconnectStatusObservable =>
      _reconnectStatusSubject?.stream;

  BehaviorSubject<Map<String, dynamic>?>? _withdrawResponse =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get withdrawResponseObservable =>
      _withdrawResponse?.stream;

  BehaviorSubject<Map<String, dynamic>?>? _marginResponse =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get marginResponseObservable =>
      _marginResponse?.stream;

  BehaviorSubject<Map<String, dynamic>?>? _holdingResponse =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get holdingResponseObservable =>
      _holdingResponse?.stream;

  BehaviorSubject<Map<String, dynamic>?>? _productChnageResponse =
      BehaviorSubject<Map<String, dynamic>?>();
  Stream<Map<String, dynamic>?>? get productChnageObservable =>
      _productChnageResponse?.stream;

  String _gscid = "";
  String _gcid = "";
  String _sessionID = "";
  String _deviceID = "";
  String _deviceType = "";

  void disposeSocketIO() {
    _reconnectStatusSubject?.close();
    _apolloBrodcastResponseSubject?.close();
    _apolloAlertDeleteResponseSubject?.close();
    _irisOrderResponseSubject?.close();
    _irisAdminMessageResponseSubject?.close();
    _apolloTopGainersSubject?.close();
    _apolloTopLoosersSubject?.close();
    _apolloMaketMoversSubject?.close();
    _apolloMarketMoversByValueSubject?.close();
    _withdrawResponse?.close();
    _marginResponse?.close();
    _holdingResponse?.close();
    _productChnageResponse?.close();
    _loginApolloRequest = null;
    _loginIrisRequest = null;

    _socketIO?.dispose();
    _socketIO = null;

    _isSocketIOConnected = false;
    _isApolloConnected = false;
    _isIrisConnected = false;

    _isApolloLoginSucessfull = false;
    _isApolloLoginRequestProcessing = false;
    _isIrisLoginSucessfull = false;
    _isIrisLoginRequestProcessing = false;

    _gscid = "";
    _gcid = "";
    _sessionID = "";
    _deviceID = "";
    _deviceType = "";
  }

  void disconnectServer({bool? isSendLogoffRequest}) {
    if (isSendLogoffRequest ?? false) {
      _logoff();
    }

    _socketIO?.dispose();
    _socketIO?.disconnected;
    _socketIO = null;

    _isSocketIOConnected = false;
    _isApolloConnected = false;
    _isIrisConnected = false;

    _isApolloLoginSucessfull = false;
    _isApolloLoginRequestProcessing = false;
    _isIrisLoginSucessfull = false;
    _isIrisLoginRequestProcessing = false;

    saveDefaultSetting();
  }

  void saveDefaultSetting() async {
    String retrieveDefaultScreen = await AppConfig().getDefaultScreen() ?? '';

    switch (retrieveDefaultScreen.toLowerCase()) {
      case 'market':
        AppFlagConstant().defaultScreenIndex = '0';
        break;
      case 'watchlist':
        AppFlagConstant().defaultScreenIndex = '1';
        break;
      case 'order':
        AppFlagConstant().defaultScreenIndex = '2';
        break;
      case 'portfolio':
        AppFlagConstant().defaultScreenIndex = '3';
        break;
      case 'funds':
        AppFlagConstant().defaultScreenIndex = '4';
        break;
      default:
    }
  }

  void connectSocketIOServer({
    required String gscid,
    required String gcid,
    required String sessionID,
    required String deviceID,
    required String deviceType,
  }) {
    disposeSocketIO();

    _reconnectStatusSubject = null;
    _reconnectStatusSubject =
        BehaviorSubject<List<bool>>.seeded([false, false]);

    _apolloBrodcastResponseSubject = null;
    _apolloBrodcastResponseSubject = BehaviorSubject<Map<String, dynamic>?>();

    _apolloAlertDeleteResponseSubject = null;
    _apolloAlertDeleteResponseSubject =
        BehaviorSubject<Map<String, dynamic>?>();

    _irisOrderResponseSubject = null;
    _irisOrderResponseSubject = BehaviorSubject<Map<String, dynamic>?>();

    _irisAdminMessageResponseSubject = null;
    _irisAdminMessageResponseSubject = BehaviorSubject<Map<String, dynamic>?>();

    _apolloTopGainersSubject = null;
    _apolloTopGainersSubject = BehaviorSubject<Object?>();

    _apolloTopLoosersSubject = null;
    _apolloTopLoosersSubject = BehaviorSubject<Object?>();

    _apolloMaketMoversSubject = null;
    _apolloMaketMoversSubject = BehaviorSubject<Object?>();

    _apolloMarketMoversByValueSubject = null;
    _apolloMarketMoversByValueSubject = BehaviorSubject<Object?>();

    _withdrawResponse = null;
    _withdrawResponse = BehaviorSubject<Map<String, dynamic>?>();

    _marginResponse = null;
    _marginResponse = BehaviorSubject<Map<String, dynamic>?>();

    _holdingResponse = null;
    _holdingResponse = BehaviorSubject<Map<String, dynamic>?>();

    _productChnageResponse = null;
    _productChnageResponse = BehaviorSubject<Map<String, dynamic>?>();

    _gscid = gscid;
    _gcid = gcid;
    _sessionID = sessionID;
    _deviceID = deviceID;
    _deviceType = deviceType;

    final socketProtocoalName =
        NetworkConstants.socketIOServerInfo.item1 ? 'https://' : 'http://';
    _socketURL = socketProtocoalName +
        NetworkConstants.socketIOServerInfo.item2 +
        ':${NetworkConstants.socketIOServerInfo.item3}';

    log("\n----------------------------\nSocket URL - $_socketURL\n----------------------------\n");

    reconnectSocketIOServer();
  }

  void reconnectSocketIOServer() {
    //final isSecure = NetworkConstants.socketIOServerInfo.item1;
    _socketIO ??= io(
      _socketURL,
      <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': true,
        //'secure': isSecure,
      },
    );

    _socketIO?.connect();

    _socketIO?.on(
      'connect',
      (status) {
        log("\n----------------------------\nSocket IO Connected\n----------------------------\n");

        _isSocketIOConnected = true;

        _socketIO?.emit('established_apollo_iris_tcp');

        //  Prepare Apollo Login Request
        _loginApolloRequest ??= ApolloRequestModel.JSONFrom(
          requestType: SocketRequestType.subscribe,
          streamingType: ApolloRequestStreamingType.login,
          gscid: null,
          gcid: null,
          data: {
            "gscid": _gscid,
            "gcid": _gcid,
            "sessionId": _sessionID,
            "deviceId": _deviceID,
            "device_type": _deviceType,
          },
        ).toBase64();

        //  Prepare Iris Login Request
        _loginIrisRequest ??= IRISRequestModel.JSONFrom(
          sessionId: _sessionID,
          requestType: SocketRequestType.subscribe,
          streamingType: IrisRequestStreamingType.login,
          gscid: null,
          gcid: null,
          data: {
            "gscid": _gscid,
            "gcid": _gcid,
            "sessionId": _sessionID,
            "deviceId": _deviceID,
            "device_type": _deviceType,
          },
        ).toBase64();
      },
    );

    _socketIO?.on(
      'apollo_connected',
      (_) {
        log("\n----------------------------\nApollo Connected\n----------------------------\n");

        _isApolloConnected = true;
        _sendSocketPacketToApollo(request: null);

        if (_isApolloReconnected) {
          _isApolloReconnected = false;
          _reconnectStatusSubject?.sink
              .add([_isApolloConnected, _isIrisConnected]);
        }
      },
    );

    _socketIO?.on(
      'iris_connected',
      (_) {
        log("\n----------------------------\nIris Connected\n----------------------------\n");

        _isIrisConnected = true;
        _sendSocketPacketToIris(request: null);

        if (_isIrisReconnected) {
          _isIrisReconnected = false;
          _reconnectStatusSubject?.sink
              .add([_isApolloConnected, _isIrisConnected]);
        }
      },
    );

    _socketIO?.on(
      'apollo_response',
      _getSocketPacketForApollo,
    );

    _socketIO?.on(
      'iris_response',
      _getSocketPacketForIris,
    );

    _socketIO?.on(
      'disconnect',
      (_) {
        log("\n----------------------------\nSocket IO Disconnected\n----------------------------\n");

        _isSocketIOConnected = false;
        _isApolloConnected = false;
        _isIrisConnected = false;
      },
    );

    _socketIO?.on(
      'apollo_disconnected',
      (flags) {
        log("\n----------------------------\nApollo Disconnected\n----------------------------\n");

        _isApolloReconnected = true;
        _isApolloConnected = false;
        _isIrisLoginSucessfull = false;
        _isIrisLoginRequestProcessing = false;

        // _socketIO?.emit(
        //   'established_apollo_iris_tcp',
        //   [_isApolloConnected, _isIrisConnected].toString(),
        // );
      },
    );

    _socketIO?.on(
      'iris_disconnected',
      (_) {
        log("\n----------------------------\nIris Disconnected\n----------------------------\n");

        _isIrisReconnected = true;
        _isIrisConnected = false;
        _isApolloLoginSucessfull = false;
        _isApolloLoginRequestProcessing = false;

        // _socketIO?.emit(
        //   'established_apollo_iris_tcp',
        //   [_isApolloConnected, _isIrisConnected].toString(),
        // );
      },
    );
  }

  void _sendSocketPacketToApollo({String? request}) {
    try {
      //  Check Socket-IO & Apollo connected or not
      if (_isSocketIOConnected && _isApolloConnected) {
        //  Check request is not empty and also apollo login
        if (_isApolloLoginSucessfull && (request?.isNotEmpty ?? false)) {
          _socketIO?.emit('apollo_request', request);
        } else {
          //  Login request in under process.
          if (_isApolloLoginRequestProcessing &&
              (request?.isNotEmpty ?? false)) {
            _pendingApolloRequest.add(request);
          }
          //  Send login request
          else {
            _isApolloLoginRequestProcessing = true;
            _socketIO?.emit('apollo_request', _loginApolloRequest);
          }
        }
      }
    } catch (sendError) {
      log("Send Data on Apollo Socket Error - ${sendError.toString()}");
    }
  }

  void _getSocketPacketForApollo(chunks) {
    try {
      if (chunks.toString().isNotEmpty) {
        for (var packet in chunks.toString().split('\n')) {
          if (packet.toString().isNotEmpty) {
            final responseObj = ApolloResponsetModel.fromBase64Data(packet);

            switch (responseObj.response.streamingType) {
              case ApolloResponseStreamingType.unknown:
                _apolloBrodcastResponseSubject?.sink.addError({
                  ApolloResponseStreamingType.unknown.toStringValue():
                      'Unknow Apollo Streaming Type'
                });
                break;

              case ApolloResponseStreamingType.LoginResponse:
                _isApolloLoginRequestProcessing = false;

                int erroCode =
                    int.parse("${responseObj.response.data["error_code"]}");
                if (erroCode == 0) {
                  _isApolloLoginSucessfull = true;

                  final requests = _pendingApolloRequest
                      .where((element) => ((element ?? "").isNotEmpty))
                      .toList();

                  _pendingApolloRequest = [];

                  for (var element in requests) {
                    _sendSocketPacketToApollo(request: element);
                  }
                } else {
                  _isApolloLoginSucessfull = false;
                  //reconnectSocketIOServer();
                }
                break;

              case ApolloResponseStreamingType.TopGainersResponse:
                _apolloTopGainersSubject?.sink.add(responseObj.response.data);
                break;

              case ApolloResponseStreamingType.TopLosersResponse:
                _apolloTopLoosersSubject?.sink.add(responseObj.response.data);
                break;

              case ApolloResponseStreamingType.MarketMoversResponse:
                _apolloMaketMoversSubject?.sink.add(responseObj.response.data);
                break;

              case ApolloResponseStreamingType.MarketMoversByValueResponse:
                _apolloMarketMoversByValueSubject?.sink
                    .add(responseObj.response.data);
                break;

              case ApolloResponseStreamingType.ltpinfo:
                _apolloBrodcastResponseSubject?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
              case ApolloResponseStreamingType.AlertResponse:
                _apolloAlertDeleteResponseSubject?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;

              case ApolloResponseStreamingType.AlertExecuted:
                if (AppFlagConstant().currentScreen == 'stockalert') {
                  _apolloAlertDeleteResponseSubject?.sink.add({
                    responseObj.response.streamingType.toStringValue():
                        responseObj.response.data
                  });
                  break;
                } else {
                  _apolloBrodcastResponseSubject?.sink.add({
                    responseObj.response.streamingType.toStringValue():
                        responseObj.response.data
                  });
                  break;
                }

              default:
                _apolloBrodcastResponseSubject?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
            }
          }
        }
      }
    } catch (readeError) {
      log("Read Packet from Apollo Socket Error - ${readeError.toString()}");
    }
  }

  void _sendSocketPacketToIris({String? request}) {
    try {
      //  Check Socket-IO & Iris connected or not
      if (_isSocketIOConnected && _isIrisConnected) {
        //  Check request is not empty and also iris login
        if (_isIrisLoginSucessfull && (request?.isNotEmpty ?? false)) {
          _socketIO?.emit('iris_request', request);
        } else {
          //  Login request in under process.
          if (_isIrisLoginRequestProcessing && (request?.isNotEmpty ?? false)) {
            _pendingIrisRequest.add(request);
          }
          //  Send login request
          else {
            _isIrisLoginRequestProcessing = true;
            _socketIO?.emit('iris_request', _loginIrisRequest);
          }
        }
      }
    } catch (sendError) {
      log("Send Data on Iris Socket Error - ${sendError.toString()}");
    }
  }

  void _getSocketPacketForIris(chunks) {
    try {
      if (chunks.toString().isNotEmpty) {
        for (var packet in chunks.toString().split('\n')) {
          if (packet.toString().isNotEmpty) {
            final responseObj = IrisResponsetModel.fromBase64Data(packet);

            switch (responseObj.response.streamingType) {
              case IrisResponseStreamingType.unknown:
                _irisOrderResponseSubject?.sink.addError({
                  IrisResponseStreamingType.unknown.toStringValue():
                      'Unknow Apollo Streaming Type'
                });
                break;

              case IrisResponseStreamingType.LoginResponse:
                _isIrisLoginRequestProcessing = false;

                int erroCode =
                    int.parse("${responseObj.response.data["error_code"]}");
                if (erroCode == 0) {
                  _isIrisLoginSucessfull = true;

                  final requests = _pendingIrisRequest
                      .where((element) => ((element ?? "").isNotEmpty))
                      .toList();

                  _pendingIrisRequest = [];

                  _irisOrderResponseSubject?.sink.add({
                    responseObj.response.streamingType.toStringValue():
                        responseObj.response.data
                  });

                  for (var element in requests) {
                    _sendSocketPacketToIris(request: element);
                  }
                } else {
                  _isIrisLoginSucessfull = false;
                  //reconnectSocketIOServer();
                }
                break;

              case IrisResponseStreamingType.AvailablePayOutResponse:
                _withdrawResponse?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
              case IrisResponseStreamingType.MarginDetailResponse:
                _marginResponse?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
              case IrisResponseStreamingType.HoldingValueInfoResp:
                _holdingResponse?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
              case IrisResponseStreamingType.ProductChangeResponse:
                _productChnageResponse?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
              case IrisResponseStreamingType.AdminMessages:
                if (AppFlagConstant().currentScreen == 'notification') {
                  _irisAdminMessageResponseSubject?.sink.add({
                    responseObj.response.streamingType.toStringValue():
                        responseObj.response.data
                  });
                } else {
                  _irisOrderResponseSubject?.sink.add({
                    responseObj.response.streamingType.toStringValue():
                        responseObj.response.data
                  });
                }

                break;
              default:
                _irisOrderResponseSubject?.sink.add({
                  responseObj.response.streamingType.toStringValue():
                      responseObj.response.data
                });
                break;
            }
          }
        }
      }
    } catch (readeError) {
      log("Read Packet from Apollo Socket Error - ${readeError.toString()}");
    }
  }

  void _logoff() {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "sessionId": _sessionID,
      "device_type": _deviceType,
    };

    final logoffRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.logoff,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToApollo(request: logoffRequest.toBase64());
    _sendSocketPacketToIris(request: logoffRequest.toBase64());
  }

  void socketIOHeartBeat() {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "sessionId": _sessionID,
    };

    final _heartbeatRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.HeartBeat,
      gscid: null,
      gcid: null,
      data: requestData,
    );
    if (_isApolloConnected) {
      _sendSocketPacketToApollo(request: _heartbeatRequest.toBase64());
    }
    if (_isIrisConnected) {
      _sendSocketPacketToIris(request: _heartbeatRequest.toBase64());
    }
  }

  void subscribeForTopGainers(int marketID) {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "marketid": "$marketID",
      "sessionId": _sessionID,
    };

    final gainerRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.topgainers,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToApollo(request: gainerRequest.toBase64());
  }

  void subscribeForTopLoosers(int marketID) {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "marketid": "$marketID",
      "sessionId": _sessionID,
    };

    final losersRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.toplosers,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToApollo(request: losersRequest.toBase64());
  }

  void subscribeForMarketMovers(int marketID) {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "marketid": "$marketID",
      "sessionId": _sessionID,
    };

    final moverRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.marketmovers,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToApollo(request: moverRequest.toBase64());
  }

  void subscribeForMarketMoversByValue(int marketID) {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "marketid": "$marketID",
      "sessionId": _sessionID,
    };

    final moversByValueRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.marketmoversByValue,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToApollo(request: moversByValueRequest.toBase64());
  }

  void unSubscribeLTPInfoTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final ltpInfoRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.unsubscribe,
      streamingType: ApolloRequestStreamingType.ltpinfo,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: ltpInfoRequest.toBase64());
  }

  void subscribeLTPInfoTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final ltpInfoRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.ltpinfo,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: ltpInfoRequest.toBase64());
  }

  void unsubscribeIndexTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final indexRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.unsubscribe,
      streamingType: ApolloRequestStreamingType.indexStream,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: indexRequest.toBase64());
  }

  void subscribeIndexTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final indexRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.indexStream,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: indexRequest.toBase64());
  }

  void unSubscribeMarketPictureTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final _marketPictureRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.unsubscribe,
      streamingType: ApolloRequestStreamingType.marketPicture,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: _marketPictureRequest.toBase64());
  }

  void subscribeMarketPictureTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final _marketPictureRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.marketPicture,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: _marketPictureRequest.toBase64());
  }

  void subscribeTouchLineTokens(List<String?> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final _touchLineRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.touchline,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: _touchLineRequest.toBase64());
  }

  void unSubscribeTouchLineTokens(List<String> tokens) {
    final symbols = {
      "symbols": tokens
          .map(
            (element) => {"symbol": element},
          )
          .toList(),
    };

    final _touchLineRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.unsubscribe,
      streamingType: ApolloRequestStreamingType.touchline,
      gscid: _gscid,
      gcid: _gcid,
      data: symbols,
    );

    _sendSocketPacketToApollo(request: _touchLineRequest.toBase64());
  }

  void placeNewOrder({required Map<String, dynamic> data}) {
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.NewOrderRequest,
      gscid: null,
      gcid: null,
      data: data,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void placeModifyOrder({required Map<String, dynamic> data}) {
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.ModifyOrderRequest,
      gscid: null,
      gcid: null,
      data: data,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void placeCancelOrder({required Map<String, dynamic> data}) {
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.CancelOrderRequest,
      gscid: null,
      gcid: null,
      data: data,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void holdingValue() {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.HoldingValueInfo,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void marginDetailRequest() {
    final requestData = {
      'segment': "2",
      "exchange_type": "-1",
      "gcid": _gcid,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.MarginDetailRequest,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void holdingDataListRequest() {
    final requestData = {
      "gscid": _gscid,
      "gcid": _gcid,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.HoldingDetailsInfo,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void userAlertRequest(AddAlertModelClass addAlertModelClass) {
    final requestData = {
      "gcid": _gcid,
      "sessionId": _sessionID,
      "rule_id": addAlertModelClass.ruleNo,
      "range_value": addAlertModelClass.range,
      "direction": addAlertModelClass.direction,
      "gtoken": addAlertModelClass.gToken,
      "rule_type": addAlertModelClass.alertType,
      "operation": addAlertModelClass.operation,
    };

    final userAlertRequest = ApolloRequestModel.JSONFrom(
      requestType: SocketRequestType.subscribe,
      streamingType: ApolloRequestStreamingType.UserAlert,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToApollo(request: userAlertRequest.toBase64());
  }

  void productChangeRequestApi(ProductChangeRequestModel obj) {
    final requestData = {
      "gscid": obj.gscid,
      "gtoken": obj.gtoken,
      "qty": obj.qty,
      "product": obj.product,
      "traded_qty": obj.tradedQty,
      "iGiveUpStatus": obj.iGiveUpStatus,
      "reason": obj.reason,
      "gorderid": obj.gorderid,
      "tradeid": obj.tradeid,
      "eorderid": obj.eorderid,
      "side": obj.side,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.ProductChangeRequest,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void getEDISHoldingInfo() {
    final requestData = {
      "gscid": _gscid,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.getEDISHoldingInfo,
      gscid: "",
      gcid: "",
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void getHoldingScripPositionInfo({required String token}) {
    final requestData = {
      "gscid": _gscid,
      "token": token,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.HoldingScripPositionInfo,
      gscid: "",
      gcid: "",
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void getEPledgeHoldingInfo() {
    final requestData = {
      "gscid": _gscid,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: "",
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.EPledgeHoldingInfo,
      gscid: "",
      gcid: "",
      data: requestData,
    );
    _sendSocketPacketToIris(request: request.toBase64());
  }

  void updateAuthorizationStatus(Object obj) {
    var ssymbols = obj;
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.updateAuthorizationStatus,
      gscid: _gscid,
      gcid: _gcid,
      data: ssymbols as Map<String, dynamic>,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void npDetailsRequest() {
    final requestData = {
      "gscid": _gscid,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.NPDetailRequest,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void securityInfoRequest(String token) {
    final requestData = {
      "gcid": _gcid,
      "gtoken": token,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.SymbolVarMarginRequest,
      gscid: _gscid,
      gcid: _gcid,
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void availablePayoutRequest() {
    final requestData = {
      "gcid": _gcid,
      "sessionId": _sessionID,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.AvailablePayOutRequest,
      gscid: '',
      gcid: '',
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void fundPayoutRequest(String payoutAmountCom, String payoutAmount) {
    final requestData = {
      "gcid": _gcid,
      "payout_amount_com": payoutAmountCom,
      'payout_amount': payoutAmount,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.FundPayOutRequest,
      gscid: '',
      gcid: '',
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }

  void fundTransfetDetailsRequest(
      {required String ourTransId,
      required String amount,
      required String orderState,
      required String segment}) {
    final requestData = {
      "gcid": _gcid,
      "our_trans_id": ourTransId,
      "gscid": _gscid,
      "amount": amount,
      "order_state": orderState,
      "segment": segment,
    };
    final request = IRISRequestModel.JSONFrom(
      sessionId: _sessionID,
      requestType: SocketRequestType.subscribe,
      streamingType: IrisRequestStreamingType.FundTransferDetails,
      gscid: '',
      gcid: '',
      data: requestData,
    );

    _sendSocketPacketToIris(request: request.toBase64());
  }
}
