// ignore_for_file: non_constant_identifier_names

class Customer {
  int? id;
  String? description;
  String? expiryDate;
  String? expiryTimestamp;
  String? optionType;
  String? seriesName;
  String? strikePrice;
  String? symbol;
  String? scripname;
  String? token;

  Customer({
    this.id,
    this.description,
    this.expiryDate,
    this.expiryTimestamp,
    this.optionType,
    this.seriesName,
    this.strikePrice,
    this.symbol,
    this.scripname,
    this.token,
  });

  Customer.fromMap(Map<String, Object?> first);

  // int? get id => id;
  String? get description_txt => description;
  String? get expiryDate_value => expiryDate;
  String? get expiryTimestamp_value => expiryTimestamp;
  String? get optionType_value => optionType;
  String? get seriesName_value => seriesName;
  String? get strikePrice_value => strikePrice;
  String? get symbol_value => symbol;
  String? get scripname_value => scripname;
  String? get token_value => token;

  factory Customer.fromJson(Map<String, dynamic> data) => Customer(
        id: data["id"],
        description: data["description"],
        expiryDate: data["expiryDate"],
        expiryTimestamp: data["expiryTimestamp"],
        optionType: data["optionType"],
        seriesName: data["seriesName"],
        strikePrice: data["strikePrice"],
        symbol: data["symbol"],
        scripname: data["scripname"],
        token: data["token"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "description": description,
        "expiryDate": expiryDate,
        "expiryTimestamp": expiryTimestamp,
        "optionType": optionType,
        "seriesName": seriesName,
        "strikePrice": strikePrice,
        "symbol": symbol,
        "scripname": scripname,
        "token": token,
      };
}
