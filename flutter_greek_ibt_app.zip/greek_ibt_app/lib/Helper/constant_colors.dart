import 'package:flutter/material.dart';

class ConstantColors {
  static const white = Colors.white;
  static const black = Colors.black;
  static const scaffoldBackgroundColor = Colors.white;
  static const primaryColor = Colors.white;
  static const cardTheme = Colors.white;
  static const primaryColorLight = Colors.lightBlue;
  static const primaryColorVitt = Color(0xFF0072B4);
  static const primaryColorDark = Colors.blueAccent;
  static const canvasColor = Colors.white;
  static const accentColor = Colors.white;
  static const bottomAppBarColor = Colors.blueAccent;
  static const cardColor = Colors.white;

  static const dividerColor = Color(0xFFA1A1A1);
  static const focusColor = Colors.blueAccent;
  static const colorsSchemePrimary = Colors.white;
  static const onPrimary = Colors.white;
  static const primaryVariant = Colors.white;
  static const secondary = Colors.white;
  static const buyColor = Color.fromRGBO(3, 165, 46, 1);
  static const textBuyColor = Color.fromRGBO(3, 165, 46, 1);

  static const sellColor = Color.fromRGBO(248, 83, 49, 1);
  static const textSellColor = Color.fromRGBO(248, 83, 49, 1);
  static const borderColor = Color(0x7CAFAFAF);
  static const watchlistText = Colors.black;
  static const marketText = Color(0xFF333333);
  static const edisheader = Color(0xFF0072B4);
  static const fundltstcontainer = Color.fromRGBO(246, 246, 246, 1);

  static const searchSymbolPlaceHolderColor = Color(0xFF707070);
}
