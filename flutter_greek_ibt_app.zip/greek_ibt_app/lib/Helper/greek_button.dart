import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';

class GreekButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onPressed;

  const GreekButton({Key? key, required this.onPressed, required this.child})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    switch (AppConfig().currentPlatform) {
      case AppPlatform.iOS:
        return CupertinoButton.filled(
          child: child,
          onPressed: onPressed,
        );

      default:
        return TextButton(
          onPressed: onPressed,
          child: child,
          style: TextButton.styleFrom(
            backgroundColor: Theme.of(context).primaryColor,
          ),
        );
    }
  }
}
