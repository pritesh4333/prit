class AppFlagConstant {
  static final AppFlagConstant _appFlagConstant = AppFlagConstant._internal();

  factory AppFlagConstant() {
    return _appFlagConstant;
  }

  AppFlagConstant._internal();

//Define Flag Structure [camelCase]]
  String kUrl = '';

  String validateTransaction = '';
  String defaultProduct = '';
  String validate2FA = '';
  String holdingFlag = '';
  String validateGuest = '';
  String validateThrough = '';
  String showLogin = '';
  String heartbeatIntervals = '';
  String reconnectionAttempts = '';
  String showDescription = '';
  String validatePasswordOnce = '';
  String ftTestingBypass = '';
  String isSecure = '';
  String arachneIP = '';
  String apolloIP = '';
  String irisIP = '';
  String arachnePort = '';
  String orderSenderPort = '';
  String broadcastSenderPort = '';
  String irisPort = '';
  String apolloPort = '';
  String chartSetting = '';
  String isStrategyProduct = '';
  String isEDISProduct = '';
  String isRedisEnabled = '';
  String aprVersion = '';
  String isBOReport = '';
  String paymentGateway = '';
  String upiPaymentEnabled = '';
  String ftLink = '';
  String ftLinkUpi = '';
  String pledgeOffline = '';
  String isPledgeProduct = '';
  String dpType = '';
  String sslUrl = '';
  String showTradeAlert = 'false';
  String isOrderConfirmDialog = 'false';
  String isOrderTradeDialog = 'false';
  String isFromScreen = '';
  String scripCountInWatchlist = '50';
  int orderResponseDialogcounter = 0;
  String eKycSignUpUrl = '';
  String eKycSignUpPort = '';
  String loginCompliance = '';
  String defaultScreenIndex = '0';
  String currentScreen = '';
}
