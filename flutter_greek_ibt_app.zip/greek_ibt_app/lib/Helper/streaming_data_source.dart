import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:tuple/tuple.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';

class StreamingDataModel {
  final int? token;
  final String? symbol;
  double? ltp;
  double? change;
  double? preChange;

  StreamingDataModel({
    required this.token,
    required this.symbol,
    required this.ltp,
    required this.change,
    required this.preChange,
  });
}

class StreamingDataSource extends DataGridSource {
  static const _symbolColumnID = "SymbolColumnID";
  static const _ltpColumnID = "LTPColumnID";

  final List<StreamingDataModel> streamingDataModelList;
  String? isFrom = '';
  StreamingDataSource({
    required this.streamingDataModelList,
    this.isFrom,
  }) {
    _registerLTPStreming();
    _preparDataSource();
  }

  @override
  void dispose() {
    unSubscribeLTPInfo();

    super.dispose();
  }

  List<String> _subscribeLTPInfoTokenArray = <String>[];
  List<String> _unSubscribeLTPInfoTokenArray = <String>[];
  void _registerLTPStreming() {
    SocketIOManager().brodcastResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();

          for (var item in keys) {
            if (item.apolloResponseStreamingType == ApolloResponseStreamingType.ltpinfo || item.apolloResponseStreamingType == ApolloResponseStreamingType.marketPicture) {
              final responseDic = event[item];
              if (responseDic is Map<String, dynamic>) {
                if ((responseDic['symbol'] != null) && (responseDic['ltp'] != null) && (responseDic['change'] != null) && (responseDic['p_change'] != null)) {
                  final token = int.tryParse(responseDic['symbol']?.toString() ?? "");
                  final ltp = double.tryParse(responseDic['ltp']?.toString() ?? "");
                  final change = double.tryParse(responseDic['change']?.toString() ?? "");
                  final pChange = double.tryParse(responseDic['p_change']?.toString() ?? "");

                  final tokenIndex = _subscribeLTPInfoTokenArray.indexOf(token?.toString() ?? "");

                  if (tokenIndex >= 0) {
                    final obj = streamingDataModelList[tokenIndex];
                    obj.ltp = ltp;
                    obj.change = change;
                    obj.preChange = pChange;

                    streamingDataModelList[tokenIndex] = obj;

                    _dataRowList[tokenIndex].getCells()[1] = DataGridCell<Tuple2>(
                      columnName: _ltpColumnID,
                      value: Tuple2<String, Tuple2<String, String>>(
                        obj.ltp?.toFormateDicemalPoint(token: obj.token) ?? "",
                        Tuple2<String, String>(
                          obj.change?.toFormateDicemalPoint(token: obj.token) ?? "",
                          obj.preChange?.toFormateDicemalPoint(token: obj.token) ?? "",
                        ),
                      ),
                    );

                    notifyDataSourceListeners(
                      rowColumnIndex: RowColumnIndex(
                        tokenIndex,
                        1,
                      ),
                    );
                  }
                }
                break;
              }
            }
          }
        }
      },
    );
  }

  void subscribeLTPInfo() {
    unSubscribeLTPInfo();

    _subscribeLTPInfoTokenArray = streamingDataModelList
        .map(
          (e) => e.token?.toString() ?? "",
        )
        .where(
          (element) => (element.isNotEmpty),
        )
        .toList();

    SocketIOManager().subscribeLTPInfoTokens(_subscribeLTPInfoTokenArray);
    _unSubscribeLTPInfoTokenArray = _subscribeLTPInfoTokenArray;
  }

  void unSubscribeLTPInfo() {
    if (_unSubscribeLTPInfoTokenArray.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(_unSubscribeLTPInfoTokenArray);
      _unSubscribeLTPInfoTokenArray.clear();
    }
  }

  List<GridColumn> dataColumnList = <GridColumn>[];
  List<DataGridRow> _dataRowList = <DataGridRow>[];

  @override
  List<DataGridRow> get rows => _dataRowList;

  void _preparDataSource() {
    dataColumnList.clear();
    dataColumnList = List<GridColumn>.generate(
      2,
      (index) {
        switch (index) {
          case 0:
            return GridColumn(
              columnName: _symbolColumnID,
              allowEditing: false,
              allowSorting: true,
              minimumWidth: 50.0,
              label: const SizedBox(height: 0.0),
            );
          default:
            return GridColumn(
              columnName: _ltpColumnID,
              allowEditing: false,
              allowSorting: true,
              width: (isFrom ?? '').toLowerCase() == "watchlist" ? 200 : 130,
              label: const SizedBox(height: 0.0),
            );
        }
      },
    );

    _dataRowList.clear();
    _dataRowList = streamingDataModelList
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: List<DataGridCell<Tuple2>>.generate(
              2,
              (index) {
                switch (index) {
                  case 0:
                    return DataGridCell<Tuple2>(
                      columnName: _symbolColumnID,
                      value: Tuple2<String, int?>(
                        e.symbol ?? "",
                        e.token,
                      ),
                    );
                  default:
                    return DataGridCell<Tuple2>(
                      columnName: _ltpColumnID,
                      value: Tuple2<String, Tuple2<String, String>>(
                        e.ltp?.toFormateDicemalPoint(token: e.token) ?? "",
                        Tuple2<String, String>(
                          e.change?.toFormateDicemalPoint(token: e.token) ?? "",
                          e.preChange?.toFormateDicemalPoint(token: e.token) ?? "",
                        ),
                      ),
                    );
                }
              },
            ),
          ),
        )
        .toList();

    notifyDataSourceListeners();

    subscribeLTPInfo();
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    int? token;
    return DataGridRowAdapter(
      cells: row.getCells().map<Widget>(
        (cellObj) {
          switch (cellObj.columnName) {
            case _symbolColumnID:
              final cellTuple = (cellObj.value as Tuple2<String, int?>);
              token = cellTuple.item2;
              return Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Flexible(
                    flex: 1,
                    child: Container(
                      padding: const EdgeInsets.only(left: 8.0, top: 8.0),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        cellTuple.item1,
                        style: GreekTextStyle.watchlistText,
                      ),
                    ),
                  ),
                  Flexible(
                    flex: 1,
                    child: Container(
                      padding: const EdgeInsets.only(left: 8.0, bottom: 8.0),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        token?.toExchange() ?? "",
                        style: GreekTextStyle.watchlistSubText,
                      ),
                    ),
                  ),
                ],
              );

            default:
              final cellTuple = (cellObj.value as Tuple2<String, Tuple2<String, String>>);
              return Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Flexible(
                    flex: 1,
                    child: Container(
                      padding: const EdgeInsets.only(right: 8.0, top: 8.0),
                      alignment: Alignment.centerRight,
                      child: Text(
                        cellTuple.item1,
                        style: GreekTextStyle.watchlistText,
                      ),
                    ),
                  ),
                  Flexible(
                    flex: 1,
                    child: Container(
                      padding: const EdgeInsets.only(right: 8.0, bottom: 8.0),
                      alignment: Alignment.centerRight,
                      child: Text(
                        "${cellTuple.item2.item1}(${cellTuple.item2.item2}%)",
                        style: ((double.tryParse(cellTuple.item2.item1) ?? 0) >= 0) ? GreekTextStyle.headingWatchlistLTPGreen : GreekTextStyle.headingWatchlistLTPRed,
                      ),
                    ),
                  ),
                ],
              );
          }
        },
      ).toList(),
    );
  }
}
