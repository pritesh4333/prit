abstract class GreekBlocs {
  void disposeBloc();
  void deactivateBloc() {}
  void activateBloc() {}
}
