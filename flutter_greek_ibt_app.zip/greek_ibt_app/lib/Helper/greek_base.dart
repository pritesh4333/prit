// ignore_for_file: invalid_use_of_protected_member

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/marketStatus_flag.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/streaming_data_source.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/bloc/landing_bloc.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/allowed_product_model.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/market_status_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/indian_indicesdata_response_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/greek_urls.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:tuple/tuple.dart';

import 'constant_colors.dart';

class GreekBase {
  // Singleton object
  static final GreekBase _singleton = GreekBase._internal();

  factory GreekBase() {
    return _singleton;
  }

  GreekBase._internal();

  BehaviorSubject<OrderScreenState>? orderScreenState =
      BehaviorSubject.seeded(OrderScreenState.unknown);
  BehaviorSubject<PortfolioScreenState?> portfolioScreenState =
      BehaviorSubject.seeded(PortfolioScreenState.holding);

  static PortfolioScreenState portfolioStateObject =
      PortfolioScreenState.unknown;

  final GlobalKey<ScaffoldState> drawerKey = GlobalKey<ScaffoldState>();
  var mapData = List<List<SymbolList>>.generate(5, (index) => <SymbolList>[]);

  void logoutApp({required BuildContext logoffContext}) {
    AppConfig().serverInfo = GreekURLs.currentServerInfo;

    SocketIOManager().disconnectServer(isSendLogoffRequest: true);
    AppConfig().islogoff = true;

    AppConfig().deleteUser();
    AppConfig().deleteOTP();
    GreekNavigator.pushReplacementNamed(
      context: logoffContext,
      routeName: GreekScreenNames.login,
    );
  }

  List<String> watchlistGroupArray = <String>[];
  BehaviorSubject<CommonListenID?> commonListenObserver =
      BehaviorSubject<CommonListenID?>();
  BehaviorSubject<bool> userActionForWatchListCreateObserver =
      BehaviorSubject<bool>();
  BehaviorSubject<int?> userActionForWatchListSelectObserver =
      BehaviorSubject<int?>();
  BehaviorSubject<int?> userActionForWatchListDeleteObserver =
      BehaviorSubject<int?>();
  BehaviorSubject<String> userActionForWatchListRenameObserver =
      BehaviorSubject<String>();
  BehaviorSubject<int?> userActionForSymbolDeleteObserver =
      BehaviorSubject<int?>();
  BehaviorSubject<FundScreenUserAction> userActionForFundScreenObserver =
      BehaviorSubject<FundScreenUserAction>();

  List<MarketSegment> marketSegments = <MarketSegment>[];
  List<AllowedProduct?> alloedProductList = <AllowedProduct?>[];

  Tuple3? productChangeParm;

  //=====================================================================
  ///
  /// For Product name or vice varsa
  ///
  //=====================================================================
  String getProductNameFromProductToken(int productToken) {
    return alloedProductList
        .firstWhere((element) => (element!.iProductToken! == productToken))!
        .cProductName!;
  }

  String getProductTokenFromProductName(String name) {
    return alloedProductList
            .firstWhere(
              (element) => (element?.cProductName
                      ?.toUpperCase()
                      .compareTo(name.toUpperCase()) ==
                  0),
              orElse: () => null,
            )
            ?.iProductToken
            ?.toString() ??
        '';
  }

  //=====================================================================

  // =====================================================================
  ///
  /// For Order Type or vice varsa
  ///
  //=====================================================================
  String getOrderNameFromOrderToken(int orderToken) {
    switch (orderToken) {
      case 1:
        return 'Limit';
      case 2:
        return 'Market';
      case 3:
        return 'Stop Loss';
      case 4:
        return 'StopLoss Market';
      case 5:
        return 'Cover';
      case 6:
        return 'After Market';
      case 7:
        return 'Bracket';
      default:
        return 'Limit';
    }
  }

  String getOrderTypeFromOrderName(String orderName) {
    switch (orderName.toLowerCase()) {
      case "limit":
        return '1';
      case "market":
        return '2';
      case "stop loss":
        return '3';
      case "stoploss market":
        return '4';
      case "cover":
        return '5';
      case "after market":
        return '6';
      case "bracket":
        return '7';
      default:
        return '1';
    }
  }

  String getOrderTypeFromShortOrderName(String orderName) {
    switch (orderName.toLowerCase()) {
      case "limit":
        return '1';
      case "market":
        return '2';
      case "sl":
        return '3';
      case "slm":
        return '4';
      case "cover":
        return '5';
      case "after market":
        return '6';
      case "bracket":
        return '7';
      default:
        return '1';
    }
  }

  //=====================================================================

  // =====================================================================
  ///
  /// For Validity or vice varsa
  ///
  //=====================================================================
  String getValidityNameFromValidityToken(int validityToken) {
    switch (validityToken) {
      case 0:
        return "DAY";
      case 1:
        return "IOC";
      case 2:
        return "EOS";
      case 3:
        return "GTD";
      case 4:
        return "GTC";
      default:
        return "DAY";
    }
  }

  String getValidityTypeFromValidityName(String validityName) {
    switch (validityName.toLowerCase()) {
      case "day":
        return '0';
      case "ioc":
        return '1';
      case "eos":
        return '2';
      case "gtd":
        return '3';
      case "gtc":
        return '4';
      default:
        return '1';
    }
  }

  int getBitResult(int orderFlag) {
/* 
        short bitRes = (short) ((orderFlag >> 6) & 0x1);

        return bitRes; */

    return ((orderFlag >> 6) & 0x1);
  }

  int _getDayResult(int orderFlag) {
    return ((orderFlag >> 3) & 0x1);
  }

  int _getIOCResult(int orderFlag) {
    return ((orderFlag >> 1) & 0x1);
  }

  int _getGTCResult(int orderFlag) {
    return ((orderFlag >> 2) & 0x1);
  }

  int _getEOSResult(int orderFlag) {
    return ((orderFlag >> 0) & 0x1);
  }

  String getValidityFromBitwiseOprater(
      {required int goodTillDate, required int validity}) {
    if (goodTillDate > 0) {
      return 'GTD';
    } else if (_getDayResult(validity) == 1) {
      return 'DAY';
    } else if (_getIOCResult(validity) == 1) {
      return 'IOC';
    } else if (_getGTCResult(validity) == 1) {
      return 'GTC';
    } else if (_getEOSResult(validity) == 1) {
      return 'EOS';
    } else {
      return '';
    }
  }

  //=====================================================================

  Widget noDataAvailableView({String? msg}) => Text(
        ((msg != null) && (msg.isNotEmpty))
            ? msg
            : ConstantMessages.GREEK_NO_DATA_MSG,
        textAlign: TextAlign.center,
        style: GreekTextStyle.heading18,
      );

  //=========================================================================

  //=====================================================================

  int getMarketIDByMarketSegment({required String marketSegment}) {
    switch (marketSegment.toUpperCase()) {
      case 'NSE':
        return 1;
      case 'NSE FUTSTK':
        return 21;
      case 'NSE OPTSTK':
        return 22;
      case 'NSECURR':
        return 3;
      case 'NSECOMM':
        return 16;
      case 'BSE':
        return 4;
      case 'BSECURR':
        return 6;
      case 'BSECOMM':
        return 17;
      case 'MCX':
        return 9;
      case 'NCDEX':
        return 7;

      default:
        return -1;
    }
  }

  //=========================================================================

  // MarketStatusFlag

  void getMarketStatusFlags(List<MarketStatusResponseModel?> value) {
    for (var item in value) {
      if (GreekBase().marketSegments.contains(MarketSegment.nseeq)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "1") {
          // MarketStatusFlag.eq = true;
          // MarketStatusFlag.nse_eq = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_eq_status = false;
          MarketStatusFlag.isPreOpen_nse_eq = false;
          MarketStatusFlag.isPostClosed_nse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "1") {
          // appConfig.eq = false;
          // appConfig.nse_eq = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_eq_status = true;
          MarketStatusFlag.isPreOpen_nse_eq = false;
          MarketStatusFlag.isPostClosed_nse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "1") {
          // MarketStatusFlag.eq = false;
          // MarketStatusFlag.nse_eq = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_eq_status = true; //closed
          MarketStatusFlag.isPreOpen_nse_eq = false;
          MarketStatusFlag.isPostClosed_nse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "1") {
          // MarketStatusFlag.eq = false;
          // MarketStatusFlag.nse_eq = "yellow';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_eq_status = false; //preopen
          MarketStatusFlag.isPreOpen_nse_eq = true;
          MarketStatusFlag.isPostClosed_nse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "1") {
          // MarketStatusFlag.eq = false;
          // MarketStatusFlag.nse_eq = "blue';// Pre open close
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_eq_status =
              true; //need to chaged straus to true after testing. in web is true
          MarketStatusFlag.isPreOpen_nse_eq = false;
          MarketStatusFlag.isPostClosed_nse_eq = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "1") {
          // MarketStatusFlag.eq = false;
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.nse_eq_status = false; // post close open
          MarketStatusFlag.isPreOpen_nse_eq = false;
          MarketStatusFlag.isPostClosed_nse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "1") {
          // MarketStatusFlag.eq = false;
          // MarketStatusFlag.nse_eq = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_eq_status = true;
          MarketStatusFlag.isPreOpen_nse_eq = false;
          MarketStatusFlag.isPostClosed_nse_eq = false;
        }
      }

      //FOR FNO
      if (GreekBase().marketSegments.contains(MarketSegment.nsefo)) {
        // if (MarketStatusFlag.allowedmarket_nfo) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "2") {
          // MarketStatusFlag.nse_fno = "green';
          // MarketStatusFlag.fno = true;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_fno_status = false;
          MarketStatusFlag.isPreOpen_nse_fno = false;
          MarketStatusFlag.isPostClosed_nse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "2") {
          // MarketStatusFlag.fno = false;
          // MarketStatusFlag.nse_fno = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_fno_status = true;
          MarketStatusFlag.isPreOpen_nse_fno = false;
          MarketStatusFlag.isPostClosed_nse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "2") {
          // MarketStatusFlag.fno = false;
          // MarketStatusFlag.nse_fno = "yellow';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_fno_status = false;
          MarketStatusFlag.isPreOpen_nse_fno = true;
          MarketStatusFlag.isPostClosed_nse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "2") {
          // MarketStatusFlag.fno = false;
          // MarketStatusFlag.nse_fno = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_fno_status = true;
          MarketStatusFlag.isPreOpen_nse_fno = false;
          MarketStatusFlag.isPostClosed_nse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "2") {
          // MarketStatusFlag.fno = false;
          // MarketStatusFlag.nse_fno = "blue';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_fno_status = false;
          MarketStatusFlag.isPreOpen_nse_fno = false;
          MarketStatusFlag.isPostClosed_nse_fno = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "2") {
          // MarketStatusFlag.fno = false;
          // MarketStatusFlag.nse_fno = "pink';
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.nse_fno_status = false;
          MarketStatusFlag.isPreOpen_nse_fno = false;
          MarketStatusFlag.isPostClosed_nse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "2") {
          // MarketStatusFlag.fno = false;
          // MarketStatusFlag.nse_fno = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_fno_status = true;
          MarketStatusFlag.isPreOpen_nse_fno = false;
          MarketStatusFlag.isPostClosed_nse_fno = false;
        }
      }

      //FOR CURRENCY
      if (GreekBase().marketSegments.contains(MarketSegment.nsecd)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "3") {
          // MarketStatusFlag.cd = true;
          // MarketStatusFlag.nse_cd = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_cd_status = false;
          MarketStatusFlag.isPreOpen_nse_cd = false;
          MarketStatusFlag.isPostClosed_nse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "3") {
          // MarketStatusFlag.nse_cd = "red';
          // MarketStatusFlag.cd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_cd_status = true;
          MarketStatusFlag.isPreOpen_nse_cd = false;
          MarketStatusFlag.isPostClosed_nse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "3") {
          // MarketStatusFlag.nse_cd = "yellow';
          // MarketStatusFlag.cd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_cd_status = false;
          MarketStatusFlag.isPreOpen_nse_cd = true;
          MarketStatusFlag.isPostClosed_nse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "3") {
          // MarketStatusFlag.nse_cd = "red';
          // MarketStatusFlag.cd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_cd_status = true;
          MarketStatusFlag.isPreOpen_nse_cd = false;
          MarketStatusFlag.isPostClosed_nse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "3") {
          // MarketStatusFlag.nse_cd = "blue';
          // MarketStatusFlag.cd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_cd_status = false;
          MarketStatusFlag.isPreOpen_nse_cd = false;
          MarketStatusFlag.isPostClosed_nse_cd = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "3") {
          // MarketStatusFlag.nse_cd = "pink';
          // MarketStatusFlag.cd = false;
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.nse_cd_status = false;
          MarketStatusFlag.isPreOpen_nse_cd = false;
          MarketStatusFlag.isPostClosed_nse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "3") {
          // MarketStatusFlag.nse_cd = "red';
          // MarketStatusFlag.cd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.nse_cd_status = true;
          MarketStatusFlag.isPreOpen_nse_cd = false;
          MarketStatusFlag.isPostClosed_nse_cd = false;
        }
      }

      // if (MarketStatusFlag.allowedmarket_mcx) {
      if (GreekBase().marketSegments.contains(MarketSegment.mcx)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = true;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "yellow';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = true;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = true;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "blue';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "pink';
          MarketStatusFlag.eq_post_close = true;

          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = true;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        }
      }

      // if (MarketStatusFlag.allowedmarket_bse) {
      if (GreekBase().marketSegments.contains(MarketSegment.bseeq)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bseeq = true;
          // MarketStatusFlag.bse_eq = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_eq_status = false;
          MarketStatusFlag.isPreOpen_bse_eq = false;
          MarketStatusFlag.isPostClosed_bse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bse_eq = "red';
          // MarketStatusFlag.bseeq = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_eq_status = true;
          MarketStatusFlag.isPreOpen_bse_eq = false;
          MarketStatusFlag.isPostClosed_bse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bse_eq = "yellow';
          // MarketStatusFlag.bseeq = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_eq_status = false;
          MarketStatusFlag.isPreOpen_bse_eq = true;
          MarketStatusFlag.isPostClosed_bse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bse_eq = "red';
          // MarketStatusFlag.bseeq = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_eq_status = true;
          MarketStatusFlag.isPreOpen_bse_eq = false;
          MarketStatusFlag.isPostClosed_bse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bse_eq = "blue';
          // MarketStatusFlag.bseeq = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_eq_status = true;
          MarketStatusFlag.isPreOpen_bse_eq = false;
          MarketStatusFlag.isPostClosed_bse_eq = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bse_eq = "pink';
          // MarketStatusFlag.bseeq = false;
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.bse_eq_status = false;
          MarketStatusFlag.isPreOpen_bse_eq = false;
          MarketStatusFlag.isPostClosed_bse_eq = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "4") {
          // MarketStatusFlag.bse_eq = "red';
          // MarketStatusFlag.bseeq = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_eq_status = true;
          MarketStatusFlag.isPreOpen_bse_eq = false;
          MarketStatusFlag.isPostClosed_bse_eq = false;
        }
      }

      // if (MarketStatusFlag.allowedmarket_bfo) {
      if (GreekBase().marketSegments.contains(MarketSegment.bsefo)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bsefno = true;
          // MarketStatusFlag.bse_fno = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_fno_status = false;
          MarketStatusFlag.isPreOpen_bse_fno = false;
          MarketStatusFlag.isPostClosed_bse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bse_fno = "red';
          // MarketStatusFlag.bsefno = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_fno_status = true;
          MarketStatusFlag.isPreOpen_bse_fno = false;
          MarketStatusFlag.isPostClosed_bse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bse_fno = "yellow';
          // MarketStatusFlag.bsefno = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_fno_status = false;
          MarketStatusFlag.isPreOpen_bse_fno = true;
          MarketStatusFlag.isPostClosed_bse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bse_fno = "red';
          // MarketStatusFlag.bsefno = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_fno_status = true;
          MarketStatusFlag.isPreOpen_bse_fno = false;
          MarketStatusFlag.isPostClosed_bse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bse_fno = "blue';
          // MarketStatusFlag.bsefno = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_fno_status = false;
          MarketStatusFlag.isPreOpen_bse_fno = false;
          MarketStatusFlag.isPostClosed_bse_fno = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bse_fno = "pink';
          // MarketStatusFlag.bsefno = false;
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.bse_fno_status = false;
          MarketStatusFlag.isPreOpen_bse_fno = false;
          MarketStatusFlag.isPostClosed_bse_fno = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "5") {
          // MarketStatusFlag.bse_fno = "red';
          // MarketStatusFlag.bsefno = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_fno_status = true;
          MarketStatusFlag.isPreOpen_bse_fno = false;
          MarketStatusFlag.isPostClosed_bse_fno = false;
        }
      }

      // if (MarketStatusFlag.allowedmarket_bcd) {
      if (GreekBase().marketSegments.contains(MarketSegment.bsecd)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bsecd = true;
          // MarketStatusFlag.bse_cd = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_cd_status = false;
          MarketStatusFlag.isPreOpen_bse_cd = false;
          MarketStatusFlag.isPostClosed_bse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bse_cd = "red';
          // MarketStatusFlag.bsecd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_cd_status = true;
          MarketStatusFlag.isPreOpen_bse_cd = false;
          MarketStatusFlag.isPostClosed_bse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bse_cd = "yellow';
          // MarketStatusFlag.bsecd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_cd_status = false;
          MarketStatusFlag.isPreOpen_bse_cd = true;
          MarketStatusFlag.isPostClosed_bse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bse_cd = "red';
          // MarketStatusFlag.bsecd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_cd_status = true;
          MarketStatusFlag.isPreOpen_bse_cd = false;
          MarketStatusFlag.isPostClosed_bse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bse_cd = "blue';
          // MarketStatusFlag.bsecd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_cd_status = false;
          MarketStatusFlag.isPreOpen_bse_cd = false;
          MarketStatusFlag.isPostClosed_bse_cd = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bse_cd = "pink';
          // MarketStatusFlag.bsecd = false;
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.bse_cd_status = false;
          MarketStatusFlag.isPreOpen_bse_cd = false;
          MarketStatusFlag.isPostClosed_bse_cd = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "6") {
          // MarketStatusFlag.bse_cd = "red';
          // MarketStatusFlag.bsecd = false;
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.bse_cd_status = true;
          MarketStatusFlag.isPreOpen_bse_cd = false;
          MarketStatusFlag.isPostClosed_bse_cd = false;
        }
      }

      // if (MarketStatusFlag.allowedmarket_ncdex) {
      if (GreekBase().marketSegments.contains(MarketSegment.ncdex)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.ncdex_com_status = false;
          MarketStatusFlag.isPreOpen_ncdex_com = false;
          MarketStatusFlag.isPostClosed_ncdex_com = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.ncdex_com_status = true;
          MarketStatusFlag.isPreOpen_ncdex_com = false;
          MarketStatusFlag.isPostClosed_ncdex_com = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "yellow';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.ncdex_com_status = false;
          MarketStatusFlag.isPreOpen_ncdex_com = true;
          MarketStatusFlag.isPostClosed_ncdex_com = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.ncdex_com_status = true;
          MarketStatusFlag.isPreOpen_ncdex_com = false;
          MarketStatusFlag.isPostClosed_ncdex_com = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "blue';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.ncdex_com_status = false;
          MarketStatusFlag.isPreOpen_ncdex_com = false;
          MarketStatusFlag.isPostClosed_ncdex_com = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "pink';
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.ncdex_com_status = false;
          MarketStatusFlag.isPreOpen_ncdex_com = false;
          MarketStatusFlag.isPostClosed_ncdex_com = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "7") {
          // MarketStatusFlag.ncdex_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.ncdex_com_status = true;
          MarketStatusFlag.isPreOpen_ncdex_com = false;
          MarketStatusFlag.isPostClosed_ncdex_com = false;
        }
      }

      // if (MarketStatusFlag.allowedmarket_mcx) {
      if (GreekBase().marketSegments.contains(MarketSegment.mcx)) {
        if (item?.session == "1" &&
            item?.status == "1" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "green';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "-1" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = true;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "0" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "yellow';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = true;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "2" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = true;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "3" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "blue';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = true;
        } else if (item?.session == "1" &&
            item?.status == "4" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "pink';
          MarketStatusFlag.eq_post_close = true;
          MarketStatusFlag.mcx_com_status = false;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        } else if (item?.session == "1" &&
            item?.status == "5" &&
            item?.marketId == "9") {
          // MarketStatusFlag.mcx_com = "red';
          MarketStatusFlag.eq_post_close = false;
          MarketStatusFlag.mcx_com_status = true;
          MarketStatusFlag.isPreOpen_mcx_com = false;
          MarketStatusFlag.isPostClosed_mcx_com = false;
        }
      }
    }
  }

  Widget scriptListView(
      {required BuildContext scripContext,
      required List<StreamingDataModel> dataList,
      bool isScrollable = true,
      String? isFrom}) {
    bool _isOpenPlaceOrderScreen = false;

    final dataGridSourceObj = StreamingDataSource(
        streamingDataModelList: dataList, isFrom: isFrom ?? '');

    final _dataGridController = DataGridController(selectedIndex: -1);

    return LayoutBuilder(builder: (_layoutContext, _boxConstraints) {
      return SfDataGrid(
        controller: _dataGridController,
        source: dataGridSourceObj,
        columns: dataGridSourceObj.dataColumnList,
        onQueryRowHeight: (details) => (details.rowIndex == 0) ? 0.0 : 55.0,
        columnWidthMode: ColumnWidthMode.fill,
        gridLinesVisibility: GridLinesVisibility.horizontal,
        headerGridLinesVisibility: GridLinesVisibility.horizontal,
        allowEditing: false,
        selectionMode: SelectionMode.singleDeselect,
        navigationMode: GridNavigationMode.row,
        horizontalScrollPhysics: const NeverScrollableScrollPhysics(),
        verticalScrollPhysics: (isScrollable)
            ? const AlwaysScrollableScrollPhysics()
            : const NeverScrollableScrollPhysics(),
        allowSwiping: isScrollable,
        swipeMaxOffset: _boxConstraints.maxWidth,
        onSwipeUpdate: (swipeUpdateDetails) {
          switch (swipeUpdateDetails.swipeDirection) {
            case DataGridRowSwipeDirection.startToEnd:
              _isOpenPlaceOrderScreen = (swipeUpdateDetails.swipeOffset >
                  (_boxConstraints.maxWidth / 2));
              break;
            case DataGridRowSwipeDirection.endToStart:
              _isOpenPlaceOrderScreen = ((swipeUpdateDetails.swipeOffset * -1) >
                  (_boxConstraints.maxWidth / 2));
              break;
          }

          return true;
        },
        onSwipeEnd: (swipeEndDetails) async {
          if (_isOpenPlaceOrderScreen) {
            final token = (dataGridSourceObj.rows[swipeEndDetails.rowIndex]
                    .getCells()[0]
                    .value as Tuple2<String, int?>)
                .item2;
            dataGridSourceObj.unSubscribeLTPInfo();
            dataGridSourceObj.notifyDataSourceListeners();

            final popResult = await GreekNavigator.pushNamed(
              context: scripContext,
              routeName: GreekScreenNames.place_order,
              arguments: [
                token,
                (swipeEndDetails.swipeDirection ==
                        DataGridRowSwipeDirection.startToEnd)
                    ? OrderAction.buy
                    : OrderAction.sell,
                OrderMode.newOrder,
                ScriptInfoTab.order.index,
              ],
            );

            if (popResult != null) {
              dataGridSourceObj.notifyDataSourceListeners();

              if (popResult is PopAction) {
                if (popResult == PopAction.rebuildWidget) {
                  dataGridSourceObj.subscribeLTPInfo();
                }
              }
            }
          }
        },
        startSwipeActionsBuilder: (startContext, dataGridRow, rowIndex) =>
            Container(
          color: ConstantColors.buyColor,
          padding: const EdgeInsets.only(left: 20.0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'BUY',
              style: GreekTextStyle.heading16,
            ),
          ),
        ),
        endSwipeActionsBuilder: (startContext, dataGridRow, rowIndex) =>
            Container(
          color: ConstantColors.sellColor,
          padding: const EdgeInsets.only(right: 20.0),
          child: Align(
            alignment: Alignment.centerRight,
            child: Text(
              'SELL',
              style: GreekTextStyle.heading16,
            ),
          ),
        ),
        onSelectionChanged: (currentRow, previousRow) async {
          if (currentRow.isNotEmpty) {
            final token = (currentRow.first.getCells().first.value
                    as Tuple2<String, int?>)
                .item2;
            if (token != null) {
              _dataGridController.selectedIndex = -1;
              dataGridSourceObj.unSubscribeLTPInfo();

              final popResult = await GreekNavigator.pushNamed(
                context: scripContext,
                routeName: GreekScreenNames.place_order,
                arguments: [
                  token,
                  OrderAction.buy,
                  OrderMode.newOrder,
                  ScriptInfoTab.overview.index,
                ],
              );

              if (popResult != null) {
                dataGridSourceObj.subscribeLTPInfo();
              }
            }
          }
        },
        onCellLongPress: (DataGridCellLongPressDetails details) {
          final selecteIndex = details.rowColumnIndex.rowIndex - 1;
          if (selecteIndex >= 0) {
            GreekBase()
                .userActionForSymbolDeleteObserver
                .sink
                .add(selecteIndex);
          }
        },
      );
    });
  }

  /*Widget scriptListView({
    required List<BehaviorSubject<SymbolList?>?> dataList,
    required WatchListBloc? watchBloc,
    bool isScrollable = true,
  }) {
    return ListView.builder(
      shrinkWrap: true,
      physics: (isScrollable)
          ? const AlwaysScrollableScrollPhysics()
          : const NeverScrollableScrollPhysics(),
      itemCount: dataList.length,
      itemBuilder: (BuildContext context, int index) {
        if ((dataList.isNotEmpty) && (dataList[index] != null)) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _listTileView(
                  symbolStream: dataList[index],
                  index: index,
                  watchBloc: watchBloc,
                  isScrollable: isScrollable),
              Container(
                height: 0.2,
                color: ConstantColors.dividerColor,
              ),
            ],
          );
        } else {
          return Container();
        }
      },
    );
  }

  Widget _listTileView({
    required BehaviorSubject<SymbolList?>? symbolStream,
    required int index,
    required WatchListBloc? watchBloc,
    bool isScrollable = true,
  }) {
    watchBloc?.listTileRectKey[index] = RectGetter.createGlobalKey();
    return RectGetter(
      key: watchBloc?.listTileRectKey[index],
      child: StreamBuilder<SymbolList?>(
        stream: symbolStream?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.data == null) {
            return const SizedBox(
              height: 55.0,
            );
          }

          return SizedBox(
            height: 55.0,
            child: Column(
              children: [
                Flexible(
                  fit: FlexFit.tight,
                  child: Dismissible(
                    key: Key(index.toString()),
                    background: (isScrollable)
                        ? Container(
                            color: ConstantColors.buyColor,
                            padding: const EdgeInsets.only(left: 20.0),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'BUY',
                                style: GreekTextStyle.heading16,
                              ),
                            ),
                          )
                        : null,
                    direction: (isScrollable)
                        ? DismissDirection.horizontal
                        : DismissDirection.none,
                    secondaryBackground: (isScrollable)
                        ? Container(
                            color: ConstantColors.sellColor,
                            padding: const EdgeInsets.only(right: 20.0),
                            child: Align(
                              alignment: Alignment.centerRight,
                              child: Text(
                                'SELL',
                                style: GreekTextStyle.heading16,
                              ),
                            ),
                          )
                        : null,
                    confirmDismiss: (DismissDirection direction) async {
                      watchBloc?.unSubscribeLTPInfo();
                      final popResult = await GreekNavigator.pushNamed(
                        context: streamContext,
                        routeName: GreekScreenNames.place_order,
                        arguments: [
                          snapshot.data?.token,
                          (direction == DismissDirection.startToEnd)
                              ? OrderAction.buy
                              : OrderAction.sell,
                          OrderMode.newOrder,
                          ScriptInfoTab.order.index,
                        ],
                      );

                      if (popResult == PopAction.rebuildWidget) {
                        watchBloc?.getWatchListDataByGroupName();
                      }
                      return null;
                    },
                    child: TextButton(
                      onPressed: () async {
                        if (snapshot.hasData) {
                          watchBloc?.unSubscribeLTPInfo();
                          final popResult = await GreekNavigator.pushNamed(
                            context: streamContext,
                            routeName: GreekScreenNames.place_order,
                            arguments: [
                              snapshot.data?.token,
                              OrderAction.buy,
                              OrderMode.newOrder,
                              ScriptInfoTab.overview.index,
                            ],
                          );

                          if (popResult == PopAction.rebuildWidget) {
                            watchBloc?.getWatchListDataByGroupName();
                          }
                        }
                      },
                      onLongPress: (watchBloc == null)
                          ? null
                          : () {
                              GreekDialogPopupView
                                  .customeCallBackWithCancelButtonDialog(
                                context: streamContext,
                                message: ConstantMessages.DELETE_SCRIP_MSG,
                                onPressed: (returnContext) {
                                  GreekNavigator.pop(context: returnContext);

                                  if (watchBloc.defaultGroupName.isNotEmpty) {
                                    watchBloc.deleteSymbolintoWatchListGroup(
                                      groupName: watchBloc.defaultGroupName,
                                      symbolList: [snapshot.data!],
                                    );
                                  }
                                },
                              );
                            },
                      child: Container(
                        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Flexible(
                              flex: 1,
                              child: Container(
                                padding: const EdgeInsets.only(bottom: 2.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      (snapshot.data?.token
                                                  ?.toAssetType()
                                                  .toLowerCase()
                                                  .compareTo("equity") ==
                                              0)
                                          ? "${snapshot.data!.description!} - ${snapshot.data!.seriesName!}"
                                          : snapshot.data!.description!,
                                      style: GreekTextStyle.watchlistText,
                                    ),
                                    Text(
                                      '${snapshot.data?.ltp?.toStringAsFixed(2) ?? 0}',
                                      style: GreekTextStyle.watchlistText,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 1,
                              child: Container(
                                padding: const EdgeInsets.only(top: 2.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      snapshot.data?.token
                                              ?.toExchange()
                                              .toString()
                                              .toUpperCase() ??
                                          '',
                                      style: GreekTextStyle.watchlistSubText,
                                    ),
                                    Text(
                                      '${(snapshot.data?.change?.toStringAsFixed(2) ?? 0)}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0}%)',
                                      style: ((snapshot.data?.change ?? 0) >= 0)
                                          ? GreekTextStyle
                                              .headingWatchlistLTPGreen
                                          : GreekTextStyle
                                              .headingWatchlistLTPRed,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }*/

  ///Common IndicesView List

  Widget indicesListView({
    required WatchListBloc? watchListBloc,
    required List<BehaviorSubject<IndianIndicesResponseModel>?> dataList,
  }) {
    return SizedBox(
      // padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
      height: 80,
      width: 425,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: dataList.length,
          itemBuilder: (context, index) {
            return SizedBox(
              width: 190,
              child: Card(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  StreamBuilder<IndianIndicesResponseModel>(
                      stream: dataList.elementAt(index)?.stream,
                      builder: (context, snapshot) {
                        return SizedBox(
                          width: 180.0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 5, top: 9),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  snapshot.data?.token ?? '',
                                  style: GreekTextStyle.marketmapIndices,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 3.0),
                                  child: Text(
                                    snapshot.data?.last.toString() ?? "0.00",
                                    style: GreekTextStyle.marketmapIndices,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5.0),
                                  /* Text(
                                        '${innerSnapshot.data?.change?.toStringAsFixed(2) ?? 0.0}(${innerSnapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)', */
                                  child: Text(
                                    '${snapshot.data?.change?.toStringAsFixed(2) ?? "0.00"}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                                    style: ((snapshot.data?.change ?? 0) >= 0)
                                        ? GreekTextStyle
                                            .headingWatchlistLTPGreen
                                        : GreekTextStyle.headingWatchlistLTPRed,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                  /*   FutureBuilder<List<GraphResponseModel?>>(
                    future: watchListBloc?.callChartData(
                        dataList.elementAt(index)?.value.indexCode.toString() ??
                            ''),
                    builder: (context, snapshot) {
                      return Container(
                        width: 60.0,
                        padding: const EdgeInsets.only(right: 3.0),
                        child: Container(),
                        /* SfCartesianChart(
                              primaryXAxis: CategoryAxis(
                                isVisible: false,
                                majorGridLines: MajorGridLines(width: 0),
                              ),
                              primaryYAxis: CategoryAxis(
                                isVisible: false,
                                majorGridLines: const MajorGridLines(width: 0),
                              ),
                              series: <ChartSeries>[

                                AreaSeries(

                                    dataSource: snapshot.data ?? [],
                                    xValueMapper: snapshot.data?.first?.lTradedVol ?? '',//volume (GRAPH DATA LIST)
                                    yValueMapper: ,//time) (GRAPH DATA LIST)
                       ), ],
                       ), */
                      );

                      /*  Container(
                        color: Colors.amber,
                        width: 110.0,
                        padding: const EdgeInsets.only(right: 3.0),
                        child: SfCartesianChart(
                          // zoomPanBehavior: _zoomPanBehavior,
                          // key: chartKey,
                          plotAreaBorderWidth: 0,
                          primaryXAxis: DateTimeAxis(
                            isVisible: false,
                            name: '',
                            majorGridLines: null,
                          ),
                          primaryYAxis: NumericAxis(
                            isVisible: false,
                            axisLine: const AxisLine(width: 0),
                            // anchorRangeToVisiblePoints: _enableAnchor,
                            majorTickLines: const MajorTickLines(size: 0),
                          ),
                          series: _overviewBloc?.getDefaultPanningSeries(),
                        ),
                      ); */
                    },
                  ),*/
                ],
              )),
            );
          }),
    );

    /* Align(
      alignment: Alignment.centerLeft,
      child: Container(
        width: 200,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: 2,
          itemBuilder: (context, index) {
            if (dataList[index] != null) {
              return Card(
                child: Container(
                    height: 100,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text("symbol"),
                            Text("symbol"),
                            Text("symbol"),
                          ],
                        ),
                        Container(
                          color: Colors.amber,
                          width: 110.0,
                          padding: const EdgeInsets.only(right: 3.0),
                          child: SfCartesianChart(
                            // zoomPanBehavior: _zoomPanBehavior,
                            // key: chartKey,
                            plotAreaBorderWidth: 0,
                            primaryXAxis: DateTimeAxis(
                              isVisible: false,
                              name: '',
                              majorGridLines: null,
                            ),
                            primaryYAxis: NumericAxis(
                              isVisible: false,
                              axisLine: const AxisLine(width: 0),
                              // anchorRangeToVisiblePoints: _enableAnchor,
                              majorTickLines: const MajorTickLines(size: 0),
                            ),
                            series: _overviewBloc?.getDefaultPanningSeries(),
                          ),
                        ),
                      ],
                    )),
              );

              // return _listTileView(
              //     symbolStream: dataList.elementAt(index),
              //     index: index,
              //     watchBloc: watchBloc,
              //     isScrollable: isScrollable);
            } else {
              return Container();
            }
          },
        ),
      ),
    ); */
  }

  /// End List

//  =========================================================================

  ///===============================================================================
  ///                           Indian Indices Index
  ///===============================================================================
  List<IndianIndicesResponseModel> indicesIndexDataList =
      <IndianIndicesResponseModel>[];
  final indicesSubject =
      BehaviorSubject<List<BehaviorSubject<IndianIndicesResponseModel>>>.seeded(
          []);
  List<BehaviorSubject<IndianIndicesResponseModel>> indicesSubjectList =
      <BehaviorSubject<IndianIndicesResponseModel>>[];

  Widget showIndicesBox(
    BuildContext context,
    String symbolName,
    String ltp,
    String change,
    String pchange,
  ) {
    final screenWidth = MediaQuery.of(context).size.width;
    final cardWidth = (screenWidth <= 375) ? 200.0 : ((screenWidth / 2) - 25);

    return Card(
      child: Container(
        width: cardWidth,
        decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          color: ConstantColors.white,
          borderRadius: BorderRadius.circular(3),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1.2,
              blurRadius: 4.5,
              offset: const Offset(1, 1),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, top: 8.0),
                    child: Text(
                      symbolName,
                      style: GreekTextStyle.marketmapIndices,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, top: 5.0),
                    child: Text(
                      ltp,
                      style: GreekTextStyle.marketmapIndices,
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0, top: 5.0),
                        child: Text(
                          change,
                          style: (double.parse(change) >= 0.00)
                              ? GreekTextStyle.marketmapIndices_change_green
                              : GreekTextStyle.marketmapIndices_change_red,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0, top: 5.0),
                        child: Text(
                          '($pchange%)',
                          style: (double.parse(pchange) >= 0.00)
                              ? GreekTextStyle.marketmapIndices_change_green
                              : GreekTextStyle.marketmapIndices_change_red,
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
            /*Container(
              width: 60.0,
              padding: const EdgeInsets.only(right: 3.0),
              child: SfCartesianChart(
                // zoomPanBehavior: _zoomPanBehavior,
                // key: chartKey,
                plotAreaBorderWidth: 0,
                primaryXAxis: DateTimeAxis(
                  isVisible: false,
                  name: '',
                  majorGridLines: null,
                ),
                primaryYAxis: NumericAxis(
                  isVisible: false,
                  axisLine: const AxisLine(width: 0),
                  // anchorRangeToVisiblePoints: _enableAnchor,
                  majorTickLines: const MajorTickLines(size: 0),
                ),
                series: _overviewBloc?.getDefaultPanningSeries(),
              ),
            ),*/
          ],
        ),
      ),
    );
  }

  List<String> _subscribeIndexTokenArray = <String>[];
  List<String> _unSubscribeIndexTokenArray = <String>[];

  void subscribeIndicesIndexTokens() {
/*     if (_unSubscribeIndexTokenArray.isNotEmpty) {
      SocketIOManager().unsubscribeIndexTokens(_unSubscribeIndexTokenArray);
    } */

    _subscribeIndexTokenArray = GreekBase()
        .indicesIndexDataList
        .map((e) => e.indexCode.toString())
        .toList();
    SocketIOManager().subscribeIndexTokens(_subscribeIndexTokenArray);
    _unSubscribeIndexTokenArray = _subscribeIndexTokenArray;
  }

  void unSubscribeindexTokens() {
    /* if (_unSubscribeIndexTokenArray.isNotEmpty) {
      SocketIOManager().unsubscribeIndexTokens(_unSubscribeIndexTokenArray);
      _unSubscribeIndexTokenArray.clear();
    } */
  }

  ///===================================== END =====================================

}
