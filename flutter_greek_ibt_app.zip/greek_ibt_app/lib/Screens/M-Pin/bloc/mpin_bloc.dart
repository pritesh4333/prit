import 'dart:developer' as developer_log;
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/M-Pin/repository/mpin_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:local_auth/local_auth.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MPinBloc extends GreekBlocs {
  BuildContext? _context;
  MPinRepository? _mPinRepository;

  final mpinTextController = TextEditingController();
  AnimationController? rotatedAnimationController;
  Animation<double>? animation;
  final _animationDuration = const Duration(milliseconds: 500);

  MpinViewState currentMpinViewState = MpinViewState.validated;
  set setMPinViewState(MpinViewState state) {
    if (currentMpinViewState != MpinViewState.forget) {
      _rotatedLeftToRightMPinView();
    }

    currentMpinViewState = state;
  }

  final _currentMPinStateSubject =
      BehaviorSubject<MpinViewState>.seeded(MpinViewState.validated);
  Stream<MpinViewState> get mpinStateStream => _currentMPinStateSubject.stream;
  var mpinCode = '';

  bool isEnableSubmitButton = false;

  MPinBloc(BuildContext context, TickerProvider vsync) {
    _context = context;
    _mPinRepository = MPinRepository(_context!);

    SocketIOManager().connectSocketIOServer(
      gscid: AppConfig().gscid,
      gcid: AppConfig().gcid,
      sessionID: AppConfig().sessionID,
      deviceID: AppConfig().deviceID,
      deviceType: AppConfig().deviceType,
    );

    currentMpinViewState =
        AppConfig().isMPinSet ? MpinViewState.validated : MpinViewState.create;
    rotatedAnimationController = AnimationController(
      vsync: vsync,
      duration: _animationDuration,
    );

    animation = TweenSequence(
      [
        TweenSequenceItem<double>(
          tween: Tween(begin: 0.0, end: pi / 2)
              .chain(CurveTween(curve: Curves.easeOut)),
          weight: 50.0,
        ),
        TweenSequenceItem<double>(
          tween: Tween(begin: (-pi / 2), end: 0.0)
              .chain(CurveTween(curve: Curves.easeOut)),
          weight: 50.0,
        ),
      ],
    ).animate(rotatedAnimationController!);

    rotatedAnimationController?.addStatusListener(
      (status) {
        clearMpinResult();
        switch (status) {
          case AnimationStatus.dismissed:
          case AnimationStatus.completed:
            _currentMPinStateSubject.sink.add(currentMpinViewState);
            break;
          default:
            break;
        }
      },
    );

    if (AppConfig().isMPinSet) {
      Future.delayed(
        const Duration(seconds: 1),
        () => _checkBiometric(context),
      );
    }
  }

  @override
  void disposeBloc() {
    rotatedAnimationController?.dispose();
    rotatedAnimationController = null;

    _currentMPinStateSubject.close();

    _mPinRepository = null;
    _context = null;
  }

  void _checkBiometric(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String gscid = prefs.getString('gscid') ?? '';
    String mpin = prefs.getString('mpin') ?? '';
    if (gscid.toUpperCase() == AppConfig().gscid.toUpperCase() && mpin != "") {
      final LocalAuthentication auth = LocalAuthentication();
      bool canCheckBiometrics = false;
      try {
        canCheckBiometrics = await auth.canCheckBiometrics;
      } catch (e) {
        developer_log.log("error biome trics $e");
      }

      developer_log.log("biometric is available: $canCheckBiometrics");

      bool authenticated = false;
      try {
        final availableBiometrics = await auth.getAvailableBiometrics();

        if (availableBiometrics.isNotEmpty) {
          authenticated = await auth.authenticate(
            biometricOnly: true,
            localizedReason: ConstantMessages.USE_BIOMETRIC_MSG,
            useErrorDialogs: true,
            sensitiveTransaction: false,
            stickyAuth: false,
          );

          if (authenticated) {
            currentMpinViewState = MpinViewState.validated;
            callMPinAPIS(context, mpin);
          }
        }
      } catch (e) {
        developer_log.log("error enumerate biometrics $e");
      }
    }
  }

  void _rotatedLeftToRightMPinView() {
    clearMpinResult();
    rotatedAnimationController?.reset();
    rotatedAnimationController?.forward();
  }

  void clearMpinResult() {
    mpinTextController.clear();
  }

  Future<void> callMPinAPIS(BuildContext context, String mpin) async {
    _callMarketStatistics();

    switch (currentMpinViewState) {
      case MpinViewState.create:
        final errorCode = await _mPinRepository?.createMPinAPI(mpinCode);

        switch (errorCode) {
          case 0:
            mpinCode = '';
            isEnableSubmitButton = false;
            setMPinViewState = MpinViewState.validated;
            break;

          case 2:
          case 4:
            GreekDialogPopupView.messageDialog(
                context, ConstantMessages.DUPLICATE_MPIN_MSG);
            break;

          default:
            GreekDialogPopupView.messageDialog(
                context, ConstantMessages.SOMETHING_WENT_WRONG);
            break;
        }

        break;

      case MpinViewState.validated:
        int? errorCode;
        if (mpin.isEmpty) {
          errorCode = await _mPinRepository?.validatedMPinAPI(mpinCode);
        } else {
          errorCode = await _mPinRepository?.validatedMPinAPI(mpin);
        }

        switch (errorCode) {
          case 0:
            if (mpin.isEmpty) {
              AppConfig().saveMPIN(
                  AppConfig().gscid.toUpperCase(), mpinCode.toString());
            } else {
              AppConfig()
                  .saveMPIN(AppConfig().gscid.toUpperCase(), mpin.toString());
            }

            mpinCode = '';
            isEnableSubmitButton = false;
            GreekNavigator.pushReplacementNamed(
              context: context,
              routeName: GreekScreenNames.landing,
            );
            break;

          case 5:
            GreekDialogPopupView.messageDialog(
                context, ConstantMessages.MAX_ATTEMPT_MPIN_MSG);
            break;

          default:
            GreekDialogPopupView.messageDialog(
                context, ConstantMessages.CP_MPIN_INVALID_MSG);
            break;
        }

        break;

      case MpinViewState.forget:
        final errorCode = await _mPinRepository?.forgetMPinAPI();

        switch (errorCode) {
          case 0:
            mpinCode = '';
            isEnableSubmitButton = false;
            setMPinViewState = MpinViewState.validatedOTP;
            break;

          default:
            GreekDialogPopupView.messageDialog(
                context, ConstantMessages.SOMETHING_WENT_WRONG);
            break;
        }

        break;

      case MpinViewState.validatedOTP:
        clearMpinResult();
        final errorCode = await _mPinRepository?.validatedMPINOTPAPI(mpinCode);

        switch (errorCode) {
          case 0:
            mpinCode = '';
            isEnableSubmitButton = false;
            setMPinViewState = MpinViewState.create;
            break;

          default:
            GreekDialogPopupView.messageDialog(
                context, ConstantMessages.CP_OTP_INVALID_MSG);
            break;
        }

        break;
    }
  }

  void _callMarketStatistics() {
    final item = (GreekBase().marketSegments.isNotEmpty)
        ? GreekBase().marketSegments.first
        : MarketSegment.nseeq;

    switch (item) {
      case MarketSegment.nseeq:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        break;
      case MarketSegment.nsefo:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        break;
      case MarketSegment.nsecd:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        break;
      case MarketSegment.nsecomm:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        break;
      case MarketSegment.bseeq:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        break;
      case MarketSegment.bsecd:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        break;
      case MarketSegment.bsecomm:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        break;
      case MarketSegment.mcx:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        break;
      case MarketSegment.ncdex:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        break;
      default:
        break;
    }
  }
}
