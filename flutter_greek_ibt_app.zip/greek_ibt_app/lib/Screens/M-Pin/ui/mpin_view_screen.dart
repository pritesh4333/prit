import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Screens/M-Pin/bloc/mpin_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class MPinScreen extends StatefulWidget {
  const MPinScreen({Key? key}) : super(key: key);

  @override
  _MPinScreenState createState() => _MPinScreenState();
}

class _MPinScreenState extends State<MPinScreen> with SingleTickerProviderStateMixin {
  MPinBloc? _mPinBloc;
  bool _obscureText = true;
  final mpinTextController = TextEditingController();

  AppBar? _appBar;

  @override
  void initState() {
    super.initState();
    _createAppBarView();
  }

  @override
  void dispose() {
    _mPinBloc?.disposeBloc();
    _mPinBloc = null;

    super.dispose();
  }

  _createAppBarView() {
    _appBar = AppBar(
      elevation: 1,
      backgroundColor: ConstantColors.primaryColor,
      title: Text(
        ConstantMessages.MPIN_HEADER_MSG,
        style: GreekTextStyle.headline2,
      ),
      leading: TextButton(
        onPressed: () {
          AppConfig().deleteUser();
          GreekNavigator.pushReplacementNamed(
            context: context,
            routeName: GreekScreenNames.login,
          );
        },
        child: const Icon(
          Icons.arrow_back_ios_new_rounded,
          color: ConstantColors.black,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    _mPinBloc ??= MPinBloc(context, this);

    return Scaffold(
      appBar: _appBar,
      body: SafeArea(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: SizedBox(
            height: (MediaQuery.of(context).size.height - _appBar!.preferredSize.height - MediaQuery.of(context).padding.top - MediaQuery.of(context).padding.bottom),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(45.0),
                  child: Center(
                    child: Image.asset(
                      'assets/images/flutter_logo.png',
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                ),
                AnimatedBuilder(
                  animation: _mPinBloc!.animation!,
                  builder: (BuildContext context, Widget? child) {
                    var transform = Matrix4.identity();
                    transform.setEntry(3, 2, 0.001);
                    transform.rotateY(_mPinBloc!.animation!.value);
                    return Transform(
                      transform: transform,
                      alignment: Alignment.center,
                      child: child,
                    );
                  },
                  child: _mpinView(context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _mpinView(BuildContext context) => StreamBuilder<MpinViewState>(
        stream: _mPinBloc?.mpinStateStream,
        builder: (context, snapshot) {
          return SizedBox(
            height: 215,
            width: 300,
            child: Stack(
              children: [
                Container(
                  height: 195,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.blue,
                      width: 3,
                    ),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(25.0),
                    ),
                  ),
                  child: Column(
                    children: [
                      const SizedBox(height: 12),
                      Text(
                        "Welcome ${AppConfig().gscid}",
                        style: const TextStyle(
                          fontFamily: 'Roboto',
                          color: ConstantColors.black,
                          fontSize: 14,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.only(top: 0),
                        child: Center(
                          child: Text(
                            (snapshot.data == MpinViewState.validated)
                                ? ConstantMessages.ENTER_6_DIGIT_MPIN
                                : (snapshot.data == MpinViewState.forget || snapshot.data == MpinViewState.validatedOTP)
                                    ? ConstantMessages.CP_OTP_EMPTY_MSG
                                    : (snapshot.data == MpinViewState.create)
                                        ? AppConfig().isMPinSet
                                            ? ConstantMessages.RESET_6_DIGIT_MPIN
                                            : ConstantMessages.CREATE_6_DIGIT_MPIN
                                        : '',
                            style: GreekTextStyle.headline2,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
                        child: SizedBox(
                          height: 45,
                          width: 200,
                          child: Stack(
                            children: [
                              TextFormField(
                                style: GreekTextStyle.mpinTextStyle,
                                textAlign: TextAlign.center,
                                controller: mpinTextController,
                                autofocus: false,
                                obscureText: _obscureText,
                                keyboardType: TextInputType.number,
                                inputFormatters: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                                ],
                                maxLength: 6,
                                decoration: const InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 10.0, right: 20.0, bottom: 16.5),
                                ),
                                onChanged: (value) {
                                  if (value.length == 6) {
                                    _mPinBloc?.mpinCode = value;
                                    FocusScope.of(context).unfocus();
                                    setState(() => _mPinBloc?.isEnableSubmitButton = true);
                                  } else {
                                    _mPinBloc?.mpinCode = value;
                                    setState(() => _mPinBloc?.isEnableSubmitButton = false);
                                  }
                                },
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: 30.0,
                                  width: 30.0,
                                  margin: const EdgeInsets.only(right: 8.0),
                                  padding: const EdgeInsets.only(bottom: 5.0),
                                  alignment: Alignment.center,
                                  child: IconButton(
                                    icon: Icon(_obscureText ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                                    // iconSize: 23.0,
                                    padding: EdgeInsets.zero,
                                    onPressed: () {
                                      setState(() => _obscureText = !_obscureText);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 20.0),
                        height: 35.0,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: TextButton(
                            onPressed: () {
                              mpinTextController.clear();
                              _obscureText = true;
                              FocusScope.of(context).unfocus();
                              _mPinBloc?.setMPinViewState = MpinViewState.forget;
                              _mPinBloc?.callMPinAPIS(context, "");

                              setState(() {});
                            },
                            child: Text(
                              (_mPinBloc?.currentMpinViewState == MpinViewState.validated)
                                  ? ConstantMessages.GREEK_FORGOT_MPIN
                                  : (_mPinBloc?.currentMpinViewState == MpinViewState.forget)
                                      ? ConstantMessages.GREEK_RESEND
                                      : (_mPinBloc?.currentMpinViewState == MpinViewState.create)
                                          ? ''
                                          : (_mPinBloc?.currentMpinViewState == MpinViewState.validatedOTP)
                                              ? ConstantMessages.GREEK_RESEND
                                              : '',
                              style: const TextStyle(
                                color: ConstantColors.primaryColorLight,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: TextButton(
                    onPressed: () {
                      mpinTextController.clear();
                      _mPinBloc?.callMPinAPIS(context, "");
                      // mpinTextController.clear();
                      // _obscureText = true;
                      // FocusScope.of(context).unfocus();
                      // _mPinBloc!.isEnableSubmitButton ? {_mPinBloc?.callMPinAPIS(context, "")} : null;
                    },
                    child: Text(
                      ConstantMessages.CP_SUBMIT_BTN,
                      style: GreekTextStyle.ordersubmit,
                    ),
                    style: TextButton.styleFrom(
                      backgroundColor: _mPinBloc!.isEnableSubmitButton ? Colors.blue : ConstantColors.primaryColorVitt,
                      fixedSize: const Size(160, 45.0),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      );
}
