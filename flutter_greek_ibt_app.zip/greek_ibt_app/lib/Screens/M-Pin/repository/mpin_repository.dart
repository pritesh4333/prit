import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/OTP/ui/OTPScreen.dart';

class MPinRepository {
  final BuildContext _context;
  MPinRepository(this._context);

  Future<int?> validatedMPinAPI(String mpin) async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        context: _context,
        apiName: APIName.validateMPIN,
        postBody: {
          'gscid': AppConfig().gscid,
          'mpin': mpin,
        },
      );

  Future<int?> createMPinAPI(String mpin) async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        context: _context,
        apiName: APIName.createMPIN,
        postBody: {
          'gscid': AppConfig().gscid,
          'gcid': AppConfig().gcid,
          'mpin': mpin,
        },
      );

  Future<int?> forgetMPinAPI() async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        context: _context,
        apiName: APIName.forgetMPIN,
        postBody: {
          'gscid': AppConfig().gscid,
        },
      );

  Future<int?> validatedMPINOTPAPI(String otp) async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        context: _context,
        apiName: APIName.jvalidate_otp_mf,
        postBody: {
          'gscid': AppConfig().gscid,
          'passType': '3',
          'otp': otp,
        },
      );

  Future<LoginResponseModel> validatedOTPAPI(
          String otp, String? deviceid, String? deviceDetail) async =>
      await NetworkManager().postAPIEncryptedwithallresponse(
        context: _context,
        apiName: APIName.jValidateLoginOTP,
        postBody: {
          'gscid': AppConfig().gscid,
          'deviceId': deviceid ?? '',
          'otp': otp,
          'deviceType': '0',
          'deviceDetails': deviceDetail ?? '',
        },
      );

  Future<int?> callLoginOTP(BuildContext context) async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        context: context,
        apiName: APIName.jLoginWithOTP,
        postBody: {
          'gscid': AppConfig().gscid,
          'version_no': AppConfig().version_no,
        },
      );
}
