class QuoteForSingleSymbolV2ResponseModel {
  String? ylow;
  String? lot;
  String? ltq;
  String? scripname;
  String? instrument;
  String? yhigh;
  String? pChange;
  String? last;
  String? high;
  String? change;
  String? open;
  String? oi;
  String? close;
  String? totVol;
  String? symbol;
  String? low;
  String? description;
  String? token;
  String? expiryDate;
  String? strikeprice;
  String? optiontype;
  List<Level2>? level2;
  String? lowRange;
  String? highRange;
  String? isinumber;
  String? atp;
  String? assetToken;
  String? assetLtp;
  String? oiPChange;
  String? ask;
  String? bid;
  String? freezQty;
  String? sqOffQty;
  String? authorizedQty;
  String? totBuyQty;
  String? totSellQty;
  String? tickSize;
  String? ltt;
  String? reason;

  QuoteForSingleSymbolV2ResponseModel(
      {this.ylow,
      this.lot,
      this.ltq,
      this.scripname,
      this.instrument,
      this.yhigh,
      this.pChange,
      this.last,
      this.high,
      this.change,
      this.open,
      this.oi,
      this.close,
      this.totVol,
      this.symbol,
      this.low,
      this.description,
      this.token,
      this.expiryDate,
      this.strikeprice,
      this.optiontype,
      this.level2,
      this.lowRange,
      this.highRange,
      this.isinumber,
      this.atp,
      this.assetToken,
      this.assetLtp,
      this.oiPChange,
      this.ask,
      this.bid,
      this.freezQty,
      this.sqOffQty,
      this.authorizedQty,
      this.totBuyQty,
      this.totSellQty,
      this.tickSize,
      this.ltt,
      this.reason});

  QuoteForSingleSymbolV2ResponseModel.fromJson(Map<String, dynamic> json) {
    ylow = '${json['ylow']}';
    lot = '${json['lot']}';
    ltq = '${json['ltq']}';
    scripname = '${json['scripname']}';
    instrument = '${json['instrument']}';
    yhigh = '${json['yhigh']}';
    pChange = '${json['p_change']}';
    last = '${json['last']}';
    high = '${json['high']}';
    change = '${json['change']}';
    open = '${json['open']}';
    oi = '${json['oi']}';
    close = '${json['close']}';
    totVol = '${json['tot_vol']}';
    symbol = '${json['symbol']}';
    low = '${json['low']}';
    description = '${json['description']}';
    token = '${json['token']}';
    expiryDate = '${json['expiryDate']}';
    strikeprice = '${json['strikeprice']}';
    optiontype = '${json['optiontype']}';
    if (json['level2'] != null) {
      level2 = <Level2>[];
      json['level2'].forEach((v) {
        level2!.add(Level2.fromJson(v));
      });
    }
    lowRange = '${json['lowRange']}';
    highRange = '${json['highRange']}';
    isinumber = '${json['isinumber']}';
    atp = '${json['atp']}';
    assetToken = '${json['assetToken']}';
    assetLtp = '${json['assetLtp']}';
    oiPChange = '${json['oi_pChange']}';
    ask = '${json['ask']}';
    bid = '${json['bid']}';
    freezQty = '${json['freezQty']}';
    sqOffQty = '${json['sqOffQty']}';
    authorizedQty = '${json['authorizedQty']}';
    totBuyQty = '${json['tot_buyQty']}';
    totSellQty = '${json['tot_sellQty']}';
    tickSize = '${json['tickSize']}';
    ltt = '${json['ltt']}';
    reason = '${json['reason']}';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ylow'] = ylow;
    data['lot'] = lot;
    data['ltq'] = ltq;
    data['scripname'] = scripname;
    data['instrument'] = instrument;
    data['yhigh'] = yhigh;
    data['p_change'] = pChange;
    data['last'] = last;
    data['high'] = high;
    data['change'] = change;
    data['open'] = open;
    data['oi'] = oi;
    data['close'] = close;
    data['tot_vol'] = totVol;
    data['symbol'] = symbol;
    data['low'] = low;
    data['description'] = description;
    data['token'] = token;
    data['expiryDate'] = expiryDate;
    data['strikeprice'] = strikeprice;
    data['optiontype'] = optiontype;
    if (level2 != null) {
      data['level2'] = level2!.map((v) => v.toJson()).toList();
    }
    data['lowRange'] = lowRange;
    data['highRange'] = highRange;
    data['isinumber'] = isinumber;
    data['atp'] = atp;
    data['assetToken'] = assetToken;
    data['assetLtp'] = assetLtp;
    data['oi_pChange'] = oiPChange;
    data['ask'] = ask;
    data['bid'] = bid;
    data['freezQty'] = freezQty;
    data['sqOffQty'] = sqOffQty;
    data['authorizedQty'] = authorizedQty;
    data['tot_buyQty'] = totBuyQty;
    data['tot_sellQty'] = totSellQty;
    data['tickSize'] = tickSize;
    data['ltt'] = ltt;
    data['reason'] = reason;
    return data;
  }
}

class Level2 {
  Bid? bid;
  Ask? ask;

  Level2({this.bid, this.ask});

  Level2.fromJson(Map<String, dynamic> json) {
    bid = json['bid'] != null ? Bid.fromJson(json['bid']) : null;
    ask = json['ask'] != null ? Ask.fromJson(json['ask']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (bid != null) {
      data['bid'] = bid!.toJson();
    }
    if (ask != null) {
      data['ask'] = ask!.toJson();
    }
    return data;
  }
}

class Bid {
  String? price;
  String? no;
  String? qty;

  Bid({this.price, this.no, this.qty});

  Bid.fromJson(Map<String, dynamic> json) {
    price = '${json['price']}';
    no = '${json['no']}';
    qty = '${json['qty']}';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['price'] = price;
    data['no'] = no;
    data['qty'] = qty;
    return data;
  }
}

class Ask {
  String? price;
  String? no;
  String? qty;

  Ask({this.price, this.no, this.qty});

  Ask.fromJson(Map<String, dynamic> json) {
    price = '${json['price']}';
    no = '${json['no']}';
    qty = '${json['qty']}';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['price'] = price;
    data['no'] = no;
    data['qty'] = qty;
    return data;
  }
}
