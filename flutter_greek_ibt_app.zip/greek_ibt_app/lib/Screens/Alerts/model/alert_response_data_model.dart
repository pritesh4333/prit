class AlertResponseDataModel {
  List<AlertResponseData>? data;

  AlertResponseDataModel({this.data});

  AlertResponseDataModel.fromJson(Map<String, dynamic> json) {
    if (json['Data'] != null) {
      data = <AlertResponseData>[];
      json['Data'].forEach((v) {
        data!.add(AlertResponseData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AlertResponseData {
  int? ruleNo;
  int? gcid;
  int? gtoken;
  String? symbol;
  String? exchange;
  int? alertType;
  String? range;
  int? isExecuted;
  int? directionFlag;
  int? startDatetime;
  int? endDatetime;
  int? lastUpdatedTime;
  String? assetType;
  String? gscid;
  int? expiryDate;
  String? seriesInstname;
  int? strikePrice;
  String? description;
  int? token;

  AlertResponseData({
    this.ruleNo,
    this.gcid,
    this.gtoken,
    this.symbol,
    this.exchange,
    this.alertType,
    this.range,
    this.isExecuted,
    this.directionFlag,
    this.startDatetime,
    this.endDatetime,
    this.lastUpdatedTime,
    this.assetType,
    this.gscid,
    this.expiryDate,
    this.seriesInstname,
    this.strikePrice,
    this.description,
    this.token,
  });

  AlertResponseData.fromJson(Map<String, dynamic> json) {
    ruleNo = json['rule_no'];
    gcid = json['gcid'];
    gtoken = json['gtoken'];
    symbol = json['symbol'];
    exchange = json['exchange'];
    alertType = json['alert_type'];
    var tRange = json['range'];
    range = tRange.toString();
    isExecuted = json['is_executed'];
    directionFlag = json['direction_flag'];
    startDatetime = json['start_datetime'];
    endDatetime = json['end_datetime'];
    lastUpdatedTime = json['last_updated_time'];
    assetType = json['assetType'];
    gscid = json['gscid'];
    expiryDate = json['expiry_date'];
    seriesInstname = json['series_instname'];
    strikePrice = json['strike_price'];
    description = json['description'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['rule_no'] = ruleNo;
    data['gcid'] = gcid;
    data['gtoken'] = gtoken;
    data['symbol'] = symbol;
    data['exchange'] = exchange;
    data['alert_type'] = alertType;
    data['range'] = range;
    data['is_executed'] = isExecuted;
    data['direction_flag'] = directionFlag;
    data['start_datetime'] = startDatetime;
    data['end_datetime'] = endDatetime;
    data['last_updated_time'] = lastUpdatedTime;
    data['assetType'] = assetType;
    data['gscid'] = gscid;
    data['expiry_date'] = expiryDate;
    data['series_instname'] = seriesInstname;
    data['strike_price'] = strikePrice;
    data['description'] = description;
    data['token'] = token;
    return data;
  }
}
