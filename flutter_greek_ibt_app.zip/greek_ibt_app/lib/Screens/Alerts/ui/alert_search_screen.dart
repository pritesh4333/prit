import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Screens/Alerts/bloc/search_alert_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class AlertSearchScreen extends StatefulWidget {
  const AlertSearchScreen({Key? key}) : super(key: key);

  @override
  State<AlertSearchScreen> createState() => _AlertSearchScreenState();
}

class _AlertSearchScreenState extends State<AlertSearchScreen> {
  SearchAlertBloc? _searchAlertBloc;
  String? _symbolName;

  @override
  void initState() {
    _searchAlertBloc = SearchAlertBloc();
    _symbolName = "";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        // leading: const Icon(
        //   Icons.arrow_back_ios_new,
        //   color: Colors.black54,
        // ),
        automaticallyImplyLeading: false,
        actions: [
          InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: const Padding(
              padding: EdgeInsets.only(right: 20.0),
              child: Icon(
                Icons.close,
                color: Colors.black,
                size: 30,
              ),
            ),
          )
        ],
        title: const Text('Search', style: TextStyle(color: Colors.black)),
      ),
      body: Column(
        children: [
          TextField(
            // controller: _watchListBloc?.searchSymbolTextController,
            autofocus: true,
            textCapitalization: TextCapitalization.characters,
            style: GreekTextStyle.headline1,
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search_rounded),
              hintText: 'Search Stock (Like: TCS, Reliance, etc...)',
              border: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide.none,
              ),
              suffixIcon: IconButton(
                // onPressed: () => _watchListBloc?.clearSearchResult(),
                onPressed: () {},
                icon: const Icon(
                  Icons.cancel_rounded,
                ),
              ),
            ),
            onChanged: (String symbolName) {
              if (symbolName.length >= 2) {
                setState(() {
                  _symbolName = symbolName;
                });
              } else {
                setState(() {
                  _symbolName = '';
                });
              }
            },
          ),
          Expanded(
            child: Container(
              child: FutureBuilder<List<SearchSymbolSqliteModel>>(
                future: _searchAlertBloc?.searchAlertSymbol(symbol: _symbolName),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    int length = snapshot.data?.length ?? 0;

                    if (length <= 0) {
                      return const SizedBox.shrink();
                    }

                    return ListView.builder(
                      itemCount: length,
                      itemBuilder: (context, index) {
                        final responseObj = snapshot.data?[index];
                        final symbol = responseObj?.symbol ?? '';
                        final series = responseObj?.seriesName ?? '';
                        final token = int.parse(responseObj?.token ?? '');
                        final exchange = token.toExchange();
                        final resultString = symbol + '-' + series + "-" + exchange;

                        return InkWell(
                          onTap: () {
                            Navigator.pop(context, responseObj);
                          },
                          child: ListTile(
                            title: Text(resultString),
                            subtitle: Text(responseObj?.description ?? ''),
                          ),
                        );
                      },
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                },
              ),
            ),
          )
        ],
      ),
    );
  }
}
