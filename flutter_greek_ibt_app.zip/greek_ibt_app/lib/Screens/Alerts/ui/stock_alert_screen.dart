import 'package:dropdown_button2/custom_dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Alerts/model/alert_response_data_model.dart';
import 'package:greek_ibt_app/Screens/Alerts/model/quote_for_single_symbol_v2_response_model.dart';
import 'package:greek_ibt_app/Screens/Alerts/ui/alert_search_screen.dart';
import 'package:greek_ibt_app/Screens/Profile/bloc/profile_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/no_data_with_progress_indicator.dart';
import 'package:greek_ibt_app/Utilities/size_config.dart';

class StockAlertsScreen extends StatefulWidget {
  const StockAlertsScreen({Key? key}) : super(key: key);

  @override
  State<StockAlertsScreen> createState() => _StockAlertsScreenState();
}

class _StockAlertsScreenState extends State<StockAlertsScreen> {
  List<String> exchangeMenuItems = ['All', 'NSE', 'BSE', 'MCX', 'NCDEX'];
  List<String> assetMenuItems = ['All', 'Equity', 'FNO', 'Currency', 'Commodity'];
  List<String> alertDirection = ['Moves Above', 'Moves Below'];
  List<String> alertType = ['Price', 'Percentage', 'Volume'];

  String selectedExchangeValue = 'All';
  String selectedAssetValue = 'All';

  String selectedAlertDirection = 'Moves Above';
  String selectedAlertType = 'Price';

  ProfileBloc? _profileBloc;
  bool shouldSort = false;
  String sortByExchange = '';
  String sortByAsset = '';
  bool totalVolVisibility = false;

  final AddAlertModelClass _addAlertModelClass = AddAlertModelClass();
  bool isDeleteCalled = false;
  bool isCreateDeleteApicalled = false;
  String rangeEntered = '';

  @override
  void initState() {
    _profileBloc = ProfileBloc();
    super.initState();
    AppFlagConstant().currentScreen = 'stockalert';
    showAlerts();
    registerForSocketListener();
  }

  void registerForSocketListener() {
    //Apollo Alert 'Add/delete Response
    SocketIOManager().brodcastAlertDeleteResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();
          for (var item in keys) {
            if (item.apolloResponseStreamingType == ApolloResponseStreamingType.AlertResponse) {
              String genericMessage = isDeleteCalled ? ConstantMessages.GREEK_ALERT_DELETE_SUCESFULLY_TXT : ConstantMessages.GREEK_CREATE_ALERT_SUCESFULLY_TXT;

              final snackBar = SnackBar(
                backgroundColor: Colors.grey.shade400,
                elevation: 2,
                duration: const Duration(
                  seconds: 1,
                ),
                content: Text(
                  genericMessage,
                  style: const TextStyle(color: Colors.black),
                ),
                action: SnackBarAction(
                    label: 'OK',
                    textColor: Colors.black,
                    onPressed: () {
                      setState(() {
                        showAlerts();
                      });
                    }),
              );

              setState(() {
                showAlerts();
              });

              if (isCreateDeleteApicalled) {
                ScaffoldMessenger.of(context).removeCurrentSnackBar();
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
                isCreateDeleteApicalled = false;
              }
            } else if (item.apolloResponseStreamingType == ApolloResponseStreamingType.AlertExecuted) {
              print('prepare alert');
              final responseDic = event['AlertExecuted'];
              String symbol = responseDic['Symbol'];
              String currentValue = responseDic['CurrentValue'];
              String rangeValue = responseDic['RangeValue'];
              String message = responseDic['Message'];
              final finalMessage = 'Alert Notification\n\n$symbol\n\nCurrent Value: $currentValue\nRange Value: $rangeValue\nMessage: $message';
              GreekDialogPopupView.messageDialog(context, finalMessage);
              setState(() {});
            }
          }
        }
      },
    );
  }

  @override
  void dispose() {
    _profileBloc?.disposeBloc();
    super.dispose();
  }

  void showAlerts() async {
    _profileBloc?.fetchAlerts();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    return Scaffold(
      appBar: AppBar(
        elevation: 0.5,
        backgroundColor: ConstantColors.white,
        leading: IconButton(
          onPressed: () {
            GreekBase().drawerKey.currentState?.openDrawer();
          },
          icon: const Icon(Icons.menu_rounded),
          iconSize: 30.0,
          color: ConstantColors.black,
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: Text('Stock Alert', style: GreekTextStyle.headline2),
        ),
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return Container(
                      margin: const EdgeInsets.fromLTRB(8, 10, 8, 4),
                      child: CustomDropdownButton2(
                        buttonWidth: constraints.maxWidth,
                        buttonHeight: 45,
                        buttonElevation: 0,
                        dropdownElevation: 1,
                        dropdownWidth: constraints.maxWidth - 14,
                        buttonDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          color: Colors.white,
                          border: Border.all(color: Colors.black12),
                        ),
                        hint: '',
                        dropdownItems: exchangeMenuItems,
                        value: selectedExchangeValue,
                        onChanged: (value) {
                          setState(
                            () {
                              selectedExchangeValue = value.toString();
                              sortByExchange = selectedExchangeValue == 'All' ? '' : selectedExchangeValue;
                              shouldSort = true;
                            },
                          );
                        },
                        icon: const Icon(Icons.arrow_drop_down_outlined, size: 40),
                      ),
                    );
                  },
                ),
              ),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return Container(
                      margin: const EdgeInsets.fromLTRB(8, 10, 8, 4),
                      child: CustomDropdownButton2(
                        buttonHeight: 45,
                        buttonWidth: constraints.maxWidth,
                        buttonElevation: 0,
                        dropdownElevation: 1,
                        dropdownWidth: constraints.maxWidth - 14,
                        buttonDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          color: Colors.white,
                          border: Border.all(color: Colors.black12),
                        ),
                        hint: '',
                        dropdownItems: assetMenuItems,
                        value: selectedAssetValue,
                        onChanged: (value) {
                          setState(
                            () {
                              selectedAssetValue = value.toString();
                              sortByAsset = selectedAssetValue == 'All' ? '' : selectedAssetValue;
                              shouldSort = true;
                            },
                          );
                        },
                        icon: const Icon(Icons.arrow_drop_down_outlined, size: 40),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          Expanded(
            child: Container(
              child: buildAlertListWidget(_profileBloc, context),
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        elevation: 8,
        backgroundColor: Colors.white,
        child: const Icon(
          Icons.add,
          size: 35,
          color: Color(0xFF127FBA),
        ),
        onPressed: () async {
          // final result = await Navigator.pushNamed(context, GreekScreenNames.alert_search_screen);
          final SearchSymbolSqliteModel result = await Navigator.push(context, MaterialPageRoute(builder: (context) => const AlertSearchScreen()));

          if (result != null) {
            showAlertBottomModelSheet(context, result);
          }
        },
      ),
    );
  }

  Future<dynamic> showAlertBottomModelSheet(BuildContext context, SearchSymbolSqliteModel result) {
    return showModalBottomSheet(
      isDismissible: false,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      enableDrag: false,
      context: context,
      builder: (context) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: StatefulBuilder(
            builder: (context, StateSetter setModalState) {
              final assetType = int.parse(result.token ?? '').toAssetType().toLowerCase();
              return createAlertWidget(setModalState, context, result.token ?? '', assetType);
            },
          ),
        );
      },
    );
  }

  String getAlertType(String alertType) {
    switch (alertType) {
      case "Price":
        return "1";
      case "Percentage":
        return "2";
      case "Volume":
        return "3";
      default:
        return "";
    }
  }

  String getDirection(String directionType) {
    switch (directionType) {
      case "Moves Above":
        return "0";
      case "Moves Below":
        return "1";
      default:
        return "";
    }
  }

  Widget createAlertWidget(StateSetter setModalState, BuildContext context, String token, String assetType) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          color: Colors.white.withOpacity(0),
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.grey.shade400, width: 0.5),
            ),
            child: FutureBuilder<QuoteForSingleSymbolV2ResponseModel?>(
              future: _profileBloc?.getQuoteForSingleSymbolV2(token, assetType),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  final scripName = snapshot.data?.scripname ?? '';
                  if (scripName == null) {
                    return const SizedBox(
                      height: 150,
                      child: Center(
                        child: Text('No Quote Available For Selected Symbol'),
                      ),
                    );
                  }

                  final responseObj = snapshot.data!;

                  final exchange = int.parse(responseObj.token ?? '').toExchange();
                  final instrument = responseObj.instrument;
                  final resultScripName = '  ' + exchange + ' - ' + (instrument ?? '');
                  String ltp = responseObj.last ?? '0.0';
                  String resultChangePerchange = (responseObj.change ?? '0.0') + ' ( ' + (responseObj.pChange ?? '0.0') + ' %)';
                  String totVolume = responseObj.totVol ?? '0.0';
                  double changeTemp = double.parse(responseObj.change ?? '0.0');
                  Color changePchangeColor = changeTemp >= 0 ? ConstantColors.buyColor : ConstantColors.sellColor;

                  //add_alert parameter preparation
                  _addAlertModelClass.exchange = exchange;
                  _addAlertModelClass.token = responseObj.token ?? '';
                  _addAlertModelClass.assetType = int.parse(responseObj.token ?? '').toAssetType();

                  switch (_addAlertModelClass.assetType?.toLowerCase().toString()) {
                    case 'equity':
                      _addAlertModelClass.symbol = responseObj.symbol ?? '';
                      break;
                    default:
                      _addAlertModelClass.symbol = responseObj.description ?? '';
                  }

                  _addAlertModelClass.alertType = getAlertType(selectedAlertType);
                  _addAlertModelClass.direction = getDirection(selectedAlertDirection);

                  // Call subscribe
                  _profileBloc?.subscribeForMarketPicture(responseObj.token ?? '');

                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.grey.shade400,
                            ),
                          ),
                          child: StreamBuilder<MarketPictureModelClass?>(
                              stream: _profileBloc?.marketPictureSubject?.stream,
                              builder: (context, snapshot) {
                                if (snapshot.hasData) {
                                  //Compare token to update the data
                                  String tcpToken = snapshot.data?.symbol ?? '';
                                  String oldToken = responseObj.token ?? '';
                                  if (tcpToken.toLowerCase() == oldToken.toLowerCase()) {
                                    ltp = snapshot.data?.ltp ?? '0.0';
                                    double change = double.parse(snapshot.data?.change ?? '0.0');
                                    changePchangeColor = change >= 0 ? ConstantColors.buyColor : ConstantColors.sellColor;
                                    resultChangePerchange = (snapshot.data?.change ?? '0.0') + ' ( ' + (snapshot.data?.pChange ?? '0.0') + ' %)';
                                    totVolume = snapshot.data?.totalVolume ?? '0.0';
                                  }
                                }
                                return Padding(
                                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                responseObj.symbol ?? '',
                                                style: const TextStyle(
                                                  fontFamily: 'Roboto',
                                                  fontSize: 16,
                                                ),
                                              ),
                                              Text(
                                                resultScripName,
                                                style: const TextStyle(
                                                  fontFamily: 'Roboto',
                                                  fontSize: 13,
                                                ),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            ltp,
                                            style: const TextStyle(
                                              fontFamily: 'Roboto',
                                              fontSize: 15,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Text(responseObj.scripname ?? ''),
                                          Text(
                                            resultChangePerchange,
                                            style: TextStyle(
                                              fontFamily: 'Roboto',
                                              fontSize: 13,
                                              color: changePchangeColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Visibility(
                                        visible: totalVolVisibility,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Text(
                                              'Total Vol.  $totVolume',
                                              style: const TextStyle(
                                                fontFamily: 'Roboto',
                                                fontSize: 13,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                return Container(
                                  margin: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                                  child: CustomDropdownButton2(
                                    buttonWidth: constraints.maxWidth,
                                    buttonHeight: 45,
                                    buttonElevation: 0,
                                    dropdownElevation: 1,
                                    dropdownWidth: constraints.maxWidth - 14,
                                    buttonDecoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: Colors.white,
                                      border: Border.all(color: Colors.black45, width: 0.6),
                                    ),
                                    hint: '',
                                    dropdownItems: alertType,
                                    value: selectedAlertType,
                                    onChanged: (value) {
                                      setModalState(
                                        () {
                                          selectedAlertType = value.toString();
                                          if (selectedAlertType.toLowerCase().compareTo('volume') == 0) {
                                            totalVolVisibility = true;
                                            selectedAlertDirection = alertDirection[0];
                                          } else {
                                            totalVolVisibility = false;
                                          }
                                        },
                                      );
                                    },
                                    icon: const Icon(Icons.arrow_drop_down_outlined, size: 40),
                                  ),
                                );
                              },
                            ),
                          ),
                          Expanded(
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                return Container(
                                  margin: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                                  child: CustomDropdownButton2(
                                    buttonHeight: 45,
                                    buttonWidth: constraints.maxWidth,
                                    buttonElevation: 0,
                                    dropdownElevation: 1,
                                    dropdownWidth: constraints.maxWidth - 14,
                                    buttonDecoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: Colors.white,
                                      border: Border.all(color: Colors.black45, width: 0.6),
                                    ),
                                    hint: '',
                                    dropdownItems: alertDirection,
                                    value: selectedAlertDirection,
                                    onChanged: totalVolVisibility
                                        ? null
                                        : (value) {
                                            setModalState(
                                              () {
                                                selectedAlertDirection = value.toString();
                                              },
                                            );
                                          },
                                    icon: const Icon(Icons.arrow_drop_down_outlined, size: 40),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        height: SizeConfig.blockSizeVertical! * 5.5,
                        child: Center(
                          child: TextFormField(
                            inputFormatters: [FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))],
                            keyboardType: const TextInputType.numberWithOptions(signed: false, decimal: true),
                            maxLength: 15,
                            style: const TextStyle(
                              fontFamily: 'Roboto',
                              color: ConstantColors.black,
                              fontSize: 14,
                              letterSpacing: 1.2,
                            ),
                            textCapitalization: TextCapitalization.characters,
                            autofocus: false,
                            decoration: InputDecoration(
                              counterText: '',
                              isDense: true,
                              hintText: 'Enter Range',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              contentPadding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                            ),
                            onChanged: (value) {
                              rangeEntered = value.toString();
                              _addAlertModelClass.range = rangeEntered;
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            height: 50,
                            width: MediaQuery.of(context).size.width / 2.5,
                            child: TextButton(
                              onPressed: () {
                                _profileBloc?.unSubscribeMarketPicture();
                                Navigator.pop(context);
                              },
                              child: Text(
                                'CANCEL',
                                textScaleFactor: 1.0,
                                style: GreekTextStyle.loginButtonText,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black26,
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: const [
                                BoxShadow(color: Colors.black12, spreadRadius: 1),
                              ],
                            ),
                          ),
                          Container(
                            height: 50,
                            width: MediaQuery.of(context).size.width / 2.5,
                            child: TextButton(
                              onPressed: () {
                                //Call 'add_alerts'

                                if (rangeEntered.isEmpty) {
                                  GreekDialogPopupView.messageDialog(
                                    context,
                                    ConstantMessages.FP_CREATE_ALERT,
                                  );
                                } else if (double.parse(rangeEntered) <= 0) {
                                  GreekDialogPopupView.messageDialog(
                                    context,
                                    'Enter valid range',
                                  );
                                } else {
                                  _profileBloc?.unSubscribeMarketPicture();
                                  Navigator.pop(context);
                                  callingAddAlertsAPI();
                                  rangeEntered = '';
                                }
                              },
                              child: Text(
                                'CREATE',
                                textScaleFactor: 1.0,
                                style: GreekTextStyle.loginButtonText,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFF127FBA),
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: const [
                                BoxShadow(color: Colors.black12, spreadRadius: 1),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 25),
                    ],
                  );
                }
                return const SizedBox(
                  height: 150,
                  child: Center(
                    child: NoDatWithProgressIndicator(topSpace: 40, showHide: true, message: 'Fetching data'),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  void callingAddAlertsAPI() async {
    final response = await _profileBloc?.addAlerts(_addAlertModelClass);
    String errorCode = '${response?['ErrorCode']}';
    String ruleNo = '${response?['RuleNo']}';
    String gToken = '${response?['Gtoken']}';

    if (errorCode == '0') {
      // Prepare 'UserAlert' TCP[Apollo] request to add/delete alert.
      _addAlertModelClass.ruleNo = ruleNo;
      _addAlertModelClass.gToken = gToken;
      _addAlertModelClass.operation = '0';
      isDeleteCalled = false;

      SocketIOManager().userAlertRequest(_addAlertModelClass);
      isCreateDeleteApicalled = true;
    }
  }

  pullToRefresh() async {}

//Perform Delete Network Request
  void _onDismissed(AlertResponseData responseData) {
    _addAlertModelClass.ruleNo = '${responseData.ruleNo}';
    _addAlertModelClass.gToken = '${responseData.gtoken}';
    _addAlertModelClass.operation = '1';
    _addAlertModelClass.alertType = '${responseData.alertType}';
    _addAlertModelClass.direction = '${responseData.directionFlag}';
    _addAlertModelClass.range = '${responseData.range}';
    print(responseData);
    isDeleteCalled = true;
    SocketIOManager().userAlertRequest(_addAlertModelClass);
    isCreateDeleteApicalled = true;
  }

  //Alerts Data
  Widget buildAlertListWidget(ProfileBloc? _profileBloc, BuildContext context) {
    double topSpace = MediaQuery.of(context).size.height / 2;
    return FutureBuilder<List<AlertResponseData>?>(
      future: _profileBloc?.fetchAlerts(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int dataLength = snapshot.data?.length ?? 0;

          List<AlertResponseData> temp = snapshot.data ?? [];
          List<AlertResponseData> sort1 = [];
          for (var item in temp) {
            String exchange = '';
            String assetType = '';

            if (sortByExchange != '') {
              exchange = (item.token ?? 0).toExchange();
            }

            if (sortByAsset != '') {
              assetType = (item.token ?? 0).toAssetType();
            }

            if (sortByExchange != '' && sortByAsset != '') {
              if (exchange.toLowerCase().compareTo(sortByExchange.toLowerCase()) == 0 && assetType.toLowerCase().compareTo(sortByAsset.toLowerCase()) == 0) {
                sort1.add(item);
              }
            } else if (sortByExchange != '') {
              if (exchange.toLowerCase().compareTo(sortByExchange.toLowerCase()) == 0) {
                sort1.add(item);
              }
            } else if (sortByAsset != '') {
              if (assetType.toLowerCase().compareTo(sortByAsset.toLowerCase()) == 0) {
                sort1.add(item);
              }
            } else {
              shouldSort = false;
            }
          }

          if (shouldSort && (sortByExchange != '' || sortByAsset != '')) {
            dataLength = sort1.length;
          } else {
            shouldSort = false;
          }

          if (dataLength <= 0) {
            return NoDatWithProgressIndicator(topSpace: topSpace, showHide: false, message: '');
          }

          return RefreshIndicator(
            semanticsLabel: 'Pull To Refresh',
            color: const Color(0xFF127FBA),
            strokeWidth: 2.0,
            onRefresh: () {
              return pullToRefresh();
            },
            child: SlidableAutoCloseBehavior(
              closeWhenOpened: true,
              child: ListView.builder(
                itemCount: dataLength,
                itemBuilder: (context, index) {
                  final responseObj = shouldSort ? sort1[index] : snapshot.data?[index];

                  String exchange = (responseObj?.token ?? 0).toExchange();
                  String instrumentType = responseObj?.seriesInstname ?? '';
                  String directionflag = '${responseObj?.directionFlag ?? -1}';
                  String alertDirection = '';

                  if (directionflag == '0') {
                    alertDirection = 'Up';
                  } else if (directionflag == '1') {
                    alertDirection = ' Down';
                  } else {
                    alertDirection = '';
                  }
                  exchange = exchange + ' - ' + instrumentType;
                  String alertStatus = '${responseObj?.isExecuted ?? -1}';
                  String type = '${responseObj?.alertType ?? -1}';
                  String alertType = '';
                  String range = responseObj?.range ?? '';

                  if (type == '1') {
                    alertType = 'Price : ' + range;
                  } else if (type == '2') {
                    alertType = range + ' ' + '%';
                  } else if (type == '3') {
                    alertType = 'Vol : ' + range;
                  }

                  return Slidable(
                    endActionPane: ActionPane(
                      motion: const StretchMotion(),
                      children: [
                        SlidableAction(
                          backgroundColor: Colors.red,
                          icon: Icons.delete,
                          label: 'Delete',
                          onPressed: (context) => _onDismissed(responseObj!),
                        )
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              offset: const Offset(0, 0),
                              spreadRadius: 0.5,
                              blurRadius: 0.5,
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 2),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Text(responseObj?.symbol ?? 'N/A'),
                                      Row(
                                        children: [
                                          Text(alertDirection, style: GreekTextStyle.headline21),
                                          const SizedBox(width: 6),
                                          alertStatus == '0'
                                              ? const Icon(Icons.thumb_down_off_alt_outlined, color: Colors.red, size: 20)
                                              : const Icon(
                                                  Icons.thumb_up_off_alt_outlined,
                                                  color: Colors.green,
                                                  size: 20,
                                                ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(8, 2, 8, 8),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Text(exchange),
                                      Row(
                                        children: [
                                          Text(
                                            alertType,
                                            style: GreekTextStyle.headline21,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          );
        } else {
          return NoDatWithProgressIndicator(topSpace: topSpace, showHide: true, message: 'Fetching data');
        }
      },
    );
  }
}

class AddAlertModelClass {
  String? symbol;
  String? assetType;
  String? exchange;
  String? alertType;
  String? token;
  String? direction;
  String? range;
  String? ruleNo;
  String? gToken;
  String? operation;
}
