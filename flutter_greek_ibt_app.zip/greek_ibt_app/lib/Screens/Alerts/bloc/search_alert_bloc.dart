import 'dart:developer';

import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';
import 'package:greek_ibt_app/sqlite/datahelper.dart';

class SearchAlertBloc extends GreekBlocs {
  @override
  void disposeBloc() {}

  Future<List<SearchSymbolSqliteModel>> searchAlertSymbol({required String? symbol}) async {
    final result = await DBHelper.searchSymbolByCode(symbolCode: symbol ?? '');
    log('Search Alert Result $result');
    List<SearchSymbolSqliteModel> responseData = [];

    if (result is List) {
      responseData = result.map((e) => SearchSymbolSqliteModel.fromJson(e)).toList();
    }
    return responseData;
  }

  
}
