import 'dart:io';

import 'package:dropdown_button2/custom_dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Settings/bloc/settings_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/profile_avatar_widget.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final titleTextStyle = const TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.w600,
    fontSize: 16,
    fontFamily: 'Roboto Medium',
  );

  final dataTextStyleBlack = const TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.normal,
    fontSize: 14,
    fontFamily: 'Roboto Medium',
  );

  final dataTextStyle = const TextStyle(
    color: Color(0xFF298BC0),
    fontWeight: FontWeight.normal,
    fontSize: 14,
    fontFamily: 'Roboto Medium',
  );

  List<String> defaultScreenList = ['Market', 'Watchlist', 'Order', 'Portfolio', 'Funds'];
  String selectedDefaultScreen = 'Market';
  File? imageFile;
  bool _obscureTextOldPass = true;
  bool _obscureTextNewPass = true;
  bool _obscureTextNewConfirmPass = true;

  String oldPassword = '';
  String newPassword = '';
  String confirmPassword = '';

  SettingsBloc? _settingsBloc;
  @override
  void initState() {
    _settingsBloc ??= SettingsBloc(context);
    super.initState();
  }

  Widget _buildProfileBannerWidget() {
    final gscid = AppConfig().gscid;
    final clientCode = AppConfig().clientName;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xFF127FBA),
        ),
        child: Row(
          children: [
            const SizedBox(width: 10),
            InkWell(
              onTap: () {
                //TODO : [Yet to fetch image from Gallery or Camera to upload]
                print('Updload profile image');
                // _getFromGallery();
              },
              child: SizedBox(
                height: 70,
                width: 70,
                child: ProfileAvatar(imageFile),
              ),
            ),
            const SizedBox(width: 30),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    clientCode,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      fontFamily: 'Roboto Medium',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    gscid,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      fontFamily: 'Roboto Medium',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.5,
        backgroundColor: ConstantColors.white,
        leading: IconButton(
          onPressed: () {
            GreekBase().drawerKey.currentState?.openDrawer();
          },
          icon: const Icon(Icons.menu_rounded),
          iconSize: 30.0,
          color: ConstantColors.black,
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: Text('Settings', style: GreekTextStyle.headline2),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Select Default Screen',
                    style: titleTextStyle,
                  ),
                ),
                const SizedBox(height: 6),
                LayoutBuilder(
                  builder: (context, constraints) {
                    return CustomDropdownButton2(
                      buttonWidth: constraints.maxWidth,
                      buttonHeight: 45,
                      buttonElevation: 0,
                      dropdownElevation: 1,
                      dropdownWidth: constraints.maxWidth - 14,
                      buttonDecoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: Colors.white,
                        border: Border.all(color: Colors.black26),
                      ),
                      hint: '',
                      dropdownItems: defaultScreenList,
                      value: selectedDefaultScreen,
                      onChanged: (value) {
                        setState(
                          () {
                            selectedDefaultScreen = value.toString();
                            AppConfig().saveDefaultScreen(data: selectedDefaultScreen);
                          },
                        );
                      },
                      icon: const Icon(Icons.arrow_drop_down_outlined, size: 40),
                    );
                  },
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: Colors.white,
                border: Border.all(color: Colors.black26),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Password & Security',
                      style: dataTextStyleBlack,
                    ),
                    InkWell(
                      onTap: () {
                        //open bottom sheet to show password change options
                        showModalBottomSheet(
                          isDismissible: true,
                          isScrollControlled: true,
                          enableDrag: true,
                          context: context,
                          backgroundColor: Colors.white.withOpacity(0),
                          builder: (context) {
                            return StatefulBuilder(
                              builder: (context, StateSetter setModalState) {
                                return Padding(
                                  padding: MediaQuery.of(context).viewInsets,
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.fromLTRB(12, 0, 12, 20),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(10),
                                          border: Border.all(color: Colors.grey.shade400, width: 0.5),
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.symmetric(vertical: 12),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    'Change Password',
                                                    style: titleTextStyle,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            _buildProfileBannerWidget(),
                                            Padding(
                                              padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
                                              child: TextFormField(
                                                inputFormatters: [FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))],
                                                keyboardType: TextInputType.text,
                                                maxLength: 12,
                                                controller: _settingsBloc?.oldPassTextFieldController,
                                                obscureText: _obscureTextOldPass,
                                                style: const TextStyle(
                                                  fontFamily: 'Roboto',
                                                  color: ConstantColors.black,
                                                  fontSize: 14,
                                                  letterSpacing: 1.2,
                                                ),
                                                textCapitalization: TextCapitalization.characters,
                                                autofocus: false,
                                                decoration: InputDecoration(
                                                  counterText: '',
                                                  isDense: true,
                                                  hintText: 'Enter Old Password',
                                                  border: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10.0),
                                                  ),
                                                  contentPadding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                                                  suffixIcon: GestureDetector(
                                                    onTap: () {
                                                      setModalState(() {
                                                        _obscureTextOldPass = !_obscureTextOldPass;
                                                      });
                                                    },
                                                    child: Icon(
                                                      _obscureTextOldPass ? Icons.visibility : Icons.visibility_off,
                                                      semanticLabel: _obscureTextOldPass ? 'show password' : 'hide password',
                                                    ),
                                                  ),
                                                ),
                                                onChanged: (String value) {
                                                  oldPassword = value;
                                                },
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            Padding(
                                              padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
                                              child: TextFormField(
                                                inputFormatters: [FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))],
                                                keyboardType: TextInputType.text,
                                                maxLength: 12,
                                                controller: _settingsBloc?.newPassTextFieldController,
                                                obscureText: _obscureTextNewPass,
                                                style: const TextStyle(
                                                  fontFamily: 'Roboto',
                                                  color: ConstantColors.black,
                                                  fontSize: 14,
                                                  letterSpacing: 1.2,
                                                ),
                                                textCapitalization: TextCapitalization.characters,
                                                autofocus: false,
                                                decoration: InputDecoration(
                                                  counterText: '',
                                                  isDense: true,
                                                  hintText: 'Enter New Password',
                                                  border: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10.0),
                                                  ),
                                                  contentPadding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                                                  suffixIcon: GestureDetector(
                                                    onTap: () {
                                                      setModalState(() {
                                                        _obscureTextNewPass = !_obscureTextNewPass;
                                                      });
                                                    },
                                                    child: Icon(
                                                      _obscureTextNewPass ? Icons.visibility : Icons.visibility_off,
                                                      semanticLabel: _obscureTextNewPass ? 'show password' : 'hide password',
                                                    ),
                                                  ),
                                                ),
                                                onChanged: (String value) {
                                                  newPassword = value;
                                                },
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            Padding(
                                              padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
                                              child: TextFormField(
                                                inputFormatters: [FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))],
                                                keyboardType: TextInputType.text,
                                                maxLength: 12,
                                                controller: _settingsBloc?.confirmPassTextFieldController,
                                                obscureText: _obscureTextNewConfirmPass,
                                                style: const TextStyle(
                                                  fontFamily: 'Roboto',
                                                  color: ConstantColors.black,
                                                  fontSize: 14,
                                                  letterSpacing: 1.2,
                                                ),
                                                textCapitalization: TextCapitalization.characters,
                                                autofocus: false,
                                                decoration: InputDecoration(
                                                  counterText: '',
                                                  isDense: true,
                                                  hintText: 'Confirm New Password',
                                                  border: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10.0),
                                                  ),
                                                  contentPadding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                                                  suffixIcon: GestureDetector(
                                                    onTap: () {
                                                      setModalState(() {
                                                        _obscureTextNewConfirmPass = !_obscureTextNewConfirmPass;
                                                      });
                                                    },
                                                    child: Icon(
                                                      _obscureTextNewConfirmPass ? Icons.visibility : Icons.visibility_off,
                                                      semanticLabel: _obscureTextNewConfirmPass ? 'show password' : 'hide password',
                                                    ),
                                                  ),
                                                ),
                                                onChanged: (String value) {
                                                  confirmPassword = value;
                                                },
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            Container(
                                              height: 50,
                                              width: MediaQuery.of(context).size.width / 2.5,
                                              child: TextButton(
                                                onPressed: () {
                                                  // Change Password API Call
                                                  _settingsBloc?.changePasswordManually();
                                                },
                                                child: Text(
                                                  'UPDATE',
                                                  textScaleFactor: 1.0,
                                                  style: titleTextStyle,
                                                ),
                                              ),
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius: BorderRadius.circular(10.0),
                                                boxShadow: const [
                                                  BoxShadow(color: Color(0xFF127FBA), spreadRadius: 0.5),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(height: 16),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                        );
                      },
                      child: Text(
                        'Change Password',
                        style: dataTextStyle,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
