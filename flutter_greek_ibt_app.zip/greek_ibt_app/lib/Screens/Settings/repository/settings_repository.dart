import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/string_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class SettingsRepository {
  
  Future<int?> jChangePassword({
    required BuildContext context,
    required String oldPass,
    required String newPass,
  }) async {
    return await NetworkManager().postAPIEncryptedOnlyForErrorCode(
      context: context,
      apiName: APIName.jchange_password,
      postBody: {
        'gscid': AppConfig().gscid,
        'encryptionType': '1',
        'oldPassword': oldPass.toMD5String(),
        'changeNewPassword': newPass.toMD5String(),
        'passType': '0',
        'brokerid': '1',
      },
    );
  }
}
