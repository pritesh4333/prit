import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Settings/repository/settings_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';

class SettingsBloc extends GreekBlocs {
  final BuildContext _settingsBlocContext;
  final _settingsRepository = SettingsRepository();

  SettingsBloc(this._settingsBlocContext) {}

  final oldPassTextFieldController = TextEditingController();
  final newPassTextFieldController = TextEditingController();
  final confirmPassTextFieldController = TextEditingController();

  @override
  void disposeBloc() {
    oldPassTextFieldController.dispose();
    newPassTextFieldController.dispose();
    confirmPassTextFieldController.dispose();
  }

  void clearAllTextField() {
    oldPassTextFieldController.clear();
    oldPassTextFieldController.text = '';

    newPassTextFieldController.clear();
    newPassTextFieldController.text = '';

    confirmPassTextFieldController.clear();
    confirmPassTextFieldController.text = '';
  }

  Future<void> changePasswordManually() async {
    if (oldPassTextFieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(_settingsBlocContext, ConstantMessages.CP_OLD_PASSWORD_EMPTY_ALERT);
    } else if (newPassTextFieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _settingsBlocContext,
        ConstantMessages.CP_NEW_PASSWORD_EMPTY_ALERT,
      );
    } else if (confirmPassTextFieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _settingsBlocContext,
        ConstantMessages.CP_CONFIRM_PASSWORD_EMPTY_ALERT,
      );
    } else if (!newPassTextFieldController.text.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) {
      GreekDialogPopupView.messageDialog(
        _settingsBlocContext,
        ConstantMessages.CP_SYMBOL_MSG,
      );
    } else if (!newPassTextFieldController.text.contains(RegExp(r'[A-Za-z0-9]'))) {
      GreekDialogPopupView.messageDialog(
        _settingsBlocContext,
        ConstantMessages.CP_ALPHANUMERIC_MSG,
      );
    } else if (newPassTextFieldController.text.toLowerCase().compareTo(confirmPassTextFieldController.text.toLowerCase()) != 0) {
      GreekDialogPopupView.messageDialog(
        _settingsBlocContext,
        ConstantMessages.CP_CONFIRM_NEW_PASSWORD_MSG,
      );
    } else {
      final errorCode = await _settingsRepository.jChangePassword(
        context: _settingsBlocContext,
        oldPass: oldPassTextFieldController.text,
        newPass: newPassTextFieldController.text,
      );

      switch (errorCode) {
        case 0:
          clearAllTextField();
          Navigator.pop(_settingsBlocContext);
          GreekBase().logoutApp(logoffContext: _settingsBlocContext);

          break;

        case 2:
          GreekDialogPopupView.messageDialog(
            _settingsBlocContext,
            ConstantMessages.GREEK_INCORRECT_PASSWORD_MSG,
          );
          break;

        case 4:
          GreekDialogPopupView.messageDialog(
            _settingsBlocContext,
            ConstantMessages.GREEK_DUPLICATE_PASSWORD_MSG,
          );
          break;

        case 5:
          GreekDialogPopupView.messageDialog(
            _settingsBlocContext,
            ConstantMessages.GREEK_MAX_MSG,
          );
          break;

        case 9:
          GreekDialogPopupView.messageDialog(
            _settingsBlocContext,
            ConstantMessages.GREEK_ID_PASS_MSG,
          );
          break;

        default:
          break;
      }
    }
  }
}
