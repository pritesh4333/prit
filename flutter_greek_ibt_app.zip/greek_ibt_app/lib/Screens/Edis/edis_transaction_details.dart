import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../Configuration/app_config.dart';
import '../../Configuration/greek_navigation.dart';
import '../../Helper/constant_colors.dart';
import '../../Helper/constant_messages.dart';
import '../../Helper/greek_base.dart';
import '../../Utilities/greek_textstyle.dart';
import '../../Utilities/required_function.dart';
import 'Model/getEdisTransactionDetailResponse.dart';
import 'bloc/edis_dashboard_bloc.dart';

// This is your new screen do anything you want here

class EdisTransactionDetails extends StatefulWidget {
  const EdisTransactionDetails({
    Key? key,
  }) : super(key: key);
  @override
  EdisTransactionDetailsState createState() => EdisTransactionDetailsState();
}

class EdisTransactionDetailsState extends State<EdisTransactionDetails> {
  String? startDate;
  String? Dateend;
  String? endDate;
  late final now;
  final customeStartDate = TextEditingController();
  final customeEndDate = TextEditingController();
  EdisDashboardBloc? _edisblock;
  List<String> selectedDropDownValues = [
    'This Month',
    'Last Month',
    'Previous Year',
    'Current Year',
    'Custom'
  ];

  @override
  void initState() {
    super.initState();
    endDate = RequiredFunction().dateFormater('MMM dd yyyy');

    now = DateTime.now();
    final startDate1 = DateTime(now.year, now.month, 1);
    final startTimeStamp =
        (startDate1.millisecondsSinceEpoch ~/ 1000).toString();
    startDate = startTimeStamp;

    final endTimeStamp = (now.millisecondsSinceEpoch ~/ 1000).toString();
    Dateend = endTimeStamp;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _edisblock ??= EdisDashboardBloc(context: context);
    _edisblock?.getEdisDashboardTransactionDetails(
        AppConfig().gscid, startDate.toString(), Dateend.toString());
    // _edisblock?.getEdisDashboardTransactionDetails(AppConfig().gscid, "1661970600", "1662488999");

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            onPressed: () {
              GreekBase().drawerKey.currentState?.openDrawer();
            },
            icon: const Icon(Icons.menu_rounded),
            iconSize: 30.0,
            color: ConstantColors.black,
          ),
          title: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              ConstantMessages.EDIS_DASHBOARD_TRANSACTION_HEADER_TXT,
              style: GreekTextStyle.headline2,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      alignment: Alignment.centerLeft,
                      margin: const EdgeInsets.only(left: 10),
                      child: Text(
                        "E-DIS  $endDate",
                        style: GreekTextStyle.headline1,
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Column(
                        children: [
                          PopupMenuButton<String>(
                            offset: const Offset(-5.0, 28),
                            itemBuilder: (context) {
                              return selectedDropDownValues.toSet().map((str) {
                                return PopupMenuItem(
                                  value: str,
                                  child: Row(
                                    children: [
                                      Text(
                                        str,
                                        style: GreekTextStyle
                                            .marketStatisticsDropdownTextStyle,
                                      ),
                                    ],
                                  ),
                                );
                              }).toList();
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 10, top: 5, bottom: 0, right: 10),
                              child: Image.asset(
                                'assets/images/setting_icon.png',
                                fit: BoxFit.fitWidth,
                              ),
                            ),
                            onSelected: (data) async {
                              if (data.isNotEmpty) {
                                if (data == "This Month") {
                                  final startDate1 =
                                      DateTime(now.year, now.month, 1);
                                  final startTimeStamp =
                                      (startDate1.millisecondsSinceEpoch ~/
                                              1000)
                                          .toString();
                                  startDate = startTimeStamp;

                                  final endTimeStamp =
                                      (now.millisecondsSinceEpoch ~/ 1000)
                                          .toString();
                                  Dateend = endTimeStamp;
                                  _edisblock
                                      ?.getEdisDashboardTransactionDetails(
                                          AppConfig().gscid,
                                          startDate.toString(),
                                          Dateend.toString());
                                } else if (data == "Last Month") {
                                  DateTime firstDayCurrentMonth = DateTime.utc(
                                      DateTime.now().year,
                                      DateTime.now().month - 1,
                                      1);
                                  // print(firstDayCurrentMonth);
                                  final startTimeStamp = (firstDayCurrentMonth
                                              .millisecondsSinceEpoch ~/
                                          1000)
                                      .toString();
                                  startDate = startTimeStamp;

                                  DateTime lastdayCurrentMonth = DateTime.utc(
                                      DateTime.now().year,
                                      DateTime.now().month,
                                      1 - 1);
                                  // print(lastdayCurrentMonth);
                                  final startTimeStamp2 = (lastdayCurrentMonth
                                              .millisecondsSinceEpoch ~/
                                          1000)
                                      .toString();
                                  Dateend = startTimeStamp2;
                                  _edisblock
                                      ?.getEdisDashboardTransactionDetails(
                                          AppConfig().gscid,
                                          startDate.toString(),
                                          Dateend.toString());
                                } else if (data == "Previous Year") {
                                  DateTime firstDayCurrentMonth = DateTime.utc(
                                      DateTime.now().year - 1, 1, 1);
                                  // print(firstDayCurrentMonth);
                                  final startTimeStamp = (firstDayCurrentMonth
                                              .millisecondsSinceEpoch ~/
                                          1000)
                                      .toString();
                                  startDate = startTimeStamp;

                                  DateTime lastdayCurrentMonth = DateTime.utc(
                                      DateTime.now().year - 1, 13, 1 - 1);
                                  // print(lastdayCurrentMonth);
                                  final startTimeStamp2 = (lastdayCurrentMonth
                                              .millisecondsSinceEpoch ~/
                                          1000)
                                      .toString();
                                  Dateend = startTimeStamp2;
                                  _edisblock
                                      ?.getEdisDashboardTransactionDetails(
                                          AppConfig().gscid,
                                          startDate.toString(),
                                          Dateend.toString());
                                } else if (data == "Current Year") {
                                  DateTime firstDayCurrentMonth =
                                      DateTime.utc(DateTime.now().year, 1, 1);
                                  // print(firstDayCurrentMonth);
                                  final startTimeStamp = (firstDayCurrentMonth
                                              .millisecondsSinceEpoch ~/
                                          1000)
                                      .toString();
                                  startDate = startTimeStamp;

                                  final endTimeStamp =
                                      (now.millisecondsSinceEpoch ~/ 1000)
                                          .toString();
                                  Dateend = endTimeStamp;
                                  // print(Dateend);
                                  _edisblock
                                      ?.getEdisDashboardTransactionDetails(
                                          AppConfig().gscid,
                                          startDate.toString(),
                                          Dateend.toString());
                                } else if (data == "Custom") {
                                  customeStartDate.text = RequiredFunction()
                                      .getDateFromTimeStamp(
                                          int.parse(startDate!));
                                  customeEndDate.text = RequiredFunction()
                                      .getDateFromTimeStamp(
                                          int.parse(Dateend!));

                                  showDialog(
                                    barrierDismissible: false,
                                    context: context,
                                    builder: (dialogContext) => Dialog(
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              20.0)), //this right here
                                      child: WillPopScope(
                                        onWillPop: () async {
                                          GreekNavigator.pop(context: context);
                                          return true;
                                        },
                                        child: StatefulBuilder(
                                            builder: (context, mystate) {
                                          return SizedBox(
                                            height: 180,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 20.0,
                                                          bottom: 8.0,
                                                          top: 18.0),
                                                  child: Text(
                                                    "Select Date",
                                                    textAlign: TextAlign.start,
                                                    style: GreekTextStyle
                                                        .headline22,
                                                  ),
                                                ),
                                                const Divider(
                                                  color: Colors.grey,
                                                  height: 2,
                                                ),
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Container(
                                                      child: InkWell(
                                                        onTap: () async {
                                                          DateTime
                                                              lastDateValue =
                                                              DateTime.now();
                                                          DateTime
                                                              selectedDate =
                                                              DateTime.now();
                                                          final DateTime?
                                                              picked =
                                                              await showDatePicker(
                                                            context: context,
                                                            initialDate:
                                                                DateTime.now(),
                                                            firstDate: DateTime(
                                                                DateTime.now()
                                                                        .year -
                                                                    50,
                                                                DateTime.now()
                                                                        .month -
                                                                    1,
                                                                DateTime.now()
                                                                        .day +
                                                                    1),
                                                            lastDate:
                                                                lastDateValue,
                                                          );
                                                          if (picked != null &&
                                                              picked !=
                                                                  selectedDate) {
                                                            final startTimeStamp =
                                                                (((selectedDate.millisecondsSinceEpoch ~/
                                                                                1000) +
                                                                            19800)
                                                                        .round())
                                                                    .toString();
                                                            mystate(() {
                                                              selectedDate =
                                                                  picked;
                                                              // final startTimeStamp = (selectedDate.millisecondsSinceEpoch ~/ 1000).toString();
                                                              startDate =
                                                                  startTimeStamp;
                                                              customeStartDate
                                                                      .text =
                                                                  RequiredFunction()
                                                                      .getDateFromTimeStamp(
                                                                          int.parse(
                                                                              startTimeStamp));
                                                            });
                                                          }
                                                        },
                                                        child: Column(
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(8.0),
                                                              child: Container(
                                                                width: 100,
                                                                height: 20,
                                                                child: Text(
                                                                  customeStartDate
                                                                      .text,
                                                                  style:
                                                                      const TextStyle(
                                                                    color: ConstantColors
                                                                        .black,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              color:
                                                                  Colors.grey,
                                                              height: 1,
                                                              width: 100,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      child: InkWell(
                                                        onTap: () async {
                                                          DateTime
                                                              lastDateValue =
                                                              DateTime.now();
                                                          // lastDateValue = DateTime(DateTime.now().year + 100000);
                                                          // DateTime selectedDate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 1);
                                                          DateTime
                                                              selectedDate =
                                                              DateTime.now();

                                                          final DateTime?
                                                              picked =
                                                              await showDatePicker(
                                                            context: context,
                                                            initialDate:
                                                                DateTime.now()
                                                                    .toUtc(),
                                                            firstDate: DateTime(
                                                                    DateTime.now()
                                                                            .year -
                                                                        50,
                                                                    DateTime.now()
                                                                            .month -
                                                                        1,
                                                                    DateTime.now()
                                                                        .day)
                                                                .toUtc(),
                                                            lastDate:
                                                                DateTime.now()
                                                                    .toUtc(),
                                                          );
                                                          if (picked != null &&
                                                              picked !=
                                                                  selectedDate) {
                                                            mystate(() {
                                                              customeEndDate
                                                                  .text = DateFormat(
                                                                      'dd MMM yyyy')
                                                                  .format(
                                                                      picked);
                                                              selectedDate =
                                                                  picked;
                                                              // final startTimeStamp = (selectedDate.millisecondsSinceEpoch ~/ 1000).toString();
                                                              final startTimeStamp =
                                                                  (((selectedDate.millisecondsSinceEpoch / 1000) +
                                                                              106199)
                                                                          .round())
                                                                      .toString();
                                                              Dateend =
                                                                  startTimeStamp;
                                                              // customeEndDate.text = RequiredFunction().getDateFromTimeStamp(int.parse(startTimeStamp));
                                                            });
                                                          }
                                                        },
                                                        child: Column(
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(8.0),
                                                              child: Container(
                                                                width: 100,
                                                                height: 20,
                                                                child: Text(
                                                                  customeEndDate
                                                                      .text,
                                                                  style:
                                                                      const TextStyle(
                                                                    color: ConstantColors
                                                                        .black,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              color:
                                                                  Colors.grey,
                                                              height: 1,
                                                              width: 100,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const Divider(
                                                  color: Colors.grey,
                                                ),
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Expanded(
                                                      child: TextButton(
                                                        onPressed: () =>
                                                            GreekNavigator.pop(
                                                                context:
                                                                    dialogContext),
                                                        child: Text(
                                                          "Cancel",
                                                          style:
                                                              const TextStyle(
                                                            color:
                                                                ConstantColors
                                                                    .black,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    // const SizedBox(
                                                    //   height: 45,
                                                    //   child: VerticalDivider(
                                                    //     color: ConstantColors.dividerColor,
                                                    //   ),
                                                    // ),
                                                    Expanded(
                                                      child: TextButton(
                                                        onPressed: () {
                                                          GreekNavigator.pop(
                                                              context:
                                                                  dialogContext);
                                                          _edisblock
                                                              ?.getEdisDashboardTransactionDetails(
                                                                  AppConfig()
                                                                      .gscid,
                                                                  startDate
                                                                      .toString(),
                                                                  Dateend
                                                                      .toString());
                                                        },
                                                        child: Text(
                                                          "Submit",
                                                          style:
                                                              const TextStyle(
                                                            color:
                                                                ConstantColors
                                                                    .black,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          );
                                        }),
                                      ),
                                    ),
                                  );
                                } else {
                                  _edisblock
                                      ?.getEdisDashboardTransactionDetails(
                                          AppConfig().gscid,
                                          startDate.toString(),
                                          Dateend.toString());
                                }
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              StreamBuilder<List<GetEdisTransactionDetailResponse>>(
                  stream: _edisblock?.edistransactionDetailsStream.stream,
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.hasData == true) {
                        var length = _edisblock?.edisholdingDetailslist.length;
                        if (length! > 0) {
                          return Column(
                            children: [
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Column(
                                  children: [
                                    Container(
                                      color: ConstantColors.edisheader,
                                      margin: const EdgeInsets.only(
                                          top: 15, bottom: 10),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            width: 70,
                                            height: 50,
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              " Date",
                                              style: GreekTextStyle
                                                  .placeOrderAppbarHeading1,
                                            ),
                                          ),
                                          Container(
                                            width: 100,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Scrip Name",
                                              style: GreekTextStyle
                                                  .placeOrderAppbarHeading1,
                                            ),
                                          ),
                                          Container(
                                            width: 70,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Free Qty",
                                              style: GreekTextStyle
                                                  .placeOrderAppbarHeading1,
                                            ),
                                          ),
                                          Container(
                                            width: 90,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Authorize \n Qty",
                                              style: GreekTextStyle
                                                  .placeOrderAppbarHeading1,
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          Container(
                                            width: 120,
                                            height: 50,
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Status",
                                              style: GreekTextStyle
                                                  .placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 120,
                                            height: 50,
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Error \nDiscription",
                                              style: GreekTextStyle
                                                  .placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height -
                                              310,
                                      width: 570,
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: _edisblock
                                            ?.edisholdingDetailslist.length,
                                        itemBuilder: (context, index) {
                                          String date = RequiredFunction()
                                              .getDateFromTimeStamp(_edisblock
                                                      ?.edisholdingDetailslist[
                                                          index]
                                                      .date ??
                                                  0);

                                          return Padding(
                                            padding: const EdgeInsets.all(0.0),
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      width: 80,
                                                      height: 40,
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Text(
                                                        " ${date}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 100,
                                                      height: 40,
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text(
                                                        "${_edisblock?.edisholdingDetailslist[index].symbol ?? ''}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 70,
                                                      height: 40,
                                                      alignment:
                                                          Alignment.centerRight,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 15),
                                                        child: Text(
                                                          "${_edisblock?.edisholdingDetailslist[index].freeQty ?? ''}",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 12.0,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 90,
                                                      height: 40,
                                                      alignment:
                                                          Alignment.centerRight,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 22),
                                                        child: Text(
                                                          "${_edisblock?.edisholdingDetailslist[index].authorizedQty ?? ''}",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 12.0,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 100,
                                                      height: 40,
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                left: 18.0),
                                                        child: Text(
                                                          "${_edisblock?.edisholdingDetailslist[index].status ?? ''}",
                                                          textAlign:
                                                              TextAlign.left,
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 12.0,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        // width: 110,
                                                        height: 40,
                                                        alignment: Alignment
                                                            .centerRight,
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  right: 8),
                                                          child: Text(
                                                            "${_edisblock?.edisholdingDetailslist[index].errorDesc ?? ''}",
                                                            textAlign:
                                                                TextAlign.right,
                                                            maxLines: 3,
                                                            style:
                                                                const TextStyle(
                                                              fontSize: 12.0,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const Divider(
                                                  thickness: 1,
                                                )
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          );
                        } else {
                          // return Container(height: MediaQuery.of(context).size.height - 240, padding: EdgeInsets.only(left: 0), child: GreekBase().noDataAvailableView());
                          return SizedBox(
                            height: MediaQuery.of(context).size.height / 2,
                            child: Center(
                                child: GreekBase().noDataAvailableView()),
                          );
                        }
                      } else {
                        return SizedBox(
                          height: MediaQuery.of(context).size.height / 2,
                          child:
                              Center(child: GreekBase().noDataAvailableView()),
                        );
                      }
                    } else {
                      return SizedBox(
                        height: MediaQuery.of(context).size.height / 2,
                        child: Center(child: GreekBase().noDataAvailableView()),
                      );
                    }
                  }),
            ],
          ),
        ),
      ),
    );
  }
}

Color getColor(number) {
  if (number > 0) {
    return ConstantColors.buyColor;
  } else {
    return ConstantColors.sellColor;
  }
}
