import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/edis_holding_info_response.dart' as holdingdata;
import 'package:greek_ibt_app/Screens/Edis/Model/getedis_authorization_responsemobile_cdsl.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_model.dart' as sendauthstockdetails;
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/required_function.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'bloc/edis_dashboard_bloc.dart';

class EdisDashboardScreen extends StatefulWidget {
  const EdisDashboardScreen({
    Key? key,
  }) : super(key: key);
  @override
  EdisDashboardScreenState createState() => EdisDashboardScreenState();
}

class EdisDashboardScreenState extends State<EdisDashboardScreen> {
  String? formattedDate;
  EdisDashboardBloc? _edisblock;

  List<TextEditingController> sellMarketRequest = [];

  List<holdingdata.StockDetails> selectedList = [];
  EDISAuthorizationResponsemobileCDSL? arg;
  @override
  void initState() {
    super.initState();
    formattedDate = RequiredFunction().dateFormater('dd-MMM-yyyy');
    selectedList = [];
  }

  @override
  void dispose() {
    sellMarketRequest.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _edisblock ??= EdisDashboardBloc(context: context);

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            onPressed: () {
              GreekBase().drawerKey.currentState?.openDrawer();
            },
            icon: const Icon(Icons.menu_rounded),
            iconSize: 30.0,
            color: ConstantColors.black,
          ),
          title: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              ConstantMessages.EDIS_DASHBOARD_HEADER_TXT,
              style: GreekTextStyle.headline2,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 15),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      alignment: Alignment.centerLeft,
                      margin: const EdgeInsets.only(left: 10),
                      child: Text(
                        "E-DIS  $formattedDate",
                        style: GreekTextStyle.headline1,
                      ),
                    ),
                  ],
                ),
              ),
              StreamBuilder<bool>(
                  stream: _edisblock?.edisholdinginfotream.stream,
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.hasData == true) {
                        sellMarketRequest = List.generate((_edisblock?.edisholdinglist.length ?? 0), (index) => TextEditingController(text: _edisblock?.edisholdinglist[index].editableqty));
                        var length = _edisblock?.edisholdinglist.length;
                        if (length! > 0) {
                          return Column(
                            children: [
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Column(
                                  children: [
                                    Container(
                                      color: ConstantColors.edisheader,
                                      margin: const EdgeInsets.only(top: 15, bottom: 10),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Container(
                                            width: 150,
                                            height: 50,
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              "Scrip Name",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                            ),
                                          ),
                                          Container(
                                            width: 60,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Free Qty",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                            ),
                                          ),
                                          Container(
                                            width: 150,
                                            height: 50,
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Transfer Qty\nSell Market \nRequest",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          Container(
                                            width: 60,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Total Qty",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 70,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Rate",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 90,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Value",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 80,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Today Sell\nMarket",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 80,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Total Sell\nMarket",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 80,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Balance\nQty",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                          Container(
                                            width: 90,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Today Sold  \nQty",
                                              style: GreekTextStyle.placeOrderAppbarHeading1,
                                              textAlign: TextAlign.right,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: MediaQuery.of(context).size.height - 310,
                                      width: 910,
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: _edisblock?.edisholdinglist.length,
                                        itemBuilder: (context, index) {
                                          var value = double.parse(_edisblock?.edisholdinglist[index].hQty ?? '0') * double.parse(_edisblock?.edisholdinglist[index].close ?? '0');
                                          var openautmintodayauth = int.parse(_edisblock?.edisholdinglist[index].openAuthQty ?? '0') + int.parse(_edisblock?.edisholdinglist[index].todayAuthQty ?? '0');
                                          var freeqty = int.parse(_edisblock?.edisholdinglist[index].hQty ?? '0') - openautmintodayauth;
                                          var tempbalqty = int.parse(_edisblock?.edisholdinglist[index].openAuthQty ?? '0') + int.parse(_edisblock?.edisholdinglist[index].todayAuthQty ?? '0');
                                          var balQty = tempbalqty - int.parse(_edisblock?.edisholdinglist[index].todaySoldQty ?? '0');
                                          return Padding(
                                            padding: const EdgeInsets.all(0.0),
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      width: 150,
                                                      height: 40,
                                                      alignment: Alignment.centerLeft,
                                                      child: Text(
                                                        " ${_edisblock?.edisholdinglist[index].symbol ?? '0'}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 60,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " $freeqty",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 40,
                                                      height: 20,
                                                      alignment: Alignment.center,
                                                      margin: const EdgeInsets.only(left: 20),
                                                      child: Checkbox(
                                                        value: _edisblock?.edisholdinglist[index].isChecked,
                                                        onChanged: (bool? newValue) {
                                                          setState(() {
                                                            _edisblock?.edisholdinglist[index].isChecked = newValue ?? false;
                                                          });
                                                        },
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 70,
                                                      height: 20,
                                                      margin: const EdgeInsets.only(right: 20),
                                                      alignment: Alignment.center,
                                                      child: TextField(
                                                        controller: sellMarketRequest[index],
                                                        textAlign: TextAlign.center,
                                                        style: GreekTextStyle.marketDepthTotal,
                                                        keyboardType: TextInputType.number,
                                                        onChanged: (string) {
                                                          //sellMarketRequest[index].text = string;
                                                          _edisblock?.edisholdinglist[index].editableqty = string;
                                                        },
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 60,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " ${_edisblock?.edisholdinglist[index].hQty ?? '0'}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 70,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " ${_edisblock?.edisholdinglist[index].close ?? '0'}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 90,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " ${value.toStringAsFixed(2)}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 80,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " ${_edisblock?.edisholdinglist[index].todayAuthQty ?? '0'}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 80,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " ${int.parse(_edisblock?.edisholdinglist[index].openAuthQty ?? '0') + int.parse(_edisblock?.edisholdinglist[index].todayAuthQty ?? '0')}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 80,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " $balQty",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 80,
                                                      height: 40,
                                                      alignment: Alignment.centerRight,
                                                      child: Text(
                                                        " ${int.parse(_edisblock?.edisholdinglist[index].todaySoldQty ?? '0')}",
                                                        style: const TextStyle(
                                                          fontSize: 12.0,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const Divider(
                                                  thickness: 1,
                                                )
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                alignment: Alignment.bottomCenter,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.only(bottom: 10),
                                      child: Checkbox(
                                        value: true,
                                        onChanged: (bool? newValue) {},
                                      ),
                                    ),
                                    Container(
                                      margin: const EdgeInsets.only(bottom: 10),
                                      child: Text(
                                        "Pre Trade",
                                        style: GreekTextStyle.order_description_ltp_textstyle,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 50,
                                    ),
                                    Container(
                                      margin: const EdgeInsets.only(bottom: 10),
                                      height: 40,
                                      width: 140,
                                      child: TextButton(
                                        onPressed: () {
                                          proceedButtonTapped(context);
                                        },
                                        child: Text(
                                          'Proceed',
                                          style: GreekTextStyle.edisprocced,
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        color: ConstantColors.primaryColor,
                                        borderRadius: BorderRadius.circular(8.0),
                                        border: Border.all(
                                          color: ConstantColors.primaryColorLight,
                                          width: 1.5,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          );
                        } else {
                          // return Container(height: MediaQuery.of(context).size.height - 240, padding: EdgeInsets.only(left: 0), child: GreekBase().noDataAvailableView());
                          return SizedBox(
                            height: MediaQuery.of(context).size.height / 2,
                            child: Center(child: GreekBase().noDataAvailableView()),
                          );
                        }
                      } else {
                        return SizedBox(
                          height: MediaQuery.of(context).size.height / 2,
                          child: Center(child: GreekBase().noDataAvailableView()),
                        );
                      }
                    } else {
                      return SizedBox(
                        height: MediaQuery.of(context).size.height / 2,
                        child: Center(child: GreekBase().noDataAvailableView()),
                      );
                    }
                  }),
            ],
          ),
        ),
      ),
    );
  }

  proceedButtonTapped(BuildContext context) {
    FocusScope.of(context).unfocus();
    selectedList = [];
    var validation = true, validationMassage = "";
    if (_edisblock?.edisholdinglist.isNotEmpty ?? false) {
      final filterList = _edisblock?.edisholdinglist.where((element) => element.isChecked);
      if (filterList?.isNotEmpty ?? false) {
        for (var item in filterList!) {
          if (item.editableqty.isEmpty) {
            validation = false;
            validationMassage = "Enter quantity should be between one to free available quantity for selected contract";
            break;
          } else if (int.parse(item.editableqty) <= 0) {
            validation = false;
            validationMassage = "Enter quantity should be between one to free available quantity for selected contract";
            break;
          } else if (int.parse(item.editableqty) > int.parse(item.hQty.toString())) {
            validation = false;
            validationMassage = "Enter quantity should be between one to free available quantity for selected contract";
            break;
          } else {
            validation = true;
            item.sellmarket = item.editableqty;
            selectedList.add(item);
          }
        }
      }

      if (!validation) {
        GreekDialogPopupView.messageDialog(
          context,
          validationMassage,
        );
      }

      if (selectedList.isNotEmpty) {
        if (selectedList.length > 50) {
          GreekDialogPopupView.messageDialog(
            context,
            "Selection of more then 50 stock not allowed in single request",
          );
        } else {
          if (validation) {
            for (int j = 0; j < selectedList.length; j++) {
              if (double.parse(selectedList[j].lotSize ?? "0") > 1) {
                if (double.parse(sellMarketRequest[j].text) % double.parse(selectedList[j].lotSize ?? "0.00") != 0) {
                  var lotsize = selectedList[j].lotSize ?? "0.00";
                  var symbols = selectedList[j].symbol;
                  GreekDialogPopupView.messageDialog(context, "Entered Quantity is not in a multiple of Lot Size (" + lotsize + ") For " + symbols.toString());
                  return;
                }
              }
            }

            if (AppFlagConstant().dpType == "NSDL") {
              sendAuthorizationRequestNSDL(selectedList, context);
            } else {
              sendAuthorizationRequestCDSL(selectedList, context);
            }
          } else {
            GreekDialogPopupView.messageDialog(
              context,
              validationMassage,
            );
          }
        }
      } else {}
    }
  }

  Future<void> sendAuthorizationRequestNSDL(List<holdingdata.StockDetails> selecteddatalist, BuildContext context) async {
    List<sendauthstockdetails.StockDetails> stockdetailslist = [];
    for (var i = 0; i < selecteddatalist.length; i++) {
      sendauthstockdetails.StockDetails details = sendauthstockdetails.StockDetails();
      details.iSIN = selecteddatalist[i].isin;
      details.quantity = selecteddatalist[i].sellmarket;
      details.token = selecteddatalist[i].token;
      var freeqty = int.parse(selecteddatalist[i].openAuthQty ?? "0") + int.parse(selecteddatalist[i].todayAuthQty ?? "0");
      details.freeQty = int.parse(selecteddatalist[i].openAuthQty ?? "0") - freeqty;
      details.description = selecteddatalist[i].symbol;
      details.instrument = selecteddatalist[i].instrument;
      stockdetailslist.add(details);
    }

    if (EdisDashboardBloc.dPId.isNotEmpty) {
      _edisblock?.sendAuthorizationRequestNSDL(AppConfig().gscid, AppFlagConstant().dpType, NetworkManager().baseURL + "getEDISAuthorizationResponseMobile", EdisDashboardBloc.dPId, stockdetailslist);
    }
  }

  Future<void> sendAuthorizationRequestCDSL(List<holdingdata.StockDetails> selecteddatalist, BuildContext context) async {
    List<sendauthstockdetails.StockDetails> stockdetailslist = [];
    for (var i = 0; i < selecteddatalist.length; i++) {
      sendauthstockdetails.StockDetails details = sendauthstockdetails.StockDetails();
      details.iSIN = selecteddatalist[i].isin;
      details.quantity = selecteddatalist[i].sellmarket;
      details.token = selecteddatalist[i].token;
      var freeqty = int.parse(selecteddatalist[i].openAuthQty ?? "0") + int.parse(selecteddatalist[i].todayAuthQty ?? "0");
      details.freeQty = int.parse(selecteddatalist[i].hQty ?? "0") - freeqty;
      details.description = selecteddatalist[i].symbol;
      details.instrument = selecteddatalist[i].instrument;
      stockdetailslist.add(details);
    }

    if (EdisDashboardBloc.dPId.isNotEmpty) {
      _edisblock?.sendAuthorizationRequestCDSL(AppConfig().gscid, AppFlagConstant().dpType, NetworkManager().baseURL + "getEDISAuthorizationResponseMobile", EdisDashboardBloc.dPId, stockdetailslist);
    }
  }
}

Color getColor(number) {
  if (number > 0) {
    return ConstantColors.buyColor;
  } else {
    return ConstantColors.sellColor;
  }
}
