import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Edis/bloc/edis_margin_pledge_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/required_function.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/edis_holding_info_response.dart' as pledgeholdinginfo;
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Request/margin_epledge_request_model.dart' as epledgerequeststockdetails;
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Request/margin_ePledge_model_nsdl_request.dart' as epledgerequeststockdetailsnsdl;
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class MarginPledgeScreen extends StatefulWidget {
  const MarginPledgeScreen({Key? key}) : super(key: key);
  @override
  State<MarginPledgeScreen> createState() => _MarginPledgeScreenState();
}

class _MarginPledgeScreenState extends State<MarginPledgeScreen> {
  var formattedDate = '';
  EdisMarginPledgeBloc? _marginPledgeBloc;
  List<TextEditingController> pledgeMarginRequest = [];
  List<pledgeholdinginfo.StockDetails> selectedList = [];

  @override
  void initState() {
    formattedDate = RequiredFunction().dateFormater('dd-MMM-yyyy');
    selectedList = [];
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    pledgeMarginRequest.clear();
  }

  @override
  Widget build(BuildContext context) {
    _marginPledgeBloc ??= EdisMarginPledgeBloc(context: context);

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            onPressed: () {
              GreekBase().drawerKey.currentState?.openDrawer();
            },
            icon: const Icon(Icons.menu_rounded),
            iconSize: 30.0,
            color: ConstantColors.black,
          ),
          title: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              ConstantMessages.EDIS_MARGIN_PLEDGE_HEADER_TXT,
              style: GreekTextStyle.headline2,
            ),
          ),
        ),
        body: Column(
          children: <Widget>[
            StreamBuilder<bool>(
              stream: _marginPledgeBloc?.edisMarginPledgeStream.stream,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  if (snapshot.hasData == true) {
                    pledgeMarginRequest = List.generate(
                      (_marginPledgeBloc?.pledgeHoldingList.length ?? 0),
                      (index) => TextEditingController(text: _marginPledgeBloc?.pledgeHoldingList[index].freeQtyPledge ?? '0'),
                    );
                    var length = _marginPledgeBloc?.pledgeHoldingList.length;
                    if (length! > 0) {
                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Column(children: <Widget>[
                          Container(
                            color: ConstantColors.edisheader,
                            margin: const EdgeInsets.only(top: 15, bottom: 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                //Scrip Name
                                Container(
                                  width: 150,
                                  height: 50,
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    '   Scrip Name',
                                    style: GreekTextStyle.placeOrderAppbarHeading1,
                                  ),
                                ),
                                //Isin
                                Container(
                                  width: 100,
                                  height: 50,
                                  alignment: Alignment.center,
                                  child: Text(
                                    'ISIN',
                                    style: GreekTextStyle.placeOrderAppbarHeading1,
                                  ),
                                ),
                                //Free Qty
                                Container(
                                  width: 100,
                                  height: 50,
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Free Qty',
                                    style: GreekTextStyle.placeOrderAppbarHeading1,
                                  ),
                                ),
                                //Checkbox and TextField
                                Container(
                                  width: 150,
                                  height: 50,
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    '',
                                    style: GreekTextStyle.placeOrderAppbarHeading1,
                                  ),
                                ),
                                //Rate
                                Container(
                                  width: 100,
                                  height: 50,
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Rate',
                                    style: GreekTextStyle.placeOrderAppbarHeading1,
                                  ),
                                ),
                                //Value
                                Container(
                                  width: 100,
                                  height: 50,
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Value',
                                    style: GreekTextStyle.placeOrderAppbarHeading1,
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: MediaQuery.of(context).size.height - 400,
                            width: 700,
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: _marginPledgeBloc?.pledgeHoldingList.length,
                              itemBuilder: (context, index) {
                                //Parse values from received response
                                var freeQty = int.parse(_marginPledgeBloc?.pledgeHoldingList[index].freeQtyPledge ?? '0');
                                var pledgeValue = double.parse(_marginPledgeBloc?.pledgeHoldingList[index].value ?? '0.0');
                                var pledgeRate = double.parse(_marginPledgeBloc?.pledgeHoldingList[index].rate ?? '0.0');
                                return Padding(
                                  padding: EdgeInsets.zero,
                                  child: Column(
                                    children: <Widget>[
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          //Scrip Name
                                          Container(
                                            width: 150,
                                            height: 50,
                                            alignment: Alignment.centerLeft,
                                            child: Padding(
                                              padding: const EdgeInsets.only(left: 8.0),
                                              child: Text(
                                                _marginPledgeBloc?.pledgeHoldingList[index].symbol ?? '0',
                                                style: const TextStyle(fontSize: 12.0),
                                              ),
                                            ),
                                          ),
                                          //ISIN
                                          Container(
                                            width: 100,
                                            height: 50,
                                            alignment: Alignment.center,
                                            child: Text(
                                              _marginPledgeBloc?.pledgeHoldingList[index].isin ?? '0',
                                              style: const TextStyle(fontSize: 12.0),
                                            ),
                                          ),
                                          //Free Qty
                                          Container(
                                            width: 100,
                                            height: 50,
                                            alignment: Alignment.center,
                                            child: Text(
                                              '$freeQty',
                                              style: const TextStyle(fontSize: 12.0),
                                            ),
                                          ),
                                          //check box widget
                                          Container(
                                            width: 50,
                                            height: 50,
                                            alignment: Alignment.centerLeft,
                                            child: Checkbox(
                                              value: _marginPledgeBloc?.pledgeHoldingList[index].isChecked,
                                              onChanged: (bool? newValue) {
                                                setState(() {
                                                  _marginPledgeBloc?.pledgeHoldingList[index].isChecked = newValue ?? false;
                                                });
                                              },
                                            ),
                                          ),
                                          // textField widget
                                          SizedBox(
                                            width: 100,
                                            height: 50,
                                            child: TextField(
                                              controller: pledgeMarginRequest[index],
                                              textAlign: TextAlign.center,
                                              style: GreekTextStyle.marketDepthTotal,
                                              keyboardType: TextInputType.number,
                                              onChanged: (data) {
                                                _marginPledgeBloc?.pledgeHoldingList[index].editableqty = data.toString();
                                              },
                                              enabled: _marginPledgeBloc?.pledgeHoldingList[index].isChecked,
                                            ),
                                          ),
                                          // Rate
                                          Container(
                                            width: 100,
                                            height: 50,
                                            alignment: Alignment.center,
                                            child: Text(
                                              '$pledgeRate',
                                              style: const TextStyle(fontSize: 12.0),
                                            ),
                                          ),
                                          // Value
                                          Container(
                                            width: 100,
                                            height: 50,
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              '$pledgeValue  ',
                                              style: const TextStyle(fontSize: 12.0),
                                            ),
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ]),
                      );
                    }
                  }
                }
                return Container();
              },
            ),
            Expanded(
              child: Container(
                alignment: Alignment.bottomCenter,
                margin: const EdgeInsets.only(left: 15.0, right: 15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      //Pre Trade checkbox and Text
                      children: [
                        Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: Checkbox(
                            value: false,
                            onChanged: (bool? newValue) {},
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          child: Text(
                            "Pre Trade",
                            style: GreekTextStyle.order_description_ltp_textstyle,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      height: 40,
                      width: 150,
                      child: TextButton(
                        onPressed: () => proceedButton(context),
                        child: Text(
                          'Proceed',
                          style: GreekTextStyle.edisprocced,
                        ),
                      ),
                      decoration: BoxDecoration(
                        color: ConstantColors.primaryColor,
                        borderRadius: BorderRadius.circular(8.0),
                        border: Border.all(
                          color: ConstantColors.primaryColorLight,
                          width: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  //Proceed Button Click Action
  proceedButton(BuildContext context) {
    FocusScope.of(context).unfocus();
    selectedList = [];
    var validation = true;
    var validationMessage = '';
    if (_marginPledgeBloc?.pledgeHoldingList.isNotEmpty ?? false) {
      final filterList = _marginPledgeBloc?.pledgeHoldingList.where((element) => element.isChecked);
      if (filterList?.isNotEmpty ?? false) {
        for (var item in filterList!) {
          if (item.editableqty.isEmpty) {
            validation = false;
            validationMessage = "Entered quantity should be between one to free available quantity for selected product.";
            break;
          } else if (int.parse(item.editableqty) <= 0) {
            validation = false;
            validationMessage = "Entered quantity should be between one to free available quantity for selected product.";
            break;
          } else if (int.parse(item.editableqty) > int.parse(item.freeQtyPledge.toString())) {
            validation = false;
            validationMessage = "Entered quantity should be between one to free available quantity for selected product.";
            break;
          } else {
            validation = true;
            item.sellmarket = item.editableqty;
            selectedList.add(item);
          }
        }
      }

      if (!validation) {
        GreekDialogPopupView.messageDialog(context, validationMessage);
      }

      if (selectedList.isNotEmpty) {
        if (selectedList.length > 50) {
          GreekDialogPopupView.messageDialog(context, 'Selection of more then 50 stock not allowed in single request');
        } else {
          if (validation) {
            for (int j = 0; j < selectedList.length; j++) {
              if (double.parse(selectedList[j].lotSize ?? "0") > 1) {
                if (double.parse(pledgeMarginRequest[j].text) % double.parse(selectedList[j].lotSize ?? "0.00") != 0) {
                  var lotsize = selectedList[j].lotSize ?? "0.00";
                  var symbols = selectedList[j].symbol;
                  GreekDialogPopupView.messageDialog(context, "Entered Quantity is not in a multiple of Lot Size (" + lotsize + ") For " + symbols.toString());
                  return;
                }
              }
            }

            if (AppFlagConstant().dpType == "NSDL") {
              //NSDL
              sendPledgeNSDLRequestAPICall(selectedList, context);
            } else {
              //CDSL
              sendEPledgeRequestAPICall(selectedList, context);
            }
          } else {
            GreekDialogPopupView.messageDialog(context, validationMessage);
          }
        }
      } else {
        if (validation) {
          GreekDialogPopupView.messageDialog(context, "Please select stock to proceed");
        } else {
          GreekDialogPopupView.messageDialog(context, validationMessage);
        }
      }
    }
  }

  // ignore: slash_for_doc_comments
  /**
   *From here we send request for Pledge of stock to NSDL sendPledgeNSDLRequestAPICall
   */
  Future<void> sendPledgeNSDLRequestAPICall(List<pledgeholdinginfo.StockDetails> selectedDataList, BuildContext context) async {
    List<epledgerequeststockdetailsnsdl.StockDetails> stockdetailslist = [];
    for (var i = 0; i < selectedDataList.length; i++) {
      epledgerequeststockdetailsnsdl.StockDetails details = epledgerequeststockdetailsnsdl.StockDetails();
      details.iSIN = selectedDataList[i].isin;
      details.quantity = selectedDataList[i].sellmarket;
      details.token = selectedDataList[i].token;
      details.freeQty = selectedDataList[i].freeQtyPledge;
      details.instrument = selectedDataList[i].instrument;
      details.description = selectedDataList[i].symbol;
      details.lockInReasonCode = "";
      details.lockInReleaseDate = "";
      stockdetailslist.add(details);
    }

    _marginPledgeBloc?.sendEPledgeRequestApiCallNSDL(AppConfig().gscid, NetworkManager().baseURL + "pledge_NSDL", stockdetailslist);
  }

  /**
   * 
   */
  ///CDSL Request For 'sendEPledgeRequest'
  Future<void> sendEPledgeRequestAPICall(List<pledgeholdinginfo.StockDetails> selectedDataList, BuildContext context) async {
    List<epledgerequeststockdetails.StockDetails> stockdetailslist = [];
    for (var i = 0; i < selectedDataList.length; i++) {
      epledgerequeststockdetails.StockDetails details = epledgerequeststockdetails.StockDetails();
      details.isin = selectedDataList[i].isin;
      details.pledgeQty = selectedDataList[i].sellmarket;
      details.token = selectedDataList[i].token;
      details.freeQty = selectedDataList[i].freeQtyPledge.toString();
      details.description = selectedDataList[i].symbol;
      details.instrument = selectedDataList[i].instrument;
      details.pledgeRate = selectedDataList[i].rate;
      details.pledgeVal = selectedDataList[i].value;
      stockdetailslist.add(details);
    }

    _marginPledgeBloc?.sendEPledgeRequestAPICallCDSL(AppConfig().gscid, AppFlagConstant().dpType, NetworkManager().baseURL + "sendEPledgeRequest", _marginPledgeBloc!.dpId, stockdetailslist);
  }
}
