import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_nsdl_response_model.dart';

import 'package:webview_flutter/webview_flutter.dart';

class MarginWebViewNSDL extends StatefulWidget {
  const MarginWebViewNSDL({Key? key}) : super(key: key);

  @override
  State<MarginWebViewNSDL> createState() => _MarginWebViewNSDLState();
}

class _MarginWebViewNSDLState extends State<MarginWebViewNSDL> {
  SendAuthorizationRequestNSDLResponse? arg;

  @override
  void initState() {
    //Enable Virtual Display
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final argument = ModalRoute.of(context)?.settings.arguments;
    if (argument is SendAuthorizationRequestNSDLResponse) {
      arg = argument;
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Margin Pledge"),
        elevation: 1,
      ),
      body: WebView(
        initialUrl: Uri.dataFromString(
                "<html><head></head><body onload='document.MPIRqst.submit()'><form name='MPIRqst' method = 'post' action='" +
                    arg!.url.toString() +
                    "'><input type='hidden' name= 'transactionType' value= '" +
                    arg!.transactionType.toString() +
                    "'/><input type='hidden' name= 'requestor' value= '" +
                    arg!.requestor.toString() +
                    "'/><input type='hidden' name= 'requestorId' value= '" +
                    arg!.requestorId.toString() +
                    "'/><input type='hidden' name= 'requestReference' value= '" +
                    arg!.requestReference.toString() +
                    "'/><input type='hidden' name= 'channel' value= '" +
                    arg!.channel.toString() +
                    "'/><input type='hidden' name= 'requestTime' value= '" +
                    arg!.requestTime.toString() +
                    "'/><input type='hidden' name= 'orderReqDtls' value= '" +
                    arg!.orderReqDtls.toString() +
                    "'/><input type='hidden' name= 'digitalSignature' value= '" +
                    arg!.signature.toString() +
                    "'/></form></body></html>",
                mimeType: 'text/html')
            .toString(),
        onWebViewCreated: (controller) {},
        javascriptMode: JavascriptMode.unrestricted,
        gestureNavigationEnabled: true,
        onPageFinished: (url) {},
      ),
    );
  }
}
