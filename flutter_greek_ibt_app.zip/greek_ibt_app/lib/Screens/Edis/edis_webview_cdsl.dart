import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Edis/bloc/edis_dashboard_bloc.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_cdsl_response_model.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/getedis_authorization_responsemobile_cdsl.dart';
import 'package:xml2json/xml2json.dart';

class EdisWebviewCDSL extends StatefulWidget {
  const EdisWebviewCDSL({
    Key? key,
  }) : super(key: key);
  @override
  EdisWebviewState createState() => EdisWebviewState();
}

class EdisWebviewState extends State<EdisWebviewCDSL> {
  SendAuthorizationRequestCDSLResponse? arg;
  var _controller;
  @override
  void initState() {
    super.initState();

    // Enable virtual display.
  }

  @override
  Widget build(BuildContext context) {
    final argument = ModalRoute.of(context)?.settings.arguments;
    if (argument is SendAuthorizationRequestCDSLResponse) {
      arg = argument;
    }
    var html =
        "<html><head></head><body onload='document.frmDIS.submit()'><form name='frmDIS' method = 'post' action= '" +
            arg!.url.toString() +
            "'><input type='hidden' name= 'DPId' value= '" +
            arg!.dPId.toString() +
            "'/><input type='hidden' name= 'ReqId' value= '" +
            arg!.reqId.toString() +
            "'/><input type='hidden' name= 'Version' value= '" +
            arg!.version.toString() +
            "'/><input type='hidden' name= 'TransDtls' value= '" +
            arg!.response.toString() +
            "'/></form></body></html>";

    return Scaffold(
      appBar: AppBar(
        title: const Text("E-DIS Dashboard"),
        elevation: 1,
      ),
      body: Container(
        child: WebView(
          initialUrl:
              Uri.dataFromString(html, mimeType: 'text/html').toString(),
          onWebViewCreated: (controller) {
            _controller = controller;
          },
          javascriptMode: JavascriptMode.unrestricted,
          gestureNavigationEnabled: true,
          onPageFinished: (url) {
            // if (url.contains("https://mockedis.cdslindia.com/EDIS/VerifyDIS")) {
            //   readResponse(context);
            // }
            if (url.contains("getEDISAuthorizationResponseMobile")) {
              readResponse(context);
            }
            log("URL :- " + url.toString());
          },
          onWebResourceError: (error) {
            log("URL :- " + error.toString());
          },
        ),
      ),
    );
  }

  void readResponse(BuildContext context) async {
    _controller
        .evaluateJavascript(
            "document.getElementsByTagName('body')[0].innerHTML")
        .then((value) async {
      if (Platform.isAndroid) {
        var data = value.toString().substring(1);
        var newdata = data.substring(0, data.length - 1);
        var n = newdata.replaceAll(
            "\\u003Cpre style=\\\"word-wrap: break-word; white-space: pre-wrap;\\\">",
            "");
        var p = n.replaceAll("\\u003C/pre>", "");
        var temp = p.replaceAll(
            'pre style="word-wrap: break-word; white-space: pre-wrap;">', '');
        var parsedString = temp.replaceAll('</pre', '');
        String jsonString = parsedString.replaceAll('\\', '');

        handleParsedDataToNavigate(
            jsonData: jsonDecode(jsonString), context: context);
      } else if (Platform.isIOS) {
        final Xml2Json xml2Json = Xml2Json();
        String jsonString = '';

        xml2Json.parse(value);
        jsonString = xml2Json.toParker();

        final jsonData = jsonDecode(jsonString);

        var string = jsonData.toString();
        var truncateString =
            (string.replaceAll('{pre:', '')).replaceAll(' ', '');
        int length = truncateString.length;
        Map<String, dynamic> finalJsonData =
            jsonDecode(truncateString.replaceRange(length - 1, length, ''));
        handleParsedDataToNavigate(jsonData: finalJsonData, context: context);
      }
    });
  }
}

void handleParsedDataToNavigate(
    {required Map<String, dynamic> jsonData, required BuildContext context}) {
  if (jsonData.isNotEmpty) {
    EDISAuthorizationResponsemobileCDSL obj =
        EDISAuthorizationResponsemobileCDSL.fromJson(jsonData);
    EdisDashboardBloc.edisAuthorizationResponsemobileCDSL = obj;
    GreekNavigator.pop(context: context, popArguments: obj);
  }
}
