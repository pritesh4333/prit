import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Response/epledge_auth_nsdl_response_model.dart';
import 'package:greek_ibt_app/Screens/Edis/repository/edis_margin_pledge_repository.dart';
import 'package:greek_ibt_app/Screens/Edis/repository/edis_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/subjects.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/edis_holding_info_response.dart'
    as pledgeholdinginfo;
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Request/margin_epledge_request_model.dart'
    as sendauthstockdetails;
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Request/margin_ePledge_model_nsdl_request.dart'
    as epledgerequeststockdetailsnsdl;
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Response/epledge_auth_nsdl_response_model.dart'
    as epledgeauthnsdlstockdetails;

class EdisMarginPledgeBloc {
  BehaviorSubject<bool> edisMarginPledgeStream =
      BehaviorSubject<bool>.seeded(false);
  List<pledgeholdinginfo.StockDetails> pledgeHoldingList =
      <pledgeholdinginfo.StockDetails>[];
  List<epledgeauthnsdlstockdetails.StockDetails> pledgeAuthNSDLList =
      <epledgeauthnsdlstockdetails.StockDetails>[];

  MarginPledgeRepository marginPledgeRepository = MarginPledgeRepository();
  var edisRepo = EDISRepository();
  String dpId = "";
  final BuildContext context;
  final marginPledgeNSDLAuthorizeStream = BehaviorSubject.seeded(true);
  dynamic globalArgument;

  EdisMarginPledgeBloc({required this.context}) {
    _callgetClientPOAStatus(AppConfig().gscid);
    SocketIOManager().getEPledgeHoldingInfo();

    SocketIOManager().orderResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();
          for (var item in keys) {
            if (item.irisResponseStreamingType ==
                IrisResponseStreamingType.EPledgeHoldingResponse) {
              final responsedic = event[item];
              if (responsedic is Map<String, dynamic>) {
                var modelObj =
                    pledgeholdinginfo.EDISHoldingInfoResponse.fromJson(
                        responsedic);
                if (((modelObj.islast ?? -1) == 1) ||
                    ((modelObj.noofrecords ?? -1) ==
                        modelObj.stockDetails!.length)) {
                  pledgeHoldingList = modelObj.stockDetails!;
                } else {
                  pledgeHoldingList.addAll(modelObj.stockDetails!);
                }
              }
              edisMarginPledgeStream.sink.add(true);
            }

            // if (globalArgument == null) {
            //   GreekDialogPopupView.showMarginPledgeNSDLStatusPopup(context).then(
            //     (value) {
            //       if (value) {
            //         print('Success');
            //       }
            //       SocketIOManager().getEPledgeHoldingInfo();
            //     },
            //   );
            // }

            ///This Listener for 'UpdateNSDLPledgeAuthorizationResponse'.
            if (item.irisResponseStreamingType ==
                IrisResponseStreamingType
                    .UpdateNSDLPledgeAuthorizationResponse) {
              String jsonString = """ 
              {
  "response": {
    "svcName": "pledge_NSDL",
    "svcGroup": "portfolio",
    "data": {
      "Segment": "00",
      "gscid": "0H003",
      "stockDetails": [
        {
          "ISIN": "INE467B01029",
          "lockInReasonCode": "",
          "token": "101011536",
          "Quantity": "10",
          "FreeQty": "980",
          "description": "TATA CONSULTANCY SERV LT",
          "instrument": "EQ",
          "lockInReleaseDate": ""
        }
      ],
      "ExID": "01",
      "deviceId": "6789325E60AE",
      "channel": "WEB"
    },
    "svcVersion": "1.0.0",
    "requestType": "U",
    "FormFactor": "M"
  }
}
              """;
              //Send data to alert list view to show
              final jsonObj = json.decode(jsonString);
              final response = jsonObj["response"];
              final obj = EPledgeAuthNSDLResponse.fromJson(
                  response as Map<String, dynamic>);
              pledgeAuthNSDLList = obj.data?.stockDetails ?? [];
              marginPledgeNSDLAuthorizeStream.add(true);
              var irisReq = pledgeAuthNSDLList
                  .where((element) => element.status == 'Success')
                  .toList();
              if (irisReq.isNotEmpty) {
                var finalReqIris = irisReq.map(
                  (e) {
                    return {
                      "token": e.token.toString(),
                      "Qty": e.quantity.toString(),
                      "Isin": e.iSIN.toString(),
                      "Status": e.status.toString(),
                      "ReqType": e.reqType ?? '',
                      "ReqIdentifier": e.reqIdentifier ?? '',
                      "TxnId": e.txnId.toString(),
                    };
                  },
                ).toList();

                if (finalReqIris.isNotEmpty) {
                  //Need to send request to IRIS to update authorization status
                }
              }
            }
          }
        }
      },
    );
  }

  void _callgetClientPOAStatus(String gscid) {
    edisRepo.callGetClientPOAStatus(gscid: gscid).then((obj) {
      if (obj != null) {
        if (obj.dPId!.isNotEmpty) {
          dpId = obj.dPId.toString();
        }
      }
    });
  }

  sendEPledgeRequestAPICallCDSL(
      String gscid,
      String dPType,
      String url,
      String dpId,
      List<sendauthstockdetails.StockDetails> stockdetailslist) async {
    marginPledgeRepository
        .sendEPledgeRequestAPICallCDSL(
            gscid, dPType, url, dpId, stockdetailslist)
        .then(
      (obj) async {
        if (obj != null) {
          if (obj.message!.isNotEmpty) {
            GreekDialogPopupView.messageDialogCDSLPledge(
                context, obj.message ?? '');
          }
        }
      },
    );
  }

  ///Send Pledge NSDL Request
  sendEPledgeRequestApiCallNSDL(String gscid, String url,
      List<epledgerequeststockdetailsnsdl.StockDetails> stockdetailslist) {
    marginPledgeRepository
        .sendEPledgeRequestAPICallNSDL(gscid, url, stockdetailslist)
        .then(
      (obj) async {
        if (obj != null) {
          if (obj.signature!.isNotEmpty) {
            final argument = await GreekNavigator.pushNamed(
              context: context,
              routeName: GreekScreenNames.edis_marginwebviewnsdl,
              arguments: obj,
            );
            globalArgument = argument;

            // if (argument != null) {
            //   GreekDialogPopupView.edisTransactionStatusDialog(context: context, obj: argument).then(
            //     (value) {
            //       if (value) {
            //         // _doneBtnPressed(argument);
            //       }

            //     },
            //   );
            // }
          }
          // SocketIOManager().getEPledgeHoldingInfo();
          // GreekDialogPopupView.showMarginPledgeNSDLStatusPopup(context);
        }
      },
    );
  }
}
