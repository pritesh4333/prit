import 'dart:developer';

import 'package:flutter/widgets.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/edis_holding_info_response.dart' as edisholding;
import 'package:greek_ibt_app/Screens/Edis/Model/getedis_authorization_responsemobile_cdsl.dart';
import 'package:greek_ibt_app/Screens/Edis/repository/edis_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_model.dart' as sendauthstockdetails;

import '../Model/getEdisTransactionDetailResponse.dart';

class EdisDashboardBloc {
  static EDISAuthorizationResponsemobileCDSL edisAuthorizationResponsemobileCDSL = EDISAuthorizationResponsemobileCDSL();

  BehaviorSubject<bool> edisholdinginfotream = BehaviorSubject<bool>.seeded(false);
  BehaviorSubject<List<GetEdisTransactionDetailResponse>> edistransactionDetailsStream = BehaviorSubject();
  List<GetEdisTransactionDetailResponse> edisholdingDetailslist = <GetEdisTransactionDetailResponse>[];

  List<edisholding.StockDetails> edisholdinglist = <edisholding.StockDetails>[];
  EDISRepository edisRepo = EDISRepository();
  static String dPId = "";
  bool defaultPOA = false;
  final BuildContext context;
  EdisDashboardBloc({required this.context}) {
    callgetClientPOAStatus(AppConfig().gscid);
    SocketIOManager().getEDISHoldingInfo();

    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType == IrisResponseStreamingType.EDISHoldingInfoResponse) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              var modelObj = edisholding.EDISHoldingInfoResponse.fromJson(responseDic);
              if (modelObj.islast == 1 || (modelObj.stockDetails?.length == modelObj.noofrecords && modelObj.islast == 2)) {
                edisholdinglist = modelObj.stockDetails!;
              } else {
                edisholdinglist.addAll(modelObj.stockDetails!);
              }
            }
            edisholdinginfotream.sink.add(true);
          }
        }
      }
    });
    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType == IrisResponseStreamingType.UpdateNSDLAuthorizationResponse) {
            final responseDic = event[item];
            log("UpdateNSDLAuthorizationResponse" + responseDic);
            //if (responseDic is Map<String, dynamic>) {

            // var modelObj = EDISHoldingInfoResponse.fromJson(responseDic);

            // if (modelObj.islast == 1 || modelObj.stockDetails!.length == modelObj.noofrecords) {
            //   if (modelObj.noofrecords!.isNotEmpty) {
            //     //edisholdinginfotream = BehaviorSubject<EDISHoldingInfoResponse>();
            //     edisholdinginfotream.sink.add(modelObj);
            //   } else {
            //     edisholdinginfotream.sink.add(modelObj);
            //   }
            // } else {
            //   edisholdinginfotream.sink.add(modelObj);
            // }
            //  }
          }
        }
      }
    });
  }

  void callgetClientPOAStatus(String gscid) {
    edisRepo.callGetClientPOAStatus(gscid: gscid).then((obj) {
      defaultPOA = false;
      if (obj != null) {
        if (obj.dPId!.isNotEmpty) {
          dPId = obj.dPId.toString();
        }

        if (obj.defaultPOA == "YES") {
          defaultPOA = true;
        }
      }
    });
  }

  void getEdisDashboardTransactionDetails(String gscid, String startDate, String endDate) {
    edisRepo.getEdisTransactionDetail(gscid: gscid, startDate: startDate, endDate: endDate).then((obj) {
      edisholdingDetailslist = obj!;
      edistransactionDetailsStream.sink.add(obj);
    });
  }

  void sendAuthorizationRequestNSDL(String gscid, String dPType, String url, String dpId, List<sendauthstockdetails.StockDetails> stockdetailslist) async {
    edisRepo.sendAuthorizationRequestForNSDL(gscid, dPType, url, dpId, stockdetailslist).then(
      (obj) async {
        if (obj != null) {
          if (obj.signature!.isNotEmpty) {
            final argument = await GreekNavigator.pushNamed(
              context: context,
              routeName: GreekScreenNames.edis_webviewnsdl,
              arguments: obj,
            );
            if (argument != null) {
              GreekDialogPopupView.edisTransactionStatusDialog(
                context: context,
                obj: edisAuthorizationResponsemobileCDSL,
              ).then(
                (value) {
                  if (value) {
                    _doneBtnPressed();
                  }
                  SocketIOManager().getEDISHoldingInfo();
                },
              );
            }
          }
        }
      },
    );
  }

  void sendAuthorizationRequestCDSL(String gscid, String dPType, String url, String dpId, List<sendauthstockdetails.StockDetails> stockdetailslist) async {
    edisRepo.sendAuthorizationRequestForCDSL(gscid, dPType, url, dpId, stockdetailslist).then(
      (obj) async {
        if (obj != null) {
          if (obj.response!.isNotEmpty) {
            final argument = await GreekNavigator.pushNamed(
              context: context,
              routeName: GreekScreenNames.edis_webviewcdsl,
              arguments: obj,
            );
            if (argument != null) {
              GreekDialogPopupView.edisTransactionStatusDialog(
                context: context,
                obj: edisAuthorizationResponsemobileCDSL,
              ).then(
                (value) {
                  if (value) {
                    _doneBtnPressed();
                  }
                  // SocketIOManager().getEDISHoldingInfo();
                },
              );
            }
          }
        }
      },
    );
  }

  void _doneBtnPressed() async {
    // var obj = edisAuthorizationResponsemobileCDSL;
    // var stckdetails = obj.response!.data!.stockDetails;
    // List<authsmbols>? symbolelist = [];
    // for (var i = 0; i < stckdetails!.length; i++) {
    //   if (stckdetails[i].status == "Success") {
    //     authsmbols? symbols = authsmbols();
    //     symbols.token = stckdetails[i].token.toString();
    //     symbols.qty = stckdetails[i].quantity.toString();
    //     symbols.isin = stckdetails[i].iSIN;
    //     symbols.status = stckdetails[i].status;
    //     symbols.reqType = stckdetails[i].reqType;
    //     symbols.reqIdentifier = stckdetails[i].reqIdentifier;
    //     symbols.txnId = stckdetails[i].txnId;
    //     symbolelist.add(symbols);
    //   }
    // }

    // final object = {"symbols": symbolelist};

    // SocketIOManager().updateAuthorizationStatus(object);
    SocketIOManager().getEDISHoldingInfo();
  }
}
