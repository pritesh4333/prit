import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_cdsl_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Request/margin_epledge_request_model.dart'
    as sendauthstockdetails;
import 'package:greek_ibt_app/Screens/Edis/Model/marginModels/Request/margin_ePledge_model_nsdl_request.dart'
    as epledgerequeststockdetailsnsdl;
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_nsdl_response_model.dart';

class MarginPledgeRepository {
  Future<SendAuthorizationRequestCDSLResponse?> sendEPledgeRequestAPICallCDSL(
      String gscid,
      String dPType,
      String url,
      String dpId,
      List<sendauthstockdetails.StockDetails> stockdetailslist) async {
    final response = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.sendEPledgeRequest,
        postBody: {
          "gscid": gscid,
          "deviceId": AppConfig().deviceID,
          "BOId": dpId,
          "reqType": "NORMAL",
          "stockDetails": stockdetailslist,
        });

    if (response is Map) {
      if (response.isNotEmpty) {
        final obj = SendAuthorizationRequestCDSLResponse.fromJson(
            response as Map<String, dynamic>);
        return obj;
      }
    }
    return null;
  }

  Future<SendAuthorizationRequestNSDLResponse?> sendEPledgeRequestAPICallNSDL(
      String gscid,
      String url,
      List<epledgerequeststockdetailsnsdl.StockDetails>
          stockdetailslist) async {
    final response = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.pledge_NSDL,
        postBody: {
          "gscid": gscid,
          "ExID": "01", // Need to make dynamic
          "deviceId": AppConfig().deviceID,
          "channel": "WEB",
          "Segment": "00", //Need to make dynamic
          "stockDetails": stockdetailslist,
        });

    if (response is Map) {
      if (response.isNotEmpty) {
        final obj = SendAuthorizationRequestNSDLResponse.fromJson(
            response as Map<String, dynamic>);
        return obj;
      }
    }
    return null;
  }
}
