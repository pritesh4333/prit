import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_model.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_cdsl_response_model.dart';

import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/1_Splash%20Screen/models/client_poa_status_response_model.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_nsdl_response_model.dart';

import '../Model/getEdisTransactionDetailResponse.dart';

class EDISRepository {
  Future<ClientPOAStatusResponseModel?> callGetClientPOAStatus({required String gscid}) async {
    final requestQuery = "gscid=" + gscid.toString();
    final resp = await NetworkManager().getAPIEncrypted(apiName: APIName.getClientPOAStatus, query: requestQuery);

    if (resp is List) {
      final obj = resp.map((e) => ClientPOAStatusResponseModel.fromJson(e)).toList();
      return obj.first;
    } else if (resp is Map<String, dynamic>) {
      final obj = ClientPOAStatusResponseModel.fromJson(resp);
      return obj;
    }

    return null;
  }

  Future<List<GetEdisTransactionDetailResponse>?> getEdisTransactionDetail({required String gscid, required String startDate, required String endDate}) async {
    final requestQuery = "gscid=" + gscid.toString() + "&startDate=" + startDate.toString() + "&endDate=" + endDate.toString();
    final resp = await NetworkManager().getAPIEncrypted(apiName: APIName.getEDISTransactionDashboard, query: requestQuery);

    if (resp is List) {
      List<GetEdisTransactionDetailResponse> obj = resp.map((e) => GetEdisTransactionDetailResponse.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<SendAuthorizationRequestNSDLResponse?> sendAuthorizationRequestForNSDL(String gscid, String dPType, String url, String dpId, List<StockDetails> stockdetailslist) async {
    final response = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.sendAuthorizationRequest_NSDL,
        postBody: {
          "gscid": gscid,
          "DPType": dPType,
          "ReqType": "U",
          "ReqIdentifier": "S",
          "RU": url,
          "BOID": dpId,
          "ExID": "01",
          "deviceId": AppConfig().deviceID,
          "stockDetails": stockdetailslist,
          "channel": "MOB",
          "Segment": "00",
        });

    if (response is Map) {
      if (response.isNotEmpty) {
        final obj = SendAuthorizationRequestNSDLResponse.fromJson(response as Map<String, dynamic>);
        return obj;
      }
    }
    return null;
  }

  Future<SendAuthorizationRequestCDSLResponse?> sendAuthorizationRequestForCDSL(String gscid, String dPType, String url, String dpId, List<StockDetails> stockdetailslist) async {
    final response = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.sendAuthorizationRequest,
        postBody: {
          "gscid": gscid,
          "DPType": dPType,
          "ReqType": "D",
          "ReqIdentifier": "S",
          "RU": url,
          "BOID": dpId,
          "ExID": "12",
          "deviceId": AppConfig().deviceID,
          "stockDetails": stockdetailslist,
        });

    if (response is Map) {
      if (response.isNotEmpty) {
        final obj = SendAuthorizationRequestCDSLResponse.fromJson(response as Map<String, dynamic>);
        return obj;
      }
    }
    return null;
  }
}
