class UpdateNSDLAuthorizationResponseModel {
  Data? data;

  UpdateNSDLAuthorizationResponseModel({this.data});

  UpdateNSDLAuthorizationResponseModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? gscid;
  List<StockDetails>? stockDetails;

  Data({this.gscid, this.stockDetails});

  Data.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetails {
  String? iSIN;
  String? quantity;
  String? remark;
  String? status;
  String? symbol;
  String? txnId;
  String? token;

  StockDetails({this.iSIN, this.quantity, this.remark, this.status, this.symbol, this.txnId, this.token});

  StockDetails.fromJson(Map<String, dynamic> json) {
    iSIN = json['ISIN'];
    quantity = json['Quantity'];
    remark = json['Remark'];
    status = json['Status'];
    symbol = json['Symbol'];
    txnId = json['TxnId'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ISIN'] = iSIN;
    data['Quantity'] = quantity;
    data['Remark'] = remark;
    data['Status'] = status;
    data['Symbol'] = symbol;
    data['TxnId'] = txnId;
    data['token'] = token;
    return data;
  }
}
