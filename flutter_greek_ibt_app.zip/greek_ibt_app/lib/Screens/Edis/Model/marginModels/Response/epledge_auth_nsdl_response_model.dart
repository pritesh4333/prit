class EPledgeAuthNSDLResponseModel {
  EPledgeAuthNSDLResponse? response;

  EPledgeAuthNSDLResponseModel({this.response});

  EPledgeAuthNSDLResponseModel.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null ? EPledgeAuthNSDLResponse.fromJson(json['response']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (response != null) {
      data['response'] = response!.toJson();
    }
    return data;
  }
}

class EPledgeAuthNSDLResponse {
  String? appID;
  EPledgeAuthNSDLResponseData? data;
  String? infoID;
  String? serverTime;
  String? streamingType;
  String? svcName;

  EPledgeAuthNSDLResponse({this.appID, this.data, this.infoID, this.serverTime, this.streamingType, this.svcName});

  EPledgeAuthNSDLResponse.fromJson(Map<String, dynamic> json) {
    appID = json['appID'];
    data = json['data'] != null ? EPledgeAuthNSDLResponseData.fromJson(json['data']) : null;
    infoID = json['infoID'];
    serverTime = json['serverTime'];
    streamingType = json['streaming_type'];
    svcName = json['svcName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['appID'] = appID;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['infoID'] = infoID;
    data['serverTime'] = serverTime;
    data['streaming_type'] = streamingType;
    data['svcName'] = svcName;
    return data;
  }
}

class EPledgeAuthNSDLResponseData {
  String? gscid;
  List<StockDetails>? stockDetails;

  EPledgeAuthNSDLResponseData({this.gscid, this.stockDetails});

  EPledgeAuthNSDLResponseData.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetails {
  String? iSIN;
  String? quantity;
  String? remark;
  String? status;
  String? symbol;
  String? txnId;
  String? pledgeStatus;
  String? token;
  String? reqType;
  String? reqIdentifier;

  StockDetails({this.iSIN, this.quantity, this.remark, this.status, this.symbol, this.txnId, this.pledgeStatus, this.token});

  StockDetails.fromJson(Map<String, dynamic> json) {
    iSIN = json['ISIN'];
    quantity = json['Quantity'];
    remark = json['Remark'];
    status = json['Status'];
    symbol = json['Symbol'];
    txnId = json['TxnId'];
    pledgeStatus = json['pledgeStatus'];
    token = json['token'];
    reqType = json['ReqType'];
    reqIdentifier = json['ReqIdentifier'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ISIN'] = iSIN;
    data['Quantity'] = quantity;
    data['Remark'] = remark;
    data['Status'] = status;
    data['Symbol'] = symbol;
    data['TxnId'] = txnId;
    data['pledgeStatus'] = pledgeStatus;
    data['token'] = token;
    data['ReqType'] = reqType;
    data['ReqIdentifier'] = reqIdentifier;
    return data;
  }
}
