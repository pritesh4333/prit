class MarginEPledgeRequestModel {
  MarginEPledgeRequestData? data;

  MarginEPledgeRequestModel({this.data});

  MarginEPledgeRequestModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null
        ? MarginEPledgeRequestData.fromJson(json['data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class MarginEPledgeRequestData {
  String? gscid;
  String? deviceId;
  String? reqType;
  List<StockDetails>? stockDetails;
  String? bOId;

  MarginEPledgeRequestData(
      {this.gscid, this.deviceId, this.reqType, this.stockDetails, this.bOId});

  MarginEPledgeRequestData.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    deviceId = json['deviceId'];
    reqType = json['reqType'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
    bOId = json['BOId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    data['deviceId'] = deviceId;
    data['reqType'] = reqType;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    data['BOId'] = bOId;
    return data;
  }
}

class StockDetails {
  String? description;
  String? token;
  String? pledgeVal;
  String? freeQty;
  String? instrument;
  String? isin;
  String? pledgeRate;
  String? pledgeQty;

  StockDetails(
      {this.description,
      this.token,
      this.pledgeVal,
      this.freeQty,
      this.instrument,
      this.isin,
      this.pledgeRate,
      this.pledgeQty});

  StockDetails.fromJson(Map<String, dynamic> json) {
    description = json['description'];
    token = json['token'];
    pledgeVal = json['PledgeVal'];
    freeQty = json['FreeQty'];
    instrument = json['instrument'];
    isin = json['isin'];
    pledgeRate = json['PledgeRate'];
    pledgeQty = json['PledgeQty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['description'] = description;
    data['token'] = token;
    data['PledgeVal'] = pledgeVal;
    data['FreeQty'] = freeQty;
    data['instrument'] = instrument;
    data['isin'] = isin;
    data['PledgeRate'] = pledgeRate;
    data['PledgeQty'] = pledgeQty;
    return data;
  }
}
