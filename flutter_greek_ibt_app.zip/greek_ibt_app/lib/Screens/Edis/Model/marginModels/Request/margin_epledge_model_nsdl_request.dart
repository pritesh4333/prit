class MarginEPledgeRequestNsdlModel {
  MarginPledgeNSDLData? data;

  MarginEPledgeRequestNsdlModel({this.data});

  MarginEPledgeRequestNsdlModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? MarginPledgeNSDLData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class MarginPledgeNSDLData {
  String? segment;
  String? gscid;
  List<StockDetails>? stockDetails;
  String? exID;
  String? deviceId;
  String? channel;

  MarginPledgeNSDLData({this.segment, this.gscid, this.stockDetails, this.exID, this.deviceId, this.channel});

  MarginPledgeNSDLData.fromJson(Map<String, dynamic> json) {
    segment = json['Segment'];
    gscid = json['gscid'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
    exID = json['ExID'];
    deviceId = json['deviceId'];
    channel = json['channel'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Segment'] = segment;
    data['gscid'] = gscid;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    data['ExID'] = exID;
    data['deviceId'] = deviceId;
    data['channel'] = channel;
    return data;
  }
}

class StockDetails {
  String? iSIN;
  String? lockInReasonCode;
  String? token;
  String? quantity;
  String? freeQty;
  String? description;
  String? instrument;
  String? lockInReleaseDate;

  StockDetails({this.iSIN, this.lockInReasonCode, this.token, this.quantity, this.freeQty, this.description, this.instrument, this.lockInReleaseDate});

  StockDetails.fromJson(Map<String, dynamic> json) {
    iSIN = json['ISIN'];
    lockInReasonCode = json['lockInReasonCode'];
    token = json['token'];
    quantity = json['Quantity'];
    freeQty = json['FreeQty'];
    description = json['description'];
    instrument = json['instrument'];
    lockInReleaseDate = json['lockInReleaseDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ISIN'] = iSIN;
    data['lockInReasonCode'] = lockInReasonCode;
    data['token'] = token;
    data['Quantity'] = quantity;
    data['FreeQty'] = freeQty;
    data['description'] = description;
    data['instrument'] = instrument;
    data['lockInReleaseDate'] = lockInReleaseDate;
    return data;
  }
}
