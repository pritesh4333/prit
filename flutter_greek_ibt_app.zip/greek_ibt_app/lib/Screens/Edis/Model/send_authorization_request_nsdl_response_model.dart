class SendAuthorizationRequestNSDLResponse {
  String? signature;
  String? requestor;
  String? requestorId;
  int? requestReference;
  String? channel;
  String? orderReqDtls;
  String? requestTime;
  String? transactionType;
  String? url;
  String? signUrl;

  SendAuthorizationRequestNSDLResponse({
    this.signature,
    this.requestor,
    this.requestorId,
    this.requestReference,
    this.channel,
    this.orderReqDtls,
    this.requestTime,
    this.transactionType,
    this.url,
    this.signUrl,
  });

  SendAuthorizationRequestNSDLResponse.fromJson(Map<String, dynamic> json) {
    signature = json['signature'];
    requestor = json['requestor'];
    requestorId = json['requestorId'];
    requestReference = json['requestReference'];
    channel = json['channel'];
    orderReqDtls = json['orderReqDtls'];
    requestTime = json['requestTime'];
    transactionType = json['transactionType'];
    url = json['Url'];
    signUrl = json['signUrl'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['signature'] = signature;
    data['requestor'] = requestor;
    data['requestorId'] = requestorId;
    data['requestReference'] = requestReference;
    data['channel'] = channel;
    data['orderReqDtls'] = orderReqDtls;
    data['requestTime'] = requestTime;
    data['transactionType'] = transactionType;
    data['Url'] = url;
    data['signUrl'] = signUrl;
    return data;
  }
}
