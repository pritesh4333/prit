class EDISAuthorizationResponsemobileCDSL {
  Response? response;
  Config? config;

  EDISAuthorizationResponsemobileCDSL({Response? response, Config? config}) {
    if (response != null) {
      response = response;
    }
    if (config != null) {
      config = config;
    }
  }

  /*Response? get response => _response;
  set response(Response? response) => _response = response;
  Config? get config => _config;
  set config(Config? config) => _config = config;*/

  EDISAuthorizationResponsemobileCDSL.fromJson(Map<String, dynamic> json) {
    response =
        json['response'] != null ? Response.fromJson(json['response']) : null;
    config = json['config'] != null ? Config.fromJson(json['config']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (response != null) {
      data['response'] = response!.toJson();
    }
    if (config != null) {
      data['config'] = config!.toJson();
    }
    return data;
  }
}

class Response {
  String? svcName;
  String? serverTime;
  String? infoID;
  String? appID;
  String? svcVersion;
  String? msgID;
  String? svcGroup;
  int? errorCode;
  Data? data;

  Response(
      {String? svcName,
      String? serverTime,
      String? infoID,
      String? appID,
      String? svcVersion,
      String? msgID,
      String? svcGroup,
      int? errorCode,
      Data? data}) {
    if (svcName != null) {
      svcName = svcName;
    }
    if (serverTime != null) {
      serverTime = serverTime;
    }
    if (infoID != null) {
      infoID = infoID;
    }
    if (appID != null) {
      appID = appID;
    }
    if (svcVersion != null) {
      svcVersion = svcVersion;
    }
    if (msgID != null) {
      msgID = msgID;
    }
    if (svcGroup != null) {
      svcGroup = svcGroup;
    }
    if (errorCode != null) {
      errorCode = errorCode;
    }
    if (data != null) {
      data = data;
    }
  }

  Response.fromJson(Map<String, dynamic> json) {
    svcName = json['svcName'];
    serverTime = json['serverTime'];
    infoID = json['infoID'];
    appID = json['appID'];
    svcVersion = json['svcVersion'];
    msgID = json['msgID'];
    svcGroup = json['svcGroup'];
    errorCode = json['ErrorCode'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data['svcName'] = svcName;
    _data['serverTime'] = serverTime;
    _data['infoID'] = infoID;
    _data['appID'] = appID;
    _data['svcVersion'] = svcVersion;
    _data['msgID'] = msgID;
    _data['svcGroup'] = svcGroup;
    _data['ErrorCode'] = errorCode;
    _data['data'] = data?.toJson();

    return _data;
  }
}

class Data {
  String? reqId;
  String? status;
  List<StockDetails>? stockDetails;

  Data({String? reqId, String? status, List<StockDetails>? stockDetails}) {
    if (reqId != null) {
      reqId = reqId;
    }
    if (status != null) {
      status = status;
    }
    if (stockDetails != null) {
      stockDetails = stockDetails;
    }
  }

  Data.fromJson(Map<String, dynamic> json) {
    reqId = json['ReqId'];
    status = json['Status'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ReqId'] = reqId;
    data['Status'] = status;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetails {
  String? iSIN;
  String? symbol;
  int? quantity;
  int? token;
  String? status;
  String? reqType;
  String? reqIdentifier;
  String? txnId;

  StockDetails(
      {String? iSIN,
      String? symbol,
      int? quantity,
      int? token,
      String? status,
      String? reqType,
      String? reqIdentifier,
      String? txnId}) {
    if (iSIN != null) {
      iSIN = iSIN;
    }
    if (symbol != null) {
      symbol = symbol;
    }
    if (quantity != null) {
      quantity = quantity;
    }
    if (token != null) {
      token = token;
    }
    if (status != null) {
      status = status;
    }
    if (reqType != null) {
      reqType = reqType;
    }
    if (reqIdentifier != null) {
      reqIdentifier = reqIdentifier;
    }
    if (txnId != null) {
      txnId = txnId;
    }
  }

  StockDetails.fromJson(Map<String, dynamic> json) {
    iSIN = json['ISIN'];
    symbol = json['Symbol'];
    quantity = json['Quantity'];
    token = json['token'];
    status = json['Status'];
    reqType = json['ReqType'];
    reqIdentifier = json['ReqIdentifier'];
    txnId = json['TxnId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ISIN'] = iSIN;
    data['Symbol'] = symbol;
    data['Quantity'] = quantity;
    data['token'] = token;
    data['Status'] = status;
    data['ReqType'] = reqType;
    data['ReqIdentifier'] = reqIdentifier;
    data['TxnId'] = txnId;
    return data;
  }
}

class Config {
  int? _label;
  int? _message;
  int? _app;

  Config({int? label, int? message, int? app}) {
    if (label != null) {
      _label = label;
    }
    if (message != null) {
      _message = message;
    }
    if (app != null) {
      _app = app;
    }
  }

  Config.fromJson(Map<String, dynamic> json) {
    _label = json['label'];
    _message = json['message'];
    _app = json['app'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['label'] = _label;
    data['message'] = _message;
    data['app'] = _app;
    return data;
  }
}
