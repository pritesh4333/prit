class GetEdisTransactionDetailResponse {
  int? date;
  String? symbol;
  int? freeQty;
  int? authorizedQty;
  String? status;
  String? errorDesc;

  GetEdisTransactionDetailResponse({this.date, this.symbol, this.freeQty, this.authorizedQty, this.status, this.errorDesc});

  GetEdisTransactionDetailResponse.fromJson(Map<String, dynamic> json) {
    date = json['Date'];
    symbol = json['symbol'];
    freeQty = json['FreeQty'];
    authorizedQty = json['AuthorizedQty'];
    status = json['Status'];
    errorDesc = json['ErrorDesc'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Date'] = date;
    data['symbol'] = symbol;
    data['FreeQty'] = freeQty;
    data['AuthorizedQty'] = authorizedQty;
    data['Status'] = status;
    data['ErrorDesc'] = errorDesc;
    return data;
  }
}
