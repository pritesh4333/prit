class SendAuthorizationRequestCDSLResponse {
  String? response;
  String? dPId;
  int? reqId;
  String? version;
  String? url;
  String? message;

  SendAuthorizationRequestCDSLResponse({
    this.response,
    this.dPId,
    this.reqId,
    this.version,
    this.url,
    this.message,
  });

  SendAuthorizationRequestCDSLResponse.fromJson(Map<String, dynamic> json) {
    response = json['response'];
    dPId = json['DPId'];
    reqId = json['ReqId'];
    version = json['Version'];
    url = json['Url'];
    message = json['Message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['response'] = response;
    data['DPId'] = dPId;
    data['ReqId'] = reqId;
    data['Version'] = version;
    data['Url'] = url;
    data['Message'] = message;

    return data;
  }
}
