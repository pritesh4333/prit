class EdisAuthorizationResponse {
  String? noofrecords;
  String? islast;
  List<StockDetails>? stockDetails;

  EdisAuthorizationResponse({this.noofrecords, this.islast, this.stockDetails});

  EdisAuthorizationResponse.fromJson(Map<String, dynamic> json) {
    noofrecords = json['noofrecords'];
    islast = json['islast'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['noofrecords'] = noofrecords;
    data['islast'] = islast;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetails {
  String? token;
  String? hQty;
  String? openAuthQty;
  String? todayAuthQty;
  String? todaySoldQty;
  String? symbol;
  String? isin;
  String? instrument;
  String? close;
  String? lotSize;
  int freeqty = 0;
  int balanceqty = 0;
  String autAdittextQty = "";
  bool isChecked = false;

  StockDetails({this.token, this.hQty, this.openAuthQty, this.todayAuthQty, this.todaySoldQty, this.symbol, this.isin, this.instrument, this.close, this.lotSize});

  StockDetails.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    hQty = json['HQty'];
    openAuthQty = json['OpenAuthQty'];
    todayAuthQty = json['TodayAuthQty'];
    todaySoldQty = json['TodaySoldQty'];
    symbol = json['symbol'];
    isin = json['isin'];
    instrument = json['instrument'];
    close = json['close'];
    lotSize = json['lotSize'];

    balanceqty = (int.parse(openAuthQty ?? '') + int.parse(todayAuthQty ?? '')) - int.parse(todaySoldQty ?? '');

    freeqty = (int.parse(hQty ?? '') - (int.parse(openAuthQty ?? '') + int.parse(todayAuthQty ?? '')));

    autAdittextQty = freeqty.toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['token'] = token;
    data['HQty'] = hQty;
    data['OpenAuthQty'] = openAuthQty;
    data['TodayAuthQty'] = todayAuthQty;
    data['TodaySoldQty'] = todaySoldQty;
    data['symbol'] = symbol;
    data['isin'] = isin;
    data['instrument'] = instrument;
    data['close'] = close;
    data['lotSize'] = lotSize;
    return data;
  }
}
