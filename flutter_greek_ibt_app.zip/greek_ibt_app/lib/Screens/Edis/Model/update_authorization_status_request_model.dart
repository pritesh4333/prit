class UpdateAuthorizationStatusRequestModel {
  List<AuthSymbols>? authsymbols;

  UpdateAuthorizationStatusRequestModel({this.authsymbols});

  UpdateAuthorizationStatusRequestModel.fromJson(Map<String, dynamic> json) {
    if (json['symbols'] != null) {
      authsymbols = <AuthSymbols>[];
      json['symbols'].forEach((v) {
        authsymbols!.add(AuthSymbols.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (authsymbols != null) {
      data['symbols'] = authsymbols!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AuthSymbols {
  String? token;
  String? qty;
  String? isin;
  String? status;
  String? reqType;
  String? reqIdentifier;
  String? txnId;

  AuthSymbols({this.token, this.qty, this.isin, this.status, this.reqType, this.reqIdentifier, this.txnId});

  AuthSymbols.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    qty = json['Qty'];
    isin = json['Isin'];
    status = json['Status'];
    reqType = json['ReqType'];
    reqIdentifier = json['ReqIdentifier'];
    txnId = json['TxnId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['token'] = token;
    data['Qty'] = qty;
    data['Isin'] = isin;
    data['Status'] = status;
    data['ReqType'] = reqType;
    data['ReqIdentifier'] = reqIdentifier;
    data['TxnId'] = txnId;
    return data;
  }
}
