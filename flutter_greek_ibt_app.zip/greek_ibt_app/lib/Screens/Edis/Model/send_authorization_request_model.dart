class SendAuthorizationRequestModel {
  SendAuthorizationData? data;

  SendAuthorizationRequestModel({this.data});

  SendAuthorizationRequestModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null
        ? SendAuthorizationData.fromJson(json['data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class SendAuthorizationData {
  String? gscid;
  String? dPType;
  String? reqType;
  String? reqIdentifier;
  String? rU;
  String? bOID;
  String? exID;
  String? deviceId;
  List<StockDetails>? stockDetails;
  String? channel;
  String? segment;

  SendAuthorizationData(
      {this.gscid,
      this.dPType,
      this.reqType,
      this.reqIdentifier,
      this.rU,
      this.bOID,
      this.exID,
      this.deviceId,
      this.stockDetails,
      this.channel,
      this.segment});

  SendAuthorizationData.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    dPType = json['DPType'];
    reqType = json['ReqType'];
    reqIdentifier = json['ReqIdentifier'];
    rU = json['RU'];
    bOID = json['BOID'];
    exID = json['ExID'];
    deviceId = json['deviceId'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
    channel = json['channel'];
    segment = json['Segment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    data['DPType'] = dPType;
    data['ReqType'] = reqType;
    data['ReqIdentifier'] = reqIdentifier;
    data['RU'] = rU;
    data['BOID'] = bOID;
    data['ExID'] = exID;
    data['deviceId'] = deviceId;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    data['channel'] = channel;
    data['Segment'] = segment;
    return data;
  }
}

class StockDetails {
  String? iSIN;
  String? quantity;
  String? token;
  int? freeQty;
  String? description;
  String? instrument;

  StockDetails({
    this.iSIN,
    this.quantity,
    this.token,
    this.freeQty,
    this.description,
    this.instrument,
  });

  StockDetails.fromJson(Map<String, dynamic> json) {
    iSIN = json['ISIN'];
    quantity = json['Quantity'];
    token = json['token'];
    freeQty = json['FreeQty'];
    description = json['description'];
    instrument = json['instrument'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ISIN'] = iSIN;
    data['Quantity'] = quantity;
    data['token'] = token;
    data['FreeQty'] = freeQty;
    data['description'] = description;
    data['instrument'] = instrument;
    return data;
  }
}
