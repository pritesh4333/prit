class EDISHoldingInfoResponse {
  int? noofrecords;
  int? islast;
  List<StockDetails>? stockDetails;

  EDISHoldingInfoResponse({this.noofrecords, this.islast, this.stockDetails});

  EDISHoldingInfoResponse.fromJson(Map<String, dynamic> json) {
    noofrecords = int.parse(json['noofrecords']?.toString() ?? "-1");
    islast = int.parse(json['islast']?.toString() ?? "-1");
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['noofrecords'] = noofrecords;
    data['islast'] = islast;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetails {
  bool isChecked = false;
  String editableqty = "";
  String? token;
  String? hQty;
  String? openAuthQty;
  String? todayAuthQty;
  String? todaySoldQty;
  String? symbol;
  String? isin;
  String? instrument;
  String? close;
  String? lotSize;
  String? sellmarket;
  //Margin Pledge Fields
  String? freeQtyPledge;
  String? pledgedQty;
  String? rate;
  String? value;

  StockDetails({
    this.token,
    this.hQty,
    this.openAuthQty,
    this.todayAuthQty,
    this.todaySoldQty,
    this.symbol,
    this.isin,
    this.instrument,
    this.close,
    this.lotSize,
    this.sellmarket,
    this.freeQtyPledge,
    this.pledgedQty,
    this.rate,
    this.value,
  });

  StockDetails.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    hQty = json['HQty'];
    openAuthQty = json['OpenAuthQty'];
    todayAuthQty = json['TodayAuthQty'];
    todaySoldQty = json['TodaySoldQty'];
    symbol = json['symbol'];
    isin = json['isin'];
    instrument = json['instrument'];
    close = json['close'];
    lotSize = json['lotSize'];
    sellmarket = json['sellmarket'];
    freeQtyPledge = json['FreeQty'];
    pledgedQty = json['PledgedQty'];
    rate = json['Rate'];
    value = json['Value'];

    var openautmintodayauth = int.parse(openAuthQty ?? '0') + int.parse(todayAuthQty ?? '0');
    var freeqty = int.parse(hQty ?? '0') - openautmintodayauth;
    editableqty = freeqty.toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['token'] = token;
    data['HQty'] = hQty;
    data['OpenAuthQty'] = openAuthQty;
    data['TodayAuthQty'] = todayAuthQty;
    data['TodaySoldQty'] = todaySoldQty;
    data['symbol'] = symbol;
    data['isin'] = isin;
    data['instrument'] = instrument;
    data['close'] = close;
    data['lotSize'] = lotSize;
    data['sellmarket'] = sellmarket;
    data['FreeQty'] = freeQtyPledge;
    data['PledgedQty'] = pledgedQty;
    data['Rate'] = rate;
    data['Value'] = value;
    return data;
  }
}
