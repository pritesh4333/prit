import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/send_authorization_request_nsdl_response_model.dart';

import 'package:webview_flutter/webview_flutter.dart';

class EdisWebviewNSDL extends StatefulWidget {
  const EdisWebviewNSDL({
    Key? key,
  }) : super(key: key);
  @override
  EdisWebviewState createState() => EdisWebviewState();
}

class EdisWebviewState extends State<EdisWebviewNSDL> {
  SendAuthorizationRequestNSDLResponse? arg;
  var _controller;

  @override
  void initState() {
    super.initState();

    // Enable virtual display.
  }

  @override
  Widget build(BuildContext context) {
    final argument = ModalRoute.of(context)?.settings.arguments;
    if (argument is SendAuthorizationRequestNSDLResponse) {
      arg = argument;
    }
    log("NSDL HTML PAGE " +
        "<html><head></head><body onload='document.DISRqst.submit()'><form name='DISRqst' method = 'post' action='" +
        arg!.url.toString() +
        "'><input type='hidden' name= 'transactionType' value= '" +
        arg!.transactionType.toString() +
        "'/><input type='hidden' name= 'requestor' value= '" +
        arg!.requestor.toString() +
        "'/><input type='hidden' name= 'requestorId' value= '" +
        arg!.requestorId.toString() +
        "'/><input type='hidden' name= 'requestReference' value= '" +
        arg!.requestReference.toString() +
        "'/><input type='hidden' name= 'channel' value= '" +
        arg!.channel.toString() +
        "'/><input type='hidden' name= 'requestTime' value= '" +
        arg!.requestTime.toString() +
        "'/><input type='hidden' name= 'orderReqDtls' value= '" +
        arg!.orderReqDtls.toString() +
        "'/><input type='hidden' name= 'digitalSignature' value= '" +
        arg!.signature.toString() +
        "'/></form></body></html>");
    return Scaffold(
      appBar: AppBar(
        title: const Text("E-DIS Dashboard"),
        elevation: 1,
      ),
      body: Container(
          child: WebView(
        initialUrl: Uri.dataFromString(
                "<html><head></head><body onload='document.DISRqst.submit()'><form name='DISRqst' method = 'post' action='" +
                    arg!.url.toString() +
                    "'><input type='hidden' name= 'transactionType' value= '" +
                    arg!.transactionType.toString() +
                    "'/><input type='hidden' name= 'requestor' value= '" +
                    arg!.requestor.toString() +
                    "'/><input type='hidden' name= 'requestorId' value= '" +
                    arg!.requestorId.toString() +
                    "'/><input type='hidden' name= 'requestReference' value= '" +
                    arg!.requestReference.toString() +
                    "'/><input type='hidden' name= 'channel' value= '" +
                    arg!.channel.toString() +
                    "'/><input type='hidden' name= 'requestTime' value= '" +
                    arg!.requestTime.toString() +
                    "'/><input type='hidden' name= 'orderReqDtls' value= '" +
                    arg!.orderReqDtls.toString() +
                    "'/><input type='hidden' name= 'digitalSignature' value= '" +
                    arg!.signature.toString() +
                    "'/></form></body></html>",
                mimeType: 'text/html')
            .toString(),
        onWebViewCreated: (controller) {
          _controller = controller;
        },
        javascriptMode: JavascriptMode.unrestricted,
        gestureNavigationEnabled: true,
        onPageFinished: (url) {
          // if (url.contains("getEDISAuthorizationResponseMobile")) {
          //   readResponse(context);
          // }
          log("NSDL URL " + url);
        },
      )),
    );
  }
}
