class SymbolInstrumentData {
  String? symbol;

  SymbolInstrumentData({this.symbol});

  SymbolInstrumentData.fromJson(Map<String, dynamic> json) {
    symbol = json['symbol'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['symbol'] = symbol;
    return data;
  }
}
