// To parse this JSON data, do
//
//     final mostActiveRespModel = mostActiveRespModelFromJson(jsonString);

import 'dart:convert';

MostActiveRespModel mostActiveRespModelFromJson(String str) =>
    MostActiveRespModel.fromJson(json.decode(str));

String mostActiveRespModelToJson(MostActiveRespModel data) =>
    json.encode(data.toJson());

class MostActiveRespModel {
  MostActiveRespModel({
    this.exchange,
    this.assetType,
    this.optType,
    this.symbol,
    this.instName,
    this.strikePrice,
    this.expiryDate,
    this.volTraded,
    this.oi,
    this.ltp,
    this.perChange,
    this.cashInstName,
    this.token,
    this.lotSize,
    this.tickSize,
    this.multiplyFactor,
    this.change,
    this.description,
  });

  String? exchange;
  String? assetType;
  String? optType;
  String? symbol;
  String? instName;
  int? strikePrice;
  int? expiryDate;
  int? volTraded;
  String? oi;
  int? ltp;
  double? perChange;
  String? cashInstName;
  int? token;
  int? lotSize;
  double? tickSize;
  int? multiplyFactor;
  double? change;
  String? description;

  factory MostActiveRespModel.fromJson(Map<String, dynamic> json) =>
      MostActiveRespModel(
        exchange: json["exchange"],
        assetType: json["assetType"],
        optType: json["OptType"],
        symbol: json["symbol"],
        instName: json["InstName"],
        strikePrice: json["StrikePrice"],
        expiryDate: json["expiryDate"],
        volTraded: json["vol_traded"],
        oi: json["oi"],
        ltp: json["ltp"],
        perChange: json["perChange"].toDouble(),
        cashInstName: json["cashInstName"],
        token: json["token"],
        lotSize: json["lotSize"],
        tickSize: json["tickSize"].toDouble(),
        multiplyFactor: json["multiply_factor"],
        change: json["change"].toDouble(),
        description: json["description"],
      );

  Map<String, dynamic> toJson() => {
        "exchange": exchange,
        "assetType": assetType,
        "OptType": optType,
        "symbol": symbol,
        "InstName": instName,
        "StrikePrice": strikePrice,
        "expiryDate": expiryDate,
        "vol_traded": volTraded,
        "oi": oi,
        "ltp": ltp,
        "perChange": perChange,
        "cashInstName": cashInstName,
        "token": token,
        "lotSize": lotSize,
        "tickSize": tickSize,
        "multiply_factor": multiplyFactor,
        "change": change,
        "description": description,
      };
}
