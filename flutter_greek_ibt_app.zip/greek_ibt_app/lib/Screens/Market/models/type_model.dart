class TypeModel {
  String? index;
  String? stock;

  TypeModel({this.index, this.stock});

  TypeModel.fromJson(Map<String, dynamic> json) {
    index = json['Index'];
    stock = json['Stock'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Index'] = index;
    data['Stock'] = stock;
    return data;
  }
}
