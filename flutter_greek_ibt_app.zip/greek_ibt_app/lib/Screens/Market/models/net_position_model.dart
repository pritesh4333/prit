class NetPositionMTMModel {
  String? success;
  String? message;
  int? errorCode;
  List<Data>? data;

  NetPositionMTMModel({this.success, this.message, this.errorCode, this.data});

  NetPositionMTMModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    errorCode = json['ErrorCode'];
    if (json['data'] != null) {
      // data = new List<Data>();
      json['data'].forEach((v) {
        data?.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    data['ErrorCode'] = errorCode;
    if (this.data != null) {
      data['data'] = this.data?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  double? mTM;

  Data({this.mTM});

  Data.fromJson(Map<String, dynamic> json) {
    mTM = json['MTM'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['MTM'] = mTM;
    return data;
  }
}
