class AdvanceDeclineResponseModel {
  int? advances;
  int? declines;
  int? total;

  AdvanceDeclineResponseModel({this.advances, this.declines, this.total});

  AdvanceDeclineResponseModel.fromJson(Map<String, dynamic> json) {
    advances = int.parse(json['Advances'].toString());
    declines = int.parse(json['Declines'].toString());
    total = int.parse(json['Total'].toString());
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Advances'] = advances;
    data['Declines'] = declines;
    data['Total'] = total;
    return data;
  }
}
