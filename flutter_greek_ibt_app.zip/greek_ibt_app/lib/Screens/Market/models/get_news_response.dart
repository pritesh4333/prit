import 'dart:convert';

class GetNewsResponse {
  int? sno;
  String? sectionName;
  int? date;
  int? time;
  String? heading;
  String? caption;
  String? arttext;
  String? coCode;
  int? dateformat;

  GetNewsResponse({this.sno, this.sectionName, this.date, this.time, this.heading, this.caption, this.arttext, this.coCode, this.dateformat});

  GetNewsResponse.fromJson(Map<String, dynamic> json) {
    sno = json['Sno'];
    sectionName = json['Section_name'];
    date = json['Date'];
    time = json['Time'];
    heading = utf8.decode(
      base64.decode(json['Heading']?.toString() ?? ''),
    );
    caption = json['Caption'];
    arttext = utf8.decode(
      base64.decode(json['Arttext']?.toString() ?? ''),
    );
    coCode = json['co_code'];
    dateformat = json['dateformat'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Sno'] = sno;
    data['Section_name'] = sectionName;
    data['Date'] = date;
    data['Time'] = time;
    data['Heading'] = heading;
    data['Caption'] = caption;
    data['Arttext'] = arttext;
    data['co_code'] = coCode;
    data['dateformat'] = dateformat;
    return data;
  }
}
