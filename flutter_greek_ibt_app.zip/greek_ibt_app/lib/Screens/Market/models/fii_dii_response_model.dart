class FIIDIIResponseModelNew {
  String? reportingDate;
  String? investmentCategory;
  String? investmentRoute;
  double? netInvestementInr;
  String? derivativeProduct;
  double? buyAmmount;
  double? sellAmmount;
  double? netAmount;

  FIIDIIResponseModelNew({this.reportingDate, this.investmentCategory, this.investmentRoute, this.netInvestementInr, this.derivativeProduct, this.buyAmmount, this.sellAmmount});

  FIIDIIResponseModelNew.fromJson(Map<String, dynamic> json) {
    reportingDate = json['reportingDate'] ?? '';
    investmentCategory = json['investment_category'] ?? '';
    investmentRoute = json['investment_route'] ?? '';
    netInvestementInr = double.parse(json['net_investement_inr']?.toString() ?? '0.0');
    derivativeProduct = json['derivative_product'] ?? '';
    buyAmmount = double.parse(json['buy_ammount']?.toString() ?? '0.0');
    sellAmmount = double.parse(json['sell_ammount']?.toString() ?? '0.0');

    if (derivativeProduct?.isNotEmpty ?? false) {
      if ((buyAmmount! > 0) && (sellAmmount! > 0)) {
        netAmount = buyAmmount! - sellAmmount!;
      }
    } else {
      netAmount = netInvestementInr!;
    }
  }
}
