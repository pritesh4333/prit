class RollOverResponseModel {
  List<Data>? data;

  RollOverResponseModel({this.data});

  RollOverResponseModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? symbol1;
  int? token1;
  int? expiry1;
  int? token2;
  String? symbol2;
  int? expiry2;
  int? token3;
  String? symbol3;
  int? expiry3;
  String? exchange;
  String? assetType;
  String? optType;
  String? instName;
  int? strikePrice;
  int? expiryDate;
  String? cashInstName;
  int? lotSize;
  double? tickSize;
  int? multiplyFactor;
  String? description;
  double? ltp1;
  double? ltp2;
  int? oi1;
  int? oi2;
  int? oi3;
  double? ltp;
  double? change;
  double? perChange;
  String? type;
  String? symbol;
  int? token;

  Data(
      {this.symbol1,
      this.token1,
      this.expiry1,
      this.token2,
      this.symbol2,
      this.expiry2,
      this.token3,
      this.symbol3,
      this.expiry3,
      this.exchange,
      this.assetType,
      this.optType,
      this.instName,
      this.strikePrice,
      this.expiryDate,
      this.cashInstName,
      this.lotSize,
      this.tickSize,
      this.multiplyFactor,
      this.description,
      this.ltp1,
      this.ltp2,
      this.oi1,
      this.oi2,
      this.oi3,
      this.ltp,
      this.change,
      this.perChange,
      this.type,
      this.symbol,
      this.token});

  Data.fromJson(Map<String, dynamic> json) {
    symbol1 = json['symbol1'];
    token1 = json['token1'];
    expiry1 = json['expiry1'];
    token2 = json['token2'];
    symbol2 = json['symbol2'];
    expiry2 = json['expiry2'];
    token3 = json['token3'];
    symbol3 = json['symbol3'];
    expiry3 = json['expiry3'];
    exchange = json['exchange'];
    assetType = json['assetType'];
    optType = json['OptType'];
    instName = json['InstName'];
    strikePrice = json['StrikePrice'];
    expiryDate = json['expiryDate'];
    cashInstName = json['cashInstName'];
    lotSize = json['lotSize'];
    tickSize = json['tickSize'];
    multiplyFactor = json['multiply_factor'];
    description = json['description'];
    ltp1 = json['Ltp1'];
    ltp2 = json['Ltp2'];
    oi1 = json['oi1'];
    oi2 = json['oi2'];
    oi3 = json['oi3'];
    ltp = json['ltp'];
    change = json['change'];
    perChange = json['perChange'];
    type = json['type'];
    symbol = json['symbol'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['symbol1'] = symbol1;
    data['token1'] = token1;
    data['expiry1'] = expiry1;
    data['token2'] = token2;
    data['symbol2'] = symbol2;
    data['expiry2'] = expiry2;
    data['token3'] = token3;
    data['symbol3'] = symbol3;
    data['expiry3'] = expiry3;
    data['exchange'] = exchange;
    data['assetType'] = assetType;
    data['OptType'] = optType;
    data['InstName'] = instName;
    data['StrikePrice'] = strikePrice;
    data['expiryDate'] = expiryDate;
    data['cashInstName'] = cashInstName;
    data['lotSize'] = lotSize;
    data['tickSize'] = tickSize;
    data['multiply_factor'] = multiplyFactor;
    data['description'] = description;
    data['Ltp1'] = ltp1;
    data['Ltp2'] = ltp2;
    data['oi1'] = oi1;
    data['oi2'] = oi2;
    data['oi3'] = oi3;
    data['ltp'] = ltp;
    data['change'] = change;
    data['perChange'] = perChange;
    data['type'] = type;
    data['symbol'] = symbol;
    data['token'] = token;
    return data;
  }
}
