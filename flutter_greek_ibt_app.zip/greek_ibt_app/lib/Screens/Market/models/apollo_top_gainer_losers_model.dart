class ApolloTopGainerAndLosserDataModel {
  int? token;
  String? symbol;
  double? ltp;
  double? perchange;
  double? change;
  double? close;
  String? voltraded;
  String? description;
  String? exchange;
  String? lotSize;
  String? assetType;
  String? tickSize;
  String? multiplyFactor;
  String? expiryDate;
  String? optiontype;
  double? strikeprice;
  String? instrumentname;

  ApolloTopGainerAndLosserDataModel({
    required this.token,
    required this.symbol,
    required this.ltp,
    required this.perchange,
    required this.change,
    required this.close,
    required this.voltraded,
    required this.description,
    required this.exchange,
    required this.lotSize,
    required this.assetType,
    required this.tickSize,
    required this.multiplyFactor,
    required this.expiryDate,
    required this.optiontype,
    required this.strikeprice,
    required this.instrumentname,
  });

  ApolloTopGainerAndLosserDataModel.fromJson(Map<String, dynamic> json) {
    token = int.parse('${json['token']}');
    symbol = '${json['symbol']}';
    ltp = double.parse('${json['ltp']}');
    perchange = double.parse('${json['perchange']}');
    change = double.parse('${json['change']}');
    close = double.parse('${json['close']}');
    voltraded = '${json['voltraded']}';
    description = '${json['description']}';
    exchange = '${json['Exchange']}';
    lotSize = '${json['LotSize']}';
    assetType = '${json['AssetType']}';
    tickSize = '${json['TickSize']}';
    multiplyFactor = '${json['Multiply_factor']}';
    expiryDate = '${json['ExpiryDate']}';
    optiontype = '${json['optiontype']}';
    strikeprice = double.parse('${json['strikeprice']}');
    instrumentname = '${json['instrumentname']}';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['token'] = token?.toString() ?? '';
    data['symbol'] = symbol ?? '';
    data['ltp'] = ltp?.toString() ?? '';
    data['perchange'] = perchange?.toString() ?? '';
    data['change'] = change?.toString() ?? '';
    data['close'] = close?.toString() ?? '';
    data['voltraded'] = voltraded ?? '';
    data['description'] = description ?? '';
    data['Exchange'] = exchange ?? '';
    data['LotSize'] = lotSize ?? '';
    data['AssetType'] = assetType ?? '';
    data['TickSize'] = tickSize ?? '';
    data['Multiply_factor'] = multiplyFactor ?? '';
    data['ExpiryDate'] = expiryDate ?? '';
    data['optiontype'] = optiontype ?? '';
    data['strikeprice'] = strikeprice?.toString() ?? '';
    data['instrumentname'] = instrumentname ?? '';
    return data;
  }
}
