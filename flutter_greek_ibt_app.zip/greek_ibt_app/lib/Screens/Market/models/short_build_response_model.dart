class ShortBuildupResModel {
  String? exchange;
  String? assetType;
  String? bid;
  String? ask;
  String? optType;
  String? symbol;
  String? instName;
  String? strikePrice;
  String? expiryDate;
  String? volTraded;
  String? oi;
  String? ltp;
  String? perChange;
  String? cashInstName;
  String? token;
  String? lotSize;
  String? tickSize;
  String? multiplyFactor;
  String? change;
  String? description;

  ShortBuildupResModel(
      {this.exchange,
      this.assetType,
      this.bid,
      this.ask,
      this.optType,
      this.symbol,
      this.instName,
      this.strikePrice,
      this.expiryDate,
      this.volTraded,
      this.oi,
      this.ltp,
      this.perChange,
      this.cashInstName,
      this.token,
      this.lotSize,
      this.tickSize,
      this.multiplyFactor,
      this.change,
      this.description});

  ShortBuildupResModel.fromJson(Map<String, dynamic> json) {
    exchange = json['exchange'].toString();
    assetType = json['assetType'].toString();
    bid = json['bid'].toString();
    ask = json['ask'].toString();
    optType = json['OptType'].toString();
    symbol = json['symbol'].toString();
    instName = json['InstName'].toString();
    strikePrice = json['StrikePrice'].toString();
    expiryDate = json['expiryDate'].toString();
    volTraded = json['vol_traded'].toString();
    oi = json['oi'].toString();
    ltp = json['ltp'].toString();
    perChange = json['perChange'].toString();
    cashInstName = json['cashInstName'].toString();
    token = json['token'].toString();
    lotSize = json['lotSize'].toString();
    tickSize = json['tickSize'].toString();
    multiplyFactor = json['multiply_factor'].toString();
    change = json['change'].toString();
    description = json['description'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['exchange'] = exchange;
    data['assetType'] = assetType;
    data['bid'] = bid;
    data['ask'] = ask;
    data['OptType'] = optType;
    data['symbol'] = symbol;
    data['InstName'] = instName;
    data['StrikePrice'] = strikePrice;
    data['expiryDate'] = expiryDate;
    data['vol_traded'] = volTraded;
    data['oi'] = oi;
    data['ltp'] = ltp;
    data['perChange'] = perChange;
    data['cashInstName'] = cashInstName;
    data['token'] = token;
    data['lotSize'] = lotSize;
    data['tickSize'] = tickSize;
    data['multiply_factor'] = multiplyFactor;
    data['change'] = change;
    data['description'] = description;
    return data;
  }
}
