// To parse this JSON data, do
//
//     final instrumentSymbolResponseModel = instrumentSymbolResponseModelFromJson(jsonString);

import 'dart:convert';

InstrumentSymbolResponseModel instrumentSymbolResponseModelFromJson(
        String str) =>
    InstrumentSymbolResponseModel.fromJson(json.decode(str));

String instrumentSymbolResponseModelToJson(
        InstrumentSymbolResponseModel data) =>
    json.encode(data.toJson());

class InstrumentSymbolResponseModel {
  InstrumentSymbolResponseModel({
    this.data,
  });

  List<Datum>? data;

  factory InstrumentSymbolResponseModel.fromJson(Map<String, dynamic> json) =>
      InstrumentSymbolResponseModel(
        data: List<Datum>.from(json["data"]?.map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.symbol,
  });

  String? symbol;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        symbol: json["symbol"],
      );

  Map<String, dynamic> toJson() => {
        "symbol": symbol,
      };
}
