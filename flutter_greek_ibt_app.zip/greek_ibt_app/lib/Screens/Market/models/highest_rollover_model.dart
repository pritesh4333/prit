// To parse this JSON data, do
//
//     final highestRolloverResponseModel = highestRolloverResponseModelFromJson(jsonString);

import 'dart:convert';

HighestRolloverResponseModel highestRolloverResponseModelFromJson(String str) =>
    HighestRolloverResponseModel.fromJson(json.decode(str));

String highestRolloverResponseModelToJson(HighestRolloverResponseModel data) =>
    json.encode(data.toJson());

class HighestRolloverResponseModel {
  HighestRolloverResponseModel({
    this.data,
  });

  List<Datum>? data;

  factory HighestRolloverResponseModel.fromJson(Map<String, dynamic> json) =>
      HighestRolloverResponseModel(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.symbol1,
    this.token1,
    this.expiry1,
    this.token2,
    this.symbol2,
    this.expiry2,
    this.token3,
    this.symbol3,
    this.expiry3,
    this.exchange,
    this.assetType,
    this.optType,
    this.instName,
    this.strikePrice,
    this.expiryDate,
    this.cashInstName,
    this.lotSize,
    this.tickSize,
    this.multiplyFactor,
    this.description,
    this.ltp1,
    this.ltp2,
    this.oi1,
    this.oi2,
    this.oi3,
    this.ltp,
    this.change,
    this.perChange,
    this.type,
    this.symbol,
    this.token,
  });

  String? symbol1;
  int? token1;
  int? expiry1;
  int? token2;
  String? symbol2;
  int? expiry2;
  int? token3;
  String? symbol3;
  int? expiry3;
  String? exchange;
  String? assetType;
  String? optType;
  String? instName;
  int? strikePrice;
  int? expiryDate;
  String? cashInstName;
  int? lotSize;
  double? tickSize;
  int? multiplyFactor;
  String? description;
  double? ltp1;
  double? ltp2;
  int? oi1;
  int? oi2;
  int? oi3;
  double? ltp;
  double? change;
  double? perChange;
  String? type;
  String? symbol;
  int? token;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        symbol1: json["symbol1"],
        token1: json["token1"],
        expiry1: json["expiry1"],
        token2: json["token2"],
        symbol2: json["symbol2"],
        expiry2: json["expiry2"],
        token3: json["token3"],
        symbol3: json["symbol3"],
        expiry3: json["expiry3"],
        exchange: json["exchange"],
        assetType: json["assetType"],
        optType: json["OptType"],
        instName: json["InstName"],
        strikePrice: json["StrikePrice"],
        expiryDate: json["expiryDate"],
        cashInstName: json["cashInstName"],
        lotSize: json["lotSize"],
        tickSize: json["tickSize"].toDouble(),
        multiplyFactor: json["multiply_factor"],
        description: json["description"],
        ltp1: json["Ltp1"].toDouble(),
        ltp2: json["Ltp2"].toDouble(),
        oi1: json["oi1"],
        oi2: json["oi2"],
        oi3: json["oi3"],
        ltp: json["ltp"].toDouble(),
        change: json["change"].toDouble(),
        perChange: json["perChange"].toDouble(),
        type: json["type"],
        symbol: json["symbol"],
        token: json["token"],
      );

  Map<String, dynamic> toJson() => {
        "symbol1": symbol1,
        "token1": token1,
        "expiry1": expiry1,
        "token2": token2,
        "symbol2": symbol2,
        "expiry2": expiry2,
        "token3": token3,
        "symbol3": symbol3,
        "expiry3": expiry3,
        "exchange": exchange,
        "assetType": assetType,
        "OptType": optType,
        "InstName": instName,
        "StrikePrice": strikePrice,
        "expiryDate": expiryDate,
        "cashInstName": cashInstName,
        "lotSize": lotSize,
        "tickSize": tickSize,
        "multiply_factor": multiplyFactor,
        "description": description,
        "Ltp1": ltp1,
        "Ltp2": ltp2,
        "oi1": oi1,
        "oi2": oi2,
        "oi3": oi3,
        "ltp": ltp,
        "change": change,
        "perChange": perChange,
        "type": type,
        "symbol": symbol,
        "token": token,
      };
}
