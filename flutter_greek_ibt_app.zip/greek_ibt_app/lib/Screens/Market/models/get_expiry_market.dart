class GetExpiryMarketResponseModel {
  String? expiry;
  String? lourtoken;

  GetExpiryMarketResponseModel({this.expiry, this.lourtoken});

  GetExpiryMarketResponseModel.fromJson(Map<String, dynamic> json) {
    expiry = json['expiry'].toString();
    lourtoken = json['lourtoken'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['expiry'] = expiry;
    data['lourtoken'] = lourtoken;
    return data;
  }
}
