class LongBuildupResModel {
  String? exchange;
  String? assetType;
  double? bid;
  double? ask;
  String? optType;
  String? symbol;
  String? instName;
  int? strikePrice;
  int? expiryDate;
  int? volTraded;
  int? oi;
  double? ltp;
  double? perChange;
  String? cashInstName;
  int? token;
  double? lotSize;
  double? tickSize;
  int? multiplyFactor;
  double? change;
  String? description;

  LongBuildupResModel({this.exchange, this.assetType, this.bid, this.ask, this.optType, this.symbol, this.instName, this.strikePrice, this.expiryDate, this.volTraded, this.oi, this.ltp, this.perChange, this.cashInstName, this.token, this.lotSize, this.tickSize, this.multiplyFactor, this.change, this.description});

  LongBuildupResModel.fromJson(Map<String, dynamic> json) {
    exchange = json['exchange'];
    assetType = json['assetType'];
    bid = json['bid'];
    ask = json['ask'];
    optType = json['OptType'];
    symbol = json['symbol'];
    instName = json['InstName'];
    strikePrice = json['StrikePrice'];
    expiryDate = json['expiryDate'];
    volTraded = json['vol_traded'];
    oi = json['oi'];
    ltp = json['ltp'];
    perChange = json['perChange'];
    cashInstName = json['cashInstName'];
    token = json['token'];
    lotSize = json['lotSize'];
    tickSize = json['tickSize'];
    multiplyFactor = json['multiply_factor'];
    change = json['change'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['exchange'] = exchange;
    data['assetType'] = assetType;
    data['bid'] = bid;
    data['ask'] = ask;
    data['OptType'] = optType;
    data['symbol'] = symbol;
    data['InstName'] = instName;
    data['StrikePrice'] = strikePrice;
    data['expiryDate'] = expiryDate;
    data['vol_traded'] = volTraded;
    data['oi'] = oi;
    data['ltp'] = ltp;
    data['perChange'] = perChange;
    data['cashInstName'] = cashInstName;
    data['token'] = token;
    data['lotSize'] = lotSize;
    data['tickSize'] = tickSize;
    data['multiply_factor'] = multiplyFactor;
    data['change'] = change;
    data['description'] = description;
    return data;
  }
}
