import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_tab_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_expiry_market.dart';
import 'package:greek_ibt_app/Screens/Market/repository/option_repository.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/option_chain_call_put_model.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Screens/Market/models/symbol_instrument.dart';
import 'package:greek_ibt_app/Screens/Market/models/type_model.dart';
import 'market_strike_reponse_model.dart';

class OptionBloc extends MarketTabBloc {
  final BuildContext context;
  // final OrderMode orderMode;
  // OrderAction orderAction;
  // OrderDetailsModel? obj;
  List<SymbolInstrumentData>? symbolList = [];
  List<OptionChainResponseModel?> filterArray = [];

  /*  List<TypeModel> typeDataList = [];
  final typeDataSubject = BehaviorSubject<List<BehaviorSubject<TypeModel>>>();
  List<BehaviorSubject<TypeModel>> typeDataListStreamList = [];

  List<ExpiryResponseModel> expiryDataList = [];
  final expiryDataSubject =
      BehaviorSubject<List<BehaviorSubject<ExpiryResponseModel>>>();
  List<BehaviorSubject<ExpiryResponseModel>> expiryDataListStreamList = []; */

  final symbolDataSubject = BehaviorSubject<List<SymbolInstrumentData>>();
  Stream<List<SymbolInstrumentData>> get symbolObserver =>
      symbolDataSubject.stream;

  final expiryDataSubject =
      BehaviorSubject<List<GetExpiryMarketResponseModel>>();
  Stream<List<GetExpiryMarketResponseModel>> get expiryObserver =>
      expiryDataSubject.stream;

  final strikeDataSubject =
      BehaviorSubject<List<GetMarketStrikeResponseModel>>();
  Stream<List<GetMarketStrikeResponseModel>> get strikeObserver =>
      strikeDataSubject.stream;

  final typeDataSubject = BehaviorSubject<List<TypeModel>>();
  Stream<List<TypeModel>> get typeObserver => typeDataSubject.stream;

  OptionBloc(this.context) {
    registerOptionChainAppListener();
  }
  String? ltp = "";

  bool isvolume = false;
  bool oi = false;
  bool oIChange = false;
  bool iv = false;
  bool greeks = false;
  bool delta = false;
  bool gama = false;
  bool vega = false;

  var headings = [
    'Oi',
    'LTP',
    'Strike',
    'LTP',
    'Oi',
  ];
  var heading1 = [
    'Change',
    'Change',
    '',
    'Change',
    'Change',
  ];

  //call table
  var headingsCall = [
    'Oi',
    'LTP',
    'Strike',
  ];
  var headingCallValue = [
    'Change',
    'Change',
    '',
  ];
  var noofStrike = "10";

  //put table
  var headingsPut = [
    'Strike',
    'LTP',
    'Oi',
  ];
  var headingCallPut = [
    '',
    'Change',
    'Change',
  ];

  final _repository = OptionRepository();
  /*  {required this.context,
      required orderMode,
      required orderAction,
      obj,
      required orderToken})
      : super(context,
            orderMode: orderMode,
            orderAction: orderAction,
            obj: obj,
            orderToken: orderToken) {
    registerCommonAppListener();
    registerOptionChainAppListener();
  } */

  List<GetExpiryMarketResponseModel?> getExpiryResponseArray =
      <GetExpiryMarketResponseModel?>[];
  List<GetMarketStrikeResponseModel?> getStrikeResponseArray =
      <GetMarketStrikeResponseModel?>[];

  final settingchangeSubject = BehaviorSubject<bool>();
  Stream<bool> get settingObserver => settingchangeSubject.stream;

  List<String?> _subscribeTouchlineToken = [];
  List<String> _subscribeputTouchlineToken = [];
  final String _unsubscribeTouchlineToken = '';

  final _itemscall = <String>[];

  final _itemsput = <String>[];

  var timemap = {};

  @override
  void disposeBloc() {
    _unsubscribeTouchlineToken;
    // orderResponseArray.clear();
    _optionChainDataSubject.close();
  }

  Future<List<SymbolInstrumentData>> callSearchForInstrumenAPi(
      String type) async {
    symbolDataSubject.sink.add([]);

    symbolList?.clear();

    final response = await _repository.getSymbolForInstrument(type);
    symbolDataSubject.sink.add(response);
    for (var item in response) {
      symbolList?.add(item);
    }
    return response;
  }

  final PublishSubject<List<OptionChainResponseModel?>>
      _optionChainDataSubject = PublishSubject();
  Stream<List<OptionChainResponseModel?>> get optionChainObserverable =>
      _optionChainDataSubject.stream;

  List<BehaviorSubject<OptionChainResponseModel>?> ltpInfoStream =
      <BehaviorSubject<OptionChainResponseModel>>[];
  List<BehaviorSubject<OptionChainResponseModel>?> ltpInfoPutStream =
      <BehaviorSubject<OptionChainResponseModel>>[];

  List<double?> getupperStrikeResponseArray = <double?>[];

  List<double?> getlowerStrikeResponseArray = <double?>[];

  Future<List<GetExpiryMarketResponseModel?>> callExpiryAPI(
      String symbol) async {
    List<GetExpiryMarketResponseModel> tempExpiryList = [];
    expiryDataSubject.sink.add([]);

    final getExpiryResponse =
        await super.repository.getMarketExpiryAPI(context, symbol: symbol);
    expiryDataSubject.sink.add(getExpiryResponse);

    for (var item in getExpiryResponse) {
      // tempExpiryList.insert(0, "select expiry");
      tempExpiryList.add(item);
    }

    getExpiryResponseArray = tempExpiryList;

    for (int i = 0; i < getExpiryResponseArray.length; i++) {
      timemap[DateFormat('ddMMMyyyy').format(
              DateTime.fromMillisecondsSinceEpoch(
                  int.parse(getExpiryResponseArray.elementAt(i)?.expiry ?? '') *
                      1000))] =
          getExpiryResponseArray.elementAt(i)?.expiry.toString();
    }
    callStrikeAPI(symbol, getExpiryResponseArray[0]?.expiry.toString() ?? "");

    return getExpiryResponseArray;
  }

  void callStrikeAPI(String symbol, String expiry) async {
    final ltpResponse = await repository.getLTP(context,
        symbol: symbol, expiry: timemap[expiry]);

    ltp = ltpResponse['ltp'].toString();

    List<GetMarketStrikeResponseModel> tempStrikeList = [];

    final getStrikeResponse = await super
        .repository
        .getStrikeAPI(context, symbol: symbol, expiry: timemap[expiry]);
    int length = getStrikeResponse.length;
    if (length > 0) {
      for (var item in getStrikeResponse) {
        tempStrikeList.add(item);
        if ((double.parse(ltp!) / 100) > double.parse(item.strikeprice ?? "")) {
          getlowerStrikeResponseArray.add(double.parse(item.strikeprice ?? ""));
        } else {
          getupperStrikeResponseArray.add(double.parse(item.strikeprice ?? ""));
        }

        // someObjects.sort((a, b) => a.someProperty.compareTo(b.someProperty));
      }
      /* getlowerStrikeResponseArray.sort();
      getupperStrikeResponseArray.sort(); */
      // String fromStrikr, tostrike;
      List<double?> templower = [];
      List<double?> tempupper = [];
      if (noofStrike != "All") {
        for (int i = getlowerStrikeResponseArray.length - 1;
            i >= getlowerStrikeResponseArray.length - int.parse(noofStrike);
            i--) {
          templower.add(getlowerStrikeResponseArray[i]);
        }

        for (int i = 0; i < int.parse(noofStrike); i++) {
          tempupper.add(getupperStrikeResponseArray[i]);
        }
      } else {
        templower.addAll(getlowerStrikeResponseArray);
        tempupper.addAll(getupperStrikeResponseArray);
      }

      templower.sort();
      tempupper.sort();

      callOptionChainAPIS(
        symbol: symbol,
        expiry: expiry,
        fromStrike: '${templower[0]}',
        //getStrikeResponseArray.first?.strikeprice.toString() ?? '',
        toStrike: '${tempupper[tempupper.length - 1]}',
        // getStrikeResponseArray.last?.strikeprice.toString() ?? '',
      );
      // subscribeTouchLine();
    }
  }

  void callOptionChainAPIS({
    required String symbol,
    required String expiry,
    required String fromStrike,
    required String toStrike,
  }) async {
    List<OptionChainResponseModel?> mainObj =
        await super.repository.getOptionChainAPI(
              context: context,
              exchange: '', //orderToken.toExchange().toString().toUpperCase(),
              symbol: symbol,
              fromStrike: fromStrike,
              toStrike: toStrike,
              expiry: expiry,
            );

    filterArray = mainObj
        .where(
          (element) => (expiry
                  .toLowerCase()
                  .compareTo(element?.call?.expiryDate?.toLowerCase() ?? '') ==
              0),
        )
        .toList();

    filterArray.sort((a, b) => (double.parse(a!.strikePrice.toString()))
        .compareTo(double.parse(b!.strikePrice.toString())));
    // players.sort((a, b) => a.gameID.compareTo(b.gameID));

    _optionChainDataSubject.sink.add(filterArray);
    for (var item in filterArray) {
      _itemscall.add(item?.call?.lOurToken.toString() ?? '');
      _itemsput.add(item?.put?.lOurToken.toString() ?? '');
    }
    subscribeTouchLine();
  }

  /*  void callOptionChainAPIS({
    required String symbol,
    required String expiry,
    required String fromStrike,
    required String toStrike,
  }) async {
    final mainObj = await super.repository.getOptionChainAPI(
          context: context,
          exchange: '', //orderToken.toExchange().toString().toUpperCase(),
          symbol: symbol,
          fromStrike: fromStrike,
          toStrike: toStrike,
          expiry: expiry,
        );

    /*  filterArray = mainObj.where(
      (element) {
        var exp = DateFormat('ddMMMyyyy')
            .format(DateTime.fromMillisecondsSinceEpoch(int.parse(
                    element.call?.expiryDate.toString().toLowerCase() ?? '') *
                1000))
            .toString();
        log("======$exp");
        return (expiry.toLowerCase().compareTo(exp) == 0);
      },
    ).toList(); */

    filterArray = mainObj
        .where(
          (element) {
            /* var exp = DateFormat('ddMMMyyyy')
            .format(DateTime.fromMillisecondsSinceEpoch(int.parse(
                    element.call?.expiryDate.toString().toLowerCase() ?? '') *
                1000))
            .toString(); */
            log("======${element.call?.expiryDate.toString()}");
            return (expiry
                    .toLowerCase()
                    .compareTo(element.call?.expiryDate?.toLowerCase() ?? '') ==
                0);
          },
        )
        .toSet()
        .toList();

    filterArray.sort(
      (b, a) => (-(a.call?.strike ?? 0).compareTo(b.call?.strike ?? 0)),
    );
    // var compare = (b, a) => -a.compareTo(b);

    ltpInfoStream = List<BehaviorSubject<OptionChainResponseModel>>.generate(
      filterArray.length,
      (index) {
        return BehaviorSubject<OptionChainResponseModel>.seeded(
          filterArray[index],
        );
      },
    );

    _optionChainDataSubject.sink.add(filterArray);
    for (var item in filterArray) {
      _itemscall.add(item.call?.lOurToken.toString() ?? '');
      _itemsput.add(item.put?.lOurToken.toString() ?? '');
    }
    subscribeLTPInfo(List.generate(filterArray.length, (index) => index));
    subscribeTouchLine();

    // subscribeTouchLine();
  }
 */
  /* void subscribeLTPInfo(List<int> tokenRanges) {
    if (_unsubscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().unSubscribeTouchLineTokens(_itemscall);
      SocketIOManager().unSubscribeTouchLineTokens(_itemsput);
    }

    if (tokenRanges.isNotEmpty) {
      List<String?> result = tokenRanges.map(
        (i) {
          return filterArray.elementAt(i).call?.lOurToken!.toString();
        },
      ).toList();

      List<String?> result1 = tokenRanges.map(
        (i) {
          return filterArray.elementAt(i).put?.lOurToken!.toString();
        },
      ).toList();

      _subscribeTouchlineToken = result;
      _subscribeTouchlinePutToken = result1;

      SocketIOManager().subscribeTouchLineTokens(_subscribeTouchlineToken);
      SocketIOManager().subscribeTouchLineTokens(_subscribeTouchlinePutToken);
      // _unsubscribeTouchlineToken = _subscribeTouchlineToken;
    }

    /* _subscribeLTPInfoTokenArray =
        currentSymbolLists.map((e) => e.token.toString()).toList();
    SocketIOManager().subscribeLTPInfoTokens(_subscribeLTPInfoTokenArray);
    _unSubscribeLTPInfoTokenArray = _subscribeLTPInfoTokenArray; */
  }
 */
  /* void registerOptionChainAppListener() {
    //SocketIOManager().brodcastResponseObservable.listen((event) {
    SocketIOManager().brodcastResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.apolloResponseStreamingType ==
              ApolloResponseStreamingType.touchline) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              if ((responseDic['symbol'] != null) &&
                  (responseDic['ltp'] != null) &&
                  (responseDic['change'] != null) &&
                  (responseDic['p_change'] != null)) {
                final token = int.parse(responseDic['symbol'].toString());
                // final ltp = double.parse(responseDic['ltp'].toString());
                // final change = double.parse(responseDic['change'].toString());
                // final pChange = double.parse(responseDic['p_change'].toString());
                final vol = double.parse(responseDic['tot_vol'].toString());
                final ltp = double.parse('${responseDic['ltp']}');
                final pChange = double.parse('${responseDic['p_change']}');
                for (var item in filterArray) {
                  if ((_itemscall.call?.lOurToken ?? -1) == token) {
                    var obj = item;
                    item.call?.lVolume = vol;

                    final foundedIndex = _itemscall
                        .indexOf(item.call?.lOurToken.toString() ?? '');
                    if (foundedIndex >= 0) {
                      // item.put?.lVolume = vol;
                      obj.call?.lVolume = vol;

                      obj.call?.ltp = ltp;

                      obj.call?.change = pChange;
                      filterArray[foundedIndex] = obj;
                      ltpInfoStream.elementAt(foundedIndex)?.sink.add(obj);
                      break;
                    }
                  }
                  if ((item.put?.lOurToken ?? -1) == token) {
                    var obj1 = item;
                    item.put?.lVolume = vol;

                    final foundedIndex1 =
                        _itemsput.indexOf(item.put?.lOurToken.toString() ?? '');
                    if (foundedIndex1 >= 0) {
                      obj1.put?.lVolume = vol;
                      filterArray[foundedIndex1] = obj1;
                      ltpInfoStream.elementAt(foundedIndex1)?.sink.add(obj1);
                      break;
                    }
                  }
                }
              }
              break;
            }
          }
        }

        /*  for (var item in keys) {
          if (item.apolloResponseStreamingType ==
              ApolloResponseStreamingType.touchline) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              final token = int.parse('${responseDic['symbol']}');
              if (_subscribeTouchlineToken
                      .toUpperCase()
                      .compareTo(token.toString().toUpperCase()) ==
                  0) {
                final ltp = double.parse('${responseDic['ltp']}');

                // orderResponseArray[currentExchangeIndex]?.last = ltp;

                /*       _marketPictureSubject?.sink.add(
                  orderResponseArray[currentExchangeIndex],
                );
*/

                break;
              }

              break;
            }
          }
        } */
      }
    });
  }
 */

  void registerOptionChainAppListener() {
    //SocketIOManager().brodcastResponseObservable.listen((event) {
    SocketIOManager().brodcastResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.apolloResponseStreamingType ==
              ApolloResponseStreamingType.touchline) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              final token = int.parse('${responseDic['symbol']}');

              final ltp = double.parse('${responseDic['ltp']}');
              final pChange = double.parse('${responseDic['p_change']}');
              final volume = double.parse('${responseDic['tot_vol']}');
              for (int i = 0; i < _itemscall.length; i++) {
                if (token.toString() == _itemscall[i].toString()) {
                  int foundindex = _itemscall.indexOf(token.toString());
                  filterArray[foundindex]?.call?.ltp = ltp;
                  filterArray[foundindex]?.call?.lVolume = volume;
                  filterArray[foundindex]?.call?.change = pChange;
                  _optionChainDataSubject.sink.add(filterArray);
                  break;
                }
              }

              for (int i = 0; i < _itemsput.length; i++) {
                if (token.toString() == _itemsput[i].toString()) {
                  int foundindexput = _itemsput.indexOf(token.toString());
                  if (foundindexput >= 0) {
                    filterArray[foundindexput]?.put?.ltp = ltp;
                    filterArray[foundindexput]?.put?.lVolume = volume;
                    filterArray[foundindexput]?.put?.change = pChange;
                    _optionChainDataSubject.sink.add(filterArray);
                    break;
                  }
                }
              }
            }
          }
        }
      }
    });
  }

  /*  void subscribeTouchLine() {
    if (_unsubscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().unSubscribeTouchLineTokens(_itemscall);
      SocketIOManager().unSubscribeTouchLineTokens(_itemsput);
    }

    // _subscribeTouchlineToken = _itemscall.toString();
    // _subscribeTouchlineToken = _itemsput.toString();

    if (_subscribeTouchlineToken.isNotEmpty) {
      // SocketIOManager().subscribeTouchLineTokens([_subscribeTouchlineToken]);
      // _unsubscribeTouchlineToken = _subscribeTouchlineToken;
    }
  }
 */

  void subscribeTouchLine() {
    if (_unsubscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().unSubscribeTouchLineTokens(_itemscall);
      SocketIOManager().unSubscribeTouchLineTokens(_itemsput);
    }

    _subscribeTouchlineToken = _itemscall;
    _subscribeputTouchlineToken = _itemsput;
    if (_subscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().subscribeTouchLineTokens(_subscribeTouchlineToken);
      SocketIOManager().subscribeTouchLineTokens(_subscribeputTouchlineToken);
      // _unsubscribeTouchlineToken = _subscribeTouchlineToken;
    }
  }

  void unSubscribeTouchLine() {
    if (_unsubscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().unSubscribeTouchLineTokens(_itemscall);
      SocketIOManager().unSubscribeTouchLineTokens(_itemsput);
    }
  }
}
