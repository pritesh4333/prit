class GetMarketStrikeResponseModel {
  String? lourtoken;
  String? strikeprice;

  GetMarketStrikeResponseModel({this.lourtoken, this.strikeprice});

  GetMarketStrikeResponseModel.fromJson(Map<String, dynamic> json) {
    lourtoken = json['lourtoken'].toString();
    strikeprice = json['strikeprice'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lourtoken'] = lourtoken;
    data['strikeprice'] = strikeprice;
    return data;
  }
}
