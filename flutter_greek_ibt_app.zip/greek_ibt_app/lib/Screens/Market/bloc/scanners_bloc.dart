import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_tab_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/repository/scanner_repository.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rect_getter/rect_getter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Screens/Market/models/expiry_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/highest_rollover_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/most_active_future_data_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/short_build_response_model.dart';

class ScannerBloc extends MarketTabBloc {
  late final BuildContext context;

  final listTileRectKey = {};
  final listViewRectKey = RectGetter.createGlobalKey();
  final _repository = ScannerRespository();

  List<BehaviorSubject<MostActiveFutureData>?> ltpInfoStream =
      <BehaviorSubject<MostActiveFutureData>>[];

  List<BehaviorSubject<MostActiveFutureData>?> ltpInfoStreamStock =
      <BehaviorSubject<MostActiveFutureData>>[];

  List<BehaviorSubject<MostActiveFutureData>?> ltpInfoStreamIndex =
      <BehaviorSubject<MostActiveFutureData>>[];

  List<BehaviorSubject<ShortBuildupResModel>?> ltpInfoStream1 =
      <BehaviorSubject<ShortBuildupResModel>>[];
  List<BehaviorSubject<ShortBuildupResModel>?> ltpInfoStreamShortBuildup =
      <BehaviorSubject<ShortBuildupResModel>>[];
  List<BehaviorSubject<ShortBuildupResModel>?> ltpInfoStreamLongUnwinding =
      <BehaviorSubject<ShortBuildupResModel>>[];

  List<BehaviorSubject<ShortBuildupResModel>?> ltpInfoStreamShortUnwinding =
      <BehaviorSubject<ShortBuildupResModel>>[];

  List<BehaviorSubject<Datum>?> ltpInfoStreamLowestRollOver =
      <BehaviorSubject<Datum>>[];

  List<BehaviorSubject<Datum>?> ltpInfoStream2 = <BehaviorSubject<Datum>>[];

  final marketMoverSubject =
      BehaviorSubject<List<BehaviorSubject<MostActiveFutureData>>>();
  static List<MostActiveFutureData> mostActiveFutureDataList = [];
  final mostActiveFutureDataSubject =
      BehaviorSubject<List<BehaviorSubject<MostActiveFutureData>>>();
  List<BehaviorSubject<MostActiveFutureData>>
      mostActiveFutureDataListStreamList = [];
  List<String> subscribemostActiveFutureDataTokens = [];
  List<String> unSubscribemostActiveFutureDataTokens = [];

  static List<MostActiveFutureData> mostActiveStockDataList = [];
  final mostActiveStockDataSubject =
      BehaviorSubject<List<BehaviorSubject<MostActiveFutureData>>>();
  List<BehaviorSubject<MostActiveFutureData>>
      mostActiveStockDataListStreamList = [];
  List<String> subscribemostActiveStockDataTokens = [];
  List<String> unSubscribemostActiveStockDataTokens = [];

  List<MostActiveFutureData> mostActiveIndexDataList = [];
  final mostActiveIndexDataSubject =
      BehaviorSubject<List<BehaviorSubject<MostActiveFutureData>>>();
  List<BehaviorSubject<MostActiveFutureData>>
      mostActiveIndexDataListStreamList = [];
  List<String> subscribemostActiveIndexDataTokens = [];
  List<String> unSubscribemostActiveIndexDataTokens = [];

  List<ShortBuildupResModel> longBuildUpDataList = [];
  final longBuildUpDataSubject =
      BehaviorSubject<List<BehaviorSubject<ShortBuildupResModel>>>();
  List<BehaviorSubject<ShortBuildupResModel>> longBuildupDataListStreamList =
      [];
  List<String> subscribeLongBuildupDataTokens = [];
  List<String> unSubscribeLongBuildupDataTokens = [];

  List<ShortBuildupResModel> shortBuildUpDataList = [];
  final shortBuildUpDataSubject =
      BehaviorSubject<List<BehaviorSubject<ShortBuildupResModel>>>();
  List<BehaviorSubject<ShortBuildupResModel>> shortBuildUpListStreamList = [];
  List<String> subscribeshortBuildUpDataTokens = [];
  List<String> unSubscribeshortBuildUpDataTokens = [];

  List<ShortBuildupResModel> shortUnwindingDataList = [];
  final shortUnwindingDataSubject =
      BehaviorSubject<List<BehaviorSubject<ShortBuildupResModel>>>();
  List<BehaviorSubject<ShortBuildupResModel>> shortUnwindingDataListStreamList =
      [];
  List<String> subscribeShortUnwindingDataTokens = [];
  List<String> unSubscribeShortUnwindingDataTokens = [];

  List<ShortBuildupResModel> longUnwindingDataList = [];
  final longUnwindingDataSubject =
      BehaviorSubject<List<BehaviorSubject<ShortBuildupResModel>>>();
  List<BehaviorSubject<ShortBuildupResModel>> longUnwindingDataListStreamList =
      [];
  List<String> subscribelongUnwindingDataTokens = [];
  List<String> unSubscribelongUnwindingDataTokens = [];

  List<Datum> highestRollOverDataList = [];
  final highestRollOverDataSubject =
      BehaviorSubject<List<BehaviorSubject<Datum>>>();
  List<BehaviorSubject<Datum>> highestRollOverListStreamList = [];
  List<String> subscribehighestRollOverDataTokens = [];
  List<String> unSubscribehighestRollOverDataTokens = [];

  List<Datum> lowestRollOverDataList = [];
  final lowestRollOverDataSubject =
      BehaviorSubject<List<BehaviorSubject<Datum>>>();
  List<BehaviorSubject<Datum>> lowestRollOverDataListStreamList = [];
  List<String> subscribelonglowestRollOverDataTokens = [];
  List<String> unSubscribelowestRollOverDataTokens = [];
  List<String> expiryFnoActivityList = [];

  @override
  void disposeBloc() {
    unSubscribeLTPInfo();
    super.disposeBloc();
  }

  void unSubscribeLTPInfo() {
    if (unSubscribemostActiveFutureDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveFutureDataTokens);
      unSubscribemostActiveFutureDataTokens.clear();
    }
    if (unSubscribemostActiveStockDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveStockDataTokens);
      unSubscribemostActiveStockDataTokens.clear();
    }
    if (unSubscribemostActiveIndexDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveIndexDataTokens);
      unSubscribemostActiveIndexDataTokens.clear();
    }
    if (unSubscribeLongBuildupDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeLongBuildupDataTokens);
      unSubscribeLongBuildupDataTokens.clear();
    }

    if (unSubscribeShortUnwindingDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeShortUnwindingDataTokens);
      unSubscribeShortUnwindingDataTokens.clear();
    }

    if (unSubscribeShortUnwindingDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeShortUnwindingDataTokens);
      unSubscribeShortUnwindingDataTokens.clear();
    }

    if (unSubscribelongUnwindingDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribelongUnwindingDataTokens);
      unSubscribelongUnwindingDataTokens.clear();
    }

    if (unSubscribehighestRollOverDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribehighestRollOverDataTokens);
      unSubscribehighestRollOverDataTokens.clear();
    }
    if (unSubscribelowestRollOverDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribelowestRollOverDataTokens);
      unSubscribelowestRollOverDataTokens.clear();
    }
  }

  void getExpiryFNOActivity() async {
    var responseMap = await _repository.getExpiryFNOActivity();
    if (responseMap is List) {
      var responseList = responseMap.toList();
      for (int i = 0; i < (responseList.length); i++) {
        expiryFnoActivityList.add(responseList[i]['expiry_date'].toString());
      }
    }

    /// For now we are sending first expiry from list [expiryFnoActivityList] by default
    ///Calling [MOST ACTIVE STOCK OPTION]
    callMostActiveStockOption(expiryFnoActivityList[0]);

    /// [MOST ACTIVE INDEX OPTION]
    callMostActiveIndexOption(expiryFnoActivityList[0]);

    /// [MOST ACTIVE FUTURES]
    callMostActiveFutures(expiryFnoActivityList[0]);
  }

  ScannerBloc(this.context) {
    // Getting [getExpiryFNOActivity]
    getExpiryFNOActivity();

    SocketIOManager().brodcastResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();

          for (var item in keys) {
            if (item.apolloResponseStreamingType ==
                    ApolloResponseStreamingType.ltpinfo ||
                item.apolloResponseStreamingType ==
                    ApolloResponseStreamingType.marketPicture) {
              final responseDic = event[item];
              if (responseDic is Map<String, dynamic>) {
                if ((responseDic['symbol'] != null) &&
                    (responseDic['ltp'] != null) &&
                    (responseDic['change'] != null) &&
                    (responseDic['p_change'] != null)) {
                  final token = int.parse(responseDic['symbol'].toString());
                  final ltp = double.parse(responseDic['ltp'].toString());
                  final change = double.parse(responseDic['change'].toString());
                  double pChange = 0.0;
                  try {
                    pChange = double.parse(responseDic['p_change'].toString());
                  } catch (e) {
                    log(e.toString());
                  }
                  log("Token ---->>>>>> : $token");
                  if (mostActiveFutureDataList.isNotEmpty) {
                    for (var item1 in mostActiveFutureDataList) {
                      if (int.parse(item1.token ?? "-1") == token) {
                        var obj = item1;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex =
                            mostActiveFutureDataList.indexOf(item1);
                        if (foundedIndex >= 0) {
                          mostActiveFutureDataList[foundedIndex] = obj;
                          if (ltpInfoStream.length > 0) {
                            ltpInfoStream
                                .elementAt(foundedIndex)
                                ?.sink
                                .add(obj);
                          }
                          break;
                        }
                      }
                    }
                  }

                  if (mostActiveStockDataList.isNotEmpty) {
                    for (var item2 in mostActiveStockDataList) {
                      if (int.parse(item2.token ?? "-1") == token) {
                        var obj = item2;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex =
                            mostActiveStockDataList.indexOf(item2);
                        if (foundedIndex >= 0) {
                          mostActiveStockDataList[foundedIndex] = obj;
                          ltpInfoStreamStock
                              .elementAt(foundedIndex)
                              ?.sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }

                  if (mostActiveIndexDataList.isNotEmpty) {
                    for (var item1 in mostActiveIndexDataList) {
                      if (int.parse(item1.token ?? "-1") == token) {
                        var obj = item1;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex =
                            mostActiveIndexDataList.indexOf(item1);
                        if (foundedIndex >= 0) {
                          mostActiveIndexDataList[foundedIndex] = obj;
                          ltpInfoStreamIndex
                              .elementAt(foundedIndex)
                              ?.sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }

                  if (longBuildUpDataList.isNotEmpty) {
                    for (var item1 in longBuildUpDataList) {
                      if (int.parse(item1.token.toString()) == token) {
                        var obj = item1;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex = longBuildUpDataList.indexOf(item1);
                        if (foundedIndex >= 0) {
                          longBuildUpDataList[foundedIndex] = obj;
                          ltpInfoStream1.elementAt(foundedIndex)?.sink.add(obj);
                          break;
                        }
                      }
                    }
                  }
                  if (shortBuildUpDataList.isNotEmpty) {
                    for (var item1 in shortBuildUpDataList) {
                      if (int.parse(item1.token ?? "-1") == token) {
                        var obj = item1;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex =
                            shortBuildUpDataList.indexOf(item1);
                        if (foundedIndex >= 0) {
                          shortBuildUpDataList[foundedIndex] = obj;
                          ltpInfoStreamShortBuildup
                              .elementAt(foundedIndex)
                              ?.sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }
                  if (shortUnwindingDataList.isNotEmpty) {
                    for (var item1 in shortUnwindingDataList) {
                      if (int.parse(item1.token ?? "-1") == token) {
                        var obj = item1;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex =
                            shortUnwindingDataList.indexOf(item1);
                        if (foundedIndex >= 0) {
                          shortUnwindingDataList[foundedIndex] = obj;
                          ltpInfoStreamShortUnwinding
                              .elementAt(foundedIndex)
                              ?.sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }
                  if (longUnwindingDataList.isNotEmpty) {
                    for (var item1 in longUnwindingDataList) {
                      if (int.parse(item1.token ?? "-1") == token) {
                        var obj = item1;
                        obj.ltp = ltp.toString();
                        obj.change = change.toString();
                        obj.perChange = pChange.toString();

                        final foundedIndex =
                            longUnwindingDataList.indexOf(item1);
                        if (foundedIndex >= 0) {
                          longUnwindingDataList[foundedIndex] = obj;
                          ltpInfoStreamLongUnwinding
                              .elementAt(foundedIndex)
                              ?.sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }
                  if (highestRollOverDataList.isNotEmpty) {
                    for (var item in highestRollOverDataList) {
                      if ((item.token ?? -1) == token) {
                        var obj = item;
                        obj.ltp = ltp;
                        obj.change = change;
                        obj.perChange = pChange;

                        final foundedIndex =
                            highestRollOverDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          highestRollOverDataList[foundedIndex] = obj;
                          ltpInfoStream2.elementAt(foundedIndex)?.sink.add(obj);
                          break;
                        }
                      }
                    }
                  }
                  if (lowestRollOverDataList.isNotEmpty) {
                    for (var item in lowestRollOverDataList) {
                      if ((item.token ?? -1) == token) {
                        var obj = item;
                        obj.ltp = ltp;
                        obj.change = change;
                        obj.perChange = pChange;

                        final foundedIndex =
                            lowestRollOverDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          lowestRollOverDataList[foundedIndex] = obj;
                          ltpInfoStreamLowestRollOver
                              .elementAt(foundedIndex)
                              ?.sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }
                }
                break;
              }
            }
          }
        }
      },
    );

    // void unSubscribeMostActiveFutureLTPInfoTokens() {
    //   if (unSubscribemostActiveFutureDataTokens.isNotEmpty) {
    //     SocketIOManager().unSubscribeLTPInfoTokens(unSubscribemostActiveFutureDataTokens);
    //   }

    //   unSubscribemostActiveFutureDataTokens.clear();
    //   subscribemostActiveFutureDataTokens.clear();
    // }
  }

  final _highestRollOverResultSubject = BehaviorSubject<List<Datum>>();
  Stream<List<Datum>> get highestRollOverResultObserver =>
      _highestRollOverResultSubject.stream;

  final _lowestRollOverResultSubject = BehaviorSubject<List<Datum>>();
  Stream<List<Datum>> get lowestRollOverResultObserver =>
      _lowestRollOverResultSubject.stream;

  final _mostActiveFeatureResultSubject =
      BehaviorSubject<List<MostActiveFutureData>>();
  Stream<List<MostActiveFutureData>> get mostActiveFeatureResultObserver =>
      _mostActiveFeatureResultSubject.stream;

  final _mostActiveStockOptionResultSubject =
      BehaviorSubject<List<MostActiveFutureData>>();
  Stream<List<MostActiveFutureData>> get mostActiveStockOptionResultObserver =>
      _mostActiveStockOptionResultSubject.stream;

  final _mostActiveIndexOptionResultSubject =
      BehaviorSubject<List<MostActiveFutureData>>();
  Stream<List<MostActiveFutureData>> get mostActiveIndexOptionResultObserver =>
      _mostActiveIndexOptionResultSubject.stream;

  final _longBuildupResultSubject =
      BehaviorSubject<List<ShortBuildupResModel>>();
  Stream<List<ShortBuildupResModel>> get longBuildupResultObserver =>
      _longBuildupResultSubject.stream;

  final _shortBuildupResultSubject =
      BehaviorSubject<List<ShortBuildupResModel>>();
  Stream<List<ShortBuildupResModel>> get shortBuildupResultObserver =>
      _shortBuildupResultSubject.stream;

  final _shortUnwindingResultSubject =
      BehaviorSubject<List<ShortBuildupResModel>>();
  Stream<List<ShortBuildupResModel>> get shortUnwindingResultObserver =>
      _shortUnwindingResultSubject.stream;

  final _longUnwindingResultSubject =
      BehaviorSubject<List<ShortBuildupResModel>>();
  Stream<List<ShortBuildupResModel>> get longUnwindingResultObserver =>
      _longUnwindingResultSubject.stream;

  Future<List<ExpiryResponseModel>> callgetExpiry() async {
    return await _repository.getExpiry();
  }

  Future<List<MostActiveFutureData>> callMostActiveFutures(
      String expiry) async {
    final response = await _repository.getMostActiveFeautures(expiry);
    _mostActiveFeatureResultSubject.sink.add(response);

    mostActiveFutureDataList = response;

    ltpInfoStream = List<BehaviorSubject<MostActiveFutureData>>.generate(
      response.length,
      (index) => BehaviorSubject<MostActiveFutureData>.seeded(
        response[index],
      ),
    );

    mostActiveFutureDataSubject.sink.add(mostActiveFutureDataListStreamList);
    subscribeMostActiveFutureLTPInfoTokens();
    return response;
  }

  Future<List<MostActiveFutureData>> callMostActiveStockOption(
      String expiry) async {
    final response = await _repository.getMostActiveStockOption(expiry);
    _mostActiveStockOptionResultSubject.sink.add(response);
    mostActiveStockDataList = response;

    ltpInfoStreamStock = List<BehaviorSubject<MostActiveFutureData>>.generate(
      response.length,
      (index) => BehaviorSubject<MostActiveFutureData>.seeded(
        response[index],
      ),
    );

    mostActiveStockDataSubject.sink.add(mostActiveStockDataListStreamList);
    subscribeMostActiveStockLTPInfoTokens();
    return response;
  }

  Future<List<MostActiveFutureData>> callMostActiveIndexOption(
      String expiry) async {
    final response = await _repository.getMostActiveIndexOption(expiry);
    _mostActiveIndexOptionResultSubject.sink.add(response);
    mostActiveIndexDataList = response;

    ltpInfoStreamIndex = List<BehaviorSubject<MostActiveFutureData>>.generate(
      response.length,
      (index) => BehaviorSubject<MostActiveFutureData>.seeded(
        response[index],
      ),
    );

    mostActiveIndexDataSubject.sink.add(mostActiveIndexDataListStreamList);
    subscribeMostActiveIndexLTPInfoTokens();

    return response;
  }

  Future<List<ShortBuildupResModel>> callLongBuildUP() async {
    final response = await _repository.getLongBuildUP();
    _longBuildupResultSubject.sink.add(response);
    longBuildUpDataList = response;

    ltpInfoStream1 = List<BehaviorSubject<ShortBuildupResModel>>.generate(
      response.length,
      (index) => BehaviorSubject<ShortBuildupResModel>.seeded(
        response[index],
      ),
    );

    longBuildUpDataSubject.sink.add(longBuildupDataListStreamList);
    subscribeLongBuildupLTPInfoToken();
    return response;
  }

  Future<List<ShortBuildupResModel>> callShortBuildUP() async {
    final response = await _repository.getShortBuildup();
    _shortBuildupResultSubject.sink.add(response);
    shortBuildUpDataList = response;

    ltpInfoStreamShortBuildup =
        List<BehaviorSubject<ShortBuildupResModel>>.generate(
      response.length,
      (index) => BehaviorSubject<ShortBuildupResModel>.seeded(
        response[index],
      ),
    );

    shortBuildUpDataSubject.sink.add(shortBuildUpListStreamList);
    subscribeShortBuildupLTPInfoTokens();
    return response;
  }

  Future<List<ShortBuildupResModel>> callShortUnwindingUp() async {
    final response = await _repository.getShortUnbinding();
    _shortUnwindingResultSubject.sink.add(response);
    shortUnwindingDataList = response;

    ltpInfoStreamShortUnwinding =
        List<BehaviorSubject<ShortBuildupResModel>>.generate(
      response.length,
      (index) => BehaviorSubject<ShortBuildupResModel>.seeded(
        response[index],
      ),
    );

    shortBuildUpDataSubject.sink.add(shortBuildUpListStreamList);
    subscribeShortUnwindingLTPInfoToken();
    return response;
  }

  Future<List<ShortBuildupResModel>> callLongUnWInding() async {
    final response = await _repository.getLongUnbinding();
    _longUnwindingResultSubject.sink.add(response);
    longUnwindingDataList = response;

    ltpInfoStreamLongUnwinding =
        List<BehaviorSubject<ShortBuildupResModel>>.generate(
      response.length,
      (index) => BehaviorSubject<ShortBuildupResModel>.seeded(
        response[index],
      ),
    );

    longBuildUpDataSubject.sink.add(longBuildupDataListStreamList);
    subscribeLongUnwindingLTPInfoTokens();
    return response;
  }

  Future<List<Datum>> callHighestRollOver() async {
    final response = await _repository.getHighestRollOver();
    _highestRollOverResultSubject.sink.add(response);
    highestRollOverDataList = response;

    ltpInfoStream2 = List<BehaviorSubject<Datum>>.generate(
      response.length,
      (index) => BehaviorSubject<Datum>.seeded(
        response[index],
      ),
    );

    highestRollOverDataSubject.sink.add(highestRollOverListStreamList);
    subscribeHighestRolloverLTPInfoTokens();
    return response;
  }

  Future<List<Datum>> callLowestRollOver() async {
    final response = await _repository.getLowestRollOver();
    _lowestRollOverResultSubject.sink.add(response);
    lowestRollOverDataList = response;

    ltpInfoStreamLowestRollOver = List<BehaviorSubject<Datum>>.generate(
      response.length,
      (index) => BehaviorSubject<Datum>.seeded(
        response[index],
      ),
    );

    lowestRollOverDataSubject.sink.add(lowestRollOverDataListStreamList);
    subscribeLowestRolloverLTPInfoTokens();
    return response;
  }

  void subscribeMostActiveFutureLTPInfoTokens() {
    if (unSubscribemostActiveFutureDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveFutureDataTokens);
    }

    subscribemostActiveFutureDataTokens = mostActiveFutureDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribemostActiveFutureDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager()
        .subscribeLTPInfoTokens(subscribemostActiveFutureDataTokens);

    unSubscribemostActiveFutureDataTokens = subscribemostActiveFutureDataTokens;
  }

  void subscribeMostActiveStockLTPInfoTokens() {
    if (unSubscribemostActiveStockDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveStockDataTokens);
    }

    subscribemostActiveStockDataTokens = mostActiveStockDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribemostActiveFutureDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager()
        .subscribeLTPInfoTokens(subscribemostActiveStockDataTokens);

    unSubscribemostActiveStockDataTokens = subscribemostActiveStockDataTokens;
  }

  void subscribeMostActiveIndexLTPInfoTokens() {
    if (unSubscribemostActiveIndexDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveIndexDataTokens);
    }

    subscribemostActiveIndexDataTokens = mostActiveIndexDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribemostActiveIndexDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager()
        .subscribeLTPInfoTokens(subscribemostActiveIndexDataTokens);

    unSubscribemostActiveIndexDataTokens = subscribemostActiveIndexDataTokens;
  }

  void subscribeLongBuildupLTPInfoToken() {
    /*  if (unSubscribeLongBuildupDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeLongBuildupDataTokens);
    } */

    subscribeLongBuildupDataTokens = longBuildUpDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribeLongBuildupDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );
    log("Subscribe tokens :-${subscribeLongBuildupDataTokens.toString()}");

    SocketIOManager().subscribeLTPInfoTokens(subscribeLongBuildupDataTokens);

    unSubscribeLongBuildupDataTokens = subscribeLongBuildupDataTokens;
  }

  void subscribeShortBuildupLTPInfoTokens() {
    if (unSubscribeshortBuildUpDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeshortBuildUpDataTokens);
    }

    subscribeshortBuildUpDataTokens = shortBuildUpDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribeshortBuildUpDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeshortBuildUpDataTokens);

    unSubscribeshortBuildUpDataTokens = subscribeshortBuildUpDataTokens;
  }

  void subscribeShortUnwindingLTPInfoToken() {
    if (unSubscribeShortUnwindingDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeShortUnwindingDataTokens);
    }

    subscribeShortUnwindingDataTokens = shortUnwindingDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribeShortUnwindingDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeShortUnwindingDataTokens);

    unSubscribeShortUnwindingDataTokens = subscribeShortUnwindingDataTokens;
  }

  void subscribeLongUnwindingLTPInfoTokens() {
    if (unSubscribelongUnwindingDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribelongUnwindingDataTokens);
    }

    subscribelongUnwindingDataTokens = longUnwindingDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribelongUnwindingDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribelongUnwindingDataTokens);

    unSubscribelongUnwindingDataTokens = subscribelongUnwindingDataTokens;
  }

  void subscribeHighestRolloverLTPInfoTokens() {
    if (unSubscribehighestRollOverDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribehighestRollOverDataTokens);
    }

    subscribehighestRollOverDataTokens = highestRollOverDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribehighestRollOverDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager()
        .subscribeLTPInfoTokens(subscribehighestRollOverDataTokens);

    unSubscribehighestRollOverDataTokens = subscribehighestRollOverDataTokens;
  }

  void subscribeLowestRolloverLTPInfoTokens() {
    if (unSubscribelowestRollOverDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribelowestRollOverDataTokens);
    }

    subscribelonglowestRollOverDataTokens = lowestRollOverDataList
        .map(
          (e) => (e.token?.toString() ?? ''),
        )
        .toList();
    subscribelonglowestRollOverDataTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager()
        .subscribeLTPInfoTokens(subscribelonglowestRollOverDataTokens);

    unSubscribelowestRollOverDataTokens = subscribelonglowestRollOverDataTokens;
  }

  void unSubscribeMostActiveFeauturesLTPInfoTokens() {
    if (unSubscribemostActiveFutureDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveFutureDataTokens);
    }

    unSubscribemostActiveFutureDataTokens.clear();
    subscribemostActiveFutureDataTokens.clear();
  }

  void unSubscribeMostActiveStockLTPInfoTokens() {
    if (unSubscribemostActiveStockDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveStockDataTokens);
    }

    unSubscribemostActiveStockDataTokens.clear();
    subscribemostActiveStockDataTokens.clear();
  }

  void unSubscribeMostActiveIndexLTPInfoTokens() {
    if (unSubscribemostActiveIndexDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribemostActiveIndexDataTokens);
    }

    unSubscribemostActiveIndexDataTokens.clear();
    subscribemostActiveIndexDataTokens.clear();
  }

  void unSubscribeLongBuildUpLTPInfoTokens() {
    /*  if (unSubscribeLongBuildupDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeLongBuildupDataTokens);
    } */

    unSubscribeLongBuildupDataTokens.clear();
    subscribeLongBuildupDataTokens.clear();
  }

  void unSubscribeShortBuildUpLTPInfoTokens() {
    /*  if (unSubscribeshortBuildUpDataTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeshortBuildUpDataTokens);
    } */

    unSubscribeshortBuildUpDataTokens.clear();
    subscribeshortBuildUpDataTokens.clear();
  }
}
