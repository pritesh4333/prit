import 'dart:async';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_tab_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/advance_decline_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_news_response.dart';
import 'package:greek_ibt_app/Screens/Market/repository/market_map_repository.dart';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/chartModel/model.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:rxdart/subjects.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_response_data_new_model.dart'
    as holding_models;
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:greek_ibt_app/Screens/Edis/Model/edis_authorization_response.dart'
    as edis_authorize_holding;

class MarketMapBloc extends MarketTabBloc {
  final _repository = MarketMapRespository();
  late List<ChartSampleData> randomData = [];

  final _advanceDeclinedResultSubject =
      BehaviorSubject<List<AdvanceDeclineResponseModel>>();
  Stream<List<AdvanceDeclineResponseModel>> get advanceDeclinedResultObserver =>
      _advanceDeclinedResultSubject.stream;

  List<String> topGainerMaketSegment = <String>[];
  String selectedTopGainerSegment = '';

  List<String> topLoosersMaketSegment = <String>[];
  String selectedTopLoosersSegment = '';

  List<String> marketMoversMaketSegment = <String>[];
  String selectedMarketMoversSegment = '';

  List<String> marketMoversByValueMaketSegment = <String>[];
  String selectedMarketMoversByValueSegment = '';

  int myNumber = 0;
  StreamSubscription<Map<String, dynamic>?>? _subscription;

  StreamSubscription<Object?>? _subscriptionTopGainers;
  StreamSubscription<Object?>? _subscriptionTopLosers;
  StreamSubscription<Object?>? _subscriptionMarketMOvers;
  StreamSubscription<Object?>? _subscriptionMarketMOversByValue;

  List<SymbolList> topGainersDataList = [];
  List<BehaviorSubject<SymbolList?>> topGainersStreamList = [];
  List<String> subscribeTopGainersTokens = [];
  List<String> unSubscribeTopGainersTokens = [];

  List<SymbolList> topLoosersDataList = [];
  List<BehaviorSubject<SymbolList?>> topLoosersStreamList = [];
  List<String> subscribeTopLoosersTokens = [];
  List<String> unSubscribeTopLoosersTokens = [];

  List<SymbolList> marketMoverDataList = [];
  List<BehaviorSubject<SymbolList?>> marketMoversStreamList = [];
  List<String> subscribeMarketMoversTokens = [];
  List<String> unSubscribeMarketMoversTokens = [];

  List<SymbolList> marketMoverByValueDataList = [];
  List<BehaviorSubject<SymbolList?>> marketMoversByValueStreamList = [];
  List<String> subscribeMarketMoversByValueTokens = [];
  List<String> unSubscribeMarketMoversByValueTokens = [];

  BehaviorSubject<List<GetNewsResponse>> getnewsSubject =
      BehaviorSubject.seeded([]);

  BehaviorSubject<List<GetNewsResponse>> getPortfolionewsSubject =
      BehaviorSubject.seeded([]);
  String selectedDropValue = '';
  BehaviorSubject<bool> dropDownValueTg = BehaviorSubject.seeded(true);

  List<holding_models.StockDetails> actualHoldingDataList = [];
  List<holding_models.StockDetails> tempactualHoldingDataList = [];
  List<edis_authorize_holding.StockDetails> edisactualHoldingDataList = [];

  List<BehaviorSubject<holding_models.StockDetails>> holdingDataStream =
      <BehaviorSubject<holding_models.StockDetails>>[];

  List<String> subscribeholdingDetailsTokens = [];
  List<String> unSubscribeholdingDetailsTokens = [];

  BehaviorSubject<String> currentBalance = BehaviorSubject<String>();

  final mainStream = BehaviorSubject.seeded(true);

  @override
  void disposeBloc() {
    _subscription?.cancel();

    topGainersDataList.clear();
    subscribeTopGainersTokens.clear();
    unSubscribeTopGainersTokens.clear();
    for (final element in topGainersStreamList) {
      element.close();
    }
    _subscriptionTopGainers?.cancel();

    topLoosersDataList.clear();
    subscribeTopLoosersTokens.clear();
    unSubscribeTopLoosersTokens.clear();
    for (final element in topLoosersStreamList) {
      element.close();
    }
    _subscriptionTopLosers?.cancel();

    marketMoverDataList.clear();
    subscribeMarketMoversTokens.clear();
    unSubscribeMarketMoversTokens.clear();
    for (final element in marketMoversStreamList) {
      element.close();
    }
    _subscriptionMarketMOvers?.cancel();

    marketMoverByValueDataList.clear();
    subscribeMarketMoversByValueTokens.clear();
    unSubscribeMarketMoversByValueTokens.clear();
    for (final element in marketMoversByValueStreamList) {
      element.close();
    }
    _subscriptionMarketMOversByValue?.cancel();
  }

  MarketMapBloc() {
    myNumber = SocketIOManager().marketmapNumber++;
    SocketIOManager().holdingDataListRequest();

    GreekBase().commonListenObserver.sink.add(null);
    for (var item in GreekBase().marketSegments) {
      switch (item) {
        case MarketSegment.nseeq:
          topGainerMaketSegment.add('NSE');
          topLoosersMaketSegment.add('NSE');
          marketMoversMaketSegment.add('NSE');
          marketMoversByValueMaketSegment.add('NSE');
          break;
        case MarketSegment.nsefo:
          topGainerMaketSegment.add('NSE FUTSTK');
          topLoosersMaketSegment.add('NSE FUTSTK');
          marketMoversMaketSegment.add('NSE FUTSTK');
          marketMoversByValueMaketSegment.add('NSE FUTSTK');

          topGainerMaketSegment.add('NSE OPTSTK');
          topLoosersMaketSegment.add('NSE OPTSTK');
          marketMoversMaketSegment.add('NSE OPTSTK');
          marketMoversByValueMaketSegment.add('NSE OPTSTK');
          break;
        case MarketSegment.nsecd:
          topGainerMaketSegment.add('NSECURR');
          topLoosersMaketSegment.add('NSECURR');
          marketMoversMaketSegment.add('NSECURR');
          marketMoversByValueMaketSegment.add('NSECURR');
          break;
        case MarketSegment.nsecomm:
          topGainerMaketSegment.add('NSECOMM');
          topLoosersMaketSegment.add('NSECOMM');
          marketMoversMaketSegment.add('NSECOMM');
          marketMoversByValueMaketSegment.add('NSECOMM');
          break;
        case MarketSegment.bseeq:
          topGainerMaketSegment.add('BSE');
          topLoosersMaketSegment.add('BSE');
          marketMoversMaketSegment.add('BSE');
          marketMoversByValueMaketSegment.add('BSE');
          break;
        case MarketSegment.bsecd:
          topGainerMaketSegment.add('BSECURR');
          topLoosersMaketSegment.add('BSECURR');
          marketMoversMaketSegment.add('BSECURR');
          marketMoversByValueMaketSegment.add('BSECURR');
          break;
        case MarketSegment.bsecomm:
          topGainerMaketSegment.add('BSECOMM');
          topLoosersMaketSegment.add('BSECOMM');
          marketMoversMaketSegment.add('BSECOMM');
          marketMoversByValueMaketSegment.add('BSECOMM');
          break;
        case MarketSegment.mcx:
          topGainerMaketSegment.add('MCX');
          topLoosersMaketSegment.add('MCX');
          marketMoversMaketSegment.add('MCX');
          marketMoversByValueMaketSegment.add('MCX');
          break;
        case MarketSegment.ncdex:
          topGainerMaketSegment.add('NCDEX');
          topLoosersMaketSegment.add('NCDEX');
          marketMoversMaketSegment.add('NCDEX');
          marketMoversByValueMaketSegment.add('NCDEX');
          break;
        default:
          break;
      }
    }

    selectedTopGainerSegment = topGainerMaketSegment.first;
    selectedTopLoosersSegment = topLoosersMaketSegment.first;
    selectedMarketMoversSegment = marketMoversMaketSegment.first;
    selectedMarketMoversByValueSegment = marketMoversByValueMaketSegment.first;

    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType ==
              IrisResponseStreamingType.HoldingDetailsInfoResp) {
            final responseDic = event[item];

            if (responseDic is Map<String, dynamic>) {
              // for (var ii = 0; ii < token.length; ii++) {

              //   lists.add(token[ii]);

              // }
              // responseDic["stockDetails"].perchange = 0.00;

              var modelObj = holding_models.HoldinResponseDataNewModel.fromJson(
                  responseDic);

              if (modelObj.stockDetails != null) {
                //Prepare the list of holding data if it receives in multi packets.

                if (modelObj.islast == 1 ||
                    (modelObj.stockDetails?.length == modelObj.noofrecords &&
                        modelObj.islast == 2)) {
                  actualHoldingDataList = modelObj.stockDetails!;
                  tempactualHoldingDataList = modelObj.stockDetails!;

                  subscribeholdingDetailsLTPInfoTokensHolding();
                } else {
                  actualHoldingDataList.addAll(modelObj.stockDetails!);
                  tempactualHoldingDataList.addAll(modelObj.stockDetails!);
                }
                holdingDataStream = actualHoldingDataList
                    .map((e) => BehaviorSubject.seeded(e))
                    .toList();

                mainStream.sink.add(true);

                break;
              }
            }
          }
        }
      }
    });

    _subscription = SocketIOManager().brodcastResponseObservable?.listen(
      (apolloEvent) {
        if (apolloEvent != null) {
          final keys = apolloEvent.keys.toList();
          for (var item in keys) {
            switch (item.apolloResponseStreamingType) {
              case ApolloResponseStreamingType.LoginResponse:
                break;

              case ApolloResponseStreamingType.ltpinfo:
                final ltpInfoResponse = apolloEvent[item];
                if (ltpInfoResponse is Map<String, dynamic>) {
                  if ((ltpInfoResponse['symbol'] != null) &&
                      (ltpInfoResponse['ltp'] != null) &&
                      (ltpInfoResponse['change'] != null) &&
                      (ltpInfoResponse['p_change'] != null) &&
                      (ltpInfoResponse['symbol'] != '') &&
                      (ltpInfoResponse['ltp'] != '') &&
                      (ltpInfoResponse['change'] != '') &&
                      (ltpInfoResponse['p_change'] != '')) {
                    final token =
                        int.parse(ltpInfoResponse['symbol'].toString());
                    final ltp = double.parse(ltpInfoResponse['ltp'].toString());
                    final change =
                        double.parse(ltpInfoResponse['change'].toString());
                    final pChange =
                        double.parse(ltpInfoResponse['p_change'].toString());

                    for (var item in topGainersDataList) {
                      if ((item.token ?? -1) == token) {
                        var obj = item;
                        obj.ltp = ltp;
                        obj.change = change;
                        obj.pChange = pChange;

                        final foundedIndex = topGainersDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          topGainersDataList[foundedIndex] = obj;
                          topGainersStreamList
                              .elementAt(foundedIndex)
                              .sink
                              .add(obj);
                          break;
                        }
                      }
                    }

                    for (var item in topLoosersDataList) {
                      if ((item.token ?? -1) == token) {
                        var obj = item;
                        obj.ltp = ltp;
                        obj.change = change;
                        obj.pChange = pChange;

                        final foundedIndex = topLoosersDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          topLoosersDataList[foundedIndex] = obj;
                          topLoosersStreamList
                              .elementAt(foundedIndex)
                              .sink
                              .add(obj);
                          break;
                        }
                      }
                    }

                    for (var item in marketMoverDataList) {
                      if ((item.token ?? -1) == token) {
                        var obj = item;
                        obj.ltp = ltp;
                        obj.change = change;
                        obj.pChange = pChange;

                        final foundedIndex = marketMoverDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          marketMoverDataList[foundedIndex] = obj;
                          marketMoversStreamList
                              .elementAt(foundedIndex)
                              .sink
                              .add(obj);
                          break;
                        }
                      }
                    }

                    for (var item in marketMoverByValueDataList) {
                      if ((item.token ?? -1) == token) {
                        var obj = item;
                        obj.ltp = ltp;
                        obj.change = change;
                        obj.pChange = pChange;

                        final foundedIndex =
                            marketMoverByValueDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          marketMoverByValueDataList[foundedIndex] = obj;
                          marketMoversByValueStreamList
                              .elementAt(foundedIndex)
                              .sink
                              .add(obj);
                          break;
                        }
                      }
                    }
                  }
                }
                break;

              default:
                break;
            }
          }
        }
      },
    );
  }

  void initalCallingMarketStatistics() {
    callTopGainerWithMarketID();
    callTopLoosersWithMarketID();
    callMarketMoversWithMarketID();
    callMarketMoversByValueWithMarketID();
  }

  void subscribeholdingDetailsLTPInfoTokensHolding() {
    if (unSubscribeholdingDetailsTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeholdingDetailsTokens);
    }

    subscribeholdingDetailsTokens =
        actualHoldingDataList.map((e) => (e.nSEToken.toString())).toList();

    subscribeholdingDetailsTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeholdingDetailsTokens);

    unSubscribeholdingDetailsTokens = subscribeholdingDetailsTokens;
  }

  void callTopGainerWithMarketID() {
    SocketIOManager().subscribeForTopGainers(GreekBase()
        .getMarketIDByMarketSegment(marketSegment: selectedTopGainerSegment));
  }

  void subscribeTopGainerLTPInfoTokens() {
    if (unSubscribeTopGainersTokens.isNotEmpty) {
      _unSubscribeTopGainerLTPInfoTokens();
    }

    subscribeTopGainersTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeTopGainersTokens);

    unSubscribeTopGainersTokens.clear();
    unSubscribeTopGainersTokens = subscribeTopGainersTokens;
  }

  void _unSubscribeTopGainerLTPInfoTokens() {
    if (unSubscribeTopGainersTokens.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(unSubscribeTopGainersTokens);
      unSubscribeTopGainersTokens.clear();
    }
  }

  void callTopLoosersWithMarketID() {
    SocketIOManager().subscribeForTopLoosers(GreekBase()
        .getMarketIDByMarketSegment(marketSegment: selectedTopLoosersSegment));
  }

  void subscribeTopLoosersLTPInfoTokens() {
    if (unSubscribeTopLoosersTokens.isNotEmpty) {
      _unSubscribeTopLoosersLTPInfoTokens();
    }

    subscribeTopLoosersTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeTopLoosersTokens);

    unSubscribeTopLoosersTokens.clear();
    unSubscribeTopLoosersTokens = subscribeTopLoosersTokens;
  }

  void _unSubscribeTopLoosersLTPInfoTokens() {
    if (unSubscribeTopGainersTokens.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(unSubscribeTopLoosersTokens);
      unSubscribeTopLoosersTokens.clear();
    }
  }

  void callMarketMoversWithMarketID() {
    SocketIOManager().subscribeForMarketMovers(GreekBase()
        .getMarketIDByMarketSegment(
            marketSegment: selectedMarketMoversSegment));
  }

  void subscribeMarketMoversLTPInfoTokens() {
    if (unSubscribeMarketMoversTokens.isNotEmpty) {
      _unSubscribeMarketMoversLTPInfoTokens();
    }

    subscribeMarketMoversTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeMarketMoversTokens);

    unSubscribeMarketMoversTokens.clear();
    unSubscribeMarketMoversTokens = subscribeMarketMoversTokens;
  }

  void _unSubscribeMarketMoversLTPInfoTokens() {
    if (unSubscribeMarketMoversTokens.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(unSubscribeMarketMoversTokens);
      unSubscribeMarketMoversTokens.clear();
    }
  }

  void callMarketMoversByValueWithMarketID() {
    SocketIOManager().subscribeForMarketMoversByValue(GreekBase()
        .getMarketIDByMarketSegment(
            marketSegment: selectedMarketMoversByValueSegment));
  }

  void subscribeMarketMoversByValueLTPInfoTokens() {
    if (unSubscribeMarketMoversByValueTokens.isNotEmpty) {
      _unSubscribeMarketMoversByValueLTPInfoTokens();
    }

    subscribeMarketMoversByValueTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager()
        .subscribeLTPInfoTokens(subscribeMarketMoversByValueTokens);

    unSubscribeMarketMoversByValueTokens.clear();
    unSubscribeMarketMoversByValueTokens = subscribeMarketMoversByValueTokens;
  }

  void _unSubscribeMarketMoversByValueLTPInfoTokens() {
    if (unSubscribeMarketMoversByValueTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeMarketMoversByValueTokens);
      unSubscribeMarketMoversByValueTokens.clear();
    }
  }

  Future<AdvanceDeclineResponseModel?> callAdvanceDeclineAPIS() async {
    return await _repository.getAdvanceDeclineAPi();
  }

  void callNetPositionMTMAPIS() async {
    _repository.getNetPositionMTMApi();
  }

  void callNewsDataAPIS() async {
    _repository.getNewsDataApi();
  }

  List<AreaSeries<ChartSampleData, DateTime>> getDefaultPanningSeries() {
    return <AreaSeries<ChartSampleData, DateTime>>[
      AreaSeries<ChartSampleData, DateTime>(
        dataSource: randomData,
        xValueMapper: (ChartSampleData sales, _) => sales.x as DateTime,
        yValueMapper: (ChartSampleData sales, _) => sales.y,
        gradient: LinearGradient(
            colors: <Color>[Colors.red[50]!, Colors.red[200]!, Colors.red],
            stops: const <double>[0.0, 0.4, 1.0],
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter),
      )
    ];
  }

  void getDateTimeData() {
    randomData = <ChartSampleData>[
      ChartSampleData(x: DateTime(1950, 3, 31), y: 100),
      ChartSampleData(x: DateTime(1950, 4, 31), y: 95),
      ChartSampleData(x: DateTime(1950, 5, 31), y: 90),
      ChartSampleData(x: DateTime(1950, 6, 1), y: 86),
      ChartSampleData(x: DateTime(1950, 7, 2), y: 55),
      ChartSampleData(x: DateTime(1950, 8, 3), y: 51),
      ChartSampleData(x: DateTime(1950, 9, 4), y: 46),
      ChartSampleData(x: DateTime(1950, 10, 5), y: 41),
      ChartSampleData(x: DateTime(1950, 11, 5), y: 0),
    ];
  }

  Future<void> getNewsData() async {
    var newsDataResponse = await _repository.getNewsData();
    getnewsSubject.sink.add(newsDataResponse);
  }

  Future<void> getPortfolioNewsData(String scripname) async {
    var newsDataResponse = await _repository.getPortfolioNewsData(scripname);
    if (newsDataResponse.isNotEmpty) {
      getPortfolionewsSubject.sink.add(newsDataResponse);
    }
  }
}
