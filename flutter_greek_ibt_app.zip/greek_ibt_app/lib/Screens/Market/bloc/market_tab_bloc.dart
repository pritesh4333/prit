import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_map_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/repository/option_repository.dart';

class MarketTabBloc extends GreekBlocs {
  late final MarketMapBloc marketBloc;
  final repository = OptionRepository();

  @override
  void disposeBloc() {}
}
