import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_tab_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/fii_dii_response_model.dart';
import 'package:rxdart/rxdart.dart';

class FiiDiiBloc extends MarketTabBloc {
  final BuildContext _fidiContext;

  FiiDiiBloc(this._fidiContext);

  FiiDiiType fiiDiiType = FiiDiiType.FII_Cash;
  FiiDiiInterval fiiDiiInterval = FiiDiiInterval.Daily;

  BehaviorSubject<List<FIIDIIResponseModelNew?>?> fiidiiSubject = BehaviorSubject();

  Stream<List<FIIDIIResponseModelNew?>?> get fiidiiObserver => fiidiiSubject.stream;
  List<FIIDIIResponseModelNew?> fiidiiArray = <FIIDIIResponseModelNew?>[];
  double maxVal = 0.0;
  double minVal = 0.0;

  void callFiiDiiAPI() {
    super
        .repository
        .getFiiDiiAPI(
          context: _fidiContext,
          type: fiiDiiType,
          interval: fiiDiiInterval,
        )
        .then((response) {
      for (final item in response) {
        if ((item.netAmount!.abs()) > 0) {
          maxVal = item.netAmount!.abs();
        }
      }
      minVal = maxVal * (-1);

      fiidiiSubject.sink.add(response);
    });
  }
}
