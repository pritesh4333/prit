import 'dart:async';
import 'dart:developer';
import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/streaming_data_source.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/margin_response_madel.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_map_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/advance_decline_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_news_response.dart';
import 'package:greek_ibt_app/Screens/Market/ui/top_gainer_lossers_full_screen_view.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_list_response_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_value_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/indian_indicesdata_response_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

class MarketMap extends StatefulWidget {
  const MarketMap({Key? key}) : super(key: key);

  @override
  _MarketMapState createState() => _MarketMapState();
}

class _MarketMapState extends State<MarketMap> with WidgetsBindingObserver {
  MarketMapBloc? _marketBloc;
  final PageController controller = PageController(initialPage: 0);
  Timer? timer;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    /*switch (state) {
      case AppLifecycleState.resumed:
        _marketBloc?.subscribeTopGainerLTPInfoTokens();
        _marketBloc?.subscribeTopLoosersLTPInfoTokens();
        _marketBloc?.subscribeMarketMoversLTPInfoTokens();
        _marketBloc?.subscribeMarketMoversByValueLTPInfoTokens();
        break;

      default:
        _marketBloc?.unSubscribeLTPInfo();
        break;
    }*/
  }

  @override
  void dispose() {
    _marketBloc?.disposeBloc();
    _marketBloc = null;
    timer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        GreekBase().subscribeIndicesIndexTokens();

        _marketBloc?.initalCallingMarketStatistics();
        _marketBloc?.callNetPositionMTMAPIS();

        SocketIOManager().marginDetailRequest();
        SocketIOManager().holdingValue();
        Future.delayed(const Duration(seconds: 1)).then((value) => timer =
            Timer.periodic(const Duration(seconds: 10),
                (Timer t) => _marketBloc?.getNewsData()));
      },
    );
  }

  var finalTotalInvested = 0.00;
  var finalCurrentValue = 0.00;
  var finalPreviousValue = 0.00;
  var finalDaysPnL = 0.00;
  @override
  Widget build(BuildContext context) {
    _marketBloc ??= MarketMapBloc();
    return SafeArea(
        child: SingleChildScrollView(
      physics: const ScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            _indicesView(),
            _advanceDeclineView(),
            const SizedBox(height: 8.0),
            _topGainerLossersView(),
            const SizedBox(height: 8.0),
            _portfolioView(),
            const SizedBox(height: 8.0),
            _latestNewsView(),
          ],
        ),
      ),
    ));
  }

  Widget _indicesView() {
    return StreamBuilder<List<BehaviorSubject<IndianIndicesResponseModel?>?>?>(
        stream: GreekBase().indicesSubject.stream,
        builder: (context, mainSnapshot) {
          if ((mainSnapshot.hasData) &&
              (mainSnapshot.data?.isNotEmpty ?? false)) {
            return Container(
              height: 90.0,
              padding: const EdgeInsets.only(
                  left: 2, top: 2.0, bottom: 2.0, right: 2),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: mainSnapshot.data!.length,
                itemBuilder: (context, index) {
                  return StreamBuilder<IndianIndicesResponseModel?>(
                      stream: mainSnapshot.data?[index]?.stream,
                      builder: (context, innerSnapshot) {
                        return GreekBase().showIndicesBox(
                            context,
                            innerSnapshot.data?.token ?? '',
                            '${innerSnapshot.data?.last?.toStringAsFixed(2) ?? 0}',
                            '${innerSnapshot.data?.change?.toStringAsFixed(2) ?? 0.0}',
                            '${innerSnapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}');
                      });
                },
              ),
            );
          }

          return Container();
        });
  }

  _createBoxDecoration() => BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: ConstantColors.borderColor,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(3),
      );

  Widget _advanceDeclineView() {
    return FutureBuilder<AdvanceDeclineResponseModel?>(
      future: _marketBloc?.callAdvanceDeclineAPIS(),
      builder: (context, snapshot) {
        int advance =
            (snapshot.data != null) ? (snapshot.data!.advances ?? 0) : 0;
        int decline =
            (snapshot.data != null) ? (snapshot.data!.declines ?? 0) : 0;
        int total =
            (snapshot.data != null) ? (snapshot.data!.total ?? 100) : 100;

        return Container(
          height: 73.0,
          decoration: _createBoxDecoration(),
          child: Column(
            children: [
              const Padding(
                padding:
                    EdgeInsets.only(left: 10, right: 10, top: 5, bottom: 5),
                child: Text(
                  "Advances / Declines",
                  style: TextStyle(
                      color: Color(0xFF333333),
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      advance.toString(),
                      style: const TextStyle(
                          color: Color(0xFF00CC33),
                          fontWeight: FontWeight.bold,
                          fontSize: 15),
                    ),
                    Text(
                      decline.toString(),
                      style: const TextStyle(
                          color: Color(0xFFFF3333),
                          fontWeight: FontWeight.bold,
                          fontSize: 15),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                    left: 10, right: 10, top: 3, bottom: 8),
                child: StepProgressIndicator(
                  totalSteps: (total <= 0) ? 100 : total,
                  currentStep: advance,
                  size: 10,
                  padding: 0,
                  selectedColor: ((advance == 0) && (decline == 0))
                      ? Colors.grey
                      : Colors.green,
                  unselectedColor: ((advance == 0) && (decline == 0))
                      ? Colors.grey
                      : Colors.red,
                  roundedEdges: const Radius.circular(3),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _topGainerLossersView() => SizedBox(
        height: 318.0,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: 4,
          separatorBuilder: (_, __) => const SizedBox(width: 20.0),
          itemBuilder: (horizontalListContext, horizontalListindex) {
            var titleName = '';
            List<String>? selectedDropDownValues = <String>[];
            String? selectedDropDownItem = '';

            Stream<Object?>? currentStream;

            switch (horizontalListindex) {
              case 0:
                titleName = 'top gainers';
                selectedDropDownValues = _marketBloc?.topGainerMaketSegment;
                selectedDropDownItem = _marketBloc?.selectedTopGainerSegment;
                _marketBloc!.selectedDropValue = selectedDropDownItem ?? '';
                currentStream = SocketIOManager().topGainersObservable;
                break;

              case 1:
                titleName = 'top losers';
                selectedDropDownValues = _marketBloc?.topLoosersMaketSegment;
                selectedDropDownItem = _marketBloc?.selectedTopLoosersSegment;
                _marketBloc!.selectedDropValue = selectedDropDownItem ?? '';
                currentStream = SocketIOManager().topLoosersObservable;
                break;

              case 2:
                titleName = 'market movers';
                selectedDropDownValues = _marketBloc?.marketMoversMaketSegment;
                selectedDropDownItem = _marketBloc?.selectedMarketMoversSegment;
                _marketBloc!.selectedDropValue = selectedDropDownItem ?? '';
                currentStream = SocketIOManager().marketMOversObservable;
                break;

              case 3:
                titleName = 'market movers (by value)';
                selectedDropDownValues =
                    _marketBloc?.marketMoversByValueMaketSegment;
                selectedDropDownItem =
                    _marketBloc?.selectedMarketMoversByValueSegment;
                _marketBloc!.selectedDropValue = selectedDropDownItem ?? '';
                currentStream = SocketIOManager().marketMoverByValueObservable;
                break;

              default:
                break;
            }

            return OpenContainer(
              transitionType: ContainerTransitionType.fade,
              closedShape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(3.0),
                ),
                side: BorderSide(
                  width: .7,
                  color: ConstantColors.borderColor,
                ),
              ),
              closedBuilder: (_, __) => SizedBox(
                width: (MediaQuery.of(horizontalListContext).size.width - 45.0),
                child: Padding(
                  padding: const EdgeInsets.all(1.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 40.0,
                        child: Container(
                          padding: const EdgeInsets.only(left: 20.0),
                          alignment: Alignment.centerLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Flexible(
                                child: Text(
                                  titleName.toUpperCase(),
                                  style: GreekTextStyle.heading18,
                                  //maxLines: 2,
                                ),
                              ),
                              StreamBuilder<bool>(
                                stream: _marketBloc!.dropDownValueTg.stream,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData &&
                                      snapshot.data != null &&
                                      snapshot.data == true) {
                                    if (snapshot.data == true) {
                                      switch (horizontalListindex) {
                                        case 0:
                                          selectedDropDownValues = _marketBloc
                                              ?.topGainerMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedTopGainerSegment;

                                          currentStream = SocketIOManager()
                                              .topGainersObservable;
                                          break;

                                        case 1:
                                          selectedDropDownValues = _marketBloc
                                              ?.topLoosersMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedTopLoosersSegment;

                                          currentStream = SocketIOManager()
                                              .topLoosersObservable;
                                          break;

                                        case 2:
                                          selectedDropDownValues = _marketBloc
                                              ?.marketMoversMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedMarketMoversSegment;

                                          currentStream = SocketIOManager()
                                              .marketMOversObservable;
                                          break;

                                        case 3:
                                          selectedDropDownValues = _marketBloc
                                              ?.marketMoversByValueMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedMarketMoversByValueSegment;

                                          currentStream = SocketIOManager()
                                              .marketMoverByValueObservable;
                                          break;

                                        default:
                                          break;
                                      }
                                    } else {
                                      switch (horizontalListindex) {
                                        case 0:
                                          selectedDropDownValues = _marketBloc
                                              ?.topGainerMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedTopGainerSegment;

                                          currentStream = SocketIOManager()
                                              .topGainersObservable;
                                          break;

                                        case 1:
                                          selectedDropDownValues = _marketBloc
                                              ?.topLoosersMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedTopLoosersSegment;

                                          currentStream = SocketIOManager()
                                              .topLoosersObservable;
                                          break;

                                        case 2:
                                          selectedDropDownValues = _marketBloc
                                              ?.marketMoversMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedMarketMoversSegment;

                                          currentStream = SocketIOManager()
                                              .marketMOversObservable;
                                          break;

                                        case 3:
                                          selectedDropDownValues = _marketBloc
                                              ?.marketMoversByValueMaketSegment;
                                          selectedDropDownItem = _marketBloc
                                              ?.selectedMarketMoversByValueSegment;

                                          currentStream = SocketIOManager()
                                              .marketMoverByValueObservable;
                                          break;

                                        default:
                                          break;
                                      }
                                    }

                                    return PopupMenuButton<String>(
                                      itemBuilder: (context) {
                                        return selectedDropDownValues!
                                            .toSet()
                                            .map((str) {
                                          return PopupMenuItem(
                                            value: str,
                                            child: Text(
                                              str,
                                              style: GreekTextStyle
                                                  .marketStatisticsDropdownTextStyle,
                                            ),
                                          );
                                        }).toList();
                                      },
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          Text(
                                            selectedDropDownItem!,
                                            style: GreekTextStyle
                                                .marketStatisticsDropdownTextStyle,
                                          ),
                                          const Icon(
                                            Icons.arrow_drop_down,
                                            color: ConstantColors.black,
                                          ),
                                        ],
                                      ),
                                      onSelected: (data) {
                                        if (data.isNotEmpty) {
                                          switch (horizontalListindex) {
                                            case 0:
                                              _marketBloc
                                                      ?.selectedTopGainerSegment =
                                                  data;
                                              _marketBloc
                                                  ?.callTopGainerWithMarketID();

                                              setState(() {});
                                              break;

                                            case 1:
                                              _marketBloc
                                                      ?.selectedTopLoosersSegment =
                                                  data;
                                              _marketBloc
                                                  ?.callTopLoosersWithMarketID();

                                              setState(() {});
                                              break;

                                            case 2:
                                              _marketBloc
                                                      ?.selectedMarketMoversSegment =
                                                  data;
                                              _marketBloc
                                                  ?.callMarketMoversWithMarketID();

                                              setState(() {});
                                              break;

                                            case 3:
                                              _marketBloc
                                                      ?.selectedMarketMoversByValueSegment =
                                                  data;
                                              _marketBloc
                                                  ?.callMarketMoversByValueWithMarketID();

                                              setState(() {});
                                              break;

                                            default:
                                              break;
                                          }

                                          setState(() {});
                                        }
                                      },
                                    );
                                  } else {
                                    return const SizedBox.shrink();
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: 1.0,
                        color: ConstantColors.dividerColor,
                      ),
                      Flexible(
                        fit: FlexFit.loose,
                        child: StreamBuilder<Object?>(
                          stream: currentStream,
                          builder: (streamContext, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data != null) {
                                final symbolDataList = <StreamingDataModel>[];
                                if (snapshot.data is List) {
                                  final _list = snapshot.data! as List;
                                  if (_list.isNotEmpty) {
                                    final _tempTopList = _list
                                        .map(
                                          (e) => SymbolList.fromJson(
                                            json: e,
                                            isWatchListScreen: false,
                                          ),
                                        )
                                        .toList();

                                    for (final item in _tempTopList) {
                                      if ((item.token ?? 0) > 0) {
                                        final obj = StreamingDataModel(
                                          token: item.token,
                                          symbol: (item.token
                                                      ?.toAssetType()
                                                      .toLowerCase() ==
                                                  "equity")
                                              ? "${item.description} - ${item.seriesName}"
                                              : item.description,
                                          ltp: item.ltp,
                                          change: item.change,
                                          preChange: item.pChange,
                                        );

                                        symbolDataList.add(obj);
                                      }
                                    }

                                    if (symbolDataList.isNotEmpty) {
                                      return GreekBase().scriptListView(
                                          scripContext: streamContext,
                                          dataList: symbolDataList,
                                          isScrollable: false,
                                          isFrom: "topgainer");
                                    }
                                  }

                                  /*switch (horizontalListindex) {
                                    case 0:
                                      if (_list.isNotEmpty) {
                                        _marketBloc?.topGainersDataList = _list
                                            .map(
                                              (e) =>
                                                  SymbolList.fromJson(json: e),
                                            )
                                            .toList();

                                        _marketBloc?.subscribeTopGainersTokens
                                            .clear();
                                        _marketBloc?.subscribeTopGainersTokens =
                                            List<String>.from(
                                          _marketBloc?.topGainersDataList
                                                  .map(
                                                    (e) => e.token!.toString(),
                                                  )
                                                  .toList() ??
                                              [],
                                        );

                                        for (final element in (_marketBloc
                                                ?.topGainersStreamList ??
                                            [])) {
                                          element.close();
                                        }
                                        _marketBloc?.topGainersStreamList
                                            .clear();
                                        _marketBloc?.topGainersStreamList =
                                            List<
                                                BehaviorSubject<
                                                    SymbolList?>>.from(
                                          _marketBloc?.topGainersDataList
                                                  .map(
                                                    (e) => BehaviorSubject<
                                                        SymbolList?>.seeded(e),
                                                  )
                                                  .toList() ??
                                              [],
                                        );
                                      }

                                      _marketBloc
                                          ?.subscribeTopGainerLTPInfoTokens();

                                      return GreekBase().scriptListView(
                                        dataList:
                                            _marketBloc?.topGainersStreamList ??
                                                [],
                                        watchBloc: null,
                                        isScrollable: false,
                                      );

                                    case 1:
                                      if (_list.isNotEmpty) {
                                        _marketBloc?.topLoosersDataList = _list
                                            .map(
                                              (e) =>
                                                  SymbolList.fromJson(json: e),
                                            )
                                            .toList();

                                        _marketBloc?.subscribeTopLoosersTokens
                                            .clear();
                                        _marketBloc?.subscribeTopLoosersTokens =
                                            List<String>.from(
                                          _marketBloc?.topLoosersDataList
                                                  .map(
                                                    (e) => e.token!.toString(),
                                                  )
                                                  .toList() ??
                                              [],
                                        );

                                        for (final element in (_marketBloc
                                                ?.topLoosersStreamList ??
                                            [])) {
                                          element.close();
                                        }
                                        _marketBloc?.topLoosersStreamList
                                            .clear();
                                        _marketBloc?.topLoosersStreamList =
                                            List<
                                                BehaviorSubject<
                                                    SymbolList?>>.from(
                                          _marketBloc?.topLoosersDataList
                                                  .map(
                                                    (e) => BehaviorSubject<
                                                        SymbolList?>.seeded(e),
                                                  )
                                                  .toList() ??
                                              [],
                                        );
                                      }

                                      _marketBloc
                                          ?.subscribeTopLoosersLTPInfoTokens();

                                      return GreekBase().scriptListView(
                                        dataList:
                                            _marketBloc?.topLoosersStreamList ??
                                                [],
                                        watchBloc: null,
                                        isScrollable: false,
                                      );

                                    case 2:
                                      if (_list.isNotEmpty) {
                                        _marketBloc?.marketMoverDataList = _list
                                            .map(
                                              (e) =>
                                                  SymbolList.fromJson(json: e),
                                            )
                                            .toList();

                                        _marketBloc?.subscribeMarketMoversTokens
                                            .clear();
                                        _marketBloc
                                                ?.subscribeMarketMoversTokens =
                                            List<String>.from(
                                          _marketBloc?.marketMoverDataList
                                                  .map(
                                                    (e) => e.token!.toString(),
                                                  )
                                                  .toList() ??
                                              [],
                                        );

                                        for (final element in (_marketBloc
                                                ?.marketMoversStreamList ??
                                            [])) {
                                          element.close();
                                        }
                                        _marketBloc?.marketMoversStreamList
                                            .clear();
                                        _marketBloc?.marketMoversStreamList =
                                            List<
                                                BehaviorSubject<
                                                    SymbolList?>>.from(
                                          _marketBloc?.marketMoverDataList
                                                  .map(
                                                    (e) => BehaviorSubject<
                                                        SymbolList?>.seeded(e),
                                                  )
                                                  .toList() ??
                                              [],
                                        );
                                      }

                                      _marketBloc
                                          ?.subscribeMarketMoversLTPInfoTokens();

                                      return GreekBase().scriptListView(
                                        dataList: _marketBloc
                                                ?.marketMoversStreamList ??
                                            [],
                                        watchBloc: null,
                                        isScrollable: false,
                                      );

                                    case 3:
                                      if (_list.isNotEmpty) {
                                        _marketBloc?.marketMoverByValueDataList =
                                            _list
                                                .map(
                                                  (e) => SymbolList.fromJson(
                                                      json: e),
                                                )
                                                .toList();

                                        _marketBloc
                                            ?.subscribeMarketMoversByValueTokens
                                            .clear();
                                        _marketBloc
                                                ?.subscribeMarketMoversByValueTokens =
                                            List<String>.from(
                                          _marketBloc
                                                  ?.marketMoverByValueDataList
                                                  .map(
                                                    (e) => e.token!.toString(),
                                                  )
                                                  .toList() ??
                                              [],
                                        );

                                        for (final element in (_marketBloc
                                                ?.marketMoversByValueStreamList ??
                                            [])) {
                                          element.close();
                                        }
                                        _marketBloc
                                            ?.marketMoversByValueStreamList
                                            .clear();
                                        _marketBloc
                                                ?.marketMoversByValueStreamList =
                                            List<
                                                BehaviorSubject<
                                                    SymbolList?>>.from(
                                          _marketBloc
                                                  ?.marketMoverByValueDataList
                                                  .map(
                                                    (e) => BehaviorSubject<
                                                        SymbolList?>.seeded(e),
                                                  )
                                                  .toList() ??
                                              [],
                                        );
                                      }

                                      _marketBloc
                                          ?.subscribeMarketMoversByValueLTPInfoTokens();

                                      return GreekBase().scriptListView(
                                        dataList: _marketBloc
                                                ?.marketMoversByValueStreamList ??
                                            [],
                                        watchBloc: null,
                                        isScrollable: false,
                                      );

                                    default:
                                      return GreekBase().noDataAvailableView();
                                  }*/
                                }
                              }
                            } else {
                              return const Center(
                                child: SizedBox.square(
                                  dimension: 35,
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            }

                            return Center(
                              child: SizedBox(
                                height:
                                    MediaQuery.of(streamContext).size.height /
                                        2,
                                child: Center(
                                    child: GreekBase().noDataAvailableView()),
                              ),
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ),
              ),
              openBuilder: (openContext, _) {
                return TopGainerLossersFullScreen(
                  marketMapBloc: _marketBloc!,
                  selectedTabIndex: horizontalListindex,
                );
              },
            );
          },
        ),
      );

  Widget _portfolioView() {
    return Container(
      decoration: _createBoxDecoration(),
      child: Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "MY PORTFOLIO",
                  style: GreekTextStyle.marketmapportfolioheader,
                ),
                TextButton(
                  onPressed: () {
                    GreekBase()
                        .commonListenObserver
                        .sink
                        .add(CommonListenID.navigateFundScreen);
                    GreekBase()
                        .userActionForFundScreenObserver
                        .sink
                        .add(FundScreenUserAction.add_fund);
                  },
                  child: Text(
                    "ADD FUND",
                    style: GreekTextStyle.marketmapportfolioAddfund,
                  ),
                )
              ],
            ),
            const Divider(
              height: 1,
              color: Color(0xFFE1E1E1),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, right: 8.0),
              child: StreamBuilder<Map<String, dynamic>?>(
                  stream: SocketIOManager().holdingResponseObservable,
                  builder: (context, snapshot) {
                    HoldingValueResponseModel? obj;
                    if (snapshot.data != null) {
                      final keys = snapshot.data!.keys.toList();

                      for (var item in keys) {
                        if (item.irisResponseStreamingType ==
                            IrisResponseStreamingType.HoldingValueInfoResp) {
                          final holdingValueResponse = snapshot.data![item];
                          log(holdingValueResponse.toString());
                          obj = HoldingValueResponseModel.fromJson(
                              holdingValueResponse);
                        }
                      }
                    }
                    return StreamBuilder<bool>(
                        stream: _marketBloc?.mainStream.stream,
                        builder: (context, snapshot) {
                          if (snapshot.hasData == true) {
                            finalTotalInvested = 0.00;
                            finalCurrentValue = 0.00;
                            finalPreviousValue = 0.00;
                            finalDaysPnL = 0.0;
                            for (int i = 0;
                                i <
                                    int.parse(_marketBloc
                                            ?.actualHoldingDataList.length
                                            .toString() ??
                                        "");
                                i++) {
                              var totalInvested = double.parse(_marketBloc
                                          ?.actualHoldingDataList[i].hPrice
                                          .toString() ??
                                      "") *
                                  double.parse(_marketBloc
                                          ?.actualHoldingDataList[i].qty
                                          .toString() ??
                                      "");
                              finalTotalInvested += totalInvested;
                              var currentValue = double.parse(_marketBloc
                                          ?.actualHoldingDataList[i].ltp
                                          .toString() ??
                                      "") *
                                  double.parse(_marketBloc
                                          ?.actualHoldingDataList[i].qty
                                          .toString() ??
                                      "");
                              // var previousValue = double.parse(_marketBloc?.actualHoldingDataList[i].close.toString()) * double.parse(_marketBloc?.actualHoldingDataList[i].qty.toString());
                              var mtm = (double.parse(_marketBloc
                                              ?.actualHoldingDataList[i].ltp
                                              .toString() ??
                                          "") -
                                      double.parse(_marketBloc
                                              ?.actualHoldingDataList[i].hPrice
                                              .toString() ??
                                          "")) *
                                  int.parse(_marketBloc
                                          ?.actualHoldingDataList[i].qty
                                          .toString() ??
                                      "");
                              var daysmtm = (double.parse(_marketBloc
                                              ?.actualHoldingDataList[i].ltp
                                              .toString() ??
                                          "") -
                                      double.parse(_marketBloc
                                              ?.actualHoldingDataList[i].close
                                              .toString() ??
                                          "")) *
                                  int.parse(_marketBloc
                                          ?.actualHoldingDataList[i].qty
                                          .toString() ??
                                      "");
                              finalCurrentValue =
                                  (finalCurrentValue) + currentValue;
                              // finalPreviousValue += previousValue;
                              finalDaysPnL = finalDaysPnL + daysmtm;
                              finalPreviousValue = (finalPreviousValue) + (mtm);
                            }
                            var balance =
                                double.parse(finalCurrentValue.toString()) -
                                    double.parse(finalTotalInvested.toString());
                            // var todays-PnL = double.parse(finalCurrentValue.toString()) - double.parse(finalPreviousValue.toString());
                            var todaysPnL = finalDaysPnL.toString();

                            _marketBloc?.currentBalance.sink
                                .add(balance.toString());
                          }
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "PORTFOLIO VALUE",
                                style: GreekTextStyle.marketmapportfoliodata,
                              ),
                              Text(
                                double.parse(obj?.hValue ?? '0.00')
                                    .toStringAsFixed(2),
                                style: GreekTextStyle.marketmapportfoliodata,
                              )
                            ],
                          );
                        });
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, right: 8.0),
              child: StreamBuilder<String>(
                  stream: _marketBloc?.currentBalance.stream,
                  builder: (context, snapshot) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "OVERALL P&L",
                          style: GreekTextStyle.marketmapportfoliodata,
                        ),
                        Text(
                          double.parse(snapshot.data ?? '0.00')
                              .toStringAsFixed(2),
                          style: GreekTextStyle.marketmapportfoliodata,
                        ),
                      ],
                    );
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, right: 8.0),
              child: StreamBuilder<Map<String, dynamic>?>(
                  stream: SocketIOManager().marginResponseObservable,
                  builder: (context, snapshot) {
                    MarginResponseModel? obj;
                    if (snapshot.data != null) {
                      final keys = snapshot.data!.keys.toList();

                      for (var item in keys) {
                        if (item.irisResponseStreamingType ==
                            IrisResponseStreamingType.MarginDetailResponse) {
                          final marginDetailsResponse = snapshot.data![item];
                          log(marginDetailsResponse.toString());
                          obj = MarginResponseModel.fromJson(
                              marginDetailsResponse);
                        }
                      }
                    }
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "CASH AVAILABLE",
                          style: GreekTextStyle.marketmapportfoliodata,
                        ),
                        Text(
                          double.parse(obj?.availFund ?? '0.00')
                              .toStringAsFixed(2),
                          style: GreekTextStyle.marketmapportfoliodata,
                        ),
                      ],
                    );
                  }),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    GreekBase()
                        .commonListenObserver
                        .sink
                        .add(CommonListenID.navigateFundScreen);
                    GreekBase()
                        .userActionForFundScreenObserver
                        .sink
                        .add(FundScreenUserAction.portfolio);
                  },
                  child: const Text(
                    "More",
                    style: TextStyle(
                      color: Color(0xFF0098FE),
                      fontWeight: FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _latestNewsView() {
    var height = MediaQuery.of(context).viewPadding.bottom;
    return Container(
      decoration: _createBoxDecoration(),
      margin: EdgeInsets.only(bottom: height),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 10, top: 15, bottom: 15),
                  child: Text(
                    "LATEST NEWS",
                    style: GreekTextStyle.marketmapnewsheader,
                  ),
                ),
              ],
            ),
            const Divider(
              height: 1,
              color: Color(0xFFE1E1E1),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, right: 8.0),
              child: StreamBuilder<List<GetNewsResponse>>(
                  stream: _marketBloc!.getnewsSubject.stream,
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Column(
                        children: [
                          ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: snapshot.data?.length,
                            itemBuilder: (context, index) {
                              return Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10,
                                        right: 10,
                                        top: 10,
                                        bottom: 10),
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        " ${snapshot.data?[index].heading ?? ''}",
                                        style: GreekTextStyle.marketmapnewsdata,
                                        maxLines: 2,
                                      ),
                                    ),
                                  ),
                                  const Divider(
                                    thickness: 1,
                                  )
                                ],
                              );
                            },
                          ),
                        ],
                      );
                    } else {
                      return SizedBox(
                        height: MediaQuery.of(context).size.height / 2,
                        child: Center(child: GreekBase().noDataAvailableView()),
                      );
                    }
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
