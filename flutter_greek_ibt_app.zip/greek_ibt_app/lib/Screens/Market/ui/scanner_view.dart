import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/scanners_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/most_active_future_data_model.dart';
import 'package:greek_ibt_app/Utilities/no_data_with_progress_indicator.dart';
import 'package:rect_getter/rect_getter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/highest_rollover_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/short_build_response_model.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({Key? key}) : super(key: key);

  @override
  _ScannerScreenState createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  WatchListBloc? _watchListBloc;
  int cliclableindex = 0;
  List<String> scannerList = [
    'MOST ACTIVE FUTURES',
    'MOST ACTIVE STOCK OPTION',
    'MOST ACTIVE INDEX OPTION',
    'LONG BUILD UP (OI UP - PRICE UP)',
    'SHORT BUILD UP (OI UP - PRICE DOWN)',
    'SHORT UNWINDING UP (OI UP - PRICE DOWN)',
    'LONG UNWINDING UP (OI UP - PRICE UP)',
    'HIGHEST ROLL OVER',
    'LOWEST ROLL OVER',
  ];

  bool isScannerFullScreen = false;
  bool isScannerScreen = true;

  ScannerBloc? scannerBloc;

  Widget _mostActiveFeautures() {
    return StreamBuilder<List<MostActiveFutureData>>(
        stream: scannerBloc?.mostActiveFeatureResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            int lengthData = snapshot.data?.length ?? 0;
            if (lengthData <= 0) {
              return NoDatWithProgressIndicator(
                topSpace: MediaQuery.of(context).size.height / 2,
                showHide: false,
                message: '',
              );
            }
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStream.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listMostActive(
                        symbolStream:
                            scannerBloc?.ltpInfoStream.elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          /*  return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          ); */
          return NoDatWithProgressIndicator(
            topSpace: MediaQuery.of(context).size.height / 2,
            showHide: true,
            message: 'Fetching data',
          );
        });
  }

  Widget listMostActive({
    required BehaviorSubject<MostActiveFutureData>? symbolStream,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<MostActiveFutureData>(
        stream: symbolStream?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listMostActiveStock({
    required BehaviorSubject<MostActiveFutureData>? symbolStream1,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<MostActiveFutureData>(
        stream: symbolStream1?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listMostActiveIndex({
    required BehaviorSubject<MostActiveFutureData>? symbolStream2,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<MostActiveFutureData>(
        stream: symbolStream2?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listLongBuildup({
    required BehaviorSubject<ShortBuildupResModel>? symbolStream,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<ShortBuildupResModel>(
        stream: symbolStream?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listShortBuildup({
    required BehaviorSubject<ShortBuildupResModel>? symbolStreamShortBuild,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<ShortBuildupResModel>(
        stream: symbolStreamShortBuild?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listShortUnwinding({
    required BehaviorSubject<ShortBuildupResModel>? symbolStreamShortUnwinding,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<ShortBuildupResModel>(
        stream: symbolStreamShortUnwinding?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listLongUnwinding({
    required BehaviorSubject<ShortBuildupResModel>? symbolStreamLongUnwinding,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<ShortBuildupResModel>(
        stream: symbolStreamLongUnwinding?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(snapshot.data?.token ?? ''),
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            int.parse(snapshot.data?.token ?? ''),
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${double.parse(snapshot.data?.change ?? '').toStringAsFixed(2)}(${double.parse(snapshot.data?.perChange ?? '').toStringAsFixed(2)}%)',
                              style:
                                  ((double.parse('${snapshot.data?.change}')) >=
                                          0)
                                      ? GreekTextStyle.headingWatchlistLTPGreen
                                      : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listHighestRollOver({
    required BehaviorSubject<Datum>? symbolStream,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<Datum>(
        stream: symbolStream?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        snapshot.data?.token,
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            snapshot.data?.token,
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${snapshot.data?.change?.toStringAsFixed(2)}(${snapshot.data?.perChange?.toStringAsFixed(2)}%)',
                              // style: GreekTextStyle.headingWatchlistLTPRed,
                              style: ((snapshot.data?.change ?? 0) == 0)
                                  ? GreekTextStyle.headingWatchlistLTPGreen
                                  : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget listLowestRollOver({
    required BehaviorSubject<Datum>? symbolStreamLowestRollOver,
    required int index,
  }) {
    return RectGetter(
      key: scannerBloc?.listTileRectKey[index],
      child: StreamBuilder<Datum>(
        stream: symbolStreamLowestRollOver?.stream,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Dismissible(
                  key: Key(index.toString()),
                  background: Container(
                    color: ConstantColors.buyColor,
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'BUY',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  secondaryBackground: Container(
                    color: ConstantColors.sellColor,
                    padding: const EdgeInsets.only(right: 20.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'SELL',
                        style: GreekTextStyle.heading16,
                      ),
                    ),
                  ),
                  confirmDismiss: //_swapActionOnPress,
                      (DismissDirection direction) async {
                    _watchListBloc?.unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: streamContext,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        snapshot.data?.token,
                        (direction == DismissDirection.startToEnd)
                            ? OrderAction.buy
                            : OrderAction.sell,
                        OrderMode.newOrder,
                        ScriptInfoTab.order.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      setState(
                          () => _watchListBloc?.getWatchListDataByGroupName());
                    }
                    return;
                  },
                  child: TextButton(
                    onPressed: () async {
                      if (snapshot.hasData) {
                        _watchListBloc?.unSubscribeLTPInfo();
                        final popResult = await GreekNavigator.pushNamed(
                          context: streamContext,
                          routeName: GreekScreenNames.place_order,
                          arguments: [
                            snapshot.data?.token,
                            OrderAction.buy,
                            OrderMode.newOrder,
                            ScriptInfoTab.overview.index,
                          ],
                        );

                        if (popResult == PopAction.rebuildWidget) {
                          setState(() =>
                              _watchListBloc?.getWatchListDataByGroupName());
                        }
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.description ?? '',
                              style: GreekTextStyle.watchlistText,
                            ),
                            Text(
                              double.parse(snapshot.data?.ltp.toString() ?? '')
                                  .toStringAsFixed(2),
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data?.exchange?.toUpperCase() ?? '',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '${snapshot.data?.change?.toStringAsFixed(2)}(${snapshot.data?.perChange?.toStringAsFixed(2)}%)',
                              // style: GreekTextStyle.headingWatchlistLTPRed,
                              style: ((snapshot.data?.change ?? 0) == 0)
                                  ? GreekTextStyle.headingWatchlistLTPGreen
                                  : GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(
                  thickness: 0.8,
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget _mostActiveStockOption() {
    return StreamBuilder<List<MostActiveFutureData>>(
        stream: scannerBloc?.mostActiveStockOptionResultObserver,
        builder: (context, snapshot) {
          int stockLength = scannerBloc?.ltpInfoStreamStock.length ?? 0;
          if (snapshot.hasData && stockLength != 0) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStreamStock.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listMostActiveStock(
                        symbolStream1:
                            scannerBloc?.ltpInfoStreamStock.elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _mostActiveIndexOption() {
    return StreamBuilder<List<MostActiveFutureData>>(
        stream: scannerBloc?.mostActiveIndexOptionResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStreamIndex.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listMostActiveIndex(
                        symbolStream2:
                            scannerBloc?.ltpInfoStreamIndex.elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _longBuildup() {
    return StreamBuilder<List<ShortBuildupResModel>>(
        stream: scannerBloc?.longBuildupResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStream1.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listLongBuildup(
                        symbolStream:
                            scannerBloc?.ltpInfoStream1.elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _shortBuildUp() {
    return StreamBuilder<List<ShortBuildupResModel>>(
        stream: scannerBloc?.shortBuildupResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStreamShortBuildup.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listShortBuildup(
                        symbolStreamShortBuild: scannerBloc
                            ?.ltpInfoStreamShortBuildup
                            .elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _shortUnwinding() {
    return StreamBuilder<List<ShortBuildupResModel>>(
        stream: scannerBloc?.shortUnwindingResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStreamShortUnwinding.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listShortUnwinding(
                        symbolStreamShortUnwinding: scannerBloc
                            ?.ltpInfoStreamShortUnwinding
                            .elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _longUnwinding() {
    return StreamBuilder<List<ShortBuildupResModel>>(
        stream: scannerBloc?.longUnwindingResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStreamLongUnwinding.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listLongUnwinding(
                        symbolStreamLongUnwinding: scannerBloc
                            ?.ltpInfoStreamLongUnwinding
                            .elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _highestRollOver() {
    return StreamBuilder<List<Datum>>(
        stream: scannerBloc?.highestRollOverResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStream2.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listHighestRollOver(
                        symbolStream:
                            scannerBloc?.ltpInfoStream2.elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _lowestRollOver() {
    return StreamBuilder<List<Datum>>(
        stream: scannerBloc?.lowestRollOverResultObserver,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: scannerBloc?.ltpInfoStreamLowestRollOver.length,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      listLowestRollOver(
                        symbolStreamLowestRollOver: scannerBloc
                            ?.ltpInfoStreamLowestRollOver
                            .elementAt(index),
                        index: index,
                      ),
                    ],
                  );
                });
          }
          return SizedBox(
            height: MediaQuery.of(context).size.height / 2,
            child: Center(child: GreekBase().noDataAvailableView()),
          );
        });
  }

  Widget _fullScreenScannerView() {
    return Visibility(
      visible: isScannerFullScreen,
      child: Container(
        padding: const EdgeInsets.only(left: 10.0, right: 15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              height: 40.0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  IconButton(
                    onPressed: () {
                      setState(
                        () {
                          isScannerFullScreen = false;
                          isScannerScreen = true;
                        },
                      );
                    },
                    icon: const Icon(Icons.arrow_back_ios),
                  ),
                  const SizedBox(
                    width: 10.0,
                  ),
                  Text(
                    scannerList[cliclableindex],
                    style: const TextStyle(
                        fontSize: 14.0, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            if (cliclableindex == 0) _mostActiveFeautures(),
            if (cliclableindex == 1) _mostActiveStockOption(),
            if (cliclableindex == 2) _mostActiveIndexOption(),
            if (cliclableindex == 3) _longBuildup(),
            if (cliclableindex == 4) _shortBuildUp(),
            if (cliclableindex == 5) _shortUnwinding(),
            if (cliclableindex == 6) _longUnwinding(),
            if (cliclableindex == 7) _highestRollOver(),
            if (cliclableindex == 8) _lowestRollOver(),
          ],
        ),
      ),
    );
  }

  Widget _scannerList() {
    return SingleChildScrollView(
      child: Container(
        color: Colors.white,
        margin: const EdgeInsets.only(top: 5.0),
        child: Column(
          children: [
            Visibility(
              visible: isScannerScreen,
              child: SizedBox(
                height: MediaQuery.of(context).size.height / 1.35,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: scannerList.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        setState(() {
                          isScannerFullScreen = true;
                          isScannerScreen = false;
                        });

                        cliclableindex = index;
                        scannerList[index]
                                .toLowerCase()
                                .contains('long build up')
                            ? scannerBloc?.callLongBuildUP()
                            : scannerList[index]
                                    .toLowerCase()
                                    .contains('short build up')
                                ? scannerBloc?.callShortBuildUP()
                                : scannerList[index]
                                        .toLowerCase()
                                        .contains('short unwinding')
                                    ? scannerBloc?.callShortUnwindingUp()
                                    : scannerList[index]
                                            .toLowerCase()
                                            .contains('long unwinding')
                                        ? scannerBloc?.callLongUnWInding()
                                        : scannerList[index]
                                                .toLowerCase()
                                                .contains('highest roll')
                                            ? scannerBloc?.callHighestRollOver()
                                            : scannerBloc?.callLowestRollOver();

                        log('${scannerList[index]}======clicked');
                      },
                      child: Container(
                        height: 50,
                        margin: const EdgeInsets.only(
                            top: 8.0, left: 8.0, right: 8.0),
                        padding: const EdgeInsets.all(8.0),
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          color: const Color(0xFFEEEEEE),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        child: Text(
                          scannerList[index],
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            _fullScreenScannerView(),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    scannerBloc = ScannerBloc(context);
    /* scannerBloc?.callHighestRollOver();
    scannerBloc?.callLowestRollOver();
    scannerBloc?.callLongBuildUP();
    scannerBloc?.callShortBuildUP();
    scannerBloc?.callShortUnwindingUp();
    scannerBloc?.callLongUnWInding(); */
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ScannerBloc _scannerBloc = ScannerBloc(context);
    return _scannerList();
  }
}
