import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/option_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MarketOptionchainSettingScreen extends StatefulWidget {
  final OptionBloc? optionChainBloc;
  const MarketOptionchainSettingScreen({
    Key? key,
    required this.optionChainBloc,
  }) : super(key: key);

  @override
  _OptionchainSettingScreen createState() => _OptionchainSettingScreen();
}

class _OptionchainSettingScreen extends State<MarketOptionchainSettingScreen> {
  bool fivepress = false;
  bool tenpress = true;
  bool fifteenpress = false;
  bool twentypress = false;
  bool allpress = false;

  bool isSwitched = false;
  SharedPreferences? sp;

  // OptionChainBloc? optionChainBloc;

  @override
  Widget build(BuildContext context) {
    SharedPreferences.getInstance().then((value) {
      sp = value;
      getdefaultvalues();
    });

    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.only(top: 15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text("Option Chain Setting", style: GreekTextStyle.optionchainsetting),
              Container(
                width: 80,
                height: 35,
                // color: Color.fromRGBO(220, 230, 242, 1),
                decoration: BoxDecoration(
                  color: const Color.fromRGBO(220, 230, 242, 1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey, width: 1),
                ),
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      widget.optionChainBloc?.noofStrike = "10";
                      widget.optionChainBloc?.isvolume = false;
                      widget.optionChainBloc?.oi = true;
                      widget.optionChainBloc?.oIChange = true;
                      widget.optionChainBloc?.iv = false;
                      widget.optionChainBloc?.greeks = false;
                      widget.optionChainBloc?.delta = false;
                      widget.optionChainBloc?.gama = false;
                      widget.optionChainBloc?.vega = false;
                    });
                  },
                  child: const Text(
                    "Reset",
                    textScaleFactor: 1.0,
                    style: TextStyle(color: Color.fromARGB(255, 130, 153, 214), fontSize: 13.0),
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  GreekNavigator.pop(context: context, popArguments: null);
                },
                iconSize: 25,
                color: ConstantColors.black,
                icon: const Icon(Icons.close),
              ),
            ],
          ),
        ),
        const SizedBox(height: 4.0),
        Container(
          padding: const EdgeInsets.only(top: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            // ignore: prefer_const_literals_to_create_immutables
            children: [
              Padding(padding: const EdgeInsets.only(left: 10.0), child: Text('No of Strike', style: GreekTextStyle.optionchainsettingStrike)),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: Colors.grey, width: 1),
                ),
                height: 40,
                width: (MediaQuery.of(context).size.width / 2) / 5,
                // color: Colors.red,
                child: TextButton(
                    onPressed: () {
                      setState(() {
                        widget.optionChainBloc?.noofStrike = "5";
                      });
                    },
                    child: Text(
                      '5',
                      style: widget.optionChainBloc?.noofStrike == "5" ? GreekTextStyle.optionChainsettingStrikenoclick : GreekTextStyle.optionChainsettingStrikeno,
                    )),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: Colors.grey, width: 1),
                ),
                height: 40,
                width: (MediaQuery.of(context).size.width / 2) / 5,
                // color: Colors.yellow,
                child: TextButton(
                    onPressed: () {
                      setState(() {
                        widget.optionChainBloc?.noofStrike = "10";
                      });
                    },
                    child: Text(
                      '10',
                      style: widget.optionChainBloc?.noofStrike == "10" ? GreekTextStyle.optionChainsettingStrikenoclick : GreekTextStyle.optionChainsettingStrikeno,
                    )),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: Colors.grey, width: 1),
                ),
                height: 40,
                width: (MediaQuery.of(context).size.width / 2) / 5,
                // color: Colors.blue,
                child: TextButton(
                    onPressed: () {
                      setState(() {
                        widget.optionChainBloc?.noofStrike = "15";
                      });
                    },
                    child: Text(
                      '15',
                      style: widget.optionChainBloc?.noofStrike == "15" ? GreekTextStyle.optionChainsettingStrikenoclick : GreekTextStyle.optionChainsettingStrikeno,
                    )),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: Colors.grey, width: 1),
                ),
                height: 40,
                width: (MediaQuery.of(context).size.width / 2) / 5,
                // color: Colors.purple,
                child: TextButton(
                    onPressed: () {
                      setState(() {
                        widget.optionChainBloc?.noofStrike = "20";
                      });
                    },
                    child: Text(
                      '20',
                      style: widget.optionChainBloc?.noofStrike == "20" ? GreekTextStyle.optionChainsettingStrikenoclick : GreekTextStyle.optionChainsettingStrikeno,
                    )),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: Colors.grey, width: 1),
                ),
                height: 40,
                width: (MediaQuery.of(context).size.width / 2) / 5,
                // color: Colors.purple,
                child: TextButton(
                    onPressed: () {
                      setState(() {
                        widget.optionChainBloc?.noofStrike = "All";
                      });
                    },
                    child: Text(
                      'All',
                      style: widget.optionChainBloc?.noofStrike == "All" ? GreekTextStyle.optionChainsettingStrikenoclick : GreekTextStyle.optionChainsettingStrikeno,
                    )),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Volume', style: GreekTextStyle.optionchainsettingStrike),
                  // SizedBox(width: 8.0)
                  Switch(
                    value: widget.optionChainBloc?.isvolume ?? false,
                    onChanged: (value) {
                      setState(() {
                        widget.optionChainBloc?.isvolume = value;
                        sp?.setBool('mvolume', widget.optionChainBloc?.isvolume ?? false);
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('OI', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: true,
                    onChanged: (value) {
                      setState(() {
                        isSwitched = value;
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('OI Change%', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: true,
                    onChanged: (value) {
                      setState(() {
                        isSwitched = value;
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('IV', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: widget.optionChainBloc?.iv ?? false,
                    onChanged: (value) {
                      setState(() {
                        widget.optionChainBloc?.iv = value;
                        sp?.setBool('miv', widget.optionChainBloc?.iv ?? false);
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('GREEKS', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: widget.optionChainBloc?.greeks ?? false,
                    onChanged: (value) {
                      setState(() {
                        widget.optionChainBloc?.greeks = value;
                        sp?.setBool('mgreeks', widget.optionChainBloc?.greeks ?? false);
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('DELTA', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: widget.optionChainBloc?.delta ?? false,
                    onChanged: (value) {
                      setState(() {
                        widget.optionChainBloc?.delta = value;
                        sp?.setBool('mdelta', widget.optionChainBloc?.delta ?? false);
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('GAMA', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: widget.optionChainBloc?.gama ?? false,
                    onChanged: (value) {
                      setState(() {
                        widget.optionChainBloc?.gama = value;
                        sp?.setBool('mgama', widget.optionChainBloc?.gama ?? false);
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('VEGA', style: GreekTextStyle.optionchainsettingStrike),
                  const SizedBox(width: 8.0),
                  Switch(
                    value: widget.optionChainBloc?.vega ?? false,
                    onChanged: (value) {
                      setState(() {
                        widget.optionChainBloc?.vega = value;
                        sp?.setBool('mvega', widget.optionChainBloc?.vega ?? false);
                      });
                    },
                    activeTrackColor: const Color.fromRGBO(250, 103, 17, 1),
                    activeColor: const Color.fromRGBO(1, 97, 193, 1),
                    inactiveTrackColor: const Color.fromRGBO(163, 190, 250, 1),
                  ),
                ],
              ),
            ],
          ),
        ),
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Row(
                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    // ignore: prefer_const_literals_to_create_immutables
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: const [],
                  ),
                ],
              ),
            ),
            Container(
              height: 50,
              width: MediaQuery.of(context).size.width - 250,
              margin: const EdgeInsets.only(bottom: 10),
              child: TextButton(
                onPressed: () async {
                  /*    widget.optionChainBloc?.headings.insert(0, "delta");
                  widget.optionChainBloc?.headings.add("delta");
                  widget.optionChainBloc?.heading1.insert(0, "");
                  widget.optionChainBloc?.heading1.add(""); */

                  setcolumn();

                  /*  sp?.setBool('iv', widget.optionChainBloc?.iv ?? false);
                  sp?.setBool('greeks', widget.optionChainBloc?.greeks ?? false);
                  sp?.setBool('delta', widget.optionChainBloc?.delta ?? false);
                  sp?.setBool('gama', widget.optionChainBloc?.gama ?? false);
                  sp?.setBool('vega', widget.optionChainBloc?.vega ?? false); */
                  sp?.setString("mnoofsrike", widget.optionChainBloc?.noofStrike ?? "10");

                  GreekNavigator.pop(context: context, popArguments: widget.optionChainBloc?.noofStrike);
                },
                child: const Text(
                  "Apply",
                  textScaleFactor: 1.0,
                  style: TextStyle(color: Colors.black87),
                ),
              ),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.blueAccent),
                borderRadius: BorderRadius.circular(30.0),
                boxShadow: const [
                  BoxShadow(color: Colors.white, spreadRadius: 3),
                ],
              ),
            ),
          ],
        )
      ],
    );
  }

  void setcolumn() {
    if (widget.optionChainBloc!.iv) {
      if (!widget.optionChainBloc!.headings.contains("IV")) {
        widget.optionChainBloc?.headings.insert(0, "IV");
        widget.optionChainBloc?.heading1.insert(0, "");
        widget.optionChainBloc?.headings.add("IV");
        widget.optionChainBloc?.heading1.add("");
      }
    } else {
      if (widget.optionChainBloc!.headings.contains("IV")) {
        int index = widget.optionChainBloc?.headings.indexOf("IV") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("IV");
      }
      if (widget.optionChainBloc!.headings.contains("IV")) {
        int index = widget.optionChainBloc?.headings.indexOf("IV") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("IV");
      }
    }

    if (widget.optionChainBloc!.isvolume) {
      if (!widget.optionChainBloc!.headings.contains("Volume")) {
        widget.optionChainBloc?.headings.insert(0, "Volume");
        widget.optionChainBloc?.heading1.insert(0, "");
        widget.optionChainBloc?.headings.add("Volume");
        widget.optionChainBloc?.heading1.add("");
      }
    } else {
      if (widget.optionChainBloc!.headings.contains("Volume")) {
        int index = widget.optionChainBloc?.headings.indexOf("Volume") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("Volume");
      }
      if (widget.optionChainBloc!.headings.contains("Volume")) {
        int index = widget.optionChainBloc?.headings.indexOf("Volume") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("Volume");
      }
    }

    if (widget.optionChainBloc!.greeks) {
      if (!widget.optionChainBloc!.headings.contains("GREEKS")) {
        widget.optionChainBloc?.headings.insert(0, "GREEKS");
        widget.optionChainBloc?.heading1.insert(0, "");
        widget.optionChainBloc?.headings.add("GREEKS");
        widget.optionChainBloc?.heading1.add("");
      }
    } else {
      if (widget.optionChainBloc!.headings.contains("GREEKS")) {
        int index = widget.optionChainBloc?.headings.indexOf("GREEKS") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("GREEKS");
      }
      if (widget.optionChainBloc!.headings.contains("GREEKS")) {
        int index = widget.optionChainBloc?.headings.indexOf("GREEKS") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("GREEKS");
      }
    }

    if (widget.optionChainBloc!.delta) {
      if (!widget.optionChainBloc!.headings.contains("DELTA")) {
        widget.optionChainBloc?.headings.insert(0, "DELTA");
        widget.optionChainBloc?.heading1.insert(0, "");

        widget.optionChainBloc?.headings.add("DELTA");
        widget.optionChainBloc?.heading1.add("");
      }
    } else {
      if (widget.optionChainBloc!.headings.contains("DELTA")) {
        int index = widget.optionChainBloc?.headings.indexOf("DELTA") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("DELTA");
      }
      if (widget.optionChainBloc!.headings.contains("DELTA")) {
        int index = widget.optionChainBloc?.headings.indexOf("DELTA") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("DELTA");
      }
    }

    if (widget.optionChainBloc!.gama) {
      if (!widget.optionChainBloc!.headings.contains("GAMA")) {
        widget.optionChainBloc?.headings.insert(0, "GAMA");
        widget.optionChainBloc?.heading1.insert(0, "");

        widget.optionChainBloc?.headings.add("GAMA");
        widget.optionChainBloc?.heading1.add("");
      }
    } else {
      if (widget.optionChainBloc!.headings.contains("GAMA")) {
        int index = widget.optionChainBloc?.headings.indexOf("GAMA") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("GAMA");
      }
      if (widget.optionChainBloc!.headings.contains("GAMA")) {
        int index = widget.optionChainBloc?.headings.indexOf("GAMA") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("GAMA");
      }
    }

    if (widget.optionChainBloc!.vega) {
      if (!widget.optionChainBloc!.headings.contains("VEGA")) {
        widget.optionChainBloc?.headings.insert(0, "VEGA");
        widget.optionChainBloc?.heading1.insert(0, "");

        widget.optionChainBloc?.headings.add("VEGA");
        widget.optionChainBloc?.heading1.add("");
      }
    } else {
      if (widget.optionChainBloc!.headings.contains("VEGA")) {
        int index = widget.optionChainBloc?.headings.indexOf("VEGA") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("VEGA");
      }
      if (widget.optionChainBloc!.headings.contains("VEGA")) {
        int index = widget.optionChainBloc?.headings.indexOf("VEGA") ?? -1;
        widget.optionChainBloc?.heading1.removeAt(index);

        widget.optionChainBloc?.headings.remove("VEGA");
      }
    }
  }

  getdefaultvalues() {
    widget.optionChainBloc?.isvolume = sp?.getBool("mvolume") ?? false;
    widget.optionChainBloc?.iv = sp?.getBool("miv") ?? false;
    widget.optionChainBloc?.greeks = sp?.getBool("mgreeks") ?? false;
    widget.optionChainBloc?.delta = sp?.getBool("mdelta") ?? false;
    widget.optionChainBloc?.gama = sp?.getBool("mgama") ?? false;
    widget.optionChainBloc?.vega = sp?.getBool("mvega") ?? false;

    setcolumn();

    setState(() {});
  }
}
