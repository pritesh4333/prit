import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_tab_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/ui/fii_dii_view.dart';
import 'package:greek_ibt_app/Screens/Market/ui/market_map.dart';
import 'package:greek_ibt_app/Screens/Market/ui/market_option_chain_view.dart';
import 'package:greek_ibt_app/Screens/Market/ui/scanner_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class MarketBottomTab extends StatefulWidget {
  const MarketBottomTab({Key? key}) : super(key: key);

  @override
  _MarketBottomTabState createState() => _MarketBottomTabState();
}

class _MarketBottomTabState extends State<MarketBottomTab> {
  MarketTabBloc? _marketTabBloc;

  @override
  void initState() {
    super.initState();

    /* WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        GreekBase().subscribeIndicesIndexTokens();

        _marketBloc?.initalCallingMarketStatistics();
      },
    ); */
  }

  @override
  Widget build(BuildContext context) {
    _marketTabBloc = MarketTabBloc();

    return DefaultTabController(
      length: 4,
      initialIndex: 0,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            elevation: 1,
            automaticallyImplyLeading: false,
            toolbarHeight: 90.0,
            flexibleSpace: tabBarView(),
          ),
          body: tabSection(),
        ),
      ),
    );
  }

  Widget tabBarView() {
    return Container(
      color: ConstantColors.white,
      padding: const EdgeInsets.only(top: 2.0, left: 4.0, right: 8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.menu_rounded),
                color: Colors.black,
                iconSize: 30.0,
                onPressed: () => GreekBase().drawerKey.currentState?.openDrawer(),
              ),
              Text(
                ConstantMessages.GREEK_MARKET_NAME,
                style: GreekTextStyle.headline2,
              )
            ],
          ),
          const SizedBox(height: 5.0),
          Container(
            color: Colors.white,
            height: 31,
            child: TabBar(
              isScrollable: true,
              labelStyle: GreekTextStyle.headline23,
              labelColor: Colors.blue,
              unselectedLabelStyle: GreekTextStyle.headline23,
              unselectedLabelColor: Colors.black,
              tabs: const [
                Text(
                  "MARKET MAP",
                ),
                Text(
                  "SCANNERS",
                ),
                Text(
                  "OPTION CHAIN",
                ),
                Text(
                  "FII/DII",
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget tabSection() {
    return Container(
      // height: 700,
      margin: const EdgeInsets.only(top: 2.0),
      child: const TabBarView(
        physics: NeverScrollableScrollPhysics(),
        children: [
          MarketMap(),
          ScannerScreen(),
          MarketOptionChainView(),
          FiiDiiScreen(),
        ],
      ),
    );
  }
}
