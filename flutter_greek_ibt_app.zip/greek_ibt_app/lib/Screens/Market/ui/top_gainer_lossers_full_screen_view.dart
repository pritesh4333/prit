import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/streaming_data_source.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_map_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';

class TopGainerLossersFullScreen extends StatefulWidget {
  final MarketMapBloc marketMapBloc;
  final int selectedTabIndex;

  const TopGainerLossersFullScreen({
    Key? key,
    required this.marketMapBloc,
    required this.selectedTabIndex,
  }) : super(key: key);

  @override
  _TopGainerLossersFullScreenState createState() => _TopGainerLossersFullScreenState();
}

class _TopGainerLossersFullScreenState extends State<TopGainerLossersFullScreen> with SingleTickerProviderStateMixin {
  final tabTitles = ['top gainers', 'top losers', 'market movers', 'market movers (by value)'];

  int selectedTabIndexValue = 0;

  @override
  void initState() {
    super.initState();

    selectedTabIndexValue = widget.selectedTabIndex;
  }

  @override
  Widget build(BuildContext context) {
    List<String> popupMenuItems = <String>[];
    String selectedPopupMenuItem = "";

    switch (selectedTabIndexValue) {
      case 0:
        popupMenuItems = widget.marketMapBloc.topGainerMaketSegment;
        selectedPopupMenuItem = widget.marketMapBloc.selectedTopGainerSegment;
        widget.marketMapBloc.selectedDropValue = selectedPopupMenuItem;

        widget.marketMapBloc.callTopGainerWithMarketID();
        break;

      case 1:
        popupMenuItems = widget.marketMapBloc.topLoosersMaketSegment;
        selectedPopupMenuItem = widget.marketMapBloc.selectedTopLoosersSegment;
        widget.marketMapBloc.selectedDropValue = selectedPopupMenuItem;

        widget.marketMapBloc.callTopLoosersWithMarketID();
        break;

      case 2:
        popupMenuItems = widget.marketMapBloc.marketMoversMaketSegment;
        selectedPopupMenuItem = widget.marketMapBloc.selectedMarketMoversSegment;
        widget.marketMapBloc.selectedDropValue = selectedPopupMenuItem;

        widget.marketMapBloc.callMarketMoversWithMarketID();
        break;

      case 3:
        popupMenuItems = widget.marketMapBloc.marketMoversByValueMaketSegment;
        selectedPopupMenuItem = widget.marketMapBloc.selectedMarketMoversByValueSegment;
        widget.marketMapBloc.selectedDropValue = selectedPopupMenuItem;

        widget.marketMapBloc.callMarketMoversByValueWithMarketID();
        break;

      default:
        break;
    }

    return DefaultTabController(
      length: tabTitles.length,
      initialIndex: widget.selectedTabIndex,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          actions: [
            PopupMenuButton<String>(
              itemBuilder: (context) {
                return popupMenuItems.toSet().map(
                  (str) {
                    return PopupMenuItem(
                      value: str,
                      child: Text(
                        str,
                        style: GreekTextStyle.marketStatisticsDropdownTextStyle,
                      ),
                    );
                  },
                ).toList();
              },
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    selectedPopupMenuItem,
                    style: GreekTextStyle.marketStatisticsDropdownTextStyle,
                  ),
                  const Icon(
                    Icons.arrow_drop_down,
                    color: ConstantColors.black,
                  ),
                ],
              ),
              onSelected: (_selectedItem) {
                switch (selectedTabIndexValue) {
                  case 0:
                    widget.marketMapBloc.selectedTopGainerSegment = _selectedItem;
                    setState(() {});
                    break;

                  case 1:
                    widget.marketMapBloc.selectedTopLoosersSegment = _selectedItem;
                    setState(() {});
                    break;

                  case 2:
                    widget.marketMapBloc.selectedMarketMoversSegment = _selectedItem;
                    setState(() {});
                    break;

                  case 3:
                    widget.marketMapBloc.selectedMarketMoversByValueSegment = _selectedItem;
                    setState(() {});
                    break;

                  default:
                    break;
                }
              },
            ),
          ],
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: ConstantColors.black,
            ),
            highlightColor: Colors.transparent,
            splashColor: Colors.transparent,
            onPressed: () {
              widget.marketMapBloc.dropDownValueTg.sink.add(true);
              Navigator.pop(context);
            },
          ),
          title: Text(
            'Market Map',
            style: GreekTextStyle.heading18,
          ),
          bottom: TabBar(
            onTap: (_tabIndex) => setState(
              () => selectedTabIndexValue = _tabIndex,
            ),
            labelStyle: GreekTextStyle.selected_tab_label_blue,
            labelColor: GreekTextStyle.selected_tab_label_blue.color,
            unselectedLabelStyle: GreekTextStyle.unselected_tab_label_blue,
            unselectedLabelColor: GreekTextStyle.unselected_tab_label_blue.color,
            labelPadding: const EdgeInsets.all(5.0),
            isScrollable: true,
            tabs: tabTitles
                .map(
                  (e) => Text(
                    e.toUpperCase(),
                  ),
                )
                .toList(),
          ),
        ),
        body: TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: [
            _topGainer(),
            _topLoosers(),
            _marketMovers(),
            _marketMoversbyValue(),
          ],
        ),
      ),
    );
  }

  _topGainer() => StreamBuilder<Object?>(
        stream: SocketIOManager().topGainersObservable,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            if ((snapshot.data != null) && (snapshot.data is List)) {
              final _list = snapshot.data! as List;
              if (_list.isNotEmpty) {
                final symbolDataList = <StreamingDataModel>[];

                final _tempTopList = _list
                    .map(
                      (e) => SymbolList.fromJson(
                        json: e,
                        isWatchListScreen: false,
                      ),
                    )
                    .toList();

                for (final item in _tempTopList) {
                  if ((item.token ?? 0) > 0) {
                    final obj = StreamingDataModel(
                      token: item.token,
                      symbol: (item.token?.toAssetType().toLowerCase() == "equity") ? "${item.description} - ${item.seriesName}" : item.description,
                      ltp: item.ltp,
                      change: item.change,
                      preChange: item.pChange,
                    );

                    symbolDataList.add(obj);
                  }
                }

                if (symbolDataList.isNotEmpty) {
                  return GreekBase().scriptListView(
                    scripContext: streamContext,
                    dataList: symbolDataList,
                    isScrollable: false,
                  );
                }
              }

              /*if (_list.isNotEmpty) {
                widget.marketMapBloc.topGainersDataList = _list
                    .map(
                      (e) => SymbolList.fromJson(json: e),
                    )
                    .toList();

                widget.marketMapBloc.subscribeTopGainersTokens.clear();
                widget.marketMapBloc.subscribeTopGainersTokens =
                    List<String>.from(
                  widget.marketMapBloc.topGainersDataList
                      .map(
                        (e) => e.token!.toString(),
                      )
                      .toList(),
                );

                for (final element
                    in widget.marketMapBloc.topGainersStreamList) {
                  element.close();
                }
                widget.marketMapBloc.topGainersStreamList.clear();
                widget.marketMapBloc.topGainersStreamList =
                    List<BehaviorSubject<SymbolList?>>.from(
                  widget.marketMapBloc.topGainersDataList
                      .map(
                        (e) => BehaviorSubject<SymbolList?>.seeded(e),
                      )
                      .toList(),
                );

                widget.marketMapBloc.subscribeTopGainerLTPInfoTokens();

                return GreekBase().scriptListView(
                  dataList: widget.marketMapBloc.topGainersStreamList,
                  watchBloc: null,
                  isScrollable: false,
                );
              }*/
            }
            return Center(
              child: SizedBox(
                height: MediaQuery.of(streamContext).size.height / 2,
                child: Center(child: GreekBase().noDataAvailableView()),
              ),
            );
          } else {
            return const Center(
              child: SizedBox.square(
                dimension: 35,
                child: CircularProgressIndicator(),
              ),
            );
          }
        },
      );

  _topLoosers() => StreamBuilder<Object?>(
        stream: SocketIOManager().topLoosersObservable,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            if ((snapshot.data != null) && (snapshot.data is List)) {
              final _list = snapshot.data! as List;
              if (_list.isNotEmpty) {
                final symbolDataList = <StreamingDataModel>[];

                final _tempTopList = _list
                    .map(
                      (e) => SymbolList.fromJson(
                        json: e,
                        isWatchListScreen: false,
                      ),
                    )
                    .toList();

                for (final item in _tempTopList) {
                  if ((item.token ?? 0) > 0) {
                    final obj = StreamingDataModel(
                      token: item.token,
                      symbol: (item.token?.toAssetType().toLowerCase() == "equity") ? "${item.description} - ${item.seriesName}" : item.description,
                      ltp: item.ltp,
                      change: item.change,
                      preChange: item.pChange,
                    );

                    symbolDataList.add(obj);
                  }
                }

                if (symbolDataList.isNotEmpty) {
                  return GreekBase().scriptListView(
                    scripContext: streamContext,
                    dataList: symbolDataList,
                    isScrollable: false,
                  );
                }
              }

              /*if (_list.isNotEmpty) {
                widget.marketMapBloc.topLoosersDataList = _list
                    .map(
                      (e) => SymbolList.fromJson(json: e),
                    )
                    .toList();

                widget.marketMapBloc.subscribeTopLoosersTokens.clear();
                widget.marketMapBloc.subscribeTopLoosersTokens =
                    List<String>.from(
                  widget.marketMapBloc.topLoosersDataList
                      .map(
                        (e) => e.token!.toString(),
                      )
                      .toList(),
                );

                for (final element
                    in widget.marketMapBloc.topLoosersStreamList) {
                  element.close();
                }
                widget.marketMapBloc.topLoosersStreamList.clear();
                widget.marketMapBloc.topLoosersStreamList =
                    List<BehaviorSubject<SymbolList?>>.from(
                  widget.marketMapBloc.topLoosersDataList
                      .map(
                        (e) => BehaviorSubject<SymbolList?>.seeded(e),
                      )
                      .toList(),
                );

                widget.marketMapBloc.subscribeTopLoosersLTPInfoTokens();

                return GreekBase().scriptListView(
                  dataList: widget.marketMapBloc.topLoosersStreamList,
                  watchBloc: null,
                  isScrollable: false,
                );
              }*/
            }
            return Center(
              child: SizedBox(
                height: MediaQuery.of(streamContext).size.height / 2,
                child: Center(child: GreekBase().noDataAvailableView()),
              ),
            );
          } else {
            return const Center(
              child: SizedBox.square(
                dimension: 35,
                child: CircularProgressIndicator(),
              ),
            );
          }
        },
      );

  _marketMovers() => StreamBuilder<Object?>(
        stream: SocketIOManager().marketMOversObservable,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            if ((snapshot.data != null) && (snapshot.data is List)) {
              final _list = snapshot.data! as List;
              if (_list.isNotEmpty) {
                final symbolDataList = <StreamingDataModel>[];

                final _tempTopList = _list
                    .map(
                      (e) => SymbolList.fromJson(
                        json: e,
                        isWatchListScreen: false,
                      ),
                    )
                    .toList();

                for (final item in _tempTopList) {
                  if ((item.token ?? 0) > 0) {
                    final obj = StreamingDataModel(
                      token: item.token,
                      symbol: (item.token?.toAssetType().toLowerCase() == "equity") ? "${item.description} - ${item.seriesName}" : item.description,
                      ltp: item.ltp,
                      change: item.change,
                      preChange: item.pChange,
                    );

                    symbolDataList.add(obj);
                  }
                }

                if (symbolDataList.isNotEmpty) {
                  return GreekBase().scriptListView(
                    scripContext: streamContext,
                    dataList: symbolDataList,
                    isScrollable: false,
                  );
                }
              }

              /*if (_list.isNotEmpty) {
                widget.marketMapBloc.marketMoverDataList = _list
                    .map(
                      (e) => SymbolList.fromJson(json: e),
                    )
                    .toList();

                widget.marketMapBloc.subscribeMarketMoversTokens.clear();
                widget.marketMapBloc.subscribeMarketMoversTokens =
                    List<String>.from(
                  widget.marketMapBloc.marketMoverDataList
                      .map(
                        (e) => e.token!.toString(),
                      )
                      .toList(),
                );

                for (final element
                    in widget.marketMapBloc.marketMoversStreamList) {
                  element.close();
                }
                widget.marketMapBloc.marketMoversStreamList.clear();
                widget.marketMapBloc.marketMoversStreamList =
                    List<BehaviorSubject<SymbolList?>>.from(
                  widget.marketMapBloc.marketMoverDataList
                      .map(
                        (e) => BehaviorSubject<SymbolList?>.seeded(e),
                      )
                      .toList(),
                );

                widget.marketMapBloc.subscribeMarketMoversLTPInfoTokens();

                return GreekBase().scriptListView(
                  dataList: widget.marketMapBloc.marketMoversStreamList,
                  watchBloc: null,
                  isScrollable: false,
                );
              }*/
            }
            return Center(
              child: SizedBox(
                height: MediaQuery.of(streamContext).size.height / 2,
                child: Center(child: GreekBase().noDataAvailableView()),
              ),
            );
          } else {
            return const Center(
              child: SizedBox.square(
                dimension: 35,
                child: CircularProgressIndicator(),
              ),
            );
          }
        },
      );

  _marketMoversbyValue() => StreamBuilder<Object?>(
        stream: SocketIOManager().marketMoverByValueObservable,
        builder: (streamContext, snapshot) {
          if (snapshot.hasData) {
            if ((snapshot.data != null) && (snapshot.data is List)) {
              final _list = snapshot.data! as List;
              if (_list.isNotEmpty) {
                final symbolDataList = <StreamingDataModel>[];

                final _tempTopList = _list
                    .map(
                      (e) => SymbolList.fromJson(
                        json: e,
                        isWatchListScreen: false,
                      ),
                    )
                    .toList();

                for (final item in _tempTopList) {
                  if ((item.token ?? 0) > 0) {
                    final obj = StreamingDataModel(
                      token: item.token,
                      symbol: (item.token?.toAssetType().toLowerCase() == "equity") ? "${item.description} - ${item.seriesName}" : item.description,
                      ltp: item.ltp,
                      change: item.change,
                      preChange: item.pChange,
                    );

                    symbolDataList.add(obj);
                  }
                }

                if (symbolDataList.isNotEmpty) {
                  return GreekBase().scriptListView(
                    scripContext: streamContext,
                    dataList: symbolDataList,
                    isScrollable: false,
                  );
                }
              }

              /*if (_list.isNotEmpty) {
                widget.marketMapBloc.marketMoverByValueDataList = _list
                    .map(
                      (e) => SymbolList.fromJson(json: e),
                    )
                    .toList();

                widget.marketMapBloc.subscribeMarketMoversByValueTokens.clear();
                widget.marketMapBloc.subscribeMarketMoversByValueTokens =
                    List<String>.from(
                  widget.marketMapBloc.marketMoverByValueDataList
                      .map(
                        (e) => e.token!.toString(),
                      )
                      .toList(),
                );

                for (final element
                    in widget.marketMapBloc.marketMoversByValueStreamList) {
                  element.close();
                }
                widget.marketMapBloc.marketMoversByValueStreamList.clear();
                widget.marketMapBloc.marketMoversByValueStreamList =
                    List<BehaviorSubject<SymbolList?>>.from(
                  widget.marketMapBloc.marketMoverByValueDataList
                      .map(
                        (e) => BehaviorSubject<SymbolList?>.seeded(e),
                      )
                      .toList(),
                );

                widget.marketMapBloc
                    .subscribeMarketMoversByValueLTPInfoTokens();

                return GreekBase().scriptListView(
                  dataList: widget.marketMapBloc.marketMoversByValueStreamList,
                  watchBloc: null,
                  isScrollable: false,
                );
              }*/
            }
            return Center(
              child: SizedBox(
                height: MediaQuery.of(streamContext).size.height / 2,
                child: Center(child: GreekBase().noDataAvailableView()),
              ),
            );
          } else {
            return const Center(
              child: SizedBox.square(
                dimension: 35,
                child: CircularProgressIndicator(),
              ),
            );
          }
        },
      );
}
