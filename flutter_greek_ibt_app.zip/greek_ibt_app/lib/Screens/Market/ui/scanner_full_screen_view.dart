import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class ScannerFullScreenView extends StatefulWidget {
  const ScannerFullScreenView({Key? key}) : super(key: key);

  @override
  State<ScannerFullScreenView> createState() => _ScannerFullScreenViewState();
}

class _ScannerFullScreenViewState extends State<ScannerFullScreenView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.only(left: 10.0, right: 15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 40.0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.arrow_back_ios),
                    ),
                    const SizedBox(
                      width: 20.0,
                    ),
                    const Text(
                      'Most Active By Futures',
                      style: TextStyle(
                          fontSize: 15.0, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              ListView.builder(
                  itemCount: 5,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'TCS',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '99.2',
                              style: GreekTextStyle.watchlistText,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 3.0,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'BSE',
                              style: GreekTextStyle.headline4,
                            ),
                            Text(
                              '55.2',
                              style: GreekTextStyle.headingWatchlistLTPRed,
                            ),
                          ],
                        ),
                        const Divider(
                          thickness: 0.5,
                          color: ConstantColors.dividerColor,
                        ),
                      ],
                    );
                  }),
            ],
          ),
        ),
      ),
    );
  }
}
