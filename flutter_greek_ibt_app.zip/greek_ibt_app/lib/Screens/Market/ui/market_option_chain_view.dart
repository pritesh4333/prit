import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_strike_reponse_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/option_chain_call_put_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/ui/option_chain_view.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/no_data_with_progress_indicator.dart';
import 'package:intl/intl.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/option_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_expiry_market.dart';
import 'package:greek_ibt_app/Screens/Market/models/symbol_instrument.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MarketOptionChainView extends StatefulWidget {
  const MarketOptionChainView({Key? key}) : super(key: key);

  @override
  State<MarketOptionChainView> createState() => _MarketOptionChainViewState();
}

class _MarketOptionChainViewState extends State<MarketOptionChainView> {
  OptionBloc? marketOptionChainBloc;
  String? expiryDropdownValue;
  String? fromStrike;
  String? toStrike;
  String globalVisibility = 'callput';
  double topSpace = 0;

  bool isChecked = false;
  bool selectedList = false;
  final niftyController = TextEditingController();
  TabController? tabController;

  final getExpiryResponse = GetExpiryMarketResponseModel();
  int? expiryIndex;
  int selectedIndex = 0;

  SymbolInstrumentData? selectedEvent;
  String _instrumentSymbol = '';
  String _type = 'Index';

  List<String?> validityDropdownValues = ['Stock', 'Index'];
  String validitySelectedValue = 'Stock';

  String dropdownvalue = 'Index';
  SharedPreferences? sp;

  // List of items in our dropdown menu
  var items = [
    'Index',
    'Stock',
  ];

  @override
  void initState() {
    super.initState();
    marketOptionChainBloc = OptionBloc(context);
    convertFutureListToList();
    //show loader
  }

  void convertFutureListToList() async {
    var symbolList = marketOptionChainBloc?.callSearchForInstrumenAPi(_type);
    Future<List<SymbolInstrumentData>>? _futureOfList = symbolList;
    List<SymbolInstrumentData>? list = await _futureOfList;
    bool isnifty = false;
    for (int i = 0; i < list!.length; i++) {
      if (list[i].symbol == "NIFTY") {
        isnifty = true;
      }
    }

    //Loader stops
    _instrumentSymbol = isnifty ? "NIFTY" : list.first.symbol ?? '';

    setState(() {
      // optionChainBloc?.symbolList = list;
    });
    SharedPreferences.getInstance().then((value) {
      sp = value;
      getdefaultvalues();
    });
  }

  getdefaultvalues() {
    marketOptionChainBloc!.isvolume = sp?.getBool("mvolume") ?? false;
    marketOptionChainBloc!.iv = sp?.getBool("miv") ?? false;
    marketOptionChainBloc!.greeks = sp?.getBool("mgreeks") ?? false;
    marketOptionChainBloc!.delta = sp?.getBool("mdelta") ?? false;
    marketOptionChainBloc!.gama = sp?.getBool("mgama") ?? false;
    marketOptionChainBloc!.vega = sp?.getBool("mvega") ?? false;

    _setcolumn();

    // setState(() {});
  }

  void _setcolumn() {
    if (marketOptionChainBloc?.iv ?? false) {
      if (!marketOptionChainBloc!.headings.contains("IV")) {
        marketOptionChainBloc!.headings.insert(0, "IV");
        marketOptionChainBloc!.heading1.insert(0, "");
        marketOptionChainBloc!.headings.add("IV");
        marketOptionChainBloc!.heading1.add("");
      }
    } else {
      if (marketOptionChainBloc!.headings.contains("IV")) {
        int index = marketOptionChainBloc!.headings.indexOf("IV");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("IV");
      }
      if (marketOptionChainBloc!.headings.contains("IV")) {
        int index = marketOptionChainBloc!.headings.indexOf("IV");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("IV");
      }
    }

    if (marketOptionChainBloc!.isvolume) {
      if (!marketOptionChainBloc!.headings.contains("Volume")) {
        marketOptionChainBloc!.headings.insert(0, "Volume");
        marketOptionChainBloc!.heading1.insert(0, "");
        marketOptionChainBloc!.headings.add("Volume");
        marketOptionChainBloc!.heading1.add("");
      }
    } else {
      if (marketOptionChainBloc!.headings.contains("Volume")) {
        int index = marketOptionChainBloc!.headings.indexOf("Volume");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("Volume");
      }
      if (marketOptionChainBloc!.headings.contains("Volume")) {
        int index = marketOptionChainBloc!.headings.indexOf("Volume");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("Volume");
      }
    }

    if (marketOptionChainBloc!.greeks) {
      if (!marketOptionChainBloc!.headings.contains("GREEKS")) {
        marketOptionChainBloc!.headings.insert(0, "GREEKS");
        marketOptionChainBloc!.heading1.insert(0, "");
        marketOptionChainBloc!.headings.add("GREEKS");
        marketOptionChainBloc!.heading1.add("");
      }
    } else {
      if (marketOptionChainBloc!.headings.contains("GREEKS")) {
        int index = marketOptionChainBloc!.headings.indexOf("GREEKS");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("GREEKS");
      }
      if (marketOptionChainBloc!.headings.contains("GREEKS")) {
        int index = marketOptionChainBloc!.headings.indexOf("GREEKS");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("GREEKS");
      }
    }

    if (marketOptionChainBloc!.delta) {
      if (!marketOptionChainBloc!.headings.contains("DELTA")) {
        marketOptionChainBloc!.headings.insert(0, "DELTA");
        marketOptionChainBloc!.heading1.insert(0, "");

        marketOptionChainBloc!.headings.add("DELTA");
        marketOptionChainBloc!.heading1.add("");
      }
    } else {
      if (marketOptionChainBloc!.headings.contains("DELTA")) {
        int index = marketOptionChainBloc!.headings.indexOf("DELTA");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("DELTA");
      }
      if (marketOptionChainBloc!.headings.contains("DELTA")) {
        int index = marketOptionChainBloc!.headings.indexOf("DELTA");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("DELTA");
      }
    }

    if (marketOptionChainBloc!.gama) {
      if (!marketOptionChainBloc!.headings.contains("GAMA")) {
        marketOptionChainBloc!.headings.insert(0, "GAMA");
        marketOptionChainBloc!.heading1.insert(0, "");

        marketOptionChainBloc!.headings.add("GAMA");
        marketOptionChainBloc!.heading1.add("");
      }
    } else {
      if (marketOptionChainBloc!.headings.contains("GAMA")) {
        int index = marketOptionChainBloc!.headings.indexOf("GAMA");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("GAMA");
      }
      if (marketOptionChainBloc!.headings.contains("GAMA")) {
        int index = marketOptionChainBloc!.headings.indexOf("GAMA");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("GAMA");
      }
    }

    if (marketOptionChainBloc!.vega) {
      if (!marketOptionChainBloc!.headings.contains("VEGA")) {
        marketOptionChainBloc!.headings.insert(0, "VEGA");
        marketOptionChainBloc!.heading1.insert(0, "");

        marketOptionChainBloc!.headings.add("VEGA");
        marketOptionChainBloc!.heading1.add("");
      }
    } else {
      if (marketOptionChainBloc!.headings.contains("VEGA")) {
        int index = marketOptionChainBloc!.headings.indexOf("VEGA");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("VEGA");
      }
      if (marketOptionChainBloc!.headings.contains("VEGA")) {
        int index = marketOptionChainBloc!.headings.indexOf("VEGA");
        marketOptionChainBloc!.heading1.removeAt(index);

        marketOptionChainBloc!.headings.remove("VEGA");
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    marketOptionChainBloc?.disposeBloc();
    marketOptionChainBloc = null;
  }

  @override
  Widget build(BuildContext context) {
    topSpace = MediaQuery.of(context).size.height / 2;
    return Container(
      padding: const EdgeInsets.only(top: 10.0, bottom: 5.0),
      height: MediaQuery.of(context).size.height,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _containerOne(),
          _containerTwo(),
          /*_containerThree(), */
          // _ContainerFour(),
        ],
      ),
    );
  }

  Widget _containerOne() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          rowOne(),
          // RowTwo(),
        ],
      ),
    );
  }

  Widget _containerTwo() {
    /*  return Container(
      height: 63,
      padding: const EdgeInsets.only(left: 5.0, right: 5.0),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            blurRadius: 5.0,
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(child: callView()),
          verticalDivider(),
          Expanded(child: putView()),
        ],
      ),
    );
 */

    return Container(
      child: Flexible(
        fit: FlexFit.tight,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 50,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Container(
                        height: 35,
                        // padding: EdgeInsets.all(8.0),
                        color: Colors.green[200],
                        child: Container(
                          // color: Colors.amber,
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: Colors.green[200],
                            borderRadius: BorderRadius.circular(5),
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 4.5,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const Icon(Icons.arrow_left_sharp, size: 30),
                              TextButton(
                                child: const Text('Call'),
                                onPressed: () {
                                  if (globalVisibility == 'callput') {
                                    globalVisibility = 'call';
                                  } else if (globalVisibility == 'put') {
                                    globalVisibility = 'callput';
                                  } else {
                                    globalVisibility = 'call';
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      /*    FutureBuilder<List<GetExpiryResponseModel?>>(
                        future: marketOptionChainBloc
                            ?.callExpiryAPI(niftyController.text),
                        builder: (context, snapshot) {
                          return DropdownButton<String>(
                            // Initial Value
                            value: expiryDropdownValue ??
                                ((snapshot.data?.length ?? 0) > 0
                                    ? DateFormat('ddMMMyyyy')
                                        .format(DateTime
                                            .fromMillisecondsSinceEpoch(
                                                int.parse(snapshot.data
                                                            ?.elementAt(0)
                                                            ?.expiry
                                                            .toString() ??
                                                        '') *
                                                    1000))
                                        .toString()
                                    : null),

                            // Down Arrow Icon
                            icon: const Icon(Icons.keyboard_arrow_down),

                            // Array list of items
                            items: snapshot.data?.map((item) {
                                  return DropdownMenuItem(
                                    child: Text(DateFormat('ddMMMyyyy')
                                        .format(DateTime
                                            .fromMillisecondsSinceEpoch(
                                                int.parse(item?.expiry
                                                            .toString() ??
                                                        '') *
                                                    1000))),
                                    value: DateFormat('ddMMMyyyy').format(
                                        DateTime.fromMillisecondsSinceEpoch(
                                            int.parse(
                                                    item?.expiry.toString() ??
                                                        '') *
                                                1000)),
                                  );
                                }).toList() ??
                                [],
                            // After selecting the desired option,it will
                            // change button value to selected value
                            onChanged: (String? newValue) {
                              setState(() {
                                expiryDropdownValue = newValue!;
                              });
                              marketOptionChainBloc?.callStrikeAPI(
                                  niftyController.text,
                                  expiryDropdownValue ?? '');
                            },
                          );
                        },
                      ),
  */
                      IconButton(
                        onPressed: () async {
                          final popupResult = await GreekDialogPopupView
                              .marketoptionChainSettingDialog(
                            popContext: context,
                            optionChainBloc: marketOptionChainBloc,
                          );

                          if (popupResult != null) {
                            setState(() {
                              if (marketOptionChainBloc?.noofStrike == "10" ||
                                  marketOptionChainBloc?.noofStrike == "5" ||
                                  marketOptionChainBloc?.noofStrike == "15" ||
                                  marketOptionChainBloc?.noofStrike == "20" ||
                                  marketOptionChainBloc?.noofStrike == "All") {
                                marketOptionChainBloc
                                    ?.callExpiryAPI(niftyController.text)
                                    .then((value) {
                                  marketOptionChainBloc?.callStrikeAPI(
                                      niftyController.text,
                                      expiryDropdownValue ??
                                          DateFormat('ddMMMyyyy')
                                              .format(DateTime
                                                  .fromMillisecondsSinceEpoch(
                                                      int.parse(marketOptionChainBloc
                                                                  ?.getExpiryResponseArray
                                                                  .elementAt(0)
                                                                  ?.expiry
                                                                  .toString() ??
                                                              '') *
                                                          1000))
                                              .toString());
                                });
                              }
                            });
                          }
                        },
                        iconSize: 30,
                        color: ConstantColors.black,
                        icon: Image.asset(
                          'assets/images/setting.png',
                          fit: BoxFit.fitWidth,
                          width: 50,
                          height: 50,
                        ),
                      ),
                      SizedBox(
                        height: 35,
                        // padding: EdgeInsets.all(8.0),
                        // color: Colors.green[200],
                        child: Container(
                          // color: Colors.amber,
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: Colors.pink[200],
                            borderRadius: BorderRadius.circular(5),
                            boxShadow: const [
                              BoxShadow(
                                // color: Colors.green[200],
                                // spreadRadius: 1.2,
                                blurRadius: 4.5,
                                offset: Offset(1, 1),
                              ),
                            ],
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              TextButton(
                                child: const Text('Put'),
                                onPressed: () {
                                  if (globalVisibility == 'callput') {
                                    globalVisibility = 'put';
                                  } else if (globalVisibility == 'call') {
                                    globalVisibility = 'callput';
                                  } else {
                                    globalVisibility = 'put';
                                  }
                                  setState(() {});
                                },
                              ),
                              const Icon(
                                Icons.arrow_right_sharp,
                                size: 30,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ]),
              ),
              globalVisibility == 'callput'
                  ? buildMainOptionChain(true)
                  : globalVisibility == 'call'
                      ? buildMainOptionChainCall()
                      : buildMainOptionChainPut(),
            ],
          ),
        ),
      ),
    );
  }

  // =================================
  Widget firstDropDown() {
    return Container(
      height: 45,
      width: 105,
      margin: const EdgeInsets.only(top: 10, right: 10.0),
      child: DropdownButton(
        value: _type,
        icon: const Icon(Icons.arrow_drop_down),
        iconSize: 24,
        elevation: 16,
        alignment: Alignment.centerRight,
        style: const TextStyle(color: Colors.black),
        underline: Container(
          height: 1.0,
          color: Colors.black,
        ),
        items: items.map((String items) {
          return DropdownMenuItem(value: items, child: Text(items));
        }).toList(),
        onChanged: (String? newValue) {
          _type = newValue!;

          // marketOptionChainBloc?.callSearchForInstrumenAPi(_type);

          convertFutureListToList();
          //Loader stops

          setState(() {});
        },
      ),
    );
  }

  Widget rowOne() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        firstDropDown(),
        StreamBuilder<List<SymbolInstrumentData>>(
            stream: marketOptionChainBloc?.symbolObserver,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Container();
              }
              if (_instrumentSymbol != "") {
                marketOptionChainBloc?.callExpiryAPI(_instrumentSymbol);
              }

              return Container(
                height: 45,
                width: 128,
                margin: const EdgeInsets.only(top: 10, right: 10.0),
                child: DropdownButton<String>(
                  value: _instrumentSymbol,
                  icon: const Icon(Icons.arrow_drop_down),
                  iconSize: 24,
                  elevation: 16,
                  alignment: Alignment.centerRight,
                  style: const TextStyle(color: Colors.black),
                  underline: Container(
                    height: 1.0,
                    color: Colors.black,
                  ),
                  onChanged: (String? newValue) {
                    _instrumentSymbol = newValue!;

                    setState(() {});
                    // marketOptionChainBloc?.callExpiryAPI(_instrumentSymbol);
                  },
                  items: marketOptionChainBloc?.symbolList?.map((item) {
                        return DropdownMenuItem(
                          child: Text(item.symbol ?? ""),
                          value: item.symbol ?? "",
                        );
                      }).toList() ??
                      [],
                ),
                /*   );
              },
            ), */
                // ],
              );
            }),
        StreamBuilder<List<GetExpiryMarketResponseModel?>>(
            stream: marketOptionChainBloc?.expiryObserver,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Container();
              }
              if (snapshot.data!.isNotEmpty) {
                marketOptionChainBloc?.callStrikeAPI(
                    _instrumentSymbol,
                    DateFormat('ddMMMyyyy')
                        .format(DateTime.fromMillisecondsSinceEpoch(int.parse(
                                snapshot.data
                                        ?.elementAt(0)
                                        ?.expiry
                                        .toString() ??
                                    '') *
                            1000))
                        .toString());
              }
              return Container(
                height: 45,
                width: 100,
                margin: const EdgeInsets.only(top: 10),
                child: DropdownButton<String>(
                  value: expiryDropdownValue ??
                      ((snapshot.data?.length ?? 0) > 0
                          ? DateFormat('ddMMMyyyy')
                              .format(DateTime.fromMillisecondsSinceEpoch(
                                  int.parse(snapshot.data
                                              ?.elementAt(0)
                                              ?.expiry
                                              .toString() ??
                                          '') *
                                      1000))
                              .toString()
                          : null),
                  icon: const Icon(Icons.arrow_drop_down),
                  iconSize: 24,
                  elevation: 16,
                  alignment: Alignment.centerRight,
                  style: const TextStyle(color: Colors.black),
                  underline: Container(
                    height: 1.0,
                    color: Colors.black,
                  ),
                  onChanged: (String? newValue) {
                    setState(() {
                      if (newValue != null) {
                        expiryDropdownValue = newValue;
                      }
                    });
                    marketOptionChainBloc?.callStrikeAPI(
                        _instrumentSymbol, expiryDropdownValue ?? '');
                  },
                  items: snapshot.data?.map((item) {
                        return DropdownMenuItem(
                          child: Text(DateFormat('ddMMMyyyy').format(
                              DateTime.fromMillisecondsSinceEpoch(
                                  int.parse(item?.expiry.toString() ?? '') *
                                      1000))),
                          value: DateFormat('ddMMMyyyy').format(
                              DateTime.fromMillisecondsSinceEpoch(
                                  int.parse(item?.expiry.toString() ?? '') *
                                      1000)),
                        );
                      }).toList() ??
                      [],
                ),
              );
            }),
      ],
    );
  }

  Widget rowTwo() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            const Text(
              "View",
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.normal,
                  fontSize: 13),
            ),
            TextButton(
              onPressed: () {},
              child: Row(
                children: const [
                  Icon(
                    Icons.menu,
                    color: Colors.black,
                    size: 13,
                  ),
                  SizedBox(
                    width: 8,
                  ),
                  Text(
                    "List",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                        fontSize: 13),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: () {},
              child: Row(
                children: const [
                  Text(
                    "|||",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                        fontSize: 13),
                  ),
                  SizedBox(
                    width: 8,
                  ),
                  Text(
                    "Graph",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                        fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
        Row(
          children: [
            Checkbox(
              checkColor: Colors.white,
              value: isChecked,
              onChanged: (bool? value) {
                setState(() {
                  isChecked = value!;
                });
              },
            ),
            const Text(
              "All Strikes",
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.normal,
                  fontSize: 11),
            ),
            IconButton(
              padding: EdgeInsets.zero,
              onPressed: () {},
              icon: const Icon(
                Icons.settings_outlined,
                color: Colors.black,
                size: 15,
              ),
            )
          ],
        )
      ],
    );
  }

  Widget callView() {
    return StreamBuilder<List<GetMarketStrikeResponseModel>>(
        stream: marketOptionChainBloc?.strikeObserver,
        builder: (context, snapshot) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Call",
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.normal,
                      fontSize: 13),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text(
                      "Future",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          fontSize: 13),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      snapshot.data?.first.strikeprice ?? ' ',
                      style: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 14),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget verticalDivider() {
    return Container(
      width: 1,
      height: MediaQuery.of(context).size.height,
      margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
      color: Colors.black,
    );
  }

  Widget putView() {
    return StreamBuilder<List<GetMarketStrikeResponseModel>>(
        stream: marketOptionChainBloc?.strikeObserver,
        builder: (context, snapshot) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Spot",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          fontSize: 13),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      snapshot.data?.last.strikeprice ?? '',
                      style: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 14),
                    ),
                  ],
                ),
                const Text(
                  "Put",
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.normal,
                      fontSize: 13),
                ),
              ],
            ),
          );
        });
  }

  StreamBuilder<List<OptionChainResponseModel?>> buildMainOptionChain(
      bool visibility) {
    return StreamBuilder<List<OptionChainResponseModel?>>(
      stream: marketOptionChainBloc?.optionChainObserverable,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int lengthData = snapshot.data?.length ?? 0;
          if (lengthData <= 0) {
            return NoDatWithProgressIndicator(
              topSpace: topSpace,
              showHide: false,
              message: '',
            );
          }
          num length = int.parse(
              marketOptionChainBloc?.headings.length.toString() ?? "0");
          return Visibility(
            visible: visibility,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              reverse: true,
              child: Column(
                children: [
                  SizedBox(
                    height: 35,
                    width: length * 84,
                    child: StreamBuilder<bool>(
                      stream: marketOptionChainBloc?.settingObserver,
                      builder: (context, snapshot) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: _buildRowList(from: 'callput'),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height - 320,
                    width: length * 84,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: (snapshot.data?.length),
                      itemBuilder: (context, index) {
                        return Container(
                          // width: MediaQuery.of(context).size.width * 0.25,
                          alignment: Alignment.center,
                          color: ConstantColors.white,
                          child: Row(
                            children: index > 0
                                ? _builddataRow(snapshot.data?[index], index,
                                    snapshot.data?[index - 1]?.strikePrice)
                                : _builddataRow(snapshot.data?[index], index,
                                    snapshot.data?[index]?.strikePrice),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        } else {
          return NoDatWithProgressIndicator(
            topSpace: topSpace,
            showHide: true,
            message: 'Fetching data',
          );
        }
      },
    );
  }

  StreamBuilder<List<OptionChainResponseModel?>> buildMainOptionChainCall() {
    return StreamBuilder<List<OptionChainResponseModel?>>(
      stream: marketOptionChainBloc?.optionChainObserverable,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int lengthData = snapshot.data?.length ?? 0;
          if (lengthData <= 0) {
            return NoDatWithProgressIndicator(
              topSpace: topSpace,
              showHide: false,
              message: '',
            );
          }
          num length = int.parse(
              marketOptionChainBloc?.headings.length.toString() ?? "0");
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Column(
              children: [
                SizedBox(
                  height: 35,
                  width: MediaQuery.of(context).size.width,
                  child: StreamBuilder<bool>(
                      stream: marketOptionChainBloc?.settingObserver,
                      builder: (context, snapshot) {
                        return Row(
                          children: _buildRowList(from: 'call'),
                        );
                      }),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: snapshot.data?.length,
                    itemBuilder: (context, index) {
                      return Container(
                        width: length < 5
                            ? MediaQuery.of(context).size.width
                            : MediaQuery.of(context).size.width * 0.25,
                        alignment: Alignment.center,
                        color: ConstantColors.white,
                        child: Row(
                          children: _builddataRow(snapshot.data?[index], index),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        } else {
          return NoDatWithProgressIndicator(
            topSpace: topSpace,
            showHide: true,
            message: 'Fetching data',
          );
        }
      },
    );
  }

  Widget _buildDataRowput(var data, int index) {
    return SizedBox(
      width: MediaQuery.of(context).size.width /
          marketOptionChainBloc!.headingCallPut.length,
      child: Column(
        children: [
          Row(
            children: [
              Container(
                  color: Colors.white,
                  padding: const EdgeInsets.only(right: 5),
                  width: MediaQuery.of(context).size.width /
                      marketOptionChainBloc!.headingCallPut.length,
                  height: 50,
                  alignment: Alignment.centerRight,
                  child: marketOptionChainBloc?.headingCallPut[index] != ""
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            marketOptionChainBloc?.headingsPut[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? lopeninterest(((data?.put?.lOpenInterest / 100000)
                                    .toString()))
                                : marketOptionChainBloc?.headingsPut[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? lopeninterest("${data?.put?.ltp ?? ''}")
                                    : marketOptionChainBloc?.headingsPut[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? lopeninterest("0")
                                        : marketOptionChainBloc?.headingsPut[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "volume"
                                            ? lopeninterest(
                                                "${data?.put?.lVolume ?? ''}")
                                            : marketOptionChainBloc?.headingsPut[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "gama"
                                                ? marketOptionChainBloc!.headingsPut
                                                            .indexOf("Strike") >
                                                        index
                                                    ? lopeninterest("0")
                                                    : lopeninterest("0")
                                                : marketOptionChainBloc
                                                            ?.headingsPut[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "vega"
                                                    ? marketOptionChainBloc!.headingsPut.indexOf("Strike") > index
                                                        ? lopeninterest("0")
                                                        : lopeninterest("0")
                                                    : marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() == "iv"
                                                        ? marketOptionChainBloc!.headingsPut.indexOf("Strike") > index
                                                            ? lopeninterest("0")
                                                            : lopeninterest("0")
                                                        : marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() == "Strike"
                                                            ? Container(color: Colors.grey, child: lopeninterest("${data?.strikePrice ?? ''}"))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                )),
                            marketOptionChainBloc?.headingsPut[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? changetextview("${data?.put?.oiChange ?? ''}")
                                : marketOptionChainBloc?.headingsPut[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? changetextview(
                                        "${data?.put?.change ?? ''}")
                                    : marketOptionChainBloc?.headingsPut[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? changetextview("0")
                                        : marketOptionChainBloc?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "gama"
                                            ? changetextview("0")
                                            : marketOptionChainBloc
                                                        ?.headings[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "vega"
                                                ? changetextview("0")
                                                : marketOptionChainBloc
                                                            ?.headings[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "iv"
                                                    ? changetextview("0")
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        )),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() ==
                                    "oi"
                                ? Text(
                                    lopeninterest(
                                        ((data?.put?.lOpenInterest / 100000)
                                            .toString())),
                                    style: const TextStyle(
                                      fontSize: 12.0,
                                    ),
                                  )
                                : marketOptionChainBloc?.headingsPut[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? Text("${data?.put?.ltp ?? ''}",
                                        style: const TextStyle(
                                          fontSize: 12.0,
                                        ))
                                    : marketOptionChainBloc?.headingsPut[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "volume"
                                        ? Text("${data?.put?.lVolume ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                        : marketOptionChainBloc?.headingsPut[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "delta"
                                            ? marketOptionChainBloc!.headingsPut
                                                        .indexOf("Strike") >
                                                    index
                                                ? const Text("0",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                                : const Text("0",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                            : marketOptionChainBloc
                                                        ?.headingsPut[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "iv"
                                                ? marketOptionChainBloc!.headingsPut
                                                            .indexOf("Strike") >
                                                        index
                                                    ? const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                : marketOptionChainBloc
                                                            ?.headingsPut[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "greeks"
                                                    ? marketOptionChainBloc!.headingsPut.indexOf("Strike") > index
                                                        ? const Text("0",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                        : const Text("0",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                    : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "gama"
                                                        ? marketOptionChainBloc!.headingsPut.indexOf("Strike") > index
                                                            ? const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                        : marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() == "vega"
                                                            ? marketOptionChainBloc!.headingsPut.indexOf("Strike") > index
                                                                ? const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                            : marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() == "strike"
                                                                ? Container(
                                                                    color: const Color
                                                                            .fromRGBO(
                                                                        226,
                                                                        226,
                                                                        226,
                                                                        1),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    height: 50,
                                                                    child: Text(
                                                                        "${data?.strikePrice ?? ''}",
                                                                        style: GreekTextStyle
                                                                            .optionChainStrike),
                                                                  )
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    )),
                          ],
                        )),
            ],
          ),
          Container(
              height: 1,
              width: 140,
              color: Colors.grey,
              margin: const EdgeInsets.only(top: 2, bottom: 2))
        ],
      ),
    );
  }

  StreamBuilder<List<OptionChainResponseModel?>> buildMainOptionChainPut() {
    return StreamBuilder<List<OptionChainResponseModel?>>(
      stream: marketOptionChainBloc?.optionChainObserverable,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int lengthData = snapshot.data?.length ?? 0;
          if (lengthData <= 0) {
            return NoDatWithProgressIndicator(
              topSpace: topSpace,
              showHide: false,
              message: '',
            );
          }
          num length = 0;
          if (globalVisibility == "callput") {
            length = int.parse(
                marketOptionChainBloc?.headings.length.toString() ?? "0");
          } else if (globalVisibility == "call") {
            length = int.parse(
                marketOptionChainBloc?.headingsCall.length.toString() ?? "0");
          } else if (globalVisibility == "put") {
            length = int.parse(
                marketOptionChainBloc?.headingCallPut.length.toString() ?? "0");
          }

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Column(
              children: [
                StreamBuilder<bool>(
                    stream: marketOptionChainBloc?.settingObserver,
                    builder: (context, snapshot) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: _buildRowList(from: 'put'),
                          ),
                        ],
                      );
                    }),
                SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: snapshot.data?.length,
                    itemBuilder: (context, index) {
                      return Container(
                        width: length < 5
                            ? MediaQuery.of(context).size.width
                            : MediaQuery.of(context).size.width * 0.25,
                        alignment: Alignment.center,
                        color: ConstantColors.white,
                        child: Row(
                          children: _builddataRow(snapshot.data?[index], index),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        } else {
          return NoDatWithProgressIndicator(
            topSpace: topSpace,
            showHide: true,
            message: 'Fetching data',
          );
        }
      },
    );
  }

  List<Widget> _builddataRow(param0, int index, [double? strikePrice]) {
    List<Widget> places = [];
    if (globalVisibility == "callput") {
      num length =
          int.parse(marketOptionChainBloc?.headings.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildDataRow(param0, i, strikePrice));
      }
    } else if (globalVisibility == "put") {
      num length = int.parse(
          marketOptionChainBloc?.headingsPut.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildDataRowput(param0, i));
      }
    } else if (globalVisibility == "call") {
      num length = int.parse(
          marketOptionChainBloc?.headingsCall.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildDataRowCall(param0, i));
      }
    }
    return places;
  }

  Widget _buildDataRowCall(var data, int index) {
    return Container(
      color: const Color.fromRGBO(203, 234, 203, 1),
      // decoration: BoxDecoration(color: Colors.green[50]),
      width: MediaQuery.of(context).size.width /
          marketOptionChainBloc!.headingCallValue.length,
      child: Column(
        children: [
          Row(
            // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                  padding: const EdgeInsets.only(right: 5),
                  width: MediaQuery.of(context).size.width /
                      marketOptionChainBloc!.headingsCall.length,
                  height: 50,
                  alignment: Alignment.centerRight,
                  child: marketOptionChainBloc?.headingCallValue[index] != ""
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            marketOptionChainBloc?.headingsCall[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? lopeninterest((data?.call?.lOpenInterest / 100000)
                                    .toString())
                                : marketOptionChainBloc?.headingsCall[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? lopeninterest("${data?.call?.ltp ?? ''}")
                                    : marketOptionChainBloc?.headingsCall[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? lopeninterest("0")
                                        : marketOptionChainBloc?.headingsCall[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "volume"
                                            ? lopeninterest(
                                                "${data?.call?.lVolume ?? ''}")
                                            : marketOptionChainBloc?.headingsCall[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "gama"
                                                ? marketOptionChainBloc!.headingsCall
                                                            .indexOf("Strike") >
                                                        index
                                                    ? lopeninterest("0")
                                                    : lopeninterest("0")
                                                : marketOptionChainBloc
                                                            ?.headingsCall[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "vega"
                                                    ? marketOptionChainBloc!.headingsCall.indexOf("Strike") > index
                                                        ? lopeninterest("0")
                                                        : lopeninterest("0")
                                                    : marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() == "iv"
                                                        ? marketOptionChainBloc!.headingsCall.indexOf("Strike") > index
                                                            ? lopeninterest("0")
                                                            : lopeninterest("0")
                                                        : marketOptionChainBloc?.headingsPut[index].toString().toLowerCase() == "Strike"
                                                            ? Container(color: Colors.grey, child: lopeninterest("${data?.strikePrice ?? ''}"))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                )),
                            marketOptionChainBloc?.headingsCall[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? changetextview(
                                    "${data?.call?.oiChange ?? ''}")
                                : marketOptionChainBloc?.headingsCall[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? changetextview(
                                        "${data?.call?.change ?? ''}")
                                    : marketOptionChainBloc?.headingsCall[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? changetextview("0")
                                        : marketOptionChainBloc
                                                    ?.headingsCall[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "gama"
                                            ? changetextview("0")
                                            : marketOptionChainBloc
                                                        ?.headingsCall[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "vega"
                                                ? changetextview("0")
                                                : marketOptionChainBloc
                                                            ?.headingsCall[
                                                                index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "iv"
                                                    ? changetextview("0")
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        )),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            marketOptionChainBloc?.headingsCall[index].toString().toLowerCase() ==
                                    "oi"
                                ? Text(
                                    lopeninterest(
                                        (data?.call?.lOpenInterest / 100000)
                                            .toString()),
                                    style: const TextStyle(
                                      fontSize: 12.0,
                                    ),
                                  )
                                : marketOptionChainBloc?.headingsCall[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? Text("${data?.call?.ltp ?? ''}",
                                        style: const TextStyle(
                                          fontSize: 12.0,
                                        ))
                                    : marketOptionChainBloc?.headingsCall[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "volume"
                                        ? Text("${data?.call?.lVolume ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                        : marketOptionChainBloc?.headingsCall[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "delta"
                                            ? marketOptionChainBloc!.headingsCall
                                                        .indexOf("Strike") >
                                                    index
                                                ? const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                                : const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                            : marketOptionChainBloc
                                                        ?.headingsCall[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "iv"
                                                ? marketOptionChainBloc!.headingsCall
                                                            .indexOf("Strike") >
                                                        index
                                                    ? const Text("Iv",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                    : const Text("Iv",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                : marketOptionChainBloc
                                                            ?.headingsCall[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "greeks"
                                                    ? marketOptionChainBloc!.headingsCall.indexOf("Strike") > index
                                                        ? const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                        : const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                    : marketOptionChainBloc?.headingsCall[index].toString().toLowerCase() == "gama"
                                                        ? marketOptionChainBloc!.headingsCall.indexOf("Strike") > index
                                                            ? const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                            : const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                        : marketOptionChainBloc?.headingsCall[index].toString().toLowerCase() == "vega"
                                                            ? marketOptionChainBloc!.headingsPut.indexOf("Strike") > index
                                                                ? const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                            : marketOptionChainBloc?.headingsCall[index].toString().toLowerCase() == "strike"
                                                                ? Container(
                                                                    color: const Color
                                                                            .fromRGBO(
                                                                        226,
                                                                        226,
                                                                        226,
                                                                        1),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    height: 50,
                                                                    child: Text(
                                                                        "${data?.strikePrice ?? ''}",
                                                                        style: GreekTextStyle
                                                                            .optionChainStrike),
                                                                  )
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    )),
                          ],
                        )),
            ],
          ),
          Container(
              height: 1,
              width: 140,
              color: Colors.grey,
              margin: const EdgeInsets.only(top: 2, bottom: 2))
        ],
      ),
    );
    // }
    // return Container();
  }

  Widget _buildDataRow(var data, int index, [double? previousstrike]) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        (data?.strikePrice >
                    double.parse(marketOptionChainBloc?.ltp ?? "") / 100) &&
                (previousstrike! <
                    double.parse(marketOptionChainBloc?.ltp ?? "") / 100)
            ? SizedBox(
                // color: Colors.grey[350],
                height: 30,
                width: 80,
                child: marketOptionChainBloc?.headings[index]
                            .toString()
                            .toLowerCase() ==
                        "strike"
                    ? Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                              color: const Color.fromARGB(54, 54, 54, 1),
                              width: 1),
                          color: const Color(0xFF127FBA),
                        ),
                        // color: Color(0xFF127FBA),
                        child: Center(
                          child: Text(
                            (double.parse(marketOptionChainBloc?.ltp ?? "") /
                                    100)
                                .toStringAsFixed(2),
                            style: GreekTextStyle.optionChainStrikeDispaly,
                          ),
                        ))
                    : marketOptionChainBloc!.headings.indexOf("Strike") > index
                        ? Text(
                            "",
                            style: GreekTextStyle.optionChainStrikecallputText,
                            textAlign: TextAlign.right,
                          )
                        : Text(
                            "",
                            style: GreekTextStyle.optionChainStrikecallputText,
                            textAlign: TextAlign.right,
                          ),
              )
            : Container(),
        Row(
          children: [
            GestureDetector(
              onTap: () async {
                /*       GreekNavigator.pop(context: context);
                await GreekNavigator.pushNamed(
                  context: context,
                  routeName: GreekScreenNames.place_order,
                  arguments: [
                    marketOptionChainBloc!.headings.indexOf("Strike") > index
                        ? data?.call?.lOurToken
                        : data?.put?.lOurToken,
                    OrderAction.buy,
                    OrderMode.newOrder,
                    ScriptInfoTab.overview.index,
                  ],
                ); */
              },
              child: Container(
                  color:
                      marketOptionChainBloc!.headings.indexOf("Strike") > index
                          ? const Color.fromRGBO(203, 234, 203, 1)
                          : Colors.white,
                  width: 80,
                  height: 50,
                  alignment: Alignment.centerRight,
                  child: marketOptionChainBloc?.heading1[index] != ""
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            marketOptionChainBloc?.headings[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? marketOptionChainBloc!.headings.indexOf("Strike") >
                                        index
                                    ? lopeninterest(
                                        (data?.call?.lOpenInterest / 100000)
                                            .toString())
                                    : lopeninterest(
                                        ((data?.put?.lOpenInterest / 100000)
                                            .toString()))
                                : marketOptionChainBloc?.headings[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? marketOptionChainBloc!.headings.indexOf("Strike") >
                                            index
                                        ? lopeninterest(
                                            "${data?.call?.ltp ?? ''}")
                                        : lopeninterest(
                                            "${data?.put?.ltp ?? ''}")
                                    : marketOptionChainBloc?.headings[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? marketOptionChainBloc!.headings
                                                    .indexOf("Strike") >
                                                index
                                            ? lopeninterest("0")
                                            : lopeninterest("0")
                                        : marketOptionChainBloc?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "volume"
                                            ? marketOptionChainBloc!.headings
                                                        .indexOf("Strike") >
                                                    index
                                                ? lopeninterest("${data?.call?.lVolume ?? ''}")
                                                : lopeninterest("${data?.put?.lVolume ?? ''}")
                                            : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "gama"
                                                ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                    ? lopeninterest("0")
                                                    : lopeninterest("0")
                                                : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "vega"
                                                    ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                        ? lopeninterest("0")
                                                        : lopeninterest("0")
                                                    : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "iv"
                                                        ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                            ? lopeninterest("0")
                                                            : lopeninterest("0")
                                                        : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "Strike"
                                                            ? Container(color: const Color.fromARGB(54, 54, 54, 1), child: lopeninterest("${data?.strikePrice ?? ''}"))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                )),
                            marketOptionChainBloc?.headings[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? marketOptionChainBloc!.headings.indexOf("Strike") >
                                        index
                                    ? changetextview(
                                        "${data?.call?.oiChange ?? ''}")
                                    : changetextview(
                                        "${data?.put?.oiChange ?? ''}")
                                : marketOptionChainBloc?.headings[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? marketOptionChainBloc!.headings.indexOf("Strike") >
                                            index
                                        ? changetextview(
                                            "${data?.call?.change ?? ''}")
                                        : changetextview(
                                            "${data?.put?.change ?? ''}")
                                    : marketOptionChainBloc?.headings[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? marketOptionChainBloc!.headings
                                                    .indexOf("Strike") >
                                                index
                                            ? changetextview("0")
                                            : changetextview("0")
                                        : marketOptionChainBloc?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "gama"
                                            ? marketOptionChainBloc!.headings
                                                        .indexOf("Strike") >
                                                    index
                                                ? changetextview("0")
                                                : changetextview("0")
                                            : marketOptionChainBloc?.headings[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "vega"
                                                ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                    ? changetextview("0")
                                                    : changetextview("0")
                                                : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "iv"
                                                    ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                        ? changetextview("0")
                                                        : changetextview("0")
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        )),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            marketOptionChainBloc?.headings[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? marketOptionChainBloc!.headings.indexOf("Strike") >
                                        index
                                    ? Text(
                                        lopeninterest(
                                            (data?.call?.lOpenInterest / 100000)
                                                .toString()),
                                        style: const TextStyle(
                                          fontSize: 12.0,
                                        ),
                                      )
                                    : Text(
                                        lopeninterest(
                                            (data?.put?.lOpenInterest / 100000)
                                                .toString()),
                                        style: const TextStyle(
                                          fontSize: 12.0,
                                        ),
                                      )
                                : marketOptionChainBloc?.headings[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? marketOptionChainBloc!.headings.indexOf("Strike") >
                                            index
                                        ? Text("${data?.call?.ltp ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                        : Text("${data?.put?.ltp ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                    : marketOptionChainBloc?.headings[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "volume"
                                        ? marketOptionChainBloc!.headings
                                                    .indexOf("Strike") >
                                                index
                                            ? Text(
                                                "${data?.call?.lVolume ?? ''}",
                                                style: const TextStyle(
                                                  fontSize: 12.0,
                                                ))
                                            : Text(
                                                "${data?.put?.lVolume ?? ''}",
                                                style: const TextStyle(
                                                  fontSize: 12.0,
                                                ))
                                        : marketOptionChainBloc?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "delta"
                                            ? marketOptionChainBloc!.headings
                                                        .indexOf("Strike") >
                                                    index
                                                ? const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                                : const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                            : marketOptionChainBloc?.headings[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "iv"
                                                ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                    ? const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "greeks"
                                                    ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                        ? const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                        : const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                    : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "gama"
                                                        ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                            ? const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                            : const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                        : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "vega"
                                                            ? marketOptionChainBloc!.headings.indexOf("Strike") > index
                                                                ? const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                            : marketOptionChainBloc?.headings[index].toString().toLowerCase() == "strike"
                                                                ? Container(
                                                                    color: const Color
                                                                            .fromRGBO(
                                                                        226,
                                                                        226,
                                                                        226,
                                                                        1),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    height: 50,
                                                                    child: Text(
                                                                        double.parse(data?.strikePrice.toString() ??
                                                                                "")
                                                                            .toStringAsFixed(
                                                                                2),
                                                                        style: GreekTextStyle
                                                                            .optionChainStrike),
                                                                  )
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    )),
                          ],
                        )),
            ),
          ],
        ),
        Container(
          height: 2,
          width: 80,
          color: const Color.fromRGBO(226, 226, 226, 1),
        ),
      ],
    );
  }

  changetextview(s) {
    return Container(
      width: 80,
      padding: const EdgeInsets.only(top: 5, bottom: 5),
      // color: Color.fromRGBO(203, 234, 203, 1),
      child: Text(double.parse(s).toStringAsFixed(2),
          style: double.parse(s.toString()) >= 0.00
              ? GreekTextStyle.optionchainChangepositive
              : GreekTextStyle.optionchainChangenegative,
          textAlign: TextAlign.right),
    );
  }

  lopeninterest(lOpenInterest) {
    // String textval = (double.parse(lOpenInterest)).toString();
    return Flexible(
      flex: 1,
      child: Container(
        padding: const EdgeInsets.only(top: 5, bottom: 5),
        child: Text(double.parse(lOpenInterest.toString()).toStringAsFixed(2),
            style: GreekTextStyle.optionchainlist),
      ),
    );
  }

  List<Widget> _buildRowList({required String from}) {
    List<Widget> places = [];
    //callput
    if (from == 'callput') {
      num length =
          int.parse(marketOptionChainBloc?.headings.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildPlace(marketOptionChainBloc?.headings[i] ?? "", i,
            length, marketOptionChainBloc?.heading1));
      }
    }
    //call
    else if (from == 'call') {
      num length = int.parse(
          marketOptionChainBloc?.headingsCall.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildPlacecallput(
            marketOptionChainBloc?.headingsCall[i] ?? "",
            i,
            length,
            marketOptionChainBloc?.headingCallValue));
      }
    } //put
    else if (from == 'put') {
      num length = int.parse(
          marketOptionChainBloc?.headingsPut.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildPlacecallput(
            marketOptionChainBloc?.headingsPut[i] ?? "",
            i,
            length,
            marketOptionChainBloc?.headingCallPut));
      }
    }

    return places;
  }

  Widget _buildPlace(
      String place, int index, num length, List<String>? heading) {
    bool checkTitle = true;
    switch (place.toLowerCase()) {
      case 'iv':
        checkTitle = false;
        break;
      case 'strike':
        checkTitle = false;
        break;
      default:
    }
    return Container(
        decoration: const BoxDecoration(
          color: Color.fromRGBO(255, 255, 255, 1),
        ),
        width: 80,
        height: 35,
        child: checkTitle
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    place,
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                  Text(
                    heading![index],
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0),
                    child: Text(
                      place,
                      style: GreekTextStyle.placeOrderAppbarHeading,
                    ),
                  ),
                ],
              ));
  }

  Widget _buildPlacecallput(
      String place, int index, num length, List<String>? heading) {
    bool checkTitle = true;
    switch (place.toLowerCase()) {
      case 'iv':
        checkTitle = false;
        break;
      case 'strike':
        checkTitle = false;
        break;
      default:
    }
    return Container(
        decoration: BoxDecoration(
          color: Colors.grey[200],
        ),
        //color: Colors.yellow,
        width: MediaQuery.of(context).size.width / heading!.length,
        height: 35,
        child: checkTitle
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    place,
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                  Text(
                    heading[index],
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0),
                    child: Text(
                      place,
                      style: GreekTextStyle.placeOrderAppbarHeading,
                    ),
                  ),
                ],
              ));
  }
}
