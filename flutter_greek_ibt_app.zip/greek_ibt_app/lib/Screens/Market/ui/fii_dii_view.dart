import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/fidi_view_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/fii_dii_response_model.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class FiiDiiScreen extends StatefulWidget {
  // final MarketMapBloc marketBloc;

  const FiiDiiScreen({Key? key}) : super(key: key);

  @override
  _GraphState createState() => _GraphState();
}

class _GraphState extends State<FiiDiiScreen> {
  FiiDiiBloc? _fidiBloc;
  List<String> intervalDropdownValues = [
    'Daily',
    'Monthly',
    'Yearly',
  ];
  var selectedInterval = 'Daily';

  List<String> rightDropdownValues = [
    "FII Cash",
    "DII Cash",
    "FII Index Futures",
    "FII Stock Futures",
    "FII Index Options",
    "FII Stock Options",
  ];
  var selectedType = "FII Cash";

  String expiry = '';
  String netAmoutResult = '';

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _fidiBloc?.callFiiDiiAPI();
    });
  }

  @override
  Widget build(BuildContext context) {
    _fidiBloc ??= FiiDiiBloc(context);
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            _containerOne(),
            _containerTwo(),
          ],
        ),
      ),
    );
  }

  Widget _containerOne() {
    return Container(
      height: 40,
      padding: const EdgeInsets.only(left: 8.0, right: 8.0),
      margin: const EdgeInsets.only(top: 2.0, bottom: 3.0),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            blurRadius: 5.0,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          leftDropdownWidget(),
          rightDropdownWidget(),
        ],
      ),
    );
  }

  _containerTwo() => StreamBuilder<List<FIIDIIResponseModelNew?>?>(
        stream: _fidiBloc?.fiidiiObserver,
        builder: (streamContext, snapshot) {
          if ((snapshot.data != null) && (snapshot.data!.isNotEmpty)) {
            return Flexible(
              fit: FlexFit.loose,
              child: ListView.builder(
                itemCount: snapshot.data?.length ?? 0,
                itemBuilder: (context, index) {
                  // getExpiryInvestment(index, snapshot);
                  return Container(
                    height: 50,
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: 92,
                          child: Text(
                            snapshot.data?[index]?.reportingDate ??
                                '', // expiry,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                        Expanded(
                          child: SfCartesianChart(
                            plotAreaBorderWidth: 0,
                            primaryXAxis: CategoryAxis(
                              isVisible: false,
                              majorGridLines: const MajorGridLines(width: 0),
                            ),
                            primaryYAxis: NumericAxis(
                              isVisible: false,
                              minimum: _fidiBloc?.minVal,
                              maximum: _fidiBloc?.maxVal,
                              majorTickLines: const MajorTickLines(size: 0),
                            ),
                            series: [
                              BarSeries<FIIDIIResponseModelNew?, String>(
                                dataSource: snapshot.data ?? [],
                                xValueMapper: (FIIDIIResponseModelNew? model,
                                        _) =>
                                    snapshot.data?[index]?.reportingDate ?? '',
                                yValueMapper:
                                    (FIIDIIResponseModelNew? model, _) =>
                                        snapshot.data?[index]?.netAmount ??
                                        0.0, //double.parse(netAmoutResult),
                                spacing: 2,
                                color: (snapshot.data
                                                ?.elementAt(index)
                                                ?.netAmount ??
                                            0) >
                                        0
                                    ? Colors.green
                                    : Colors.red,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 92,
                          child: Text(
                            '${snapshot.data?[index]?.netAmount?.toStringAsFixed(2) ?? '0.0'} Cr',
                            style: const TextStyle(fontSize: 14),
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            );
          }

          return GreekBase().noDataAvailableView();
        },
      );

  /*void getExpiryInvestment(
      int index, AsyncSnapshot<List<FIIDIIResponseModel?>?> snapshot) {
    if (_fidiBloc?.fiiDiiType == FiiDiiType.investment) {
      if (selectedType.toLowerCase().contains("fii")) {
        if (snapshot.data?[index]?.reportingDate != null) {
          expiry =
              '${snapshot.data?[index]?.reportingDate?.replaceAll('-', ' ')}';
        }
        if (snapshot.data?[index]?.netAmount != null) {
          netAmoutResult = double.parse('${snapshot.data?[index]?.netAmount}')
              .toStringAsFixed(2);
        }
      } else {
        if (snapshot.data?[index]?.reportingDate != null) {
          expiry =
              '${snapshot.data?[index]?.reportingDate?.replaceAll('-', ' ')}';
        }
        if (snapshot.data?[index]?.netAmount != null) {
          netAmoutResult = double.parse('${snapshot.data?[index]?.netAmount}')
              .toStringAsFixed(2);
        }
      }
    } else if (_fidiBloc?.fiiDiiType == FiiDiiType.derivatives) {
      if (selectedType.toLowerCase().contains("future")) {
        if (snapshot.data?[index]?.reportingDate != null) {
          expiry =
              '${snapshot.data?[index]?.reportingDate?.replaceAll('-', ' ')}';
        }
        if (snapshot.data?[index]?.netAmount != null) {
          netAmoutResult = double.parse('${snapshot.data?[index]?.netAmount}')
              .toStringAsFixed(2);
        }
      } else {
        if (snapshot.data?[index]?.reportingDate != null) {
          expiry =
              '${snapshot.data?[index]?.reportingDate?.replaceAll('-', ' ')}';
        }
        if (snapshot.data?[index]?.netAmount != null) {
          netAmoutResult = double.parse('${snapshot.data?[index]?.netAmount}')
              .toStringAsFixed(2);
        }
      }
    }
  }*/

  Widget leftDropdownWidget() {
    return DropdownButton<String>(
      borderRadius: const BorderRadius.all(Radius.circular(10.0)),
      value: selectedInterval,
      icon: const Icon(Icons.arrow_drop_down),
      iconSize: 24,
      elevation: 16,
      style: const TextStyle(color: Colors.black, fontSize: 16),
      underline: Container(
        height: 0.0,
      ),
      onChanged: (data) {
        setState(() {
          selectedInterval = data!;
        });

        _fidiBloc?.fiiDiiInterval =
            data?.toFiiDiiInterval() ?? FiiDiiInterval.Daily;
        _fidiBloc?.callFiiDiiAPI();
      },
      items:
          intervalDropdownValues.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(
            value,
          ),
        );
      }).toList(),
    );
  }

  Widget rightDropdownWidget() {
    return DropdownButton<String>(
      borderRadius: const BorderRadius.all(Radius.circular(10.0)),
      value: selectedType,
      icon: const Icon(Icons.arrow_drop_down),
      iconSize: 24,
      elevation: 16,
      style: const TextStyle(color: Colors.black, fontSize: 16),
      underline: Container(
        height: 0.0,
      ),
      onChanged: (data) {
        setState(() {
          selectedType = data!;
        });
        _fidiBloc?.fiiDiiType = selectedType.toFiiDiiType();
        _fidiBloc?.callFiiDiiAPI();
      },
      items: rightDropdownValues.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(
            value,
          ),
        );
      }).toList(),
    );
  }
}
