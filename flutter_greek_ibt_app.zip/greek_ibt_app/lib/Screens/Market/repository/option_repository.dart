import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_strike_reponse_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/fii_dii_response_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_expiry_market.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/option_chain_call_put_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/Market/models/symbol_instrument.dart';

class OptionRepository {
  Future<List<SymbolInstrumentData>> getSymbolForInstrument(String type) async {
    var instName = "FUTIDX";

    if (type == "Index") {
      instName = "FUTIDX";
    } else if (type == "Stock") {
      instName = "FUTSTK";
    }
    final responseBody = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getSymbolForInstrument, query: 'instName=$instName');
    if (responseBody is List) {
      final obj =
          responseBody.map((e) => SymbolInstrumentData.fromJson(e)).toList();
      return obj;
    } /* else if (ResponseBody is Map<String, dynamic>) {
      final obj = InstrumentSymbolResponseModel.fromJson(ResponseBody);
      return [];
    } */

    return [];
  }

  Future<List<GetExpiryMarketResponseModel>> getMarketExpiryAPI(
    BuildContext context, {
    required String symbol,
  }) async {
    final requestQuery = "cSymbol=" + symbol;

    final valGetExpiry = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getexpiryRequest,
      query: requestQuery,
    );

    List<GetExpiryMarketResponseModel> objList =
        <GetExpiryMarketResponseModel>[];

    if (valGetExpiry is List) {
      objList = valGetExpiry
          .map(
            (e) => GetExpiryMarketResponseModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<List<GetMarketStrikeResponseModel>> getStrikeAPI(
    BuildContext context, {
    required String symbol,
    required String expiry,
  }) async {
    final requestQuery = "cSymbol=" + symbol + "&lExpiry=" + expiry.toString();

    final valGetStrike = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getstrikeRequest,
      query: requestQuery,
    );

    List<GetMarketStrikeResponseModel> objList =
        <GetMarketStrikeResponseModel>[];

    if (valGetStrike is List) {
      objList = valGetStrike
          .map(
            (e) => GetMarketStrikeResponseModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<dynamic> getLTP(BuildContext context,
      {required String symbol, required String expiry}) async {
    final requestQuery = "symbol=" + symbol + "&expiry=" + expiry;

    final valLTP = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getFutLTP,
      query: requestQuery,
    );

    if (valLTP is Map<String, dynamic>) {
      //final obj = GetLTPModel.fromJson(valLTP);
      return valLTP;
    }
  }

  Future<List<FIIDIIResponseModelNew>> getFiiDiiAPI({
    required BuildContext context,
    required FiiDiiType type,
    required FiiDiiInterval interval,
  }) async {
    final finalType =
        ((type == FiiDiiType.FII_Cash) || (type == FiiDiiType.DII_Cash))
            ? 'investment'
            : 'derivative';
    final responseData = await NetworkManager()
        .postAPIEncrypted(apiName: APIName.getFIIDIIData, postBody: {
      'interval': interval.toStringValue(),
      'type': finalType,
      'topN': (finalType.compareTo('investment') == 0) ? '100' : '200',
    });

    if (responseData is Map) {
      final fiidiiData = responseData['data'];

      if (fiidiiData is List) {
        final arrayObj = fiidiiData
            .map((e) => FIIDIIResponseModelNew.fromJson(e))
            .toList()
            .where((element) {
          switch (type) {
            case FiiDiiType.FII_Cash:
              return (element.investmentCategory
                      ?.toUpperCase()
                      .compareTo('FII/FPI') ==
                  0);

            case FiiDiiType.DII_Cash:
              return (element.investmentCategory
                      ?.toUpperCase()
                      .compareTo('DII') ==
                  0);

            case FiiDiiType.FII_Index_Futures:
              return (element.derivativeProduct
                      ?.toUpperCase()
                      .compareTo('INDEX FUTURES') ==
                  0);

            case FiiDiiType.FII_Stock_Futures:
              return (element.derivativeProduct
                      ?.toUpperCase()
                      .compareTo('STOCK FUTURES') ==
                  0);

            case FiiDiiType.FII_Index_Options:
              return (element.derivativeProduct
                      ?.toUpperCase()
                      .compareTo('INDEX OPTIONS') ==
                  0);

            case FiiDiiType.FII_Stock_Options:
              return (element.derivativeProduct
                      ?.toUpperCase()
                      .compareTo('STOCK OPTIONS') ==
                  0);
            default:
              return false;
          }
        }).toList();

        return arrayObj;
      }
    }

    return [];
  }

  //=======================  Option Chain Request  =====================

  Future<List<OptionChainResponseModel>> getOptionChainAPI(
      {required BuildContext context,
      required String exchange,
      required String symbol,
      required String fromStrike,
      required String toStrike,
      required String expiry}) async {
    final responseOptionChain = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.OptionChainRequest,
        postBody: {
          'cExchange': exchange,
          'cSymbol': symbol,
          'dFromStrike': fromStrike,
          'dToStrike': toStrike,
          'cExpiry': expiry,
        });

    var modelObjArray = <OptionChainResponseModel>[];
    if (responseOptionChain is Map) {
      final mapObj = responseOptionChain['data'];

      if (mapObj is List) {
        var index = 0;

        while (index < mapObj.length - 1) {
          final callMap = mapObj.elementAt(index);
          final putMap = mapObj.elementAt(index + 1);
          /* var exp = DateFormat('ddMMMyyyy')
              .format(DateTime.fromMillisecondsSinceEpoch(
                  int.parse(callMap.expiryDate.toString() ?? '') * 1000))
              .toString();
          if (exp == expiry) { */
          final obj = OptionChainResponseModel.fromJson([callMap, putMap]);
          modelObjArray.add(obj);
          // }
          index += 2;
        }
      }
    }

    return modelObjArray;
  }
}
