import 'dart:convert';

import 'package:greek_ibt_app/Screens/Market/models/advance_decline_model.dart';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Market/models/fii_dii_response_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_news_response.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/graph_model.dart';

class MarketMapRespository {
  Future<AdvanceDeclineResponseModel?> getAdvanceDeclineAPi() async {
    final resp = await NetworkManager().getAPIEncrypted(apiName: APIName.getAdvanceDeclines, query: '');
    if (resp is List) {
      final obj = resp.map((e) => AdvanceDeclineResponseModel.fromJson(e)).toList();
      return obj.first;
    } else if (resp is Map<String, dynamic>) {
      final obj = AdvanceDeclineResponseModel.fromJson(resp);
      return obj;
    }

    return null;
  }

  Future<List<GraphResponseModel>> getGraphData({required BuildContext context, required String token}) async {
    // var modelArray = <GraphResponseModel>[];
    final response = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.jhistorical_New,
        postBody: {
          "token": token,
          "interval": "1",
          "date": "20220225",
          "time": "0",
          "noofdays": "1",
        });

    if (response is Map) {
      final responseData = response['data'];

      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj = responseData.map((e) => GraphResponseModel.fromJson(e)).toList();

        return obj;
      }
    }
    return [];
  }

  // return await NetworkManager().getAPIEncrypted(
  //     apiName: APIName.getAdvanceDeclines,
  //     query: '',
  //   );

  Future<Object?> getNetPositionMTMApi() async => await NetworkManager().getAPIEncrypted(
        apiName: APIName.getNetPositionMTM,
        query: '',
      );
  Future<Object?> getNewsDataApi() async {
    final response = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getNewsData,
      postBody: {
        "type": "All",
        "topN": "20",
      },
    );

    return response;
  }

  Future<List<FIIDIIResponseModelNew>> getFiiDiiAPI({required BuildContext context, required String interval, required String type, required String topN}) async {
    final responseData = await NetworkManager().postAPIEncrypted(apiName: APIName.getFIIDIIData, postBody: {
      'interval': interval,
      'type': type,
      'topN': topN,
    });

    if (responseData is List) {
      final obj = responseData.map((e) => FIIDIIResponseModelNew.fromJson(e)).toList();
      return obj;
    } else if (responseData is Map<String, dynamic>) {
      final obj = FIIDIIResponseModelNew.fromJson(responseData);
      return [obj];
    }

    return [];
  }

  Future<List<GetNewsResponse>> getNewsData() async {
    final responseData = await NetworkManager().postAPIEncrypted(apiName: APIName.getNewsData, postBody: {
      'type': "ALL",
      'topN': "5",
    });

    if (responseData is List) {
      final obj = responseData.map((e) => GetNewsResponse.fromJson(e)).toList();
      return obj;
    } else if (responseData is Map<String, dynamic>) {
      final obj = GetNewsResponse.fromJson(responseData);
      return [obj];
    }
    return [];
  }

  Future<List<GetNewsResponse>> getPortfolioNewsData(String scripname) async {
    final requestQuery = "symbol=" + base64.encode(utf8.encode(scripname)) + "&topN=" + "20";
    final resp = await NetworkManager().getAPIEncrypted(apiName: APIName.getPortfolioNews_Symbol, query: requestQuery);
    if (resp is List) {
      final obj = resp.map((e) => GetNewsResponse.fromJson(e)).toList();
      return obj;
    } else if (resp is Map<String, dynamic>) {
      final obj = GetNewsResponse.fromJson(resp);
      return [obj];
    }
    return [];
  }
}
