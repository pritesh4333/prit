import 'package:greek_ibt_app/Screens/Market/models/highest_rollover_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/Market/models/expiry_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/most_active_future_data_model.dart';
import 'package:greek_ibt_app/Screens/Market/models/short_build_response_model.dart';

class ScannerRespository {
  Future<List<ExpiryResponseModel>> getExpiry() async {
    final resp = await NetworkManager()
        .getAPIEncrypted(apiName: APIName.getExpiryFNOActivity, query: '');
    if (resp is List) {
      final obj = resp.map((e) => ExpiryResponseModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<MostActiveFutureData>> getMostActiveFeautures(
      String expiry) async {
    final resp = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getMostActiveByVolumeExpiry_Mobile,
      query: 'exchange=nse&type=future&expiry=$expiry',
    );
    if (resp is List) {
      final obj = resp.map((e) => MostActiveFutureData.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<MostActiveFutureData>> getMostActiveStockOption(
      String expiry) async {
    final resp = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getMostActiveByVolumeExpiry_Mobile,
      query: 'exchange=nse&type=option_stock&expiry=$expiry',
    );
    if (resp is List) {
      final obj = resp.map((e) => MostActiveFutureData.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<MostActiveFutureData>> getMostActiveIndexOption(
      String expiry) async {
    final resp = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getMostActiveByVolumeExpiry_Mobile,
      query: 'exchange=nse&type=option_index&expiry=$expiry',
    );
    if (resp is List) {
      final obj = resp.map((e) => MostActiveFutureData.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<ShortBuildupResModel>> getLongBuildUP() async {
    final resp = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getOpenInterestAnalysis_Mobile,
        query: 'exchange=nse&type=long_build_up');
    if (resp is List) {
      final obj = resp.map((e) => ShortBuildupResModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<ShortBuildupResModel>> getShortBuildup() async {
    final resp = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getOpenInterestAnalysis_Mobile,
        query: 'exchange=nse&type=short_build_up');
    if (resp is List) {
      final obj = resp.map((e) => ShortBuildupResModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<ShortBuildupResModel>> getShortUnbinding() async {
    final resp = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getOpenInterestAnalysis_Mobile,
        query: 'exchange=nse&type=short_covering&expiry=');
    if (resp is List) {
      final obj = resp.map((e) => ShortBuildupResModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<ShortBuildupResModel>> getLongUnbinding() async {
    final resp = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getOpenInterestAnalysis_Mobile,
        query: 'exchange=nse&type=long_unwinding');
    if (resp is List) {
      final obj = resp.map((e) => ShortBuildupResModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<Datum>> getHighestRollOver() async {
    final resp = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getRollOverData,
        query: 'exchange=nse&expiry=&type=gainer');
    if (resp is List) {
      final obj = resp.map((e) => Datum.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<List<Datum>> getLowestRollOver() async {
    final resp = await NetworkManager().getAPIEncrypted(
        apiName: APIName.getRollOverData,
        query: 'exchange=nse&expiry=&type=looser');
    if (resp is List) {
      final obj = resp.map((e) => Datum.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  Future<Object?> getExpiryFNOActivity() async {
    var expiryList = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getExpiryFNOActivity,
      query: '',
    );
    return expiryList;
  }
}
