import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/M-Pin/repository/mpin_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/subjects.dart';

class OTPBloc extends GreekBlocs {
  BuildContext? _context;
  MPinRepository? _mPinRepository;
  bool isEnableSubmitButton = false;
  var otpCode = '';
  String? otp;

  OTPBloc(BuildContext context, TickerProvider vsync) {
    _context = context;

    _mPinRepository = MPinRepository(_context!);

    SocketIOManager().connectSocketIOServer(
      gscid: AppConfig().gscid,
      gcid: AppConfig().gcid,
      sessionID: AppConfig().sessionID,
      deviceID: AppConfig().deviceID,
      deviceType: AppConfig().deviceType,
    );
  }

  final _currentMPinStateSubject = BehaviorSubject<String>.seeded("new");
  Stream<String> get mpinStateStream => _currentMPinStateSubject.stream;

  @override
  void disposeBloc() {
    // TODO: implement disposeBloc
  }

  bool getdate() {
    String cdate = DateFormat("yyyy-MM-dd").format(DateTime.now());
    Future saveOtpdate = AppConfig().getOTPdate();
    if (cdate == saveOtpdate.toString()) {
      return true;
    }

    return false;
  }

  Future<void> callOTPVerify(BuildContext context, String mpin,
      String? deviceid, String? divicedetails) async {
    _callMarketStatistics();
    String mobId = await AppConfig().mobdeviceid ?? '';
    LoginResponseModel? obj =
        await _mPinRepository?.validatedOTPAPI(otpCode, mobId, divicedetails);

    if (obj?.errorCode == UserAuthenticationCode.success) {
      // AppConfig().sessionID = obj?.sessionID ?? "";

      String cdate = DateFormat("yyyy-MM-dd").format(DateTime.now());
      AppConfig().saveotpDate(cdate);
      AppConfig().sessionID = obj?.sessionID!.trim() ?? "";
      AppConfig().saveotp(AppConfig().gscid.toUpperCase(), otpCode.toString());
      GreekNavigator.pushReplacementNamed(
        context: context,
        routeName: GreekScreenNames.landing,
      );
    } else {
      GreekDialogPopupView.messageDialog(
          context, ConstantMessages.CP_OTP_INVALID_MSG);
    }

    /* switch (errorCode.errorCode) {
      case 0:
        AppConfig().sessionID = errorCode.sessionId;
        AppConfig()
            .saveotp(AppConfig().gscid.toUpperCase(), otpCode.toString());
        otpCode = '';
        isEnableSubmitButton = false;
        // _callMarketStatistics();
        GreekNavigator.pushReplacementNamed(
          context: context,
          routeName: GreekScreenNames.landing,
        );
        break;
      default:
        GreekDialogPopupView.messageDialog(
            context, ConstantMessages.CP_OTP_INVALID_MSG);
        break;
    } */
  }

  resendOTP(BuildContext context) async {
    final errorCode = await _mPinRepository?.callLoginOTP(context);

    switch (errorCode) {
      case 0:
        GreekNavigator.pushReplacementNamed(
          context: context,
          routeName: GreekScreenNames.otp,
        );
        break;
    }
  }

  void _callMarketStatistics() {
    final item = (GreekBase().marketSegments.isNotEmpty)
        ? GreekBase().marketSegments.first
        : MarketSegment.nseeq;

    switch (item) {
      case MarketSegment.nseeq:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE'),
        );
        break;
      case MarketSegment.nsefo:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSE FUTSTK'),
        );
        break;
      case MarketSegment.nsecd:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECURR'),
        );
        break;
      case MarketSegment.nsecomm:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NSECOMM'),
        );
        break;
      case MarketSegment.bseeq:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSE'),
        );
        break;
      case MarketSegment.bsecd:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECURR'),
        );
        break;
      case MarketSegment.bsecomm:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'BSECOMM'),
        );
        break;
      case MarketSegment.mcx:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'MCX'),
        );
        break;
      case MarketSegment.ncdex:
        SocketIOManager().subscribeForTopGainers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        SocketIOManager().subscribeForTopLoosers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        SocketIOManager().subscribeForMarketMovers(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        SocketIOManager().subscribeForMarketMoversByValue(
          GreekBase().getMarketIDByMarketSegment(marketSegment: 'NCDEX'),
        );
        break;
      default:
        break;
    }
  }
}
