import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Screens/Login/bloc/login_bloc.dart';
import 'package:greek_ibt_app/Screens/OTP/bloc/OTPBloc.dart';

import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:intl/intl.dart';

class OTPScren extends StatefulWidget {
  const OTPScren({Key? key}) : super(key: key);

  @override
  _OtpScreenState createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OTPScren>
    with SingleTickerProviderStateMixin {
  OTPBloc? _otpBloc;
  AppBar? _appBar;
  bool _obscureText = true;
  final mpinTextController = TextEditingController();
  static var deviceid;
  static var devicedetails;
  String? otpDate;
  String currentDate = "";

  @override
  void initState() {
    _otpBloc ??= OTPBloc(context, this);
    getOTP();
    getOTPsavedDate();
    super.initState();
    _createAppBarView();
    deviceid = _getId();
    devicedetails = initPlatformState();
  }

  getOTPsavedDate() async {
    otpDate = await AppConfig().getOTPdate() ?? "";
    currentDate = DateFormat("yyyy-MM-dd").format(DateTime.now());
    print(otpDate);
  }

  getOTP() async {
    _otpBloc?.otp = await AppConfig().getOTP() ?? '';
    print(_otpBloc?.otp);
  }

  Future<String?> initPlatformState() async {
    final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
    var deviceData = <String, dynamic>{};

    try {
      if (Platform.isAndroid) {
        deviceData = _readAndroidBuildData(await deviceInfoPlugin.androidInfo);
        return "${deviceData['manufacturer']} - ${deviceData['model']} - ${deviceData['systemVersion']} ";
      } else if (Platform.isIOS) {
        deviceData = _readIosDeviceInfo(await deviceInfoPlugin.iosInfo);
        return "${deviceData['name']} - ${deviceData['systemName']} - ${deviceData['version.sdkInt']} ";
      }
    } on PlatformException {
      deviceData = <String, dynamic>{
        'Error:': 'Failed to get platform version.'
      };
    }
    return null;
  }

  Map<String, dynamic> _readAndroidBuildData(AndroidDeviceInfo build) {
    return <String, dynamic>{
      // 'version.securityPatch': build.version.securityPatch,
      'version.sdkInt': build.version.sdkInt,
      /*   'version.release': build.version.release,
      'version.previewSdkInt': build.version.previewSdkInt,
      'version.incremental': build.version.incremental,
      'version.codename': build.version.codename,
      'version.baseOS': build.version.baseOS,
      'board': build.board,
      'bootloader': build.bootloader,
      'brand': build.brand,
      'device': build.device,
      'display': build.display,
      'fingerprint': build.fingerprint,
      'hardware': build.hardware,
      'host': build.host,
      'id': build.id, */
      'manufacturer': build.manufacturer,
      'model': build.model,
      /* 'product': build.product,
      'supported32BitAbis': build.supported32BitAbis,
      'supported64BitAbis': build.supported64BitAbis,
      'supportedAbis': build.supportedAbis,
      'tags': build.tags,
      'type': build.type,
      'isPhysicalDevice': build.isPhysicalDevice,
      'androidId': build.androidId,
      'systemFeatures': build.systemFeatures, */
    };
  }

  Map<String, dynamic> _readIosDeviceInfo(IosDeviceInfo data) {
    return <String, dynamic>{
      'name': data.name,
      'systemName': data.systemName,
      'systemVersion': data.systemVersion,
      /*  'model': data.model,
      'localizedModel': data.localizedModel,
      'identifierForVendor': data.identifierForVendor,
      'isPhysicalDevice': data.isPhysicalDevice,
      'utsname.sysname:': data.utsname.sysname,
      'utsname.nodename:': data.utsname.nodename,
      'utsname.release:': data.utsname.release,
      'utsname.version:': data.utsname.version,
      'utsname.machine:': data.utsname.machine, */
    };
  }

  Future<String?> _getId() async {
    var deviceInfo = DeviceInfoPlugin();
    if (Platform.isIOS) {
      // import 'dart:io'
      var iosDeviceInfo = await deviceInfo.iosInfo;
      return iosDeviceInfo.identifierForVendor; // unique ID on iOS
    } else if (Platform.isAndroid) {
      var androidDeviceInfo = await deviceInfo.androidInfo;
      return androidDeviceInfo.androidId; // unique ID on Android
    }
  }

  _createAppBarView() {
    _appBar = AppBar(
      elevation: 1,
      backgroundColor: ConstantColors.primaryColor,
      title: Text(
        ConstantMessages.OTP_HEADER_MSG,
        style: GreekTextStyle.headline2,
      ),
      leading: TextButton(
        onPressed: () {
          AppConfig().deleteUser();
          GreekNavigator.pushReplacementNamed(
            context: context,
            routeName: GreekScreenNames.login,
          );
        },
        child: const Icon(
          Icons.arrow_back_ios_new_rounded,
          color: ConstantColors.black,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    _otpBloc ??= OTPBloc(context, this);

    if (_otpBloc?.otp == '' || otpDate != currentDate) {
      final snackBar = SnackBar(
        backgroundColor: Colors.grey.shade400,
        elevation: 2,
        duration: const Duration(
          seconds: 10,
        ),
        content: Text(
          " genericMessage",
          style: const TextStyle(color: Colors.black),
        ),
        action: SnackBarAction(
            label: 'OK', textColor: Colors.black, onPressed: () {}),
      );
    }
    return Scaffold(
      appBar: _appBar,
      body: SafeArea(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: SizedBox(
            height: (MediaQuery.of(context).size.height -
                _appBar!.preferredSize.height -
                MediaQuery.of(context).padding.top -
                MediaQuery.of(context).padding.bottom),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(45.0),
                  child: Center(
                    child: Image.asset(
                      'assets/images/flutter_logo.png',
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(45.0),
                  child: Center(
                    child: _otpView(context),
                  ),
                ),

                /*     AnimatedBuilder(
                  animation: _otpBloc!.animation!,
                  builder: (BuildContext context, Widget? child) {
                    var transform = Matrix4.identity();
                    transform.setEntry(3, 2, 0.001);
                    transform.rotateY(_mPinBloc!.animation!.value);
                    return Transform(
                      transform: transform,
                      alignment: Alignment.center,
                      child: child,
                    );
                  },
                  child: _otpView(context),
                ), */
              ],
            ),
          ),
        ),
      ),
    );
  }

  _otpView(BuildContext context) => StreamBuilder<String>(
        stream: _otpBloc?.mpinStateStream,
        builder: (context, snapshot) {
          return SizedBox(
            height: 215,
            width: 300,
            child: Stack(
              children: [
                Container(
                  height: 195,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.blue,
                      width: 3,
                    ),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(25.0),
                    ),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Center(
                          child: Text(
                            "WelCome ${AppConfig().gscid}",
                            style: GreekTextStyle.mpinwecometext,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Center(
                          child: Text(
                            _otpBloc?.otp == '' || currentDate != otpDate
                                ? ConstantMessages.ENTER_OTP
                                : ConstantMessages.ENTER_LAST_OTP,
                            style: GreekTextStyle.headline2,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, top: 20.0, right: 20.0),
                        child: SizedBox(
                          height: 45,
                          width: 200,
                          child: Stack(
                            children: [
                              TextFormField(
                                style: GreekTextStyle.mpinTextStyle,
                                textAlign: TextAlign.center,
                                controller: mpinTextController,
                                autofocus: false,
                                // obscureText: _obscureText,
                                keyboardType: TextInputType.number,
                                inputFormatters: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                maxLength: 6,
                                decoration: const InputDecoration(
                                  contentPadding: EdgeInsets.only(
                                      left: 10.0, right: 20.0, bottom: 16.5),
                                ),
                                onChanged: (value) {
                                  if (value.length == 6) {
                                    _otpBloc?.otpCode = value;
                                    FocusScope.of(context).unfocus();
                                    setState(() =>
                                        _otpBloc?.isEnableSubmitButton = true);
                                  } else {
                                    _otpBloc?.otpCode = value;
                                    setState(() =>
                                        _otpBloc?.isEnableSubmitButton = false);
                                  }
                                },
                              ),
                              /* Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: 30.0,
                                  width: 30.0,
                                  margin: const EdgeInsets.only(right: 8.0),
                                  padding: const EdgeInsets.only(bottom: 5.0),
                                  alignment: Alignment.center,
                                  child: IconButton(
                                    icon: Icon(_obscureText
                                        ? Icons.visibility_rounded
                                        : Icons.visibility_off_rounded),
                                    // iconSize: 23.0,
                                    padding: EdgeInsets.zero,
                                    onPressed: () {
                                      setState(
                                          () => _obscureText = !_obscureText);
                                    },
                                  ),
                                ),
                              ), */
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 20.0),
                        height: 35.0,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: TextButton(
                            onPressed: () {
                              /* 
                              mpinTextController.clear();
                              _obscureText = true;
                              FocusScope.of(context).unfocus();
                              _mPinBloc?.setMPinViewState =
                                  MpinViewState.forget;
                              _mPinBloc?.callMPinAPIS(context, "");

                              setState(() {}); */
                              _otpBloc?.resendOTP(context);
                            },
                            child: Text(
                              /* 
                              (_mPinBloc?.currentMpinViewState ==
                                      MpinViewState.validated)
                                  ? ConstantMessages.GREEK_FORGOT_MPIN
                                  : (_mPinBloc?.currentMpinViewState ==
                                          MpinViewState.forget)
                                      ? ConstantMessages.GREEK_RESEND
                                      : (_mPinBloc?.currentMpinViewState ==
                                              MpinViewState.create)
                                          ? ''
                                          : (_mPinBloc?.currentMpinViewState ==
                                                  MpinViewState.validatedOTP)
                                              ? ConstantMessages.GREEK_RESEND
                                              : */
                              ConstantMessages.RESEND_OTP,
                              style: const TextStyle(
                                color: ConstantColors.primaryColorLight,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: TextButton(
                    onPressed: () {
                      mpinTextController.clear();

                      _otpBloc?.callOTPVerify(context, "", AppConfig().deviceID,
                          AppConfig().deviceDetails);
                      // mpinTextController.clear();
                      // _obscureText = true;
                      // FocusScope.of(context).unfocus();
                      // _mPinBloc!.isEnableSubmitButton ? {_mPinBloc?.callMPinAPIS(context, "")} : null;
                    },
                    child: Text(
                      ConstantMessages.CP_SUBMIT_BTN1,
                      style: GreekTextStyle.ordersubmit,
                    ),
                    style: TextButton.styleFrom(
                      backgroundColor: _otpBloc!.isEnableSubmitButton
                          ? Colors.blue
                          : ConstantColors.primaryColorVitt,
                      fixedSize: const Size(160, 45.0),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      );
}
