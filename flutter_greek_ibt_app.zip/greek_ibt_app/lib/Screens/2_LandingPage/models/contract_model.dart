class ContractDataModel {
  String? token;
  String? symbol;
  String? description;
  String? expiryDate;
  String? expiryTimestamp;
  String? seriesName;
  String? optionType;
  String? strikePrice;
  String? scripname;

  ContractDataModel(
      {this.token,
      this.symbol,
      this.description,
      this.expiryDate,
      this.expiryTimestamp,
      this.seriesName,
      this.optionType,
      this.scripname,
      this.strikePrice});

  ContractDataModel.fromJson(Map<String, dynamic> json) {
    token = json['token'].toString();
    symbol = json['symbol'].toString();
    description = json['description'].toString();
    expiryDate = json['expiry_date'].toString();
    expiryTimestamp = json['expiry_timestamp'].toString();
    seriesName = json['series_name'].toString();
    optionType = json['option_type'].toString();
    strikePrice = json['strike_price'].toString();
    scripname = json['scripname'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['token'] = token.toString();
    data['symbol'] = symbol.toString();
    data['description'] = description.toString();
    data['expiry_date'] = expiryDate.toString();
    data['expiry_timestamp'] = expiryTimestamp.toString();
    data['series_name'] = seriesName.toString();
    data['option_type'] = optionType.toString();
    data['strike_price'] = strikePrice.toString();
    data['scripname'] = scripname.toString();
    return data;
  }

  Map<String, dynamic> toMap() {
    return {
      'token': token.toString(),
      'symbol': symbol.toString(),
      'description': description.toString(),
      'expiry_date': expiryDate.toString(),
      'expiry_timestamp': expiryTimestamp.toString(),
      'series_name': seriesName.toString(),
      'option_type': optionType.toString(),
      'strike_price': strikePrice.toString(),
      'scripname': scripname.toString(),
    };
  }
}
