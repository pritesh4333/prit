class MarketStatusResponseModel {
  String? marketId;
  String? status;
  String? session;

  MarketStatusResponseModel({this.marketId, this.status, this.session});

  MarketStatusResponseModel.fromJson(Map<String, dynamic> json) {
    marketId = json['market_id'].toString();
    status = json['status'].toString();
    session = json['session'].toString();
  }
}
