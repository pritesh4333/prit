class AllowedProduct {
  int? iProductToken;
  String? cProductName;

  AllowedProduct({this.iProductToken, this.cProductName});

  AllowedProduct.fromJson(Map<String, dynamic> json) {
    iProductToken = json['iProductToken'];
    cProductName = json['cProductName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['iProductToken'] = iProductToken;
    data['cProductName'] = cProductName;
    return data;
  }
}
