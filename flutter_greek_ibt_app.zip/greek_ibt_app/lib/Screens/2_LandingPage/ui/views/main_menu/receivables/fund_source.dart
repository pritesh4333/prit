import 'package:flutter/material.dart';

//this is your new screen do anything you want here
class FundSource extends StatelessWidget {
  const FundSource({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'This is Fund Source',
        style: TextStyle(
            fontSize: 25.0, fontWeight: FontWeight.w600, letterSpacing: 1.2),
      ),
    );
  }
}
