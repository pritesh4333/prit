import 'package:flutter/material.dart';

//this is your new screen do anything you want here

class GFSCodes extends StatelessWidget {
  const GFSCodes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'This is GFSCodes',
        style: TextStyle(
          fontSize: 25.0,
          fontWeight: FontWeight.w600,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}
