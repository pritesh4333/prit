import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

// This is your new screen do anything you want here

class Dashboard extends StatelessWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      initialIndex: 0,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            elevation: 1,
            backgroundColor: ConstantColors.white,
            leading: IconButton(
              onPressed: () {
                GreekBase().drawerKey.currentState?.openDrawer();
              },
              icon: const Icon(Icons.menu_rounded),
              iconSize: 30.0,
              color: ConstantColors.black,
            ),
            title: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                ConstantMessages.GREEK_TAB_TITLE_MENU,
                style: GreekTextStyle.order_app_title_textstyle,
              ),
            ),
          ),
          body: const Center(
            child: Text(
              'Coming Soon',
              style: TextStyle(
                fontSize: 25.0,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
