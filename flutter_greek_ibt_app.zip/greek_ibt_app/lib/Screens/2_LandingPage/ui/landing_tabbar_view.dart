// ignore_for_file: empty_catches

import 'dart:convert';
import 'dart:ffi';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/bloc/landing_bloc.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/ui/left_menu/views/dashboard.dart';
import 'package:greek_ibt_app/Screens/Alerts/ui/stock_alert_screen.dart';
import 'package:greek_ibt_app/Screens/Edis/edis_dashboard_screen.dart';
import 'package:greek_ibt_app/Screens/Edis/ui/edis_margin_pledge_screen.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/fund_screen.dart';
import 'package:greek_ibt_app/Screens/Market/ui/market_tab_view.dart';
import 'package:greek_ibt_app/Screens/Notification/ui/notification_recommendation_screen.dart';
import 'package:greek_ibt_app/Screens/Order/ui/order_screen.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/splash_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/ui/portfolio_screen.dart';
import 'package:greek_ibt_app/Screens/Portfolio/ui/watch_list_screen.dart';
import 'package:greek_ibt_app/Screens/Profile/ui/profile_screen.dart';
import 'package:greek_ibt_app/Screens/Settings/ui/setting_screen.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';

import '../../Edis/edis_transaction_details.dart';

var _selectedPageIndex = 0;

List<Widget>? _pages = [];
PageController? _pageController;
SplashBloc? _splashBloc;
List<dynamic>? elementListDataSource;

class Controller extends GetxController {
  var title = "Market".obs;
}

class LandingTabBarView extends StatefulWidget {
  const LandingTabBarView({Key? key}) : super(key: key);

  @override
  _LandingTabBarViewState createState() => _LandingTabBarViewState();
}

class _LandingTabBarViewState extends State<LandingTabBarView> with WidgetsBindingObserver {
  LandingBloc? _landinBloc;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    switch (state) {
      case AppLifecycleState.resumed:
        SocketIOManager().reconnectSocketIOServer();
        break;
      default:
        SocketIOManager().disconnectServer(isSendLogoffRequest: true);
        break;
    }
  }

  @override
  void dispose() {
    super.dispose();
    _pageController?.dispose();
  }

  @override
  void initState() {
    super.initState();

    //Pre Setting for Left Menu
    _selectedPageIndex = int.parse(AppFlagConstant().defaultScreenIndex);
    addWidgetToPages(SplashBloc.finalMenuList);

    //Initiating a Page Controller
    _pageController = PageController(initialPage: _selectedPageIndex);
  }

//This controll left menu widgets according left menu items.
  addWidgetToPages(List<dynamic> finalMenuList) {
    _pages?.clear();
    // it is important to keep these indices number so you will find it easier to reference them whne you want to open them
    // 0
    _pages?.insert(0, const MarketBottomTab());
    _pages?.insert(1, const WatchListScreen());
    _pages?.insert(2, const OrderScreen());
    _pages?.insert(3, const PortfolioScreen());
    _pages?.insert(4, const FundScreen());

    finalMenuList.toList().asMap().forEach(
      (index, element) {
        switch (element.toString()) {
          case 'Netbanking Transfer':
            _pages?.add(const FundScreen());
            break;
          case 'UPI Transfer':
            _pages?.add(const Dashboard());
            break;
          case 'Fund Transfer Details':
            _pages?.add(const Dashboard());
            break;
          case 'Ledger Report':
            _pages?.add(const Dashboard());
            break;
          case 'Trade Summary':
            _pages?.add(const Dashboard());
            break;
          case 'Holdings Report':
            _pages?.add(const Dashboard());
            break;
          case 'Transaction Report':
            _pages?.add(const Dashboard());
            break;
          case 'Client Financial Statement':
            _pages?.add(const Dashboard());
            break;
          case 'Portfolio Details':
            _pages?.add(const Dashboard());
            break;
          case 'Profit and Loss Details':
            _pages?.add(const Dashboard());
            break;
          case 'Strategy Finder':
            _pages?.add(const Dashboard());
            break;
          case 'Strategy Builder':
            _pages?.add(const Dashboard());
            break;
          case 'E-DIS Dashboard':
            _pages?.add(const EdisDashboardScreen());
            break;
          case 'E-DIS Transaction Details':
            _pages?.add(const EdisTransactionDetails());
            break;
          case 'Margin Pledge':
            _pages?.add(const MarginPledgeScreen());
            break;
          case 'Charting':
            _pages?.add(const Dashboard());
            break;
          case 'Stock Alert':
            _pages?.add(const StockAlertsScreen());
            break;
          case 'Settings':
            _pages?.add(const SettingsScreen());
            break;
          case 'IPO':
            break;
          case 'Notification':
            _pages?.add(NotificationRecommendationScreen());
            break;
          case 'Recommendation':
            _pages?.add(const Dashboard());
            break;
          case 'Default Screen':
            _pages?.add(const Dashboard());
            break;
          case 'Change Password':
            _pages?.add(const Dashboard());
            break;
          case 'Change Theme':
            _pages?.add(const Dashboard());
            break;
          case 'Profile':
            _pages?.add(const ProfileScreen());
            break;
          case 'About Us':
            _pages?.add(const Dashboard());
            break;
          case 'Version':
            _pages?.add(const Dashboard());
            break;
          case 'SEBI':
            _pages?.add(const Dashboard());
            break;
          case 'NSE':
            _pages?.add(const Dashboard());
            break;
          case 'BSE':
            _pages?.add(const Dashboard());
            break;
          case 'MCX':
            _pages?.add(const Dashboard());
            break;
          case 'NCDEX':
            _pages?.add(const Dashboard());
            break;
          case 'SSL':
            _pages?.add(const Dashboard());
            break;
          case 'Back Office':
            _pages?.add(const Dashboard());
            break;
          case 'Fund Transfer Offline':
            _pages?.add(const Dashboard());
            break;
          case 'Logout':
            _pages?.add(const Dashboard());
            break;
          default:
        }
      },
    );

    // print(_pages?.length);
  }

  final _tabViews = <Widget>[];

  @override
  Widget build(BuildContext context) {
    _landinBloc ??= LandingBloc(
      context,
      () {
        if ((_landinBloc?.selectedTabBarIndex ?? 0) == 4) {
          _selectedPageIndex = _landinBloc?.selectedTabBarIndex ?? 0;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
          });
          /*c.title.value = 'Bottom Tab';
        ConstantMessages.GREEK_TAB_TITLE_MENU = c.title.value;*/
          setState(() {});
        }
      },
    );
    Controller c = Get.put(Controller());
    if (_tabViews.isEmpty) {
      _tabViews.clear();
      _tabViews.addAll(
        [
          const MarketBottomTab(),
          const WatchListScreen(),
          const OrderScreen(),
          const PortfolioScreen(),
          const FundScreen(),
        ],
      );
    }

    return WillPopScope(
      onWillPop: () async {
        if (GreekBase().drawerKey.currentState!.isDrawerOpen) {
          Navigator.of(context).pop();
          return false;
        }
        return GreekDialogPopupView.confirmLogOutDialog(context);
      },
      child: Scaffold(
        key: GreekBase().drawerKey,
        appBar: null,
        //Left Menu Added By sushant
        drawerEnableOpenDragGesture: false,
        drawer: createDrawer(context),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              label: ConstantMessages.GREEK_MARKET_NAME,
              icon: ImageIcon(
                AssetImage("assets/images/market_gray.png"),
              ),
            ),
            BottomNavigationBarItem(
              label: ConstantMessages.GREEK_DEFAULT_WATCHLIST_NAME,
              icon: ImageIcon(
                AssetImage("assets/images/watchlist_gray.png"),
              ),
            ),
            BottomNavigationBarItem(
              label: ConstantMessages.GREEK_ORDER_NAME,
              icon: ImageIcon(
                AssetImage("assets/images/order_gray.png"),
              ),
            ),
            BottomNavigationBarItem(
              label: ConstantMessages.GREEK_PORTFOLIO_NAME,
              icon: ImageIcon(
                AssetImage("assets/images/portfolio_gray.png"),
              ),
            ),
            BottomNavigationBarItem(
              label: ConstantMessages.GREEK_FUND_NAME,
              icon: ImageIcon(
                AssetImage("assets/images/fund_gray.png"),
              ),
            ),
          ],
          selectedItemColor: const Color.fromRGBO(0, 125, 178, 1),
          unselectedItemColor: ConstantColors.black,
          showUnselectedLabels: true,
          type: BottomNavigationBarType.fixed,
          currentIndex: _landinBloc?.selectedTabBarIndex ?? 0,
          onTap: (selecteTabIndex) {
            _landinBloc?.selectedTabBarIndex = selecteTabIndex;
            GreekBase().unSubscribeindexTokens();
            if ((selecteTabIndex == 0) || (selecteTabIndex == 1)) {
              GreekBase().subscribeIndicesIndexTokens();
            }
            _selectedPageIndex = selecteTabIndex;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
            });
            c.title.value = 'Bottom Tab';
            ConstantMessages.GREEK_TAB_TITLE_MENU = c.title.value;
            setState(() {});
            //setState(() => _landinBloc?.selectedTabBarIndex = selecteTabIndex);
          },
        ),

        //commented by sushant
        // body: _landinBloc?.selectedTabBarIndex == 5
        //     ? PageView(
        //         controller: _pageController,
        //         physics: const NeverScrollableScrollPhysics(),
        //         children: _pages ?? <Widget>[],
        //       )
        //     : _tabViews.elementAt(_landinBloc?.selectedTabBarIndex ?? 0),
        body: PageView(
          controller: _pageController,
          physics: const NeverScrollableScrollPhysics(),
          children: _pages ?? <Widget>[],
        ),
      ),
    );
  }

  Future<List> readJson() async {
    final jsonString = await rootBundle.loadString('assets/LeftmenuModel.json');
    final jsonObj = json.decode(jsonString);
    manageLeftMenuDrawerItmes(jsonObj);
    if (jsonObj is List) {
      return jsonObj;
    }
    return [];
  }

  //Collecing Menu Items in Dynamic Way.
  void manageLeftMenuDrawerItmes(List menuList) {
    removeMainMenuItems(menuList);
    // _splashBloc?.createActiveMenuItemsWidgetList(menuList);
  }

  removeMainMenuItems(List<dynamic> mainMenuList) {
    //Need to Manipulate the list 'menuList'
    mainMenuList.removeWhere(
      (element) {
        switch (element['name']) {
          // case 'Fund Transfer':
          //   if ((AppFlagConstant().isFundTransfer == 'true') && (element['name'] == 'E-DIS')) {
          //     return true;
          //   }
          //   return false;
          case 'Back Office Reports':
            if (AppFlagConstant().isBOReport == 'true') {
              return true;
            }
            return false;
          case 'Strategy Finder':
            if (AppFlagConstant().isStrategyProduct == 'true') {
              return true;
            }
            return false;
          case 'Strategy Builder':
            if (AppFlagConstant().isStrategyProduct == 'true') {
              return true;
            }
            return false;
          case 'E-DIS':
            if (AppFlagConstant().isEDISProduct == 'false') {
              return true;
            }
            return false;

          case 'Stock Alert':
            // if (AppFlagConstant().isAlerts == 'true') {
            // return true;
            // }
            return false;
          case 'Notification':
            // if (AppFlagConstant().notification == 'true'){
            return false;
          // }
          //   return false;
          case 'Logout':
            return false;
          // case 'Recommendation':
          //   if (AppFlagConstant().isRecomment == 'true') {
          //     return true;
          //   }
          //   return false;
          case 'Settings':
            //   if (AppFlagConstant().isSetting == 'true') {
            //     return true;
            //   }

            return false;
          // case 'Profile':
          // if (AppFlagConstant().isProfile == 'true') {
          // return true;
          // }
          // return false;
          // case 'More':
          //   if (AppFlagConstant().more == 'true') {
          //     return true;
          //   }
          //   return false;
          //   case 'Links':
          //   if (AppFlagConstant().links == 'true') {
          //     return true;
          //   }
          //   return false;
          //   case 'Logout':
          //   if (AppFlagConstant().logout == 'true') {
          //     return true;
          //   }
          //   return false;

          default:
            return true;
        }
      },
    );

    _splashBloc?.createActiveMenuItemsWidgetList(mainMenuList);
  }

  Widget createDrawer(BuildContext drawerContext) {
    final _controller = ScrollController();

    return Drawer(
      child: SafeArea(
        child: SingleChildScrollView(
          controller: _controller,
          child: Column(
            children: <Widget>[
              /*
              UserAccountsDrawerHeader(
                decoration: const BoxDecoration(color: Colors.white),
                accountName: Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(
                    AppConfig().gscid,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                      fontSize: 16.0,
                    ),
                  ),
                ),

                accountEmail: Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(
                    AppConfig().clientName.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: 16.0,
                    ),
                  ),
                ),
                currentAccountPicture: Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: CircleAvatar(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.network('https://www.gstatic.com/webp/gallery3/2.png'),
                    ),
                    backgroundColor: Colors.grey,
                  ),
                ),
                currentAccountPictureSize: const Size(80, 80.0),
              ),
              */
              InkWell(
                onTap: () {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(5, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  Navigator.pop(context);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color(0xFF127FBA),
                    ),
                    child: Row(
                      children: [
                        const SizedBox(width: 10),
                        SizedBox(
                          height: 70,
                          width: 70,
                          child: Stack(
                            fit: StackFit.expand,
                            clipBehavior: Clip.none,
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.white,
                                radius: 35,
                                child: CircleAvatar(
                                  radius: 33,
                                  child: Padding(
                                    padding: const EdgeInsets.all(12.0),
                                    child: Image.network(
                                      AppConfig().getProfileUrl(),
                                      errorBuilder: (context, error, stackTrace) {
                                        return Image.asset('assets/images/user_icon.png');
                                      },
                                    ),
                                  ),
                                  backgroundColor: const Color(0xFF96C2DA),
                                ),
                              ),
                              Positioned(
                                bottom: 7,
                                right: -3,
                                child: Container(
                                  // color: Color(0xFFF5F6F9),
                                  decoration: BoxDecoration(color: const Color(0xFFF5F6F9), borderRadius: BorderRadius.circular(30)),
                                  height: 20,
                                  width: 20,
                                  child: const Center(
                                    child: Icon(
                                      Icons.camera_alt_outlined,
                                      color: Colors.blue,
                                      size: 15,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 30),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppConfig().clientName,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 18,
                                  fontFamily: 'Roboto Medium',
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                AppConfig().gscid,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  fontFamily: 'Roboto Medium',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // child: Container(
                //   padding: const EdgeInsets.symmetric(horizontal: 8),
                //   child: Container(
                //     height: 100,
                //     // color: Colors.white,
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(10),
                //       color: const Color(0xFF127FBA),
                //     ),
                //     child: Row(
                //       children: [
                //         const SizedBox(width: 10),
                //         CircleAvatar(
                //           backgroundColor: Colors.white,
                //           radius: 40,
                //           child: CircleAvatar(
                //             radius: 38,
                //             child: Padding(
                //               padding: const EdgeInsets.all(12.0),
                //               child: Image.network('https://www.gstatic.com/webp/gallery3/2.png'),
                //             ),
                //             backgroundColor: const Color(0xFF96C2DA),
                //           ),
                //         ),
                //         const SizedBox(width: 10),
                //         Expanded(
                //           child: Container(
                //             child: Column(
                //               mainAxisAlignment: MainAxisAlignment.center,
                //               crossAxisAlignment: CrossAxisAlignment.start,
                //               children: [
                //                 Text(
                //                   'Sushant Patil',
                //                   overflow: TextOverflow.ellipsis,
                //                   style: TextStyle(
                //                     color: Colors.black54,
                //                     fontWeight: FontWeight.w600,
                //                     fontSize: 24,
                //                   ),
                //                 ),
                //                 Text(
                //                   '0H003',
                //                   overflow: TextOverflow.ellipsis,
                //                   style: TextStyle(
                //                     color: Colors.black54,
                //                     fontWeight: FontWeight.w600,
                //                     fontSize: 18,
                //                   ),
                //                 ),
                //               ],
                //             ),
                //           ),
                //         ),
                //       ],
                //     ),
                //   ),
                // ),
              ),
              FutureBuilder<List>(
                future: readJson(),
                builder: (BuildContext context, response) {
                  if (!response.hasData) {
                    return const Center(
                      child: Text('Loading...'),
                    );
                  } else {
                    // List<dynamic> json = jsonDecode(response.data.body);
                    elementListDataSource = response.data!;
                    return MyExpansionTileList(
                      elementList: response.data!,
                    );
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}

String _currentRoute = "/";
void doRoute(BuildContext context, String name) {
  if (_currentRoute != name) {
    Navigator.pushReplacementNamed(context, name);
  } else {
    Navigator.pop(context);
  }
  _currentRoute = name;
}

class MyExpansionTileList extends StatefulWidget {
  // BuildContext context;
  final List<dynamic> elementList;

  const MyExpansionTileList({Key? key, required this.elementList}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _DrawerState();
}

class _DrawerState extends State<MyExpansionTileList> {
  // You can ask Get to find a Controller that is being used by another page and redirect you to it.
  final Controller c = Get.find();

  List<Widget> _getChildren(final List<dynamic> elementList) {
    List<Widget> children = [];

    elementList.toList().asMap().forEach((index, element) {
      int selected = -1;
      final subMenuChildren = <Widget>[];
      try {
        for (var i = 0; i < element['subMenu'].length; i++) {
          subMenuChildren.add(
            ListTile(
              leading: const Visibility(
                child: Icon(
                  Icons.account_box_rounded,
                  size: 15,
                ),
                visible: false,
              ),
              onTap: () => {
                setState(
                  () {
                    //from the json we got which contains the menu and submenu we will need the "state"
                    // json item to get the unique identifier so we know what to open

                    int index = SplashBloc.finalMenuList.indexOf(element['subMenu'][i]);
                    ConstantMessages.GREEK_TAB_TITLE_MENU = element['subMenu'][i];
                    // This is for SubMenu
                    switch (element['subMenu'][i]) {
                      case 'Netbanking Transfer':
                        //setting current index and opening a new screen using page controller with animations
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = "Fund Transfer";
                        Navigator.pop(context);
                        break;

                      case 'UPI Transfer':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Fund Transfer Details':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Ledger Report':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Trade Summary':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Holdings Report':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Transaction Report':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Client Financial Statement':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Portfolio Details':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Profit and Loss Details':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Strategy Finder':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Strategy Builder':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'E-DIS Dashboard':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'E-DIS Transaction Details':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Margin Pledge':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Charting':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;
                      case 'Stock Alert':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;
                      case 'Notification':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;
                      case 'Recommendation':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Default Screen':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Change Password':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Change Theme':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Profile':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'About Us':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Version':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      // Links
                      case 'SEBI':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'NSE':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'BSE':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'MCX':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'NCDEX':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'SSL':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Back Office':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Fund Transfer Offline':
                        _selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);
                        break;

                      case 'Logout':
                        /*_selectedPageIndex = index + 5;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                        });
                        c.title.value = element['subMenu'][i];
                        Navigator.pop(context);*/
                        Navigator.of(context).pop();
                        GreekDialogPopupView.confirmLogOutDialog(context);
                        break;
                    }
                  },
                )
              },
              title: Text(
                element['subMenu'][i],
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          );
        }
        children.add(
          ExpansionTile(
            key: Key(index.toString()),
            initiallyExpanded: index == selected,
            trailing: element['subMenu'].length > 0 ? null : const SizedBox(), //For hiding and showing up/down arrow
            leading: SvgPicture.asset(
              'assets/images/left_menu/' + element['iconData'] + '.svg',
              // height: 25.0,
            ),
            title: Text(
              element['name'],
              style: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.w500),
            ),
            children: subMenuChildren,
            onExpansionChanged: ((newState) {
              //For Main Menu Navigation [This will take action for main menu item.]
              int index = SplashBloc.finalMenuList.indexOf(element['name']);
              ConstantMessages.GREEK_TAB_TITLE_MENU = element['name'];
              switch (element['name']) {
                case 'Strategy Finder':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Strategy Builder':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Charting':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Stock Alert':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Notification':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Recommendation':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Settings':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Profile':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'IPO':
                  _selectedPageIndex = index + 5;
                  Navigator.pop(context);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _pageController?.animateToPage(_selectedPageIndex, duration: const Duration(milliseconds: 1), curve: Curves.easeInOut);
                  });
                  c.title.value = element['name'];
                  break;
                case 'Logout':
                  GreekNavigator.pop(context: context);
                  GreekDialogPopupView.confirmLogOutDialog(context);

                  break;
                default:
                  if (newState) {
                    const Duration(seconds: 20000);
                    selected = index;
                  } else {
                    selected = -1;
                  }
                  break;
              }
            }),
          ),
        );
      } catch (err) {}
    });
    return children;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: _getChildren(widget.elementList),
    );
  }

  @override
  void initState() {
    super.initState();
  }
}
