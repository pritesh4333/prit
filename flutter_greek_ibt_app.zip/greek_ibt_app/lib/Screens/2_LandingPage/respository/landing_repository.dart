import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/allowed_product_model.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/market_status_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/indian_indicesdata_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class LandingRepository {
  Future<List<IndianIndicesResponseModel>?> indicesdata() async {
    final response = await NetworkManager().postAPIEncryptedForIndianIndices(
      //context: context,
      apiName: APIName.getIndianIndicesDataForUserV2,
      assetType: "equity",
      gscid: AppConfig().gscid,
    );

    if ((response != null) && (response is Map)) {
      final responseData = response['indianIndicesData'];

      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj = responseData
            .map((e) => IndianIndicesResponseModel.fromJson(e))
            .toList();

        return obj;
      }
    }

    return null;
  }

  Future<int?> heartBeatAPI() async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        apiName: APIName.jheartbeat,
        postBody: {
          'gscid': AppConfig().gscid,
          'sessionId': AppConfig().sessionID,
        },
      );

  Future<List<AllowedProduct?>> getProduct() async {
    final response = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getAllowedProduct,
      postBody: {},
    );

    if (response is Map) {
      final productList = response['AllowedProduct'];
      if (productList is List) {
        final result = productList
            .map(
              (e) => AllowedProduct.fromJson(e),
            )
            .toList();

        return result;
      }
    }

    return [];
  }

  Future<List<MarketStatusResponseModel?>> getMarketSatusAPI() async {
    final responseData = await NetworkManager()
        .postAPIEncrypted(apiName: APIName.getMarketStatus, postBody: {
      'gscid': AppConfig().gscid,
    });

    if (responseData is Map) {
      final marketResponse = (responseData)['MarketStatus'];

      if (marketResponse is List) {
        final result = marketResponse
            .map(
              (e) => MarketStatusResponseModel.fromJson(e),
            )
            .toList();
        return result;
      }
    }
    return [];
  }
}
