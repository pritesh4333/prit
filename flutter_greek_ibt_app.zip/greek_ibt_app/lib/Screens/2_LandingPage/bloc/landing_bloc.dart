import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/respository/landing_repository.dart';
import 'package:greek_ibt_app/Screens/Edis/bloc/edis_dashboard_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/indian_indicesdata_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';

class LandingBloc extends GreekBlocs {
  final VoidCallback _callBackToLandingTabbView;

  int selectedTabBarIndex = int.parse(AppFlagConstant().defaultScreenIndex);

  final _landingRepository = LandingRepository();

  final BuildContext _landinContext;

  Timer? _heartBeatTimer;
  var _counter = 0;

  LandingBloc(this._landinContext, this._callBackToLandingTabbView) {
    _landingRepository.getProduct().then((value) {
      if (value.isNotEmpty) {
        GreekBase().alloedProductList = value;
      }
    });

    _getIndianIndecsData();
    _landingRepository
        .getMarketSatusAPI()
        .then((value) => GreekBase().getMarketStatusFlags(value));

    _heartBeatTimer?.cancel();
    _heartBeatTimer = null;
    _heartBeatTimer = Timer.periodic(
      Duration(seconds: AppConfig().heartBeatInterval),
      _callHeartBeatAPIS,
    );

    final _ =
        Timer(const Duration(seconds: 3), () => _registerCommonAppListener());
  }

  @override
  void disposeBloc() {
    _heartBeatTimer?.cancel();
    _heartBeatTimer = null;
  }

  ///===============================================================================
  ///               Send Heartbeat Request (Node , Apollo & Iris)
  ///===============================================================================
  void _callHeartBeatAPIS(_) {
    if (!AppConfig().islogoff) {
      if (_counter <= AppConfig().reconnection_attempts) {
        _landingRepository.heartBeatAPI().then(
              (errorCode) => _validatedHeartBeatErrorCode(errorCode),
            );

        SocketIOManager().socketIOHeartBeat();

        _counter++;
      } else {
        _counter = 0;
        GreekBase().logoutApp(logoffContext: _landinContext);
      }
    }
  }

  ///===================================== END =====================================

  ///===============================================================================
  /// Initilzation Common App Lister like Apollo & Iris Response
  ///===============================================================================
  void _registerCommonAppListener() {
    GreekBase().commonListenObserver.stream.listen(
      (event) {
        switch (event) {
          case CommonListenID.showWatchlistGroupNameBottomSheet:
            _showWatchListBottomSheet();
            break;
          case CommonListenID.navigateFundScreen:
            selectedTabBarIndex = 4;
            _callBackToLandingTabbView();
            break;
          default:
            break;
        }
      },
    );

    //  For Apollo Response
    SocketIOManager().brodcastResponseObservable?.listen(
      (apolloEvent) {
        if (apolloEvent != null) {
          final keys = apolloEvent.keys.toList();

          for (var item in keys) {
            switch (item.apolloResponseStreamingType) {
              case ApolloResponseStreamingType.HeartBeat:
                final errorCode = int.parse(
                  apolloEvent[item]?['error_code']?.toString() ?? '-1',
                );
                _validatedHeartBeatErrorCode(errorCode);
                break;

              case ApolloResponseStreamingType.indexStream:
                final responseDic = apolloEvent[item];
                if (responseDic is Map<String, dynamic>) {
                  if ((responseDic['indexCode'] != null) &&
                      (responseDic['ltp'] != null) &&
                      (responseDic['change'] != null) &&
                      (responseDic['p_change'] != null)) {
                    final token =
                        int.parse(responseDic['indexCode'].toString());
                    final ltp = double.parse(responseDic['ltp'].toString());
                    final change =
                        double.parse(responseDic['change'].toString());
                    final pChange =
                        double.parse(responseDic['p_change'].toString());
                    for (var item in GreekBase().indicesIndexDataList) {
                      if ((item.indexCode ?? -1) == token) {
                        var obj = item;
                        obj.last = ltp;
                        obj.change = change;
                        obj.pChange = pChange;

                        final foundedIndex =
                            GreekBase().indicesIndexDataList.indexOf(item);
                        if (foundedIndex >= 0) {
                          GreekBase().indicesIndexDataList[foundedIndex] = obj;
                          GreekBase()
                              .indicesSubjectList
                              .elementAt(foundedIndex)
                              .sink
                              .add(obj);
                          // break;
                        }
                      }
                    }
                  }
                }

                break;

              case ApolloResponseStreamingType.MarketStatus:
                _landingRepository.getMarketSatusAPI().then(
                  (value) {
                    GreekBase().getMarketStatusFlags(value);
                  },
                );
                break;

              case ApolloResponseStreamingType.AlertExecuted:
                final responseDic = apolloEvent['AlertExecuted'];
                String symbol = responseDic['Symbol'];
                String currentValue = responseDic['CurrentValue'];
                String rangeValue = responseDic['RangeValue'];
                String message = responseDic['Message'];
                final finalMessage =
                    'Alert Notification\n\n$symbol\n\nCurrent Value: $currentValue\nRange Value: $rangeValue\nMessage: $message';
                GreekDialogPopupView.messageDialog(
                    _landinContext, finalMessage);
                break;

              default:
                break;
            }
          }
        }
      },
    );

    //  For Iris Response
    SocketIOManager().orderResponseObservable?.listen(
      (irisEvent) {
        if (irisEvent != null) {
          final keys = irisEvent.keys.toList();

          for (var item in keys) {
            switch (item.irisResponseStreamingType) {
              case IrisResponseStreamingType.HeartBeat:
                final errorCode = int.parse(
                  irisEvent[item]?['error_code']?.toString() ?? '-1',
                );
                _validatedHeartBeatErrorCode(errorCode);
                break;

              case IrisResponseStreamingType.OrderResponse:
              case IrisResponseStreamingType.TriggerResponse:
              case IrisResponseStreamingType.OrderRejectionResponse:
              case IrisResponseStreamingType.RmsRejectionResponse:
                final orderResponse = irisEvent[item];
                if (orderResponse is Map<String, dynamic>) {
                  GreekDialogPopupView.orderResponseDialog(
                    popContext: GreekBase().drawerKey.currentContext,
                    response: orderResponse,
                    irisResponseStreamingType: item.irisResponseStreamingType,
                    onPressed: (orderState) {
                      if (selectedTabBarIndex == 2) {
                        GreekBase().orderScreenState?.sink.add(orderState);
                      }

                      if (AppFlagConstant().isEDISProduct.toString() ==
                              "true" &&
                          irisEvent[item]?['code']?.toString() == "249") {
                        EdisDashboardBloc(context: _landinContext)
                            .callgetClientPOAStatus(AppConfig().gscid);

                        GreekDialogPopupView.showPoaPopup(_landinContext,
                            (value) {
                          if (AppFlagConstant().dpType == "NSDL") {
                            EdisDashboardBloc(context: _landinContext)
                                .sendAuthorizationRequestNSDL(
                                    value.item1,
                                    value.item2,
                                    value.item3,
                                    value.item4,
                                    value.item5);
                          } else {
                            EdisDashboardBloc(context: _landinContext)
                                .sendAuthorizationRequestCDSL(
                                    value.item1,
                                    value.item2,
                                    value.item3,
                                    value.item4,
                                    value.item5);
                          }
                        });
                      }
                    },
                  );
                }

                break;
              case IrisResponseStreamingType.TradeResponse:
                SocketIOManager().npDetailsRequest();
                if (AppFlagConstant().showTradeAlert != 'true') {
                  break;
                }

                final orderResponse = irisEvent[item];
                if (orderResponse is Map<String, dynamic>) {
                  GreekDialogPopupView.orderResponseDialog(
                    popContext: GreekBase().drawerKey.currentContext,
                    response: orderResponse,
                    irisResponseStreamingType: item.irisResponseStreamingType,
                    onPressed: (orderState) {
                      if (selectedTabBarIndex == 2) {
                        GreekBase().orderScreenState?.sink.add(orderState);
                      } else if (selectedTabBarIndex == 3) {
                        GreekBase()
                            .portfolioScreenState
                            .sink
                            .add(GreekBase.portfolioStateObject);
                      }
                    },
                  );
                }

                break;
              case IrisResponseStreamingType.MarketStatus:
                _landingRepository.getMarketSatusAPI().then(
                  (value) {
                    GreekBase().getMarketStatusFlags(value);
                  },
                );
                break;

              case IrisResponseStreamingType.AdminMessages:
                String message = irisEvent[item]['Message'];
                String decodedMessage = utf8.decode(base64.decode(message));

                //show alert
                final snackBar = SnackBar(
                  backgroundColor: Colors.grey.shade400,
                  elevation: 2,
                  duration: const Duration(
                    seconds: 1,
                  ),
                  content: Text(
                    decodedMessage,
                    style: const TextStyle(color: Colors.black),
                  ),
                  action: SnackBarAction(
                      label: 'OK', textColor: Colors.black, onPressed: () {}),
                );

                ScaffoldMessenger.of(_landinContext).removeCurrentSnackBar();
                ScaffoldMessenger.of(_landinContext).showSnackBar(snackBar);
                break;

              default:
                break;
            }
          }
        }
      },
    );
  }

  ///===================================== END =====================================

  ///===============================================================================
  ///                 Show Watchlist Group Name Bottom Sheet
  ///===============================================================================
  void _showWatchListBottomSheet() {
    GreekDialogPopupView.showBottomShhetForWatchList(
      context: _landinContext,
      groups: GreekBase().watchlistGroupArray,
    );
  }

  ///===================================== END =====================================

  ///===============================================================================
  ///                           Validated Heartbeat
  ///===============================================================================
  void _validatedHeartBeatErrorCode(int? errorCode) {
    if (errorCode != 0) {
      _heartBeatTimer?.cancel();
      _heartBeatTimer = null;

      GreekBase().logoutApp(logoffContext: _landinContext);
    }
    if (errorCode == 0) {
      _counter = 0;
    }
  }

  ///===================================== END =====================================

  ///===============================================================================
  ///                           Indian Indices Index
  ///===============================================================================
  void _getIndianIndecsData() {
    GreekBase().indicesIndexDataList = [];

    _landingRepository.indicesdata().then(
      (value) {
        if ((value != null) && (value.isNotEmpty)) {
          GreekBase().indicesIndexDataList = value;

          GreekBase().indicesIndexDataList.sort(
                (a, b) => ((a.seqNo ?? 0).compareTo(b.seqNo ?? 0)),
              );

          for (var element in GreekBase().indicesSubjectList) {
            element.close();
          }

          GreekBase().indicesSubjectList.clear;
          GreekBase().indicesSubjectList =
              List<BehaviorSubject<IndianIndicesResponseModel>>.generate(
            GreekBase().indicesIndexDataList.length,
            (index) => BehaviorSubject<IndianIndicesResponseModel>.seeded(
              GreekBase().indicesIndexDataList[index],
            ),
          );
        }

        GreekBase().indicesSubject.sink.add(GreekBase().indicesSubjectList);
        GreekBase().subscribeIndicesIndexTokens();
      },
    );
  }

  ///===================================== END =====================================
}
