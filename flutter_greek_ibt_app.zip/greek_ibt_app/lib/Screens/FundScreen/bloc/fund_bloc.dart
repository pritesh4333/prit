import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/atom_bank_list_response_model.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/bank_details_respnse.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_details_response_model.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_transaction_details_response.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/razor_pay_model.dart';
import 'package:greek_ibt_app/Screens/FundScreen/repository/fund_respository.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/atom_webview_screen.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/payment_failure_razopay.dart';
import 'package:xml2json/xml2json.dart';

class FundBloc extends GreekBlocs {
  final _repository = FundRepository();
  final TextEditingController textEditingController = TextEditingController();
  final TextEditingController withdrawAmountController = TextEditingController();
  final TextEditingController upiTextController = TextEditingController();

  Razorpay? razorpay;

  String? msg;
  String orderID = "";
  String? failMsg;

  final BuildContext _fundContext;
  String? bankAcc;
  List<String>? finalAtomBankIdList;
  List<String>? finalAtomBankNameList;

  final ValueChanged<FundScreenUserAction> _callbackToFundView;

  FundBloc(this._fundContext, this._callbackToFundView) {
    _registerCommonListener();
    //getBankDetailsApi();
    _getFundDetails();

    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType == IrisResponseStreamingType.FundPayOutResponse) {
            final responseDic = event[item];
            log("fundpayout response : $responseDic");

            var message = (responseDic['Message']?.toString() ?? "-1");
            GreekDialogPopupView.messageDialog(
              _fundContext,
              message.toString(),
            );
          }
        }
      }
    });
  }

  @override
  void disposeBloc() {}

  void _registerCommonListener() {
    razorpay ??= Razorpay();

    razorpay?.on(Razorpay.EVENT_PAYMENT_SUCCESS, handlerPaymentSuccess);
    razorpay?.on(Razorpay.EVENT_PAYMENT_ERROR, handlerErrorFailure);
    razorpay?.on(Razorpay.EVENT_EXTERNAL_WALLET, handlerExternalWallet);

    GreekBase().userActionForFundScreenObserver.listen((value) {
      _callbackToFundView(value);
    });
  }

  Future<List<RazorPayResModel>?> razorPayApi(String accountNumber, String deviceType) async {
    final responseMap = await _repository.getRazorpayAPI(AppConfig().gscid, AppConfig().gcid, textEditingController.text, AppConfig().sessionID, '2', accountNumber, deviceType);
    orderID = responseMap?.first.arrayData?.first.respo?.id ?? "";

    return responseMap;
  }

  _verifyrazorPayApi(String paymentId, String orderId, String amount, String signature) async {
    final responseMap = await _repository.verifyRazorpayAPI(paymentId, orderId, amount, signature);

    return responseMap;
  }

  Future<List<RazorPayFailureResp>?> failedrazorPayApi(String paymentId, String orderId, String amount, String gscid) async {
    final responseMap = await _repository.failRazorpayAPI(paymentId, orderId, amount, gscid);

    failMsg = responseMap?.first.payStatus?.failed ?? 'Payment Fail';

    return responseMap;
  }

  /* _failedrazorPayApi(
      String paymentId, String orderId, String amount, String gscid) async {
    final responseMap =
        await _repository.failRazorpayAPI(paymentId, orderId, amount, gscid);

    return responseMap;
  } */

  //fundTransferDetails For NetBanking ATOM
  Future<FundDeatailsRespModel> getFundTransferDetailsNetBanking({required String segment, required String amount}) async {
    final response = await _repository.getFundTransferDetails(segment, amount);
    return response;
  }

  //fundTransferDetails For UPI ATOM
  Future<FundDeatailsRespModel> getFundTransferDetailsUpi({required String segment, required String amount, required String selectedBankName}) async {
    final response = await _repository.getFundTransferDetailsUpi(segment, amount, selectedBankName);
    return response;
  }

  //Update 'fundTransferResponseDetails'
  Future<dynamic> updateFundTransferResponseDetails(FinalAtomResponse finalAtomResponse, String orderTransId) async {
    final response = await _repository.fundTransferResponseDetails(finalAtomResponse, orderTransId);
    return response;
  }

//Update 'fTCancelResponse'
  Future<dynamic> updateFTCancelResponse(String orderTransId) async {
    final response = await _repository.fTCancelResponse(orderTransId);
    return response;
  }

  //getTransactionDetails
  Future<List<FundTransactionDetailsResponse>> getTransactionDetails({required bool showAll, required bool isFromDatePicker, required String startDate, required String endDate}) async {
    if (isFromDatePicker) {
      final response = await _repository.getTransactionDetailsByDate(startDate: startDate, endDate: endDate);
      return response;
    } else {
      if (showAll) {
        final response = await _repository.getTransactionDetails();
        return response;
      }
      return [];
    }
  }

  Future<List<BankDetailsResponseModel>?> getBankDetailsApi({required String paymentGatewayType}) async {
    final response = await _repository.getBankAPI();
    bankAcc ??= response![0].data!.bankAccountList!.first.bankAcNo;
    String merchantId = response![0].data!.merchantDetails!.first.merchantId.toString();

    final bankAccountList = List<BankAccountList>.from(response[0].data!.bankAccountList!);
    // final merchantDetails = List<MerchantDetail>.from(response[0].data!.merchantDetails!);
    //Call GetAtomBankList

    if (paymentGatewayType == 'atom') {
      final atomJsonResponse = await _repository.getATOMBankList(merchantId: merchantId);
      //Parse Json string to Json Data and get the list

      final Xml2Json xml2Json = Xml2Json();
      String jsonString = '';

      xml2Json.parse(atomJsonResponse);
      jsonString = xml2Json.toParker();
      final jsonData = jsonDecode(jsonString);

      final converter = Xml2Json();
      // firstly convert xml to json
      converter.parse(atomJsonResponse);
      var res = converter.toGData();
      var responseModel = AtomBankListResponseModel.fromJson(json.decode(res));
      final tempParam = responseModel.mMP?.mERCHANT?.rESPONSE?.param;
      List<String> bankIdList = [];
      for (var item in tempParam!) {
        bankIdList.add(item.bankid ?? '');
      }
      finalAtomBankIdList = bankIdList;

      var bankList = jsonData['MMP']['MERCHANT']['RESPONSE'];
      var bankListData = bankList['param'];

      List<String> tempList = [];
      for (var bankName in bankListData) {
        tempList.add(bankName.toString().toLowerCase());
      }

      finalAtomBankNameList = List<String>.from(tempList);

      var s1 = {
        ...bankAccountList.map((e) {
          return e.bankName?.toUpperCase();
        })
      };

      var s2 = {
        ...tempList.map((e) {
          return e.toUpperCase();
        })
      };

      var commonBankList = s1.intersection(s2).toList();

      response[0].data!.bankAccountList?.clear();
      for (var item in commonBankList) {
        for (var bankDetail in bankAccountList) {
          if (item?.toUpperCase() == bankDetail.bankName!.toUpperCase()) {
            response[0].data!.bankAccountList?.add(bankDetail);
          }
        }
      }
      return response;
    }
    return response;
  }

  Future<List<FundDeatailsRespModel>?> _getFundDetails() async {
    // final response = await _repository.getFundTransferDetails();
    // return response;
  }

  Future<List<FundDeatailsRespModel>?> getFundRespDetails() async {
    final response = await _repository.getFundResponseDetails();
    return response;
  }

  void handlerPaymentSuccess(PaymentSuccessResponse response) {
    log("Payment success"
        '${response.paymentId},${response.orderId},${response.signature}');
    msg = "SUCCESS: "
        '${response.paymentId},${response.orderId},${response.signature}';
    showToast(msg);
    _verifyrazorPayApi(response.paymentId ?? '', response.orderId ?? '', textEditingController.text, response.signature ?? '');
    /* GreekDialogPopupView.messageDialog(
      _fundContext,
      '',
    );  */
  }

  void handlerErrorFailure(
    PaymentFailureResponse response,
  ) {
    // msg = "ERROR: " +
    //     response.code.toString() +
    //     " - " +
    //     jsonDecode('${response.message}')['error']['description'];
    // showToast(msg);
    // log('==================Failed================');
    // log(msg);

    // _failedrazorPayApi('0', 'order_JVxmz52nsKm4fr', '100', AppConfig().gscid);
    failedrazorPayApi(
      '0',
      orderID,
      textEditingController.text,
      AppConfig().gscid,
    );
    GreekDialogPopupView.messageDialog(
      _fundContext,
      'Payment Failed',
    );
  }

  void handlerExternalWallet(ExternalWalletResponse response) {
    msg = "EXTERNAL_WALLET: " '${response.walletName}';
    // showToast(msg);
  }

  showToast(msg) {
    Fluttertoast.showToast(
      msg: msg,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.black,
      textColor: Colors.white,
    );
  }
}
