import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/FundScreen/bloc/fund_bloc.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_transaction_details_response.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/transaction_list_details.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/rxdart.dart';

class FundTransactionDetails extends StatefulWidget {
  @override
  State<FundTransactionDetails> createState() => _FundTransactionDetailsState();
}

class _FundTransactionDetailsState extends State<FundTransactionDetails> {
  BehaviorSubject<String> totalTransaction = BehaviorSubject.seeded('');
  // String totalTransaction = '0';
  String toDate = 'To Date';
  String fromDate = 'From Date';
  String startDate = '';
  String endDate = '';

  FundBloc? _fundBloc;
  FundTransactionDetailsResponse? _fundTransactionDetailsResponse;
  List<FundTransactionDetailsResponse>? _receivedDataListResponse;

  bool isFromDatePicker = false;
  bool showAll = true;

  @override
  void initState() {
    super.initState();
    //tz.initializeTimeZones();
    _fundBloc ??= FundBloc(
      context,
      (result) {
        _fundTransactionDetailsResponse = FundTransactionDetailsResponse();
        _receivedDataListResponse = [];
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        title: Text(
          'Fund Transfer List',
          style: GreekTextStyle.headlines2,
        ),
        backgroundColor: ConstantColors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          iconSize: 30.0,
          color: ConstantColors.black,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDatePickers(context),
          _buildTitleTransaction(),
          _buildHeaderList(),
          Expanded(
            child: SizedBox(
              child: FutureBuilder<List<FundTransactionDetailsResponse>>(
                future: _fundBloc?.getTransactionDetails(showAll: showAll, isFromDatePicker: isFromDatePicker, startDate: startDate, endDate: endDate),
                builder: (context, snapshot) {
                  if (snapshot.hasData && snapshot.data != null) {
                    int dataLength = snapshot.data!.length;
                    if (dataLength <= 0) {
                      totalTransaction.sink.add('0');
                      double topSpace = MediaQuery.of(context).size.height;
                      return NoDatWithProgressIndicator1(topSpace: topSpace, showHide: false, divider: 3.5);
                    }
                    return ListView.builder(
                      physics: const AlwaysScrollableScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemCount: snapshot.data?.length ?? 0,
                      itemBuilder: (context, index) {
                        totalTransaction.sink.add(snapshot.data?.length.toString() ?? '0');

                        final responeObj = snapshot.data?[index];
                        _receivedDataListResponse = snapshot.data ?? [];
                        var transId = responeObj?.tranId.toString() ?? '';
                        var bankTranId = responeObj?.bankTranId.toString() ?? '';
                        var bankName = responeObj?.bankName.toString() ?? '';
                        int dateReceived = int.parse(responeObj?.dateAndTime.toString() ?? '');
                        var date = timeStampToDateConverterSince1970(dateReceived);

                        var amount = responeObj?.amount.toString() ?? '';
                        var transStatus = '';
                        String statusFlag = (responeObj?.statusFlag.toString() ?? '');
                        switch (int.parse(statusFlag)) {
                          case 0:
                            transStatus = 'Initiated';
                            break;
                          case 1:
                            transStatus = 'Ack Received';
                            break;
                          case 2:
                            transStatus = 'Request Sent';
                            break;
                          case 3:
                            transStatus = 'Completed';
                            break;
                          default:
                            transStatus = 'Invalid Status';
                            break;
                        }

                        if (transId == "null") {
                          transId = '';
                        }
                        if (bankTranId == "null") {
                          bankTranId = '';
                        }
                        if (bankName == "null") {
                          bankName = '';
                        }

                        double widthContainer = MediaQuery.of(context).size.width / 3;

                        return Column(
                          // mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            InkWell(
                              onTap: () {
                                _fundTransactionDetailsResponse = _receivedDataListResponse?[index];
                                //Need to Navigate to Transaction Details on Tap of Row
                                Navigator.push(context, MaterialPageRoute(
                                  builder: (context) {
                                    return TransactionListDetailsScreen(responseObj: _fundTransactionDetailsResponse);
                                  },
                                ));
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.only(left: 10),
                                    width: widthContainer,
                                    alignment: Alignment.centerLeft,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(transId, style: TextStyle(fontSize: 12.0)),
                                        Text(date, style: TextStyle(fontSize: 12.0)),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.only(right: 30),
                                    width: widthContainer,
                                    alignment: Alignment.centerRight,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Text(
                                          bankTranId,
                                          style: TextStyle(fontSize: 12.0),
                                          textAlign: TextAlign.right,
                                        ),
                                        Text(
                                          amount,
                                          style: TextStyle(fontSize: 12.0),
                                          textAlign: TextAlign.right,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.only(right: 30),
                                    width: widthContainer,
                                    alignment: Alignment.centerRight,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          bankName.toUpperCase(),
                                          style: TextStyle(fontSize: 12.0),
                                          textAlign: TextAlign.right,
                                        ),
                                        Text(
                                          transStatus,
                                          style: TextStyle(fontSize: 12.0),
                                          textAlign: TextAlign.right,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(
                              thickness: 1,
                            )
                          ],
                        );
                      },
                    );
                  } else {
                    double topSpace = MediaQuery.of(context).size.height;
                    return NoDatWithProgressIndicator1(topSpace: topSpace, showHide: true, divider: 3.5);
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Padding _buildHeaderList() {
    return Padding(
      padding: const EdgeInsets.all(0.0),
      child: Column(
        children: [
          Container(
            color: Colors.grey.shade200,
            height: 45,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Tran ID", style: GreekTextStyle.marketStatisticsDropdownTextStyle),
                      Text("Date", style: GreekTextStyle.marketStatisticsDropdownTextStyle),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(left: 40),
                  alignment: Alignment.centerRight,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text("Bank Tran ID", style: GreekTextStyle.marketStatisticsDropdownTextStyle),
                      Text("Amount Cr/Dr", style: GreekTextStyle.marketStatisticsDropdownTextStyle),
                    ],
                  ),
                ),
                Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(left: 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text("Bank Name", style: GreekTextStyle.marketStatisticsDropdownTextStyle),
                      Text("Status", style: GreekTextStyle.marketStatisticsDropdownTextStyle),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            thickness: 1,
          )
        ],
      ),
    );
  }

  Card _buildDatePickers(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: SizedBox(
        height: 50,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            GestureDetector(
              onTap: () async {
                final DateTime? newDateTime = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now().toUtc(),
                  firstDate: DateTime(DateTime.now().year - 50, DateTime.now().month - 1, DateTime.now().day + 1).toUtc(),
                  lastDate: DateTime.now().toUtc(),
                );

                if (newDateTime != null) {
                  startDate = (((newDateTime.millisecondsSinceEpoch ~/ 1000) + 19800).round()).toString();
                  setState(() {
                    fromDate = DateFormat('dd/MM/yyyy').format(newDateTime);
                    if (startDate.isNotEmpty && endDate.isNotEmpty) {
                      if (int.parse(endDate) > int.parse(startDate)) {
                        isFromDatePicker = true;
                      } else {
                        isFromDatePicker = false;
                        showAll = false;
                        GreekDialogPopupView.messageDialog(
                          context,
                          '\'From Date\' should not be greator than \'To Date\'',
                        );
                      }
                    } else {
                      isFromDatePicker = false;
                      showAll = false;
                    }
                  });
                }
              },
              child: Row(
                children: [
                  Text(
                    fromDate,
                    style: GreekTextStyle.headline1,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(width: 8),
                  const Icon(
                    Icons.calendar_month,
                    color: Colors.blue,
                  ),
                ],
              ),
            ),
            const Text('-', style: TextStyle(fontSize: 30), textAlign: TextAlign.start),
            GestureDetector(
              onTap: () async {
                final DateTime? newDateTime = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now().toUtc(),
                  firstDate: DateTime(DateTime.now().year - 50, DateTime.now().month - 1, DateTime.now().day + 1).toUtc(),
                  lastDate: DateTime.now().toUtc(),
                );

                if (newDateTime != null) {
                  endDate = (((newDateTime.millisecondsSinceEpoch ~/ 1000) + 106199).round()).toString();
                  setState(() {
                    toDate = DateFormat('dd/MM/yyyy').format(newDateTime);
                    if (startDate.isNotEmpty && endDate.isNotEmpty) {
                      if (int.parse(startDate) < int.parse(endDate)) {
                        isFromDatePicker = true;
                      } else {
                        isFromDatePicker = false;
                        showAll = false;
                        GreekDialogPopupView.messageDialog(
                          context,
                          '\'From Date\' should not be greator than \'To Date\'',
                        );
                      }
                    } else {
                      isFromDatePicker = false;
                      showAll = false;
                    }
                  });
                }
              },
              child: Row(
                children: [
                  Text(
                    toDate,
                    style: GreekTextStyle.headline1,
                  ),
                  const SizedBox(width: 8),
                  const Icon(
                    Icons.calendar_month,
                    color: Colors.blue,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Container _buildTitleTransaction() {
    return Container(
      margin: const EdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          StreamBuilder<String>(
            stream: totalTransaction.stream,
            builder: (context, snapshot) {
              return Text(
                'Total Transaction - ${snapshot.data ?? ''}',
                style: GreekTextStyle.heading11,
              );
            },
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              primary: Colors.white,
            ),
            onPressed: () {
              setState(() {
                toDate = 'To Date';
                fromDate = 'From Date';
                startDate = '';
                endDate = '';
                showAll = true;
                isFromDatePicker = false;
                _fundBloc?.getTransactionDetails(showAll: showAll, isFromDatePicker: isFromDatePicker, startDate: startDate, endDate: endDate);
              });
            },
            child: Text(
              'Refresh',
              style: GreekTextStyle.headline1,
            ),
          ),
        ],
      ),
    );
  }

  String timeStampToDateConverterSince1970(int timeStamp) {
    return DateFormat('dd MMM yyyy').format(DateTime.fromMillisecondsSinceEpoch(timeStamp * 1000));
  }
}

class NoDatWithProgressIndicator1 extends StatelessWidget {
  const NoDatWithProgressIndicator1({
    Key? key,
    required this.topSpace,
    required this.showHide,
    required this.divider,
  }) : super(key: key);

  final double topSpace;
  final bool showHide;
  final double divider;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: topSpace / divider),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              showHide ? const CircularProgressIndicator() : const SizedBox.shrink(),
              showHide ? const SizedBox(width: 14) : const SizedBox.shrink(),
              Container(child: GreekBase().noDataAvailableView()),
            ],
          ),
        ],
      ),
    );
  }
}
