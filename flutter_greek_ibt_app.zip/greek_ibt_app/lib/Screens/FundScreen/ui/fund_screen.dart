// ignore_for_file: non_constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:crypto/crypto.dart' as crypto;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/FundScreen/bloc/fund_bloc.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/bank_details_respnse.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_details_response_model.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/margin_response_madel.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/razor_pay_model.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/atom_webview_screen.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/fund_transaction_details.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/withdraw_model.dart';
import 'package:intl/intl.dart';
import 'dart:io';

enum PaymentType {
  upi,
  netbank,
  razor,
}

class FundScreen extends StatefulWidget {
  const FundScreen({Key? key}) : super(key: key);

  @override
  _FundScreenState createState() => _FundScreenState();
}

class _FundScreenState extends State<FundScreen> {
  bool addFundVisibility = false;
  bool withdrawVisibility = false;
  bool listVisibility = true;
  bool pressed = true;
  bool pressedWithdraw = true;

  List<String> DropdownValues = ['Select Segment'];
  String SelectedValue = 'Select Segment';
  List<String> accountDropdownValues = ['Select Account Details'];
  String accountSelectedValue = 'Select Account Details';

  String segStr = "";

  List BankDetails = [];

  String orderId = '';
  double total = 0.00;
  PaymentType? paymentType;

  FundBloc? _fundBloc;
  Future<BankDetailsResponseModel>? events;

  BankDetailsResponseModel? selectedEvent;
  String selectedBank = '';

  String? segment;
  String? segmentstr;
  String? prodId;
  int? merchantId;
  String? password;
  String? reqHashKey;
  String? resHashKey;
  Timer? timer;

  String? orderTransId;
  String? amount;
  String? bankName;
  String? orderState;
  String? orderStateMsg;

  TextEditingController textEditingController = TextEditingController();
  FocusNode textFocusController = FocusNode();
  FocusNode upiFocusNode = FocusNode();

  Color selectedColorNetBanking = Colors.black26;
  Color selectedColorUpi = Colors.black26;
  bool showHideNetBankUpiSection = false;

  @override
  void initState() {
    // PortfolioBloc.searchWidgitVisiblity.sink.add(true);

    _fundBloc?.textEditingController.clear();
    _fundBloc?.withdrawAmountController.clear();
    _fundBloc?.upiTextController.clear();
    _fundBloc ??= FundBloc(
      context,
      (result) {
        switch (result) {
          case FundScreenUserAction.portfolio:
            withdrawVisibility = false;
            listVisibility = true;
            addFundVisibility = false;
            pressedWithdraw = true;
            pressed = true;
            break;
          case FundScreenUserAction.add_fund:
            withdrawVisibility = !withdrawVisibility;
            listVisibility = false;
            addFundVisibility = true;
            pressed = false;
            pressedWithdraw = true;
            break;
        }
      },
    );

    if (AppFlagConstant().paymentGateway.toLowerCase() == 'atom') {
      showHideNetBankUpiSection = false;
      selectedColorNetBanking = Colors.blue;
      selectedColorUpi = Colors.black26;
      paymentType = PaymentType.netbank;
    } else if (AppFlagConstant().paymentGateway.toLowerCase() == 'razor') {
      showHideNetBankUpiSection = true;
      paymentType = PaymentType.razor;
    }
    super.initState();
  }

  @override
  void dispose() {
    // PortfolioBloc.searchWidgitVisiblity.sink.add(false);
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: ConstantColors.white,
        leading: IconButton(
          onPressed: () => GreekBase().drawerKey.currentState?.openDrawer(),
          icon: const Icon(Icons.menu_rounded),
          iconSize: 30.0,
          color: ConstantColors.black,
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                ConstantMessages.FUNDS_HEADER_TXT,
                style: GreekTextStyle.headline2,
              ),
            ),
            Visibility(
              visible: true,
              child: GestureDetector(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => FundTransactionDetails(),
                  ));
                },
                child: Container(
                  height: 40,
                  width: 220,
                  decoration: BoxDecoration(
                    boxShadow: const [
                      BoxShadow(
                        blurRadius: 0.1,
                      ),
                    ],
                    shape: BoxShape.rectangle,
                    border: Border.all(
                      width: 0.0,
                      color: Colors.white,
                    ),
                  ),
                  child: Container(
                    color: Colors.white,
                    child: const Center(
                      child: Text(
                        'View Transaction Details',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: ConstantColors.black,
                          fontFamily: 'Roboto',
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                child: SizedBox(
                  height: 94.0,
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    child: InkWell(
                      onTap: () {
                        setState(
                          () {
                            withdrawVisibility = false;
                            listVisibility = true;
                            addFundVisibility = false;
                            pressedWithdraw = true;
                            pressed = true;
                          },
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: StreamBuilder<Map<String, dynamic>?>(
                            stream: SocketIOManager().marginResponseObservable,
                            builder: (context, snapshot) {
                              MarginResponseModel? obj;
                              if (snapshot.data != null) {
                                final keys = snapshot.data!.keys.toList();

                                for (var item in keys) {
                                  if (item.irisResponseStreamingType == IrisResponseStreamingType.MarginDetailResponse) {
                                    final marginDetailsResponse = snapshot.data![item];
                                    // log(marginDetailsResponse.toString());
                                    obj = MarginResponseModel.fromJson(marginDetailsResponse);

                                    double leftTotal = double.parse(obj.availFund ?? '0.00') + double.parse(obj.payIn ?? '0.00') + double.parse(obj.optSellCr ?? '0.00') + double.parse(obj.collateralVal ?? '0.00') + double.parse(obj.eqSellCredit ?? '0.00');

                                    /*  rightTotal = Double.parseDouble(marginDetailResponse.getUtilizedFundBajaj()) + Double.parseDouble(marginDetailResponse.getOptBuyPrem())
                        + Double.parseDouble(marginDetailResponse.getCashMargin()) + Double.parseDouble(marginDetailResponse.getSpanExp())
                        + Double.parseDouble(marginDetailResponse.getPayOut()); */
                                    /* if (double.parse(
                                            obj.unrealizedM2M ?? "0.00") >
                                        0) { */
                                    double rightTotal = double.parse(obj.utilizedFundBajaj ?? '0.00') + double.parse(obj.optBuyPrem ?? '0.00') + double.parse(obj.cashMargin ?? '0.00') + double.parse(obj.spanExp ?? '0.00') + double.parse(obj.payOut ?? '0.00');

                                    final totalactual = leftTotal - rightTotal;
                                    total = totalactual;
                                    // }
                                  }
                                }
                              }
                              return Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 5.0),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Text(
                                          "Available Margin",
                                          style: GreekTextStyle.heading19,
                                        ),
                                        /*  */
                                        Text(
                                          total.toStringAsFixed(2),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    width: 2,
                                    height: 50,
                                    color: Colors.grey,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 5.0),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Align(
                                          alignment: Alignment.center,
                                          child: Text(
                                            "Used Margin",
                                            style: GreekTextStyle.heading19,
                                          ),
                                        ),
                                        Text(double.parse(obj?.utilizedFund ?? '0.00').toStringAsFixed(2)),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                            }),
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  InkWell(
                    onTap: () {
                      setState(() {
                        withdrawVisibility = !withdrawVisibility;
                        listVisibility = false;
                        addFundVisibility = true;
                        pressed = false;
                        pressedWithdraw = true;
                      });
                    },
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 15, 0, 0),
                        child: SizedBox(
                          height: 80,
                          width: MediaQuery.of(context).size.width / 2 - 20,
                          child: Card(
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(color: Color.fromRGBO(18, 127, 186, 1)),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: Center(
                              child: Text(
                                "Add Funds",
                                style: pressed ? GreekTextStyle.addfundpress : GreekTextStyle.addfund,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        withdrawVisibility = true;
                        listVisibility = false;
                        addFundVisibility = false;
                        pressedWithdraw = false;
                        pressed = true;
                      });
                    },
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(0, 15, 12, 0),
                        child: SizedBox(
                          height: 80,
                          width: (MediaQuery.of(context).size.width / 2) - 20,
                          child: Card(
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(color: Color.fromRGBO(255, 102, 0, 1)),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: Center(
                              child: Text(
                                "Withdraw",
                                style: pressedWithdraw ? GreekTextStyle.withdrawpress : GreekTextStyle.withdraw,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              (addFundVisibility)
                  ? _add_fund_view()
                  : (withdrawVisibility)
                      ? _withdraw_fund_view()
                      : _list_data(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _withdraw_fund_view() {
    SocketIOManager().availablePayoutRequest();
    return StreamBuilder<Map<String, dynamic>?>(
        stream: SocketIOManager().withdrawResponseObservable,
        builder: (context, snapshot) {
          WithdrawResponseModel? obj;
          if (snapshot.data != null) {
            final keys = snapshot.data!.keys.toList();
            if (keys.isNotEmpty) {
              for (var item in keys) {
                if (item.irisResponseStreamingType == IrisResponseStreamingType.AvailablePayOutResponse) {
                  final withdrawResponse = snapshot.data![item];
                  // log(withdrawResponse.toString());
                  obj = WithdrawResponseModel.fromJson(withdrawResponse);
                }
              }
            }
          }
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Text(
                      obj?.availFund ?? '000',
                      style: GreekTextStyle.headline2,
                    ),
                  ),
                  Center(
                    child: Text(
                      "Withdrawable Balance",
                      style: GreekTextStyle.headlinwwithdraw,
                    ),
                  ),
                  const Divider(
                    thickness: 1,
                  ),
                  Text(
                    "Segment",
                    style: GreekTextStyle.headline2normal,
                  ),
                  FutureBuilder<List<BankDetailsResponseModel>?>(
                    future: _fundBloc?.getBankDetailsApi(paymentGatewayType: AppFlagConstant().paymentGateway.toLowerCase()),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Container();
                      }
                      if (snapshot.data!.isNotEmpty) {
                        return DropdownButton<String>(
                          isExpanded: true,
                          value: snapshot.data?.first.data?.merchantDetails?.first.segment ?? "",
                          icon: const Icon(Icons.arrow_drop_down),
                          iconSize: 24,
                          elevation: 16,
                          style: const TextStyle(color: Colors.black, fontSize: 18),
                          underline: Container(
                            height: 0.0,
                          ),
                          onChanged: (newValue) {
                            if (newValue!.isNotEmpty) {
                              segment = newValue;
                            }

                            setState(() {});
                          },
                          items: selectedEvent?.data?.merchantDetails?.map((item) {
                            return DropdownMenuItem(
                                child: Text(
                                  item.segment ?? "",
                                  style: const TextStyle(
                                    fontSize: 13.0,
                                  ),
                                ),
                                value: item.segment.toString());
                          }).toList(),
                        );
                      }
                      return DropdownButton<String>(
                        isExpanded: true,
                        value: "",
                        icon: const Icon(Icons.arrow_drop_down),
                        iconSize: 24,
                        elevation: 16,
                        style: GreekTextStyle.headline2,
                        underline: Container(
                          height: 0.0,
                        ),
                        onChanged: (newValue) {
                          if (newValue!.isNotEmpty) {
                            segment = newValue;
                          }

                          setState(() {});
                        },
                        items: selectedEvent?.data?.merchantDetails?.map((item) {
                          return DropdownMenuItem(
                              child: Text(
                                item.segment ?? "",
                                style: const TextStyle(
                                  fontSize: 13.0,
                                ),
                              ),
                              value: item.segment.toString());
                        }).toList(),
                      );
                    },
                  ),
                  const Divider(
                    thickness: 1,
                  ),
                  Text(
                    "Amount to withdraw",
                    style: GreekTextStyle.headline2normal,
                  ),
                  TextField(
                    controller: _fundBloc?.withdrawAmountController,
                    maxLength: 6,
                    decoration: const InputDecoration(contentPadding: EdgeInsets.fromLTRB(0, 10, 0, 0), border: InputBorder.none, hintText: 'Enter Amount', counterText: ""),
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  ),
                  const Divider(
                    thickness: 1,
                  ),
                  _buildWithdrawButton(),
                ],
              ),
            ),
          );
        });
  }

  Widget _add_fund_view() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: FutureBuilder<List<BankDetailsResponseModel?>?>(
          future: _fundBloc?.getBankDetailsApi(paymentGatewayType: AppFlagConstant().paymentGateway.toLowerCase()),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data!.isNotEmpty) {
                selectedEvent = snapshot.data?.first;

                segmentstr = snapshot.data?.first?.data?.merchantDetails?.first.segment;
                prodId = snapshot.data?.first?.data?.merchantDetails?.first.prodId;
                merchantId = snapshot.data?.first?.data?.merchantDetails?.first.merchantId;
                password = snapshot.data?.first?.data?.merchantDetails?.first.password;
                reqHashKey = snapshot.data?.first?.data?.merchantDetails?.first.reqHashKey;
                resHashKey = snapshot.data?.first?.data?.merchantDetails?.first.resHashKey;
                if (segmentstr == "Commodity") {
                  segStr = "1";
                } else if (segmentstr == "NON-Commodity") {
                  segStr = "2";
                }

                for (var item in selectedEvent!.data!.bankAccountList!) {
                  if (item.bankAcNo == _fundBloc!.bankAcc) {
                    selectedBank = item.bankName ?? '';
                  }
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Amount",
                      style: GreekTextStyle.headline2normal,
                    ),
                    TextField(
                      maxLength: 6,
                      controller: _fundBloc?.textEditingController,
                      decoration: const InputDecoration(contentPadding: EdgeInsets.fromLTRB(0, 10, 0, 0), border: InputBorder.none, hintText: 'Enter Amount', counterText: ""),
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Text(
                      "Segment",
                      style: GreekTextStyle.headline2normal,
                    ),
                    DropdownButton<String>(
                      isExpanded: true,
                      value: snapshot.data?.first?.data?.merchantDetails?.first.segment ?? "",
                      icon: const Icon(Icons.arrow_drop_down),
                      iconSize: 24,
                      elevation: 16,
                      style: GreekTextStyle.headline2,
                      underline: Container(
                        height: 0.0,
                      ),
                      onChanged: (newValue) {
                        if (newValue!.isNotEmpty) {
                          segment = newValue;
                        }
                        setState(() {});
                      },
                      items: selectedEvent?.data?.merchantDetails?.map((item) {
                        return DropdownMenuItem(
                            child: Text(
                              item.segment ?? "",
                              style: GreekTextStyle.headline2,
                            ),
                            value: item.segment.toString());
                      }).toList(),
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Text(
                      "Account Details",
                      style: GreekTextStyle.headline2normal,
                    ),
                    DropdownButton<String>(
                      isExpanded: true,
                      value: _fundBloc!.bankAcc,
                      icon: const Icon(Icons.arrow_drop_down),
                      iconSize: 24,
                      elevation: 16,
                      style: GreekTextStyle.headline2,
                      underline: Container(
                        height: 0.0,
                      ),
                      onChanged: (newValue) {
                        setState(() {
                          if (newValue!.isNotEmpty) {
                            _fundBloc!.bankAcc = newValue;
                          }
                        });
                      },
                      items: selectedEvent?.data?.bankAccountList?.map((item) {
                        return DropdownMenuItem(
                            child: Text(
                              item.bankAcNo ?? "",
                              style: const TextStyle(
                                fontSize: 13.0,
                              ),
                            ),
                            value: item.bankAcNo.toString());
                      }).toList(),
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Text(
                      selectedBank.toUpperCase(),
                      style: const TextStyle(
                        letterSpacing: 0.5,
                        fontWeight: FontWeight.normal,
                        color: Colors.black54,
                        fontFamily: 'Roboto',
                        fontSize: 17,
                      ),
                    ),
                    showHideNetBankUpiSection ? const SizedBox.shrink() : const SizedBox(height: 10.0),
                    showHideNetBankUpiSection ? const SizedBox.shrink() : _builNetBankingContainer(),
                    showHideNetBankUpiSection ? const SizedBox.shrink() : const SizedBox(height: 6.0),
                    showHideNetBankUpiSection ? const SizedBox.shrink() : _buildUpiContainer(),
                    _buildPayNowButton(),
                  ],
                );
              } else {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Amount",
                      style: GreekTextStyle.headline2,
                    ),
                    TextField(
                      controller: _fundBloc?.textEditingController,
                      maxLength: 6,
                      decoration: const InputDecoration(contentPadding: EdgeInsets.fromLTRB(0, 10, 0, 0), border: InputBorder.none, hintText: 'Enter Amount', counterText: ""),
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Text(
                      "Segment",
                      style: GreekTextStyle.headline2,
                    ),
                    DropdownButton<String>(
                      isExpanded: true,
                      value: SelectedValue,
                      icon: const Icon(Icons.arrow_drop_down),
                      iconSize: 24,
                      elevation: 16,
                      style: const TextStyle(color: Colors.black, fontSize: 18),
                      underline: Container(
                        height: 0.0,
                      ),
                      onChanged: (data) {
                        SelectedValue = data!;
                        setState(() {});
                      },
                      items: DropdownValues.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(
                            value,
                          ),
                        );
                      }).toList(),
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Text(
                      "Account Details",
                      style: GreekTextStyle.headline2,
                    ),
                    DropdownButton<String>(
                      isExpanded: true,
                      value: accountSelectedValue,
                      icon: const Icon(Icons.arrow_drop_down),
                      iconSize: 24,
                      elevation: 16,
                      style: const TextStyle(color: Colors.black, fontSize: 18),
                      underline: Container(
                        height: 0.0,
                      ),
                      onChanged: (data) {
                        accountSelectedValue = data!;
                        setState(() {});
                      },
                      items: accountDropdownValues.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(
                            value,
                          ),
                        );
                      }).toList(),
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    _buildPayNowButton(),
                  ],
                );
              }
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Amount",
                  style: GreekTextStyle.headline2,
                ),
                TextField(
                  // controller: _fundBloc?.textEditingController,
                  maxLength: 6,
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    border: InputBorder.none,
                    hintText: 'Enter Amount',
                    counterText: "",
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                ),
                const Divider(
                  thickness: 1,
                ),
                Text(
                  "Segment",
                  style: GreekTextStyle.headline2,
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  value: SelectedValue,
                  icon: const Icon(Icons.arrow_drop_down),
                  iconSize: 24,
                  elevation: 16,
                  style: const TextStyle(color: Colors.black, fontSize: 18),
                  underline: Container(
                    height: 0.0,
                  ),
                  onChanged: (data) {
                    SelectedValue = data!;
                    setState(() {});
                  },
                  items: DropdownValues.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                      ),
                    );
                  }).toList(),
                ),
                const Divider(
                  thickness: 1,
                ),
                Text(
                  "Account Details",
                  style: GreekTextStyle.headline2,
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  value: accountSelectedValue,
                  icon: const Icon(Icons.arrow_drop_down),
                  iconSize: 24,
                  elevation: 16,
                  style: const TextStyle(color: Colors.black, fontSize: 18),
                  underline: Container(
                    height: 0.0,
                  ),
                  onChanged: (data) {
                    accountSelectedValue = data!;
                    setState(() {});
                  },
                  items: accountDropdownValues.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                      ),
                    );
                  }).toList(),
                ),
                const Divider(
                  thickness: 1,
                ),
                showHideNetBankUpiSection ? const SizedBox.shrink() : const SizedBox(height: 10.0),
                showHideNetBankUpiSection ? const SizedBox.shrink() : _builNetBankingContainer(),
                showHideNetBankUpiSection ? const SizedBox.shrink() : const SizedBox(height: 6.0),
                showHideNetBankUpiSection ? const SizedBox.shrink() : _buildUpiContainer(),
                _buildPayNowButton(),
              ],
            );
          },
        ),
      ),
    );
  }

  GestureDetector _buildUpiContainer() {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedColorUpi = Colors.blue;
          selectedColorNetBanking = Colors.black26;
          paymentType = PaymentType.upi;
        });
      },
      child: SizedBox(
        height: 80,
        width: double.infinity,
        child: Card(
          elevation: 1,
          shape: RoundedRectangleBorder(
            side: BorderSide(color: selectedColorUpi),
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(width: 20.0),
              Image.asset(
                'assets/images/upi.png',
                height: 20,
                // width: 100,
              ),
              const SizedBox(width: 20.0),
              SizedBox(
                width: 200.0,
                child: TextField(
                  controller: _fundBloc?.upiTextController,
                  onTap: () {
                    setState(() {
                      selectedColorUpi = Colors.blue;
                      selectedColorNetBanking = Colors.black26;
                      paymentType = PaymentType.upi;
                    });
                  },
                  focusNode: upiFocusNode,
                  maxLength: 50,
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    border: InputBorder.none,
                    hintText: 'Enter UPI',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

//ATOM
  GestureDetector _builNetBankingContainer() {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedColorNetBanking = Colors.blue;
          selectedColorUpi = Colors.black26;
          paymentType = PaymentType.netbank;
          upiFocusNode.unfocus();
        });
      },
      child: SizedBox(
        height: 80,
        width: double.infinity,
        child: Card(
          elevation: 1,
          shape: RoundedRectangleBorder(
            // side: const BorderSide(color: Colors.black26),
            side: BorderSide(color: selectedColorNetBanking),
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(width: 20.0),
              Image.asset(
                'assets/images/net_bank.png',
                height: 35,
              ),
              const SizedBox(width: 20.0),
              Text(
                "Net Banking",
                style: GreekTextStyle.headline1,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPayNowButton() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: const EdgeInsets.only(top: 50.0),
        child: Container(
          height: 50,
          width: 150,
          child: TextButton(
            onPressed: () async {
              if (paymentType == PaymentType.upi) {
                if (_fundBloc?.upiTextController.text == '') {
                  GreekDialogPopupView.messageDialog(
                    context,
                    'Please Enter UPI',
                  );
                  return;
                }
              }

              if (_fundBloc?.textEditingController.text == '') {
                GreekDialogPopupView.messageDialog(
                  context,
                  'Please Enter Amount',
                );
              } else if (double.parse(_fundBloc?.textEditingController.text ?? '') <= 50.0) {
                GreekDialogPopupView.messageDialog(
                  context,
                  'Amount should be greater than 50',
                );
              } else if (double.parse(_fundBloc?.textEditingController.text ?? '') > 500000.0) {
                GreekDialogPopupView.messageDialog(
                  context,
                  'Please enter amount less than or equal to 500000',
                );
              } else {
                if (AppFlagConstant().paymentGateway.toLowerCase() == 'atom') {
                  //ATOM Flow will go from here
                  FundDeatailsRespModel? responseData;
                  if (paymentType == PaymentType.netbank) {
                    responseData = await _fundBloc?.getFundTransferDetailsNetBanking(
                      segment: segStr,
                      amount: _fundBloc?.textEditingController.text ?? '',
                    );
                  } else if (paymentType == PaymentType.upi) {
                    String upiEntered = _fundBloc?.upiTextController.text ?? '';
                    RegExp regex = RegExp(r"[A-Za-z0-9.-]+@[A-Za-z]{2,64}");

                    if (!regex.hasMatch(upiEntered)) {
                      GreekDialogPopupView.messageDialog(
                        context,
                        'Please Enter Valid UPI',
                      );
                      return;
                    }

                    responseData = await _fundBloc?.getFundTransferDetailsUpi(
                      segment: segStr,
                      amount: _fundBloc?.textEditingController.text ?? '',
                      selectedBankName: selectedBank,
                    );
                  }

                  orderTransId = responseData?.uniqueId;
                  amount = _fundBloc?.textEditingController.text;
                  String orderState = '1';
                  //Sending Fund Transfer Request to IRIS Before Proceeding further
                  SocketIOManager().fundTransfetDetailsRequest(ourTransId: orderTransId ?? '', amount: amount ?? '', orderState: orderState, segment: segStr);

                  // Preparing ATOM Fund Transfer Details
                  var selectedBankName = '';
                  for (var item in selectedEvent!.data!.bankAccountList!) {
                    if (item.bankAcNo == _fundBloc!.bankAcc) {
                      selectedBankName = item.bankName ?? '';
                    }
                  }

                  int index = _fundBloc?.finalAtomBankNameList?.indexOf(selectedBankName.toLowerCase()) ?? 0;
                  var bankid = _fundBloc?.finalAtomBankIdList?[index];
                  bankName = selectedBankName.toUpperCase();
                  final bankList = selectedEvent!.data!.bankAccountList!;
                  for (var item in bankList) {
                    if (item.bankAcNo == _fundBloc!.bankAcc) {
                      bankName = item.bankName ?? '';
                    }
                  }

                  var userUPI = _fundBloc?.upiTextController.text;
                  var mdd = 'UP|SMSUPI|$userUPI';
                  var merchantsId = merchantId.toString();
                  var txnscamt = '0';
                  var passwords = password ?? '';
                  var txncurr = "INR";
                  var clientcode = base64.encode(utf8.encode(AppConfig().gscid));
                  var custacc = _fundBloc!.bankAcc;
                  var amt = (double.parse(amount ?? '0')).toStringAsFixed(2);
                  var txnid = orderTransId ?? '';
                  var date = DateFormat('dd/MM/yyyy HH:mm:ss').format(DateTime.now());
                  var ttype = 'NBFundTransfer';

                  var reqHashKeys = reqHashKey ?? '';
                  var resHashKeys = resHashKey ?? '';
                  var prodid = prodId; // segStr; //responseData?.productID ?? '';

                  var ru = '';
                  if (paymentType == PaymentType.netbank) {
                    ru = 'https://payment.atomtech.in/mobilesdk/param';
                  } else {
                    var isSecure = AppConfig().serverInfo.item1 ? 'https://' : 'http://';
                    var arachneIp = AppConfig().serverInfo.item2.toString();

                    ru = '$isSecure$arachneIp/getUpiTransferResponse_ios';
                  }

                  var udf1 = AppConfig().gscid;
                  var udf11 = bankid;
                  var udf12 = selectedBankName;
                  var udf13 = AppConfig().gcid;

                  final s1 = merchantsId + passwords + ttype + prodid.toString() + txnid + amt + txncurr;
                  var key = utf8.encode(reqHashKeys);
                  var bytes = utf8.encode(s1);
                  var hmacSHA512 = crypto.Hmac(crypto.sha512, key);
                  crypto.Digest signature = hmacSHA512.convert(bytes);

                  var finalUrl = '';
                  if (paymentType == PaymentType.netbank) {
                    finalUrl = "https://payment.atomtech.in/paynetz/epi/fts?login=$merchantsId&pass=$passwords&bankid=$bankid&ttype=$ttype&prodid=$prodid&amt=$amt&txncurr=$txncurr&txnscamt=$txnscamt&clientcode=$clientcode&txnid=$txnid&date=$date&custacc=$custacc&ru=$ru&signature=$signature";
                  } else {
                    finalUrl = "https://payment.atomtech.in/paynetz/epi/fts?login=$merchantsId&pass=$passwords&ttype=$ttype&prodid=$prodid&amt=$amt&txncurr=$txncurr&txnscamt=$txnscamt&clientcode=$clientcode&txnid=$txnid&date=$date&custacc=$custacc&ru=$ru&signature=$signature&udf1=$udf1&udf11=$udf11&udf12=$udf12&udf13=$udf13&mdd=$mdd";
                  }

                  //Final Call to Load the WebView ATOM Payment Gateway.
                  FinalAtomResponse finalAtomResponse = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (ctx) {
                        return AtomWebViewScreen(
                          url: finalUrl,
                          returnUrl: ru,
                          paymentType: paymentType!,
                        );
                      },
                    ),
                  );

                  if (finalAtomResponse == null) {
                    _fundBloc?.textEditingController.clear();
                    _fundBloc?.upiTextController.clear();
                    updateFTCancelResponse();
                  } else {
                    _fundBloc?.textEditingController.clear();
                    _fundBloc?.upiTextController.clear();
                    if (paymentType == PaymentType.netbank) {
                      String status = finalAtomResponse.finalResponse["f_code"];
                      // var finalFundResponse = finalAtomResponse.finalResponse;
                      var fundStatus = finalAtomResponse.transactionStatus;

                      switch (fundStatus) {
                        case TransactionStatus.success:
                        case TransactionStatus.failed:
                          sendFundDetailRequest(finalAtomResponse);
                          break;

                        default:
                      }
                    } else if (paymentType == PaymentType.upi) {
                      var transAmount = finalAtomResponse.transAmount;
                      var statusCode = finalAtomResponse.statusCode;
                      statusCode = statusCode.toLowerCase() == 'failure' ? 'Failed' : statusCode;
                      String message = "Your request for addition of Rs. $transAmount has been $statusCode";
                      GreekDialogPopupView.messageDialog(context, message);
                    }
                  }
                } else {
                  String deviceType = '';
                  if (Platform.isIOS) {
                    deviceType = 'iOS';
                  } else if (Platform.isAndroid) {
                    deviceType = 'Android';
                  }
                  final razorPayResp = await _fundBloc?.razorPayApi(_fundBloc!.bankAcc ?? "", deviceType);
                  openCheckout(razorPayResp);
                }
              }
            },
            child: const Text(
              'Pay Now',
              style: TextStyle(color: ConstantColors.white, fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
          ),
          decoration: BoxDecoration(
            color: ConstantColors.primaryColorLight,
            borderRadius: BorderRadius.circular(40.0),
            border: Border.all(
              color: ConstantColors.primaryColorLight,
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  void sendFundDetailRequest(FinalAtomResponse finalAtomResponse) {
    var amount = double.parse(finalAtomResponse.finalResponse['amt']);

    switch (finalAtomResponse.transactionStatus) {
      case TransactionStatus.success:
        orderState = '0';
        orderStateMsg = "successfully processed";
        break;

      case TransactionStatus.failed:
        orderState = "1";
        orderStateMsg = "failed";
        break;

      case TransactionStatus.userCancel:
        orderState = "2";
        orderStateMsg = "failed";
        break;
      default:
    }

    var paymentType = 'netBank';
    if (paymentType == 'netBank') {
      //Sending Fund Transfer Request to IRIS After Proceed.
      SocketIOManager().fundTransfetDetailsRequest(
        ourTransId: orderTransId ?? '',
        amount: amount.toString(),
        orderState: orderState ?? '',
        segment: segStr,
      );

      switch (finalAtomResponse.transactionStatus) {
        case TransactionStatus.success:
        case TransactionStatus.failed:
          updateFundTransferResponse(finalAtomResponse);
          break;

        case TransactionStatus.userCancel:
          break;
        default:
      }
    }
  }

  void updateFundTransferResponse(FinalAtomResponse finalAtomResponse) async {
    var response = await _fundBloc?.updateFundTransferResponseDetails(finalAtomResponse, orderTransId ?? '');
    var errorCode = response['ErrorCode'].toString();
    if (errorCode == '0') {
      String message = "Your request for addition of Rs. $amount has been $orderStateMsg";
      GreekDialogPopupView.messageDialog(context, message);
    }
  }

  void updateFTCancelResponse() async {
    var response = await _fundBloc?.updateFTCancelResponse(orderTransId ?? '');
    var errorCode = response['ErrorCode'].toString();
    if (errorCode == '0') {
      String message = "Your request for addition of Rs. $amount has been failed";
      GreekDialogPopupView.messageDialog(context, message);
    }
  }

  Widget _buildWithdrawButton() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: const EdgeInsets.only(top: 50.0),
        child: Container(
          height: 50,
          width: 150,
          child: TextButton(
            onPressed: () {
              _fundBloc?.withdrawAmountController.text == ''
                  ? GreekDialogPopupView.messageDialog(
                      context,
                      'Please Enter Amount',
                    )
                  : /* GreekDialogPopupView.messageDialog(
                      context,
                      'Withdraw Amount Submitted',
                    ); */
                  SocketIOManager().fundPayoutRequest('0', _fundBloc?.withdrawAmountController.text ?? '');
            },
            child: const Text(
              'Withdraw',
              style: TextStyle(
                color: ConstantColors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          decoration: BoxDecoration(
            color: const Color.fromRGBO(255, 102, 0, 1),
            borderRadius: BorderRadius.circular(40.0),
            border: Border.all(
              color: const Color.fromRGBO(255, 102, 0, 1),
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _list_data() {
    Future.delayed(const Duration(seconds: 1)).then((value) => timer = Timer.periodic(const Duration(seconds: 10), (Timer t) => SocketIOManager().marginDetailRequest()));

    return SizedBox(
      height: MediaQuery.of(context).size.height / 1.9,
      child: StreamBuilder<Map<String, dynamic>?>(
          stream: SocketIOManager().marginResponseObservable,
          builder: (streamContext, snapshot) {
            MarginResponseModel? obj;
            if (snapshot.data != null) {
              final keys = snapshot.data!.keys.toList();

              for (var item in keys) {
                if (item.irisResponseStreamingType == IrisResponseStreamingType.MarginDetailResponse) {
                  final marginDetailsResponse = snapshot.data![item];
                  // log(marginDetailsResponse.toString());
                  obj = MarginResponseModel.fromJson(marginDetailsResponse);
                }
              }
            }

            return ListView.builder(
              itemCount: 1,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 14.0, left: 20.0, right: 14.0, bottom: 5.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        color: ConstantColors.fundltstcontainer,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Opening Balance",
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              double.parse(obj?.availFund ?? '0.00').toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0, left: 20.0, right: 14.0, bottom: 5.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.PAYIN_MSG,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              double.parse(obj?.payIn ?? '0.00').toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0, left: 20.0, right: 14.0, bottom: 8.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        color: ConstantColors.fundltstcontainer,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.COLLETRAL,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              double.parse(obj?.collateralVal ?? '0.00').toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0, left: 20.0, right: 14.0, bottom: 8.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.USED_BALANCE,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              double.parse(obj?.utilizedFund ?? '0.00').toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0, left: 20.0, right: 14.0, bottom: 8.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        color: ConstantColors.fundltstcontainer,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.AVAILABLE_BALANCE,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              total.toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0, left: 20.0, right: 14.0, bottom: 8.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.SPAN,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(double.parse(obj?.span ?? '0.00').toStringAsFixed(2), style: GreekTextStyle.fundtextvaluestyle),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 14.0, left: 20.0, right: 14.0, bottom: 8.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        color: ConstantColors.fundltstcontainer,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.EXPOSURE,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              double.parse(obj?.expos ?? '0.00').toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 14.0, left: 20.0, right: 14.0, bottom: 8.0),
                      child: Container(
                        height: 40,
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ConstantMessages.PREMIUM,
                              style: GreekTextStyle.fundtextheadingstyle,
                            ),
                            Text(
                              double.parse(obj?.optBuyPrem ?? '0.00').toStringAsFixed(2),
                              style: GreekTextStyle.fundtextvaluestyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    /*  Padding(
                      padding: const EdgeInsets.only(
                          top: 14.0, left: 14.0, right: 14.0, bottom: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(ConstantMessages.DELIVERY_FUND_MSG),
                          Text(
                            double.parse(obj?.cashMargin ?? '0.00')
                                .toStringAsFixed(2),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 14.0, left: 14.0, right: 14.0, bottom: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            ConstantMessages.UNREALIZED_MTM,
                          ),
                          Text(
                            double.parse(obj?.unrealizedM2M ?? '0.00')
                                .toStringAsFixed(2),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 14.0, left: 14.0, right: 14.0, bottom: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            ConstantMessages.PAYOUT_MSG,
                          ),
                          Text(
                            double.parse(obj?.payOut ?? '0.00')
                                .toStringAsFixed(2),
                          ),
                        ],
                      ),
                    ), */
                    const SizedBox(
                      height: 110.0,
                    ),
                  ],
                );
              },
            );
          }),
    );
  }

  void openCheckout(List<RazorPayResModel>? razorPayResp) {
    orderId = razorPayResp?.first.arrayData?.first.respo?.id ?? '';
    var options = {
      "key": razorPayResp?.first.arrayData?.first.key,
      //"rzp_live_mQqDEihLxSD0Og",
      //"rzp_test_ouc9Om8mAiIe6Y",
      "amount": int.parse(_fundBloc?.textEditingController.text ?? '').toString() * 100,
      // Convert Paisa to Rupees
      'order_id': razorPayResp?.first.arrayData?.first.respo!.id,
      "name": razorPayResp?.first.arrayData?.first.company,
      "description": "Greeksoft Payment",
      "timeout": "180",
      'send_sms_hash': true,
      "theme.color": "#03be03",
      "currency": "INR",
      "prefill": {"contact": razorPayResp?.first.arrayData?.first.mobile, "email": razorPayResp?.first.arrayData?.first.email},
    };

    try {
      _fundBloc?.razorpay?.open(options);
    } catch (e) {
      log(e.toString());
    }
  }

/* 
  void newReq() {
    var now = DateTime.now();
    var formatter = DateFormat('yyyy-MM-dd');
    String date = formatter.format(now);
//        String login = "197";
//        String login = fundTransferDetailsResponse.getClientCode();
    String login = 'merchantId';
//        String pass = "Test@123";
//        String pass = fundTransferDetailsResponse.getPassword();
    String pass = 'passKey';
    String ttype = "NBFundTransfer";
    String prodid = '';
    // productidSpinner.getSelectedItem().toString();
    String txnid = '';
    //fundTransferDetailsResponse.getUniqueId();
    String amt = _fundBloc?.textEditingController.text.toString() ?? '';
    String txncurr = "INR";

//        String reqKey = "KEY123657234";
    String reqKey = 'reqHash';
    final String signature = getEncodedValueWithSha2(
        reqKey, login, pass, ttype, prodid, txnid, amt, txncurr);

    String xmlURL = '';
    // AccountDetails.getFt_Link()+"/epi/fts";
//        String Atom2Request = xmlURL + "?ttype=" + paymodel.getXmlttype() + "&tempTxnId=" + paymodel.getXmltempTxnId() + "&token=" + paymodel.getXmltoken() + "&txnStage=" + paymodel.getXmltxnStage();
    String Atom2Request = xmlURL +
        "?login=" +
        login +
        "&pass=" +
        pass +
        "&ttype=" +
        ttype +
        "&prodid=" +
        prodid +
        "&txnid=" +
        txnid +
        "&amt=" +
        amt +
        "&txncurr=" +
        txncurr +
        "&txnscamt=0" +
        "&clientcode=" +
        //encodeToBase64(AccountDetails.getUsername(getMainActivity())) +
        "&date=" +
        date +
        "&custacc=" +
        bankacctspinner.getSelectedItem().toString() +
        "&bankid=" +
        strBankId +
        "&signature=" +
        signature +
        "&ru=" +
        AccountDetails.getIsSecure() +
        "://" +
        AccountDetails.getArachne_IP() +
        ":" +
        AccountDetails.getArachne_Port() +
        "/getFundTransferResponse";
    Atom2Request = Atom2Request.replace(" ", "%20");
    log("ATOM 2nd Request URl", Atom2Request);
  }
 */

}
