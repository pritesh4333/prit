import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/fund_screen.dart';
import 'package:html/parser.dart';

class AtomWebViewScreen extends StatefulWidget {
  final String url;
  final String returnUrl;
  final PaymentType paymentType;

  const AtomWebViewScreen({Key? key, required this.url, required this.returnUrl, required this.paymentType}) : super(key: key);

  @override
  State<AtomWebViewScreen> createState() => _AtomWebViewScreenState();
}

class _AtomWebViewScreenState extends State<AtomWebViewScreen> {
  InAppWebViewController? _webViewController;
  String url = "";
  Map<String, dynamic>? finalAtomResponse;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    url = widget.url;
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        title: const Text(
          'ATOM',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue,
      ),
      body: InAppWebView(
        initialUrlRequest: URLRequest(
          url: Uri.parse(url),
        ),
        initialOptions: InAppWebViewGroupOptions(
          crossPlatform: InAppWebViewOptions(),
        ),
        onWebViewCreated: (InAppWebViewController controller) {
          _webViewController = controller;

          controller.addJavaScriptHandler(
            handlerName: 'handle',
            callback: (arguments) {
              // print('arguments: $arguments');
            },
          );
        },
        onLoadStart: (InAppWebViewController controller, url) {
          print('on load ursl are : $url');
        },
        onLoadStop: (InAppWebViewController controller, url) {
          // if (url.toString() == 'https://payment.atomtech.in/mobilesdk/param') {
          if (url.toString() == widget.returnUrl.toString()) {
            _webViewController!.evaluateJavascript(source: 'document.documentElement.outerHTML').then(
                  (dynamic value) => {
                    parseAtomHtmlString(value),
                  },
                );
          }
        },
      ),
    );
  }

  String _parseHtmlString(String htmlString) {
    var document = parse(htmlString);
    String parsedString = parse(document.body!.text).documentElement!.text;
    return parsedString;
  }

  void parseAtomHtmlString(dynamic html) {
    if (widget.paymentType == PaymentType.upi) {
      var document = parse(html);
      var transAmount = document.querySelector('.transAmount');
      var statusCode = document.querySelector('.statusCode');

      if (statusCode?.text.toString().toLowerCase() == 'Failure'.toLowerCase()) {
        FinalAtomResponse objResponse = FinalAtomResponse(
          transactionStatus: TransactionStatus.failed,
          finalResponse: {},
          transAmount: transAmount?.text.toString() ?? '',
          statusCode: statusCode?.text.toString() ?? '',
        );
        Navigator.pop(context, objResponse);
      } else {
        FinalAtomResponse objResponse = FinalAtomResponse(
          transactionStatus: TransactionStatus.success,
          finalResponse: {},
          transAmount: transAmount?.text.toString() ?? '',
          statusCode: statusCode?.text.toString() ?? '',
        );
        Navigator.pop(context, objResponse);
      }
    } else if (widget.paymentType == PaymentType.netbank) {
      var parseHtmlString = _parseHtmlString(html);
      const start = "<body>";
      Map<String, dynamic> keyValueMap = {};
      var ts;
      if (html.contains(start)) {
        List splitText = (parseHtmlString.split("|")).where((element) => element.isNotEmpty).toList();
        for (var element in splitText) {
          element.runtimeType;
          if (element.contains('=')) {
            keyValueMap[element.split("=")[0] ?? ""] = element.split("=")[1] ?? "";
          }
        }

        ///You'll get all key value in [keyValueMap]
        keyValueMap.removeWhere(
          (key, value) {
            final v1 = value?.toString() ?? "";
            return ((v1.isEmpty) || (v1.toLowerCase().compareTo("null") == 0));
          },
        );
        finalAtomResponse = keyValueMap;
        ts = finalAtomResponse?['f_code'];
      }
      TransactionStatus transactionStatus;
      if (ts.toLowerCase().compareTo('success_00') == 0 || ts.toLowerCase().compareTo('ok') == 0) {
        transactionStatus = TransactionStatus.success;
      } else {
        transactionStatus = TransactionStatus.failed;
      }
      FinalAtomResponse objResponse = FinalAtomResponse(
        transactionStatus: transactionStatus,
        finalResponse: finalAtomResponse!,
        transAmount: '',
        statusCode: '',
      );
      Navigator.pop(context, objResponse);
    }
  }
}

class FinalAtomResponse {
  TransactionStatus transactionStatus;
  Map<String, dynamic> finalResponse;
  String transAmount;
  String statusCode;

  FinalAtomResponse({
    required this.transactionStatus,
    required this.finalResponse,
    required this.transAmount,
    required this.statusCode,
  });
}

enum TransactionStatus {
  success,
  failed,
  userCancel,
}
