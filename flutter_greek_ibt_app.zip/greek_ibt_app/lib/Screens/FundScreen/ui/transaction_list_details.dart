import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_transaction_details_response.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:intl/intl.dart';

class TransactionListDetailsScreen extends StatelessWidget {
  double widthSpace = 60.0;
  double heightSpace = 30.0;

  FundTransactionDetailsResponse? responseObj;

  TransactionListDetailsScreen({required this.responseObj});
  var transactionMode = '';
  var transStatus = '';

  String level1ReqTime = '';
  String level1ReqTimeStatus = '';
  bool level1ReqVisibility = false;

  String level1ResTime = '';
  String level1ResTimeStatus = '';
  bool level1ResVisibility = false;

  String level2ReqTime = '';
  String level2ReqTimeStatus = '';
  bool level2ReqVisibility = false;

  String level2ResTime = '';
  String level2ResTimeStatus = '';
  bool level2ResVisibility = false;

  bool showAlways = true;

  void manageStatusFlag() {
    String statusFlag = (responseObj?.statusFlag.toString() ?? '');
    switch (int.parse(statusFlag)) {
      case 0:
        transStatus = 'Initiated';
        int tempLevel1ReqTime = responseObj?.level1ReqTime ?? 0;
        if (tempLevel1ReqTime > 0) {
          level1ReqTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ReqTime * 1000))).toString();
          level1ReqVisibility = true;
          level1ReqTimeStatus = 'Fund Transfer Initiated';
        } else {
          level1ReqVisibility = false;
        }
        break;
      case 1:
        transStatus = 'Ack Received';
        int tempLevel1ReqTime = responseObj?.level1ReqTime ?? 0;
        if (tempLevel1ReqTime > 0) {
          level1ReqTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ReqTime * 1000))).toString();
          level1ReqVisibility = true;
          level1ReqTimeStatus = 'Fund Transfer Initiated';
        } else {
          level1ReqVisibility = false;
        }

        int tempLevel1ResTime = responseObj?.level1ResTime ?? 0;
        if (tempLevel1ResTime > 0) {
          level1ResTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ResTime * 1000))).toString();
          level1ResVisibility = true;
          level1ResTimeStatus = 'Fund Transfer Ack Received';
        } else {
          level1ResVisibility = false;
        }
        break;
      case 2:
        transStatus = 'Request Sent';
        int tempLevel1ReqTime = responseObj?.level1ReqTime ?? 0;
        if (tempLevel1ReqTime > 0) {
          level1ReqTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ReqTime * 1000))).toString();
          level1ReqVisibility = true;
          level1ReqTimeStatus = 'Fund Transfer Initiated';
        } else {
          level1ReqVisibility = false;
        }

        int tempLevel1ResTime = responseObj?.level1ResTime ?? 0;
        if (tempLevel1ResTime > 0) {
          level1ResTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ResTime * 1000))).toString();
          level1ResVisibility = true;
          level1ResTimeStatus = 'Fund Transfer Ack Received';
        } else {
          level1ResVisibility = false;
        }

        int tempLevel2ReqTime = responseObj?.level1ReqTime ?? 0;

        if (tempLevel2ReqTime > 0) {
          level2ReqTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel2ReqTime * 1000))).toString();
          level2ReqVisibility = true;
          level2ReqTimeStatus = 'Fund Transfer Request Sent';
        } else {
          level2ReqVisibility = false;
        }

        break;
      case 3:
        transStatus = 'Completed';
        int tempLevel1ReqTime = responseObj?.level1ReqTime ?? 0;
        if (tempLevel1ReqTime > 0) {
          level1ReqTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ReqTime * 1000))).toString();
          level1ReqVisibility = true;
          level1ReqTimeStatus = 'Fund Transfer Initiated';
        } else {
          level1ReqVisibility = false;
        }

        int tempLevel1ResTime = responseObj?.level1ResTime ?? 0;
        if (tempLevel1ResTime > 0) {
          level1ResTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel1ResTime * 1000))).toString();
          level1ResVisibility = true;
          level1ResTimeStatus = 'Fund Transfer Ack Received';
        } else {
          level1ResVisibility = false;
        }

        int tempLevel2ReqTime = responseObj?.level2ReqTime ?? 0;
        if (tempLevel2ReqTime > 0) {
          level2ReqTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel2ReqTime * 1000))).toString();
          level2ReqVisibility = true;
          level2ReqTimeStatus = 'Fund Transfer Request Sent';
        } else {
          level2ReqVisibility = false;
        }

        int tempLevel2ResTime = responseObj?.level2ResTime ?? 0;
        if (tempLevel2ResTime > 0) {
          level2ResTime = (DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(tempLevel2ResTime * 1000))).toString();
          level2ResVisibility = true;
          level2ResTimeStatus = 'Fund Transfer Req. Executed';
        } else {
          level2ResVisibility = false;
        }
        break;
      default:
        transStatus = 'Invalid Status';
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    manageStatusFlag();
    if ((responseObj?.transactionMethod ?? '').isEmpty || responseObj?.transactionMethod == "null" || responseObj?.transactionMethod == '') {
      transactionMode = 'undefined';
    } else {
      transactionMode = responseObj?.transactionMethod ?? '';
    }
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        title: Text(
          'Transaction Detail',
          style: GreekTextStyle.headlines2,
        ),
        backgroundColor: ConstantColors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          iconSize: 30.0,
          color: ConstantColors.black,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: <Widget>[
          GestureDetector(
            onTap: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Padding(
              padding: EdgeInsets.only(right: 14.0),
              child: Icon(
                Icons.home,
                color: Colors.black45,
                size: 30,
              ),
            ),
          )
        ],
      ),
      body: Container(
        margin: const EdgeInsets.only(right: 0),
        color: Colors.white,
        padding: const EdgeInsets.fromLTRB(14, 30, 0, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DetailKey(widthSpace: widthSpace, heightSpace: heightSpace, keyText: 'Transaction Id', showWidget: showAlways),
                    DetailKey(widthSpace: widthSpace - 35, heightSpace: heightSpace, keyText: 'Bank Transaction Id', showWidget: showAlways),
                    DetailKey(widthSpace: widthSpace + 20, heightSpace: heightSpace, keyText: 'Bank ', showWidget: showAlways),
                    DetailKey(widthSpace: widthSpace + 65, heightSpace: heightSpace, keyText: 'Date', showWidget: showAlways),
                    DetailKey(widthSpace: widthSpace + 45, heightSpace: heightSpace, keyText: 'Amount', showWidget: showAlways),
                    DetailKey(widthSpace: widthSpace - 20, heightSpace: heightSpace, keyText: 'Transaction Mode', showWidget: showAlways),
                    DetailKey(widthSpace: widthSpace - 20, heightSpace: heightSpace, keyText: 'Status', showWidget: showAlways),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: responseObj?.tranId ?? '', showWidget: showAlways),
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: responseObj?.bankTranId ?? '', showWidget: showAlways),
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: responseObj?.bankName ?? '', showWidget: showAlways),
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: timeStampToDateConverterSince1970(int.parse(responseObj?.dateAndTime ?? '0')), showWidget: showAlways),
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: (responseObj?.amount ?? 0).toString(), showWidget: showAlways),
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: transactionMode, showWidget: showAlways),
                    DetailValue(widthSpace: widthSpace, heightSpace: heightSpace, keyValue: transStatus, showWidget: showAlways),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              color: Colors.grey.shade200,
              child: const Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  'Stages',
                  style: TextStyle(fontSize: 24, color: Colors.black),
                  textAlign: TextAlign.left,
                ),
              ),
            ),
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DetailKey(widthSpace: widthSpace, heightSpace: heightSpace, keyText: 'Time', showWidget: true),
                    DetailKey(widthSpace: widthSpace, heightSpace: heightSpace, keyText: level1ReqTime, showWidget: level1ReqVisibility),
                    DetailKey(widthSpace: widthSpace, heightSpace: heightSpace, keyText: level1ResTime, showWidget: level1ResVisibility),
                    DetailKey(widthSpace: widthSpace, heightSpace: heightSpace, keyText: level2ReqTime, showWidget: level2ReqVisibility),
                    DetailKey(widthSpace: widthSpace, heightSpace: heightSpace, keyText: level2ResTime, showWidget: level2ResVisibility),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DetailValue(widthSpace: 30, heightSpace: heightSpace, keyValue: 'Status', showWidget: true),
                    DetailValue(widthSpace: 30, heightSpace: heightSpace, keyValue: level1ReqTimeStatus, showWidget: level1ReqVisibility),
                    DetailValue(widthSpace: 30, heightSpace: heightSpace, keyValue: level1ResTimeStatus, showWidget: level1ResVisibility),
                    DetailValue(widthSpace: 30, heightSpace: heightSpace, keyValue: level2ReqTimeStatus, showWidget: level2ReqVisibility),
                    DetailValue(widthSpace: 30, heightSpace: heightSpace, keyValue: level2ResTimeStatus, showWidget: level2ResVisibility),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String timeStampToDateConverterSince1970(int timeStamp) {
    return DateFormat('dd MMM yyyy').format(DateTime.fromMillisecondsSinceEpoch(timeStamp * 1000));
  }
}

class DetailKey extends StatelessWidget {
  DetailKey({
    required this.widthSpace,
    required this.heightSpace,
    required this.keyText,
    required this.showWidget,
  });

  final double widthSpace;
  final double heightSpace;
  final String keyText;
  final bool showWidget;

  @override
  Widget build(BuildContext context) {
    if (!showWidget) {
      return const SizedBox.shrink();
    }
    return Row(
      children: [
        Text(
          keyText,
          style: const TextStyle(fontSize: 14.0, fontWeight: FontWeight.w400),
        ),
        SizedBox(width: widthSpace),
        SizedBox(height: heightSpace),
      ],
    );
  }
}

class DetailValue extends StatelessWidget {
  DetailValue({
    required this.widthSpace,
    required this.heightSpace,
    required this.keyValue,
    required this.showWidget,
  });

  final double widthSpace;
  final double heightSpace;
  final String keyValue;
  final bool showWidget;

  @override
  Widget build(BuildContext context) {
    if (!showWidget) {
      return const SizedBox.shrink();
    }
    return Row(
      children: [
        SizedBox(width: widthSpace - 30),
        Text(
          keyValue,
          maxLines: 2,
          style: const TextStyle(fontSize: 14.0, fontWeight: FontWeight.w400),
        ),
        SizedBox(height: heightSpace),
      ],
    );
  }
}
