class NewBankDetailsResponseModel {
  String? bankAcNo;
  String? ifscCode;
  String? password;
  String? bankName;
  String? bankBranch;
  String? mobile;
  String? acHolderName;

  NewBankDetailsResponseModel({this.bankAcNo, this.ifscCode, this.password, this.bankName, this.bankBranch, this.mobile, this.acHolderName});

  NewBankDetailsResponseModel.fromJson(Map<String, dynamic> json) {
    bankAcNo = json['bankAcNo']?.toString() ?? '';
    ifscCode = json['ifscCode']?.toString() ?? '';
    password = json['password']?.toString() ?? '';
    bankName = json['bankName']?.toString() ?? '';
    bankBranch = json['bankBranch']?.toString() ?? '';
    mobile = json['mobile']?.toString() ?? '';
    acHolderName = json['acHolderName']?.toString() ?? '';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['bankAcNo'] = bankAcNo;
    data['ifscCode'] = ifscCode;
    data['password'] = password;
    data['bankName'] = bankName;
    data['bankBranch'] = bankBranch;
    data['mobile'] = mobile;
    data['acHolderName'] = acHolderName;
    return data;
  }
}
