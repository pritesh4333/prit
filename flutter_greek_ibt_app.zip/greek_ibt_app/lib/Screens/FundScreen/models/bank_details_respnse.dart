// To parse this JSON data, do
//
//     final bankDetailsResponseModel = bankDetailsResponseModelFromJson(jsonString);

import 'dart:convert';

BankDetailsResponseModel bankDetailsResponseModelFromJson(String str) =>
    BankDetailsResponseModel.fromJson(json.decode(str));

String bankDetailsResponseModelToJson(BankDetailsResponseModel data) =>
    json.encode(data.toJson());

class BankDetailsResponseModel {
  BankDetailsResponseModel({
    this.data,
  });

  Data? data;

  factory BankDetailsResponseModel.fromJson(Map<String, dynamic> json) =>
      BankDetailsResponseModel(
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
      };
}

class Data {
  Data({
    this.bankAccountList,
    this.merchantDetails,
  });

  List<BankAccountList>? bankAccountList;
  List<MerchantDetail>? merchantDetails;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        bankAccountList: List<BankAccountList>.from(
            json["BankAccountList"].map((x) => BankAccountList.fromJson(x))),
        merchantDetails: List<MerchantDetail>.from(
            json["MerchantDetails"].map((x) => MerchantDetail.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "BankAccountList":
            List<dynamic>.from(bankAccountList!.map((x) => x.toJson())),
        "MerchantDetails":
            List<dynamic>.from(merchantDetails!.map((x) => x.toJson())),
      };
}

class BankAccountList {
  BankAccountList({
    this.bankAcNo,
    this.ifscCode,
    this.password,
    this.bankName,
    this.bankBranch,
    this.mobile,
    this.acHolderName,
  });

  String? bankAcNo;
  String? ifscCode;
  String? password;
  String? bankName;
  String? bankBranch;
  String? mobile;
  String? acHolderName;

  factory BankAccountList.fromJson(Map<String, dynamic> json) =>
      BankAccountList(
        bankAcNo: json["bankAcNo"],
        ifscCode: json["ifscCode"],
        password: json["password"],
        bankName: json["bankName"],
        bankBranch: json["bankBranch"],
        mobile: json["mobile"],
        acHolderName: json["acHolderName"],
      );

  Map<String, dynamic> toJson() => {
        "bankAcNo": bankAcNo,
        "ifscCode": ifscCode,
        "password": password,
        "bankName": bankName,
        "bankBranch": bankBranch,
        "mobile": mobile,
        "acHolderName": acHolderName,
      };
}

class MerchantDetail {
  MerchantDetail({
    this.prodId,
    this.merchantId,
    this.reqHashKey,
    this.resHashKey,
    this.password,
    this.segment,
  });

  String? prodId;
  int? merchantId;
  String? reqHashKey;
  String? resHashKey;
  String? password;
  String? segment;

  factory MerchantDetail.fromJson(Map<String, dynamic> json) => MerchantDetail(
        prodId: json["prodId"],
        merchantId: json["merchant_id"],
        reqHashKey: json["reqHashKey"],
        resHashKey: json["resHashKey"],
        password: json["password"],
        segment: json["segment"],
      );

  Map<String, dynamic> toJson() => {
        "prodId": prodId,
        "merchant_id": merchantId,
        "reqHashKey": reqHashKey,
        "resHashKey": resHashKey,
        "password": password,
        "segment": segment,
      };
}
