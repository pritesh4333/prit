class AtomBankListResponseModel {
  MMP? mMP;

  AtomBankListResponseModel({this.mMP});

  AtomBankListResponseModel.fromJson(Map<String, dynamic> json) {
    mMP = json['MMP'] != null ? MMP.fromJson(json['MMP']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (mMP != null) {
      data['MMP'] = mMP!.toJson();
    }
    return data;
  }
}

class MMP {
  MERCHANT? mERCHANT;

  MMP({this.mERCHANT});

  MMP.fromJson(Map<String, dynamic> json) {
    mERCHANT = json['MERCHANT'] != null ? MERCHANT.fromJson(json['MERCHANT']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (mERCHANT != null) {
      data['MERCHANT'] = mERCHANT!.toJson();
    }
    return data;
  }
}

class MERCHANT {
  RESPONSE? rESPONSE;

  MERCHANT({this.rESPONSE});

  MERCHANT.fromJson(Map<String, dynamic> json) {
    rESPONSE = json['RESPONSE'] != null ? RESPONSE.fromJson(json['RESPONSE']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (rESPONSE != null) {
      data['RESPONSE'] = rESPONSE!.toJson();
    }
    return data;
  }
}

class RESPONSE {
  List<Param>? param;

  RESPONSE({this.param});

  RESPONSE.fromJson(Map<String, dynamic> json) {
    if (json['param'] != null) {
      param = <Param>[];
      json['param'].forEach((v) {
        param!.add(Param.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (param != null) {
      data['param'] = param!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Param {
  String? bankid;
  String? t;

  Param({this.bankid, this.t});

  Param.fromJson(Map<String, dynamic> json) {
    bankid = json['bankid'];
    t = json['$t'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['bankid'] = bankid;
    data['$t'] = t;
    return data;
  }
}
