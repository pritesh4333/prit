class FundTransactionDetailsResponse {
  int? uniqueId;
  String? cGreekClientid;
  int? gcid;
  String? gscid;
  String? token;
  String? tempTranId;
  int? amount;
  String? tType;
  String? tranId;
  String? bankTranId;
  String? bankName;
  String? cardNumber;
  String? discriminator;
  String? dateAndTime;
  String? transStatus;
  String? transStage;
  int? statusFlag;
  int? level1ReqTime;
  int? level1ResTime;
  int? level2ReqTime;
  int? level2ResTime;
  int? lastUpdatedTime;
  String? descripn;
  String? deviceType;
  String? razorPaymentId;
  String? razorOrderId;
  String? paymentMethod;
  String? transactionMethod;
  int? isreconcile;

  FundTransactionDetailsResponse(
      {this.uniqueId,
      this.cGreekClientid,
      this.gcid,
      this.gscid,
      this.token,
      this.tempTranId,
      this.amount,
      this.tType,
      this.tranId,
      this.bankTranId,
      this.bankName,
      this.cardNumber,
      this.discriminator,
      this.dateAndTime,
      this.transStatus,
      this.transStage,
      this.statusFlag,
      this.level1ReqTime,
      this.level1ResTime,
      this.level2ReqTime,
      this.level2ResTime,
      this.lastUpdatedTime,
      this.descripn,
      this.deviceType,
      this.razorPaymentId,
      this.razorOrderId,
      this.paymentMethod,
      this.transactionMethod,
      this.isreconcile});

  FundTransactionDetailsResponse.fromJson(Map<String, dynamic> json) {
    uniqueId = json['uniqueId'];
    cGreekClientid = json['cGreekClientid'];
    gcid = json['gcid'];
    gscid = json['gscid'];
    token = json['token'];
    tempTranId = json['tempTranId'];
    amount = json['amount'];
    tType = json['tType'];
    tranId = json['tranId'];
    bankTranId = json['bankTranId'];
    bankName = json['bankName'];
    cardNumber = json['cardNumber'];
    discriminator = json['discriminator'];
    dateAndTime = json['dateAndTime'];
    transStatus = json['transStatus'];
    transStage = json['transStage'];
    statusFlag = json['statusFlag'];
    level1ReqTime = json['level1_reqTime'];
    level1ResTime = json['level1_resTime'];
    level2ReqTime = json['level2_reqTime'];
    level2ResTime = json['level2_resTime'];
    lastUpdatedTime = json['last_updated_time'];
    descripn = json['descripn'];
    deviceType = json['device_type'];
    razorPaymentId = json['razor_payment_id'];
    razorOrderId = json['razor_order_id'];
    paymentMethod = json['Payment_Method'];
    transactionMethod = json['transactionMethod'];
    isreconcile = json['Isreconcile'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uniqueId'] = uniqueId;
    data['cGreekClientid'] = cGreekClientid;
    data['gcid'] = gcid;
    data['gscid'] = gscid;
    data['token'] = token;
    data['tempTranId'] = tempTranId;
    data['amount'] = amount;
    data['tType'] = tType;
    data['tranId'] = tranId;
    data['bankTranId'] = bankTranId;
    data['bankName'] = bankName;
    data['cardNumber'] = cardNumber;
    data['discriminator'] = discriminator;
    data['dateAndTime'] = dateAndTime;
    data['transStatus'] = transStatus;
    data['transStage'] = transStage;
    data['statusFlag'] = statusFlag;
    data['level1_reqTime'] = level1ReqTime;
    data['level1_resTime'] = level1ResTime;
    data['level2_reqTime'] = level2ReqTime;
    data['level2_resTime'] = level2ResTime;
    data['last_updated_time'] = lastUpdatedTime;
    data['descripn'] = descripn;
    data['device_type'] = deviceType;
    data['razor_payment_id'] = razorPaymentId;
    data['razor_order_id'] = razorOrderId;
    data['Payment_Method'] = paymentMethod;
    data['transactionMethod'] = transactionMethod;
    data['Isreconcile'] = isreconcile;
    return data;
  }
}
