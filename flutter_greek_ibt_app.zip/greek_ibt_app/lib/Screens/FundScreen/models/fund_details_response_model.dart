class FundDeatailsRespModel {
  String? cGreekClientid;
  int? gcid;
  String? password;
  String? tType;
  String? productID;
  int? custBankAcNo;
  int? clientCode;
  int? lastUpdatedTime;
  String? uniqueId;
  String? reqHashKey;
  String? resHashKey;

  FundDeatailsRespModel({this.cGreekClientid, this.gcid, this.password, this.tType, this.productID, this.custBankAcNo, this.clientCode, this.lastUpdatedTime, this.uniqueId, this.reqHashKey, this.resHashKey});

  FundDeatailsRespModel.fromJson(Map<String, dynamic> json) {
    cGreekClientid = json['cGreekClientid'];
    gcid = json['gcid'];
    password = json['password'];
    tType = json['tType'];
    productID = json['productID'];
    custBankAcNo = json['custBankAcNo'];
    clientCode = json['clientCode'];
    lastUpdatedTime = json['last_updated_time'];
    uniqueId = json['uniqueId'];
    reqHashKey = json['reqHashKey'];
    resHashKey = json['resHashKey'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cGreekClientid'] = cGreekClientid;
    data['gcid'] = gcid;
    data['password'] = password;
    data['tType'] = tType;
    data['productID'] = productID;
    data['custBankAcNo'] = custBankAcNo;
    data['clientCode'] = clientCode;
    data['last_updated_time'] = lastUpdatedTime;
    data['uniqueId'] = uniqueId;
    data['reqHashKey'] = reqHashKey;
    data['resHashKey'] = resHashKey;
    return data;
  }
}
