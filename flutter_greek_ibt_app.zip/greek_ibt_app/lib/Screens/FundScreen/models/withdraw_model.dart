class WithdrawResponseModel {
  String? availFund;

  WithdrawResponseModel({this.availFund});

  WithdrawResponseModel.fromJson(Map<String, dynamic> json) {
    availFund = json['AvailFund'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['AvailFund'] = availFund;
    return data;
  }
}
