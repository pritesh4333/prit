class MarginResponseModel {
  String? utilizedFund;
  String? realizedM2M;
  String? unrealizedM2M;
  String? availFund;
  String? payIn;
  String? payOut;
  String? optSellCr;
  String? spanExp;
  String? optBuyPrem;
  String? cashMargin;
  String? utilizedFundBajaj;
  String? collateralVal;
  String? eqSellCredit;
  String? mtm;
  String? span;
  String? expos;

  MarginResponseModel(
      {this.utilizedFund,
      this.realizedM2M,
      this.unrealizedM2M,
      this.availFund,
      this.payIn,
      this.payOut,
      this.optSellCr,
      this.spanExp,
      this.optBuyPrem,
      this.cashMargin,
      this.utilizedFundBajaj,
      this.collateralVal,
      this.eqSellCredit,
      this.mtm,
      this.span,
      this.expos});

  MarginResponseModel.fromJson(Map<String, dynamic> json) {
    utilizedFund = json['utilizedFund'];
    realizedM2M = json['realizedM2M'];
    unrealizedM2M = json['unrealizedM2M'];
    availFund = json['availFund'];
    payIn = json['payIn'];
    payOut = json['payOut'];
    optSellCr = json['optSellCr'];
    spanExp = json['spanExp'];
    optBuyPrem = json['optBuyPrem'];
    cashMargin = json['cashMargin'];
    utilizedFundBajaj = json['utilizedFundBajaj'];
    collateralVal = json['collateralVal'];
    eqSellCredit = json['eqSellCredit'];
    mtm = json['mtm'];
    span = json['span'];
    expos = json['expos'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['utilizedFund'] = utilizedFund;
    data['realizedM2M'] = realizedM2M;
    data['unrealizedM2M'] = unrealizedM2M;
    data['availFund'] = availFund;
    data['payIn'] = payIn;
    data['payOut'] = payOut;
    data['optSellCr'] = optSellCr;
    data['spanExp'] = spanExp;
    data['optBuyPrem'] = optBuyPrem;
    data['cashMargin'] = cashMargin;
    data['utilizedFundBajaj'] = utilizedFundBajaj;
    data['collateralVal'] = collateralVal;
    data['eqSellCredit'] = eqSellCredit;
    data['mtm'] = mtm;
    data['span'] = span;
    data['expos'] = expos;
    return data;
  }
}
