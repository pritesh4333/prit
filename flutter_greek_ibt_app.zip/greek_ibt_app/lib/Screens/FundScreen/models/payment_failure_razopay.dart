class RazorPayFailureResp {
  PayStatus? payStatus;

  RazorPayFailureResp({this.payStatus});

  RazorPayFailureResp.fromJson(Map<String, dynamic> json) {
    payStatus = json['payStatus'] != null
        ? PayStatus.fromJson(json['payStatus'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (payStatus != null) {
      data['payStatus'] = payStatus!.toJson();
    }
    return data;
  }
}

class PayStatus {
  String? failed;

  PayStatus({this.failed});

  PayStatus.fromJson(Map<String, dynamic> json) {
    failed = json['failed'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['failed'] = failed;
    return data;
  }
}
