class RazorPayResModel {
  List<ArrayData>? arrayData;

  RazorPayResModel({this.arrayData});

  RazorPayResModel.fromJson(Map<String, dynamic> json) {
    if (json['arrayData'] != null) {
      arrayData = <ArrayData>[];
      json['arrayData'].forEach((v) {
        arrayData!.add(ArrayData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (arrayData != null) {
      data['arrayData'] = arrayData!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ArrayData {
  Respo? respo;
  String? key;
  String? company;
  String? callbackUrl;
  String? mobile;
  String? email;
  String? mobileImg;

  ArrayData(
      {this.respo,
      this.key,
      this.company,
      this.callbackUrl,
      this.mobile,
      this.email,
      this.mobileImg});

  ArrayData.fromJson(Map<String, dynamic> json) {
    respo = json['respo'] != null ? Respo.fromJson(json['respo']) : null;
    key = json['key'];
    company = json['company'];
    callbackUrl = json['callback_url'];
    mobile = json['mobile'];
    email = json['email'];
    mobileImg = json['MobileImg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (respo != null) {
      data['respo'] = respo!.toJson();
    }
    data['key'] = key;
    data['company'] = company;
    data['callback_url'] = callbackUrl;
    data['mobile'] = mobile;
    data['email'] = email;
    data['MobileImg'] = mobileImg;
    return data;
  }
}

class Respo {
  String? id;
  String? entity;
  int? amount;
  int? amountPaid;
  int? amountDue;
  String? currency;
  dynamic receipt;
  dynamic offerId;
  String? status;
  int? attempts;
  List<dynamic>? notes;
  int? createdAt;

  Respo(
      {this.id,
      this.entity,
      this.amount,
      this.amountPaid,
      this.amountDue,
      this.currency,
      this.receipt,
      this.offerId,
      this.status,
      this.attempts,
      this.notes,
      this.createdAt});

  Respo.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    entity = json['entity'];
    amount = json['amount'];
    amountPaid = json['amount_paid'];
    amountDue = json['amount_due'];
    currency = json['currency'];
    receipt = json['receipt'];
    offerId = json['offer_id'];
    status = json['status'];
    attempts = json['attempts'];
    if (json['notes'] != null) {
      notes = <Null>[];
      json['notes'].forEach((v) {
        // notes!.add(new Null.fromJson(v));
      });
    }
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['entity'] = entity;
    data['amount'] = amount;
    data['amount_paid'] = amountPaid;
    data['amount_due'] = amountDue;
    data['currency'] = currency;
    data['receipt'] = receipt;
    data['offer_id'] = offerId;
    data['status'] = status;
    data['attempts'] = attempts;
    if (notes != null) {
      // data['notes'] = this.notes!.map((v) => v.toJson()).toList();
    }
    data['created_at'] = createdAt;
    return data;
  }
}
