class NewMerchantDetailsResponseModel {
  String? prodId;
  String? merchantId;
  String? reqHashKey;
  String? resHashKey;
  String? password;
  String? segment;

  NewMerchantDetailsResponseModel({this.prodId, this.merchantId, this.reqHashKey, this.resHashKey, this.password, this.segment});

  NewMerchantDetailsResponseModel.fromJson(Map<String, dynamic> json) {
    prodId = json['prodId']?.toString() ?? '';
    merchantId = json['merchant_id']?.toString() ?? '';
    reqHashKey = json['reqHashKey']?.toString() ?? '';
    resHashKey = json['resHashKey']?.toString() ?? '';
    password = json['password']?.toString() ?? '';
    segment = json['segment']?.toString() ?? '';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['prodId'] = prodId;
    data['merchant_id'] = merchantId;
    data['reqHashKey'] = reqHashKey;
    data['resHashKey'] = resHashKey;
    data['password'] = password;
    data['segment'] = segment;
    return data;
  }
}
