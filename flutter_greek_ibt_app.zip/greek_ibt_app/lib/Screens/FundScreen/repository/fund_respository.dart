import 'dart:async';
import 'dart:io';

import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/bank_details_respnse.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_transaction_details_response.dart' as fundTrDetails;
import 'package:greek_ibt_app/Screens/FundScreen/models/razor_pay_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/fund_details_response_model.dart';
import 'package:greek_ibt_app/Screens/FundScreen/models/payment_failure_razopay.dart';
import 'package:greek_ibt_app/Screens/FundScreen/ui/atom_webview_screen.dart';

class FundRepository {
  Future<List<RazorPayResModel>?> getRazorpayAPI(
    String gscid,
    String clientcode,
    String amount,
    String sessionId,
    String segment,
    String accountNumber,
    String deviceType,
  ) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.razorPay,
      postBody: {"gscid": gscid, "ClientCode": clientcode, "amount": amount, "SessionId": sessionId, "segment": segment, "account_number": accountNumber, "deviceType": deviceType},
    );
    if (responseBody is List) {
      final obj = responseBody.map((e) => RazorPayResModel.fromJson(e)).toList();
      return obj;
    } else if (responseBody is Map<String, dynamic>) {
      final obj = RazorPayResModel.fromJson(responseBody);
      return [obj];
    } else if (responseBody is Map) {
      final marketResponse = (responseBody)['ArrayData'];

      if (marketResponse is List) {
        final result = marketResponse
            .map(
              (e) => RazorPayResModel.fromJson(e),
            )
            .toList();
        return result;
      }
    }

    return [];
  }

  Future<Object?> verifyRazorpayAPI(
    String paymentId,
    String orderId,
    String amount,
    String signature,
  ) async =>
      await NetworkManager().postAPIEncrypted(
        apiName: APIName.razorPayVerifySign,
        postBody: {
          'razorpay_payment_id': paymentId,
          'razorpay_order_id': orderId,
          //'clientCode': AppConfig().gcid,
          'amount': amount,
          'signature': signature,
          // 'sessionid': AppConfig().sessionID,
          'gscid': AppConfig().gscid,
        },
      );
  /*  Future<Object?> failRazorpayAPI(
    String paymentId,
    String orderId,
    String amount,
    String gscid,
  ) async =>
      await NetworkManager().postAPIEncrypted(
        apiName: APIName.razorPaymentFail,
        postBody: {
          'razorpay_payment_id': paymentId,
          'razorpay_order_id': orderId,
          'gscid': AppConfig().gscid,
          'amount': amount,
        },
      );
 */
  Future<List<RazorPayFailureResp>?> failRazorpayAPI(
    String paymentId,
    String orderId,
    String amount,
    String gscid,
  ) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.razorPaymentFail,
      postBody: {
        'razorpay_payment_id': paymentId,
        'razorpay_order_id': orderId,
        'gscid': AppConfig().gscid,
        'amount': amount,
      },
    );
    if (responseBody is List) {
      final obj = responseBody.map((e) => RazorPayFailureResp.fromJson(e)).toList();
      return obj;
    } else if (responseBody is Map<String, dynamic>) {
      final obj = RazorPayFailureResp.fromJson(responseBody);
      return [obj];
    } else if (responseBody is Map) {
      final marketResponse = (responseBody)['ArrayData'];

      if (marketResponse is List) {
        final result = marketResponse
            .map(
              (e) => RazorPayFailureResp.fromJson(e),
            )
            .toList();
        return result;
      }
    }

    return [];
  }

  Future<List<BankDetailsResponseModel>?> getBankAPI() async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getBankAccountDetailMobile,
      postBody: {
        'ClientCode': AppConfig().gcid,
        'SessionId': AppConfig().sessionID,
      },
    );
    if (responseBody is List) {
      final obj = responseBody.map((e) => BankDetailsResponseModel.fromJson(e)).toList();
      return obj;
    } else if (responseBody is Map<String, dynamic>) {
      final obj = Data.fromJson(responseBody);
      final val = BankDetailsResponseModel();
      val.data = obj;
      return [val].toList();
    }

    return [];
  }

  // fundTransferResponseDetails
  Future<dynamic> fundTransferResponseDetails(FinalAtomResponse finalAtomResponse, String orderTransId) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.fundTransferResponseDetails,
      postBody: {
        "ClientCode": AppConfig().gcid,
        "SessionId": AppConfig().sessionID,
        "UniqueId": orderTransId,
        "transId": finalAtomResponse.finalResponse['mmp_txn'],
        "bankTransId": finalAtomResponse.finalResponse['bank_txn'],
        "bankName": finalAtomResponse.finalResponse['bank_name'],
        "cardNumber": "0",
      },
    );

    return responseBody;
  }

  //FTCancelResponse
  Future<dynamic> fTCancelResponse(String orderTransId) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.FTCancelResponse,
      postBody: {
        "SessionId": AppConfig().sessionID,
        "UniqueId": orderTransId,
        "ClientCode": AppConfig().gcid,
        "discriminator": "",
      },
    );

    return responseBody;
  }

  // getATOMBankList
  Future<String> getATOMBankList({required String merchantId}) async {
    final requestQuery = "merchantId=" + merchantId;
    final jsonString = await NetworkManager().getAPINonEncryptedForATOMBankList(
      apiName: APIName.getbanklist,
      query: requestQuery,
    );

    return jsonString;
  }

  //getTransactionDetails
  Future<List<fundTrDetails.FundTransactionDetailsResponse>> getTransactionDetails() async {
    final request = 'gcid=' + AppConfig().gcid + '&gscid=' + AppConfig().gscid;
    final responseData = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getTransactionDetails,
      query: request,
    );

    if (responseData is List) {
      final obj = responseData.map((e) => fundTrDetails.FundTransactionDetailsResponse.fromJson(e)).toList();
      return obj;
    }
    return [];
  }

  //getTransactionDetailsByDate
  Future<List<fundTrDetails.FundTransactionDetailsResponse>> getTransactionDetailsByDate({required String startDate, required String endDate}) async {
    final request = 'gcid=' + AppConfig().gcid + '&gscid=' + AppConfig().gscid + '&endDate=' + endDate + '&startDate=' + startDate;
    final responseData = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getTransactionDetailsByDate,
      query: request,
    );

    if (responseData is List) {
      final obj = responseData.map((e) => fundTrDetails.FundTransactionDetailsResponse.fromJson(e)).toList();
      return obj;
    }
    return [];
  }

  // ATOM Net Banking
  Future<FundDeatailsRespModel> getFundTransferDetails(String segment, String amount) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.fundTransferDetails,
      postBody: {
        'gscid': AppConfig().gscid,
        'ClientCode': AppConfig().gcid,
        'amount': amount,
        'SessionId': AppConfig().sessionID,
        'segment': segment,
      },
    );
    if (responseBody is Map<String, dynamic>) {
      final obj = FundDeatailsRespModel.fromJson(responseBody);
      return obj;
    }
    return FundDeatailsRespModel();
  }

  //ATOM UPI
  Future<FundDeatailsRespModel> getFundTransferDetailsUpi(String segment, String amount, String selectedBankName) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.fundTransferDetailsUpi,
      postBody: {
        'gscid': AppConfig().gscid,
        'ClientCode': AppConfig().gcid,
        'amount': amount,
        'SessionId': AppConfig().sessionID,
        'segment': segment,
        "bankName": selectedBankName,
        "transactionMethod": "UPI",
        "deviceType": Platform.isIOS ? "iOS" : "android",
        "descripn": "Initiated",
      },
    );
    if (responseBody is Map<String, dynamic>) {
      final obj = FundDeatailsRespModel.fromJson(responseBody);
      return obj;
    }
    return FundDeatailsRespModel();
  }

  Future<List<FundDeatailsRespModel>?> getFundResponseDetails() async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.fundTransferResponseDetails,
      postBody: {
        'ClientCode': AppConfig().gcid,
        'SessionId': AppConfig().sessionID,
        'bankTransId': "NA",
        'cardNumber': '0',
        'bankName': '',
        'UniqueId': '',
      },
    );
    if (responseBody is List) {
      final obj = responseBody.map((e) => FundDeatailsRespModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }
}
