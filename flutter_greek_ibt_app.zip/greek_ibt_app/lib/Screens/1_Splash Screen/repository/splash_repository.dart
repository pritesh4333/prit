import 'package:greek_ibt_app/Screens/2_LandingPage/models/contract_model.dart';
import 'package:greek_ibt_app/sqlite/datahelper.dart';

import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class SplashRepository {
  Future<Object?> getFlagvalueAPI() async {
    final response = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getFlagValues,
      postBody: {},
    );

    return response;
  }

  Future<Object?> getContractDetailsAPi() async {
    final contractResponse = await NetworkManager().getAPIEncrypted(
        apiName: APIName.get_all_contracts_table_data, query: '');
    if (contractResponse is List) {
      final obj =
          contractResponse.map((e) => ContractDataModel.fromJson(e)).toList();

      final _ = await DBHelper.insertContractTableData(obj);
    }
    return contractResponse;
  }
}
