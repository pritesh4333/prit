import 'dart:async';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/splash_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';
import 'package:greek_ibt_app/Utilities/required_function.dart';
import 'package:intl/intl.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  SplashBloc? _splashBlock;
  Future<SearchSymbolSqliteModel>? contractFuture;
  AnimationController? controller;

  bool? isLoading = false;
  double width = 0.0;
  double height = 0.0;
  double spaceConstant = 0.0;
  double leftRightSpacing = 0.0;
  double topBottomSpacing = 0.0;

  double percent = 0.0;
  String? otpDate;
  String currentDate = "";
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // TODO: implement didChangeAppLifecycleState
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.resumed:
        getDeviceID();
        break;
      case AppLifecycleState.inactive:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.paused:
        // TODO: Handle this case.
        break;
      case AppLifecycleState.detached:
        // TODO: Handle this case.
        break;
    }
  }

  @override
  void dispose() {
    _splashBlock?.disposeBloc();
    _splashBlock = null;

    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    getDeviceID();
  }

  void getDeviceID() async {
    var deviceID = await RequiredFunction().getID();

    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        _splashBlock!.percentage.sink.add(20);
        _splashBlock?.callContractDetailsAPIS();
        _splashBlock?.callSplashAPIS(deviceId: deviceID ?? '');
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    _splashBlock ??= SplashBloc(context);
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    spaceConstant = 10.3;
    leftRightSpacing = (width * (spaceConstant / 100));
    topBottomSpacing = 50.0;
    setState(() {
      isLoading = true;
    });

    return Scaffold(
      appBar: null,
      body: FutureBuilder(
        future: contractFuture,
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              {
                return SizedBox(
                  height: MediaQuery.of(context).size.height / 1.5,
                  child: Image.asset(
                    'assets/images/flutter_logo.png',
                    fit: BoxFit.fitWidth,
                  ),
                );
              }
            case ConnectionState.active:
              {
                break;
              }
            case ConnectionState.done:
              {
                if (snapshot.hasData) {
                  return Container();
                }
                break;
              }
            case ConnectionState.none:
              {
                break;
              }
          }
          return Padding(
            padding: EdgeInsets.only(
                left: leftRightSpacing + 10,
                right: leftRightSpacing + 10,
                bottom: topBottomSpacing - 20),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height / 1.5,
                    child: Image.asset(
                      'assets/images/flutter_logo.png',
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                  StreamBuilder<int>(
                    stream: _splashBlock!.percentage.stream,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return CircularPercentIndicator(
                          radius: 50.0,
                          lineWidth: 3.0,
                          percent: snapshot.data! / 100,
                          center: Text(
                            snapshot.data!.toString() + "%",
                            style: const TextStyle(
                                fontSize: 12.0,
                                fontWeight: FontWeight.w600,
                                color: Colors.orange),
                          ),
                          backgroundColor: Colors.grey[300]!,
                          circularStrokeCap: CircularStrokeCap.round,
                          progressColor: ConstantColors.primaryColorVitt,
                        );
                      }
                      return Container();
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
