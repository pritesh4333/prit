class GetFlagResponseModel {
  String? validateTransaction;
  String? defaultProduct;
  String? validate2FA;
  String? holdingFlag;
  String? validateGuest;
  String? validateThrough;
  String? showLogin;
  int? heartbeatIntervals;
  int? reconnectionAttempts;
  String? validatePasswordOnce;
  String? ftTestingBypass;
  bool? isSecure;
  String? arachneIP;
  String? apolloIP;
  String? irisIP;
  int? arachnePort;
  int? orderSenderPort;
  int? broadcastSenderPort;
  int? irisPort;
  int? apolloPort;
  int? socketPort;
  String? chartSetting;
  String? isStrategyProduct;
  String? isEDISProduct;
  String? isRedisEnabled;
  String? aprVersion;
  String? isBOReport;
  String? dPType;
  String? showDescription;
  String? paymentGateway;
  String? upiPaymentEnabled;
  String? ftLink;
  String? ftLinkUpi;
  String? pledgeOffline;
  String? isPledgeProduct;
  String? sslUrl;
  String? showTradeAlert;
  String? scripCountInWatchlist;
  String? eKycSignUpUrl;
  String? eKycSignUpPort;
  String? loginCompliance;

  GetFlagResponseModel(
      {this.validateTransaction,
      this.defaultProduct,
      this.validate2FA,
      this.holdingFlag,
      this.validateGuest,
      this.validateThrough,
      this.showLogin,
      this.heartbeatIntervals,
      this.reconnectionAttempts,
      this.validatePasswordOnce,
      this.ftTestingBypass,
      this.isSecure,
      this.arachneIP,
      this.apolloIP,
      this.irisIP,
      this.arachnePort,
      this.orderSenderPort,
      this.broadcastSenderPort,
      this.irisPort,
      this.apolloPort,
      this.chartSetting,
      this.isStrategyProduct,
      this.isEDISProduct,
      this.isRedisEnabled,
      this.aprVersion,
      this.isBOReport,
      this.dPType,
      this.showDescription,
      this.paymentGateway,
      this.upiPaymentEnabled,
      this.ftLink,
      this.ftLinkUpi,
      this.pledgeOffline,
      this.sslUrl,
      this.showTradeAlert,
      this.scripCountInWatchlist,
      this.eKycSignUpUrl,
      this.eKycSignUpPort,
      this.loginCompliance});

  GetFlagResponseModel.fromJson(Map<String, dynamic> json) {
    validateTransaction = json['validateTransaction'].toString();
    defaultProduct = json['defaultProduct'].toString();
    validate2FA = json['validate2FA'].toString();
    holdingFlag = json['holdingFlag'].toString();
    validateGuest = json['validateGuest'].toString();
    validateThrough = json['validateThrough'].toString();
    showLogin = json['showLogin'].toString();
    heartbeatIntervals = int.parse(json['heartbeat_Intervals'].toString());
    reconnectionAttempts = int.parse(json['reconnection_attempts'].toString());
    validatePasswordOnce = json['validatePasswordOnce'].toString();
    ftTestingBypass = json['ft_testing_bypass'].toString();
    isSecure = (json['isSecure'] != null)
        ? (json['isSecure'].toString().toLowerCase().compareTo('true') == 0)
        : false;
    arachneIP = json['Arachne_IP'].toString();
    apolloIP = json['Apollo_IP'].toString();
    irisIP = json['Iris_IP'].toString();
    arachnePort = int.parse(json['Arachne_Port'].toString());
    orderSenderPort = int.parse(json['OrderSender_Port'].toString());
    broadcastSenderPort = int.parse(json['BroadcastSender_Port'].toString());
    irisPort = int.parse(json['Iris_Port'].toString());
    apolloPort = int.parse(json['Apollo_Port'].toString());
    socketPort = int.parse(json['Socket_IO_Port']?.toString() ?? '4000');
    chartSetting = json['ChartSetting'].toString();
    isStrategyProduct = json['IsStrategyProduct'].toString();
    isEDISProduct = json['IsEDISProduct'].toString();
    isRedisEnabled = json['IsRedisEnabled'].toString();
    aprVersion = json['apr_version'].toString();
    isBOReport = json['IsBOReport'].toString();
    dPType = json['DPType'].toString();
    showDescription = json['showDescription'].toString();
    paymentGateway = json['PaymentGateway'].toString();
    upiPaymentEnabled = json['upiPaymentEnabled'].toString();
    ftLink = json['ft_Link'].toString();
    ftLinkUpi = json['ft_Link_Upi'].toString();
    pledgeOffline = json['PledgeOffline'].toString();
    isPledgeProduct = json['IsPledgeProduct'].toString();
    sslUrl = json['ssl_url'].toString();
    showTradeAlert = json['showTradeAlert'].toString();
    scripCountInWatchlist = json['scripCountInWatchlist'].toString();
    eKycSignUpUrl = json['eKycSignUpUrl'].toString();
    eKycSignUpPort = json['eKycSignUpPort'].toString();
    loginCompliance = json['login_compliance'].toString();
  }

  get clientCode => null;

  get sessionID => null;
}
