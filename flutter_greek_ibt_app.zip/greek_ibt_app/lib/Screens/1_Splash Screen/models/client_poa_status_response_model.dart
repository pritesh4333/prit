class ClientPOAStatusResponseModel {
  String? defaultPOA;
  String? dPId;

  ClientPOAStatusResponseModel({this.defaultPOA, this.dPId});

  ClientPOAStatusResponseModel.fromJson(Map<String, dynamic> json) {
    defaultPOA = json['DefaultPOA'];
    dPId = json['DPId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['DefaultPOA'] = defaultPOA;
    data['DPId'] = dPId;
    return data;
  }
}
