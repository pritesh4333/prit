import 'dart:io';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Profile/bloc/profile_bloc.dart';
import 'package:greek_ibt_app/Screens/Profile/model/profile_data_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/profile_avatar_widget.dart';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final titleTextStyle = const TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.w600,
    fontSize: 15,
    fontFamily: 'Roboto Medium',
  );

  final dataTextStyle = const TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.normal,
    fontSize: 14,
    fontFamily: 'Roboto Medium',
  );

  final dataKeyTextStyle = const TextStyle(
    color: Color(0xFF686868),
    fontWeight: FontWeight.normal,
    fontSize: 14,
    fontFamily: 'Roboto Medium',
  );

  final topMarginSpace = 19.0;
  final spaceSection = 30.0;

  ProfileBloc? _profileBloc;
  ProfileDataResponseModel? _responseObj;
  String dpID = 'N/A';

  File? imageFile;

  @override
  void initState() {
    _profileBloc ??= ProfileBloc();
    _responseObj = ProfileDataResponseModel();

    getClientDpID();
    super.initState();
  }

  void getClientDpID() async {
    dpID = await _profileBloc?.getClientDpID() ?? 'N/A';
    dpID = dpID == '' ? 'N/A' : dpID;
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      initialIndex: 0,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            elevation: 1,
            backgroundColor: ConstantColors.white,
            leading: IconButton(
              onPressed: () {
                GreekBase().drawerKey.currentState?.openDrawer();
              },
              icon: const Icon(Icons.menu_rounded),
              iconSize: 30.0,
              color: ConstantColors.black,
            ),
            title: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Profile',
                style: GreekTextStyle.headline2,
              ),
            ),
          ),
          body: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: FutureBuilder<List<ProfileDataResponseModel>>(
              future: _profileBloc?.getProfileDetailsForBajaj(),
              builder: (context, snapshot) {
                if (snapshot.hasData == false) {
                  return const SizedBox.shrink();
                }
                int length = snapshot.data?.length ?? 0;
                if (length > 0) {
                  var respObj = snapshot.data?[0];
                  _responseObj = respObj;
                }

                return Column(
                  children: [
                    _buildProfileBannerWidget(),
                    _buildPersonalDetailsWidget(),
                    SizedBox(height: spaceSection),
                    _buildBankDetailsWidget(),
                    SizedBox(height: spaceSection),
                    _buildAccoundDetailsWidget(),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Container _buildAccoundDetailsWidget() {
    final allowedProducts = _responseObj?.allowedProduct ?? 'N/A';
    final allowedSegments = _responseObj?.cmktallowed ?? 'N/A';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Column(
        children: [
          Row(
            children: [
              Text('Account Details', style: titleTextStyle),
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Demat', style: dataKeyTextStyle),
                Text(dpID, style: dataTextStyle),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Products', style: dataKeyTextStyle),
                Expanded(
                  child: Text(allowedProducts, style: dataTextStyle, maxLines: 3, textAlign: TextAlign.end),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Segment', style: dataKeyTextStyle),
                const SizedBox(width: 50),
                Expanded(
                  child: Text(allowedSegments, style: dataTextStyle, maxLines: 2, textAlign: TextAlign.end),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Container _buildBankDetailsWidget() {
    final bankName = _responseObj?.bankname ?? 'N/A';
    final accountNo = _responseObj?.bankacno ?? 'N/A';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Column(
        children: [
          Row(
            children: [
              Text('Bank Details', style: titleTextStyle),
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Bank Name', style: dataKeyTextStyle),
                Text(bankName, style: dataTextStyle),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Account Number', style: dataKeyTextStyle),
                Text(accountNo, style: dataTextStyle),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Container _buildPersonalDetailsWidget() {
    final mobileNo = _responseObj?.lmobileno ?? 'N/A';
    final emailId = _responseObj?.cemailid ?? 'N/A';
    final panNo = _responseObj?.cpanno ?? 'N/A';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Column(
        children: [
          Row(
            children: [
              Text('Personal Details', style: titleTextStyle),
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Mobile Number', style: dataKeyTextStyle),
                Text(mobileNo, style: dataTextStyle),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Email ID', style: dataKeyTextStyle),
                Expanded(
                  child: Text(emailId, style: dataTextStyle, textAlign: TextAlign.end),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: topMarginSpace),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('PAN Number', style: dataKeyTextStyle),
                Text(panNo, style: dataTextStyle),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _getFromGallery() async {
    XFile? pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      imageFile = File(pickedFile.path);
      print('got the image');
    }
  }

  Widget _buildProfileBannerWidget() {
    final gscid = AppConfig().gscid;
    final clientCode = AppConfig().clientName;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xFF127FBA),
        ),
        child: Row(
          children: [
            const SizedBox(width: 10),
            InkWell(
              onTap: () {
                //TODO : [Yet to fetch image from Gallery or Camera to upload]
                print('Updload profile image');
                // _getFromGallery();
              },
              child: SizedBox(
                height: 70,
                width: 70,
                child: ProfileAvatar(imageFile),
              ),
            ),
            const SizedBox(width: 30),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    clientCode,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      fontFamily: 'Roboto Medium',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    gscid,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      fontFamily: 'Roboto Medium',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

}
