import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/Alerts/model/alert_response_data_model.dart';
import 'package:greek_ibt_app/Screens/Alerts/model/quote_for_single_symbol_v2_response_model.dart';
import 'package:greek_ibt_app/Screens/Alerts/ui/stock_alert_screen.dart';
import 'package:greek_ibt_app/Screens/Notification/model/recomm_response_model.dart';
import 'package:greek_ibt_app/Screens/Profile/model/profile_data_response_model.dart';

class ProfileRepository {
  Future<List<ProfileDataResponseModel>> getProfileDetailsBajaj() async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getProfileDetails_Bajaj,
      postBody: {
        'clientCode': AppConfig().gcid,
        'gscid': AppConfig().gscid,
      },
    );
    if (responseBody is List) {
      final obj = responseBody.map((e) => ProfileDataResponseModel.fromJson(e)).toList();
      return obj;
    }

    return [];
  }

  //Fetch Recommendations
  Future<RecommendationResponseData> getRecommendations() async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getRecommendations,
      postBody: {
        'gscid': AppConfig().gscid,
      },
    );

    if (responseBody is Map<String, dynamic>) {
      final obj = RecommendationResponseData.fromJson(responseBody);
      return obj;
    }
    return RecommendationResponseData();
  }

  //Fetch Notifications
  Future<RecommendationResponseData> getNotifications() async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getNotifications,
      postBody: {
        'gscid': AppConfig().gscid,
      },
    );

    if (responseBody is Map<String, dynamic>) {
      final obj = RecommendationResponseData.fromJson(responseBody);
      return obj;
    }
    return RecommendationResponseData();
  }

  //Fetch alerts
  Future<AlertResponseDataModel> fetchAlerts() async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.show_alerts,
      postBody: {
        'gcid': AppConfig().gcid,
      },
    );

    if (responseBody is Map<String, dynamic>) {
      final obj = AlertResponseDataModel.fromJson(responseBody);
      return obj;
    }
    return AlertResponseDataModel();
  }

  // 'getQuoteForSingleSymbol_V2'
  Future<QuoteForSingleSymbolV2ResponseModel?> getQuoteForSingleSymbolV2(String token, String assetType) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getQuoteForSingleSymbol_V2,
      postBody: {
        'gcid': AppConfig().gcid,
        'gscid': AppConfig().gscid,
        'token': token,
        'assetType': assetType,
      },
    );

    if (responseBody is Map<String, dynamic>) {
      final responseObj = QuoteForSingleSymbolV2ResponseModel.fromJson(responseBody);
      return responseObj;
    }
    return QuoteForSingleSymbolV2ResponseModel();
  }

  // 'add_alerts'
  Future<Map<String, dynamic>> addAlerts(AddAlertModelClass addAlertModelClass) async {
    final responseBody = await NetworkManager().postAPIEncrypted(
      apiName: APIName.add_alerts,
      postBody: {
        "symbol": addAlertModelClass.symbol ?? '',
        "assetType": addAlertModelClass.assetType ?? '',
        "gcid": AppConfig().gcid,
        "exchange": addAlertModelClass.exchange ?? '',
        "gscid": AppConfig().gscid,
        "alertType": addAlertModelClass.alertType ?? '',
        "token": addAlertModelClass.token ?? '',
        "direction": addAlertModelClass.direction ?? '',
        "range": addAlertModelClass.range ?? '',
      },
    );

    if (responseBody is Map<String, dynamic>) {
      return responseBody;
    }
    return {};
  }

//Fetching Client DP ID
  Future<dynamic> getclientDpId() async {
    final gscid = 'gscid=' + AppConfig().gscid;
    final response = await NetworkManager().getAPIEncrypted(
      apiName: APIName.getClientDpId,
      query: gscid,
    );
    return response;
  }
}
