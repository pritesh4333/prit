import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Alerts/model/alert_response_data_model.dart';
import 'package:greek_ibt_app/Screens/Alerts/model/quote_for_single_symbol_v2_response_model.dart';
import 'package:greek_ibt_app/Screens/Alerts/ui/stock_alert_screen.dart';
import 'package:greek_ibt_app/Screens/Notification/model/recomm_response_model.dart';
import 'package:greek_ibt_app/Screens/Profile/Repository/profile_repository.dart';
import 'package:greek_ibt_app/Screens/Profile/model/profile_data_response_model.dart';
import 'package:rxdart/subjects.dart';

class ProfileBloc extends GreekBlocs {
  final _repository = ProfileRepository();
  BehaviorSubject<String> recommCount = BehaviorSubject<String>.seeded('0');
  BehaviorSubject<String> notificationCount = BehaviorSubject<String>.seeded('0');

  String _subscribeToken = '';
  String _unsubscribeToken = '';
  final MarketPictureModelClass _marketPictureModelClass = MarketPictureModelClass();
  final BehaviorSubject<MarketPictureModelClass?>? marketPictureSubject = BehaviorSubject<MarketPictureModelClass?>.seeded(null);

  ProfileBloc() {
    registerMarketPictureListner();
  }

  @override
  void disposeBloc() {
    recommCount.close();
    notificationCount.close();
    marketPictureSubject?.close();
    unSubscribeMarketPicture();
  }

  void registerMarketPictureListner() {
    SocketIOManager().brodcastResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();
          for (var item in keys) {
            if (item.apolloResponseStreamingType == ApolloResponseStreamingType.marketPicture) {
              final responseDic = event[item];
              if (responseDic is Map<String, dynamic>) {
                final token = int.parse('${responseDic['symbol']}');
                if (_subscribeToken.toUpperCase().compareTo(token.toString().toUpperCase()) == 0) {
                  final symbol = '${responseDic['symbol']}';
                  final ltp = '${responseDic['ltp']}';
                  final change = '${responseDic['change']}';
                  final pChange = '${responseDic['p_change']}';
                  final totVol = '${responseDic['tot_vol']}';

                  _marketPictureModelClass.symbol = symbol;
                  _marketPictureModelClass.ltp = ltp;
                  _marketPictureModelClass.change = change;
                  _marketPictureModelClass.pChange = pChange;
                  _marketPictureModelClass.totalVolume = totVol;
                  marketPictureSubject?.sink.add(_marketPictureModelClass);
                  break;
                }
              }
            }
          }
        }
      },
    );
  }

  void subscribeForMarketPicture(String token) {
    _subscribeToken = token;
    if (_unsubscribeToken.isNotEmpty) {
      SocketIOManager().unSubscribeMarketPictureTokens([_unsubscribeToken]);
    }

    if (_subscribeToken.isNotEmpty) {
      SocketIOManager().subscribeMarketPictureTokens([token]);
      _unsubscribeToken = _subscribeToken;
    }
  }

  void unSubscribeMarketPicture() {
    if (_unsubscribeToken.isNotEmpty) {
      SocketIOManager().unSubscribeMarketPictureTokens([_unsubscribeToken]);
    }
  }

  //fundTransferDetails For NetBanking ATOM
  Future<List<ProfileDataResponseModel>> getProfileDetailsForBajaj() async {
    final response = await _repository.getProfileDetailsBajaj();
    return response;
  }

  //Fetch Client DpID
  Future<String> getClientDpID() async {
    final responseData = await _repository.getclientDpId();
    if (responseData is List) {
      String dpID = responseData[0]['DPID'];
      return dpID;
    }
    return 'N/A';
  }

  //getRecommendations
  Future<List<RecommendationData>?> getRecommendations() async {
    final response = await _repository.getRecommendations();
    if (response.errorCode == 0) {
      if (response.data is List) {
        return response.data;
      }
    }
    return [];
  }

  //getNotifications
  Future<List<RecommendationData>?> getNotification() async {
    final response = await _repository.getNotifications();
    if (response.errorCode == 0) {
      if (response.data is List) {
        return response.data;
      }
    }
    return [];
  }

  //showAlerts
  Future<List<AlertResponseData>?> fetchAlerts() async {
    final response = await _repository.fetchAlerts();
    if (response.data is List) {
      return response.data;
    }
    return [];
  }

  // 'getQuoteForSingleSymbol_V2'
  Future<QuoteForSingleSymbolV2ResponseModel?> getQuoteForSingleSymbolV2(String token, String assetType) async {
    final responseObj = await _repository.getQuoteForSingleSymbolV2(token, assetType);
    return responseObj;
  }

// 'add_alerts'
  Future<Map<String, dynamic>> addAlerts(AddAlertModelClass addAlertModelClass) async {
    final responseBody = await _repository.addAlerts(addAlertModelClass);
    return responseBody;
  }
}

class MarketPictureModelClass {
  String? symbol;
  String? ltp;
  String? change;
  String? pChange;
  String? totalVolume;
}
