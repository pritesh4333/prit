class ProfileDataResponseModel {
  String? lmobileno;
  String? cemailid;
  String? cpanno;
  String? cmktallowed;
  String? bankacno;
  String? bankname;
  int? bisMF;
  String? allowedProduct;

  ProfileDataResponseModel({this.lmobileno, this.cemailid, this.cpanno, this.cmktallowed, this.bankacno, this.bankname, this.bisMF, this.allowedProduct});

  ProfileDataResponseModel.fromJson(Map<String, dynamic> json) {
    lmobileno = json['lmobileno'];
    cemailid = json['cemailid'];
    cpanno = json['cpanno'];
    cmktallowed = json['cmktallowed'];
    bankacno = json['bankacno'];
    bankname = json['bankname'];
    bisMF = json['bisMF'];
    allowedProduct = json['AllowedProduct'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lmobileno'] = lmobileno;
    data['cemailid'] = cemailid;
    data['cpanno'] = cpanno;
    data['cmktallowed'] = cmktallowed;
    data['bankacno'] = bankacno;
    data['bankname'] = bankname;
    data['bisMF'] = bisMF;
    data['AllowedProduct'] = allowedProduct;
    return data;
  }
}
