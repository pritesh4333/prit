import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Profile/bloc/profile_bloc.dart';
import 'package:intl/intl.dart';

class RecommendationResponseData extends ChangeNotifier {
  List<RecommendationData>? data;
  int? errorCode;
  int? recommCount = 0;
  int count = 0;

  RecommendationResponseData({this.data, this.errorCode});

  RecommendationResponseData.fromJson(Map<String, dynamic> json) {
    if (json['Data'] != null) {
      data = <RecommendationData>[];
      json['Data'].forEach((v) {
        data!.add(RecommendationData.fromJson(v));
      });
    }

    errorCode = json['ErrorCode'];
    updateCount(data!.length);
  }

  void updateCount(int newCount) {
    count = newCount;
    // notifyListeners();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['ErrorCode'] = errorCode;
    return data;
  }
}

class RecommendationData {
  int? lLogTime;
  String? cSenderId;
  String? cRecieverId;
  String? cMessage;
  int? iMsgType;
  int? bSendStatus;
  int? iSendingChannel;
  String? convertedLogTime;

  RecommendationData({
    this.lLogTime,
    this.cSenderId,
    this.cRecieverId,
    this.cMessage,
    this.iMsgType,
    this.bSendStatus,
    this.iSendingChannel,
    this.convertedLogTime,
  });

  RecommendationData.fromJson(Map<String, dynamic> json) {
    lLogTime = json['lLogTime'];
    cSenderId = json['cSenderId'];
    cRecieverId = json['cRecieverId'];
    cMessage = json['cMessage'];
    iMsgType = json['iMsgType'];
    bSendStatus = json['bSendStatus'];
    iSendingChannel = json['iSendingChannel'];

    convertedLogTime = timeStampToDateConverterSince1970(lLogTime ?? 0);
    print(convertedLogTime);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lLogTime'] = lLogTime;
    data['cSenderId'] = cSenderId;
    data['cRecieverId'] = cRecieverId;
    data['cMessage'] = cMessage;
    data['iMsgType'] = iMsgType;
    data['bSendStatus'] = bSendStatus;
    data['iSendingChannel'] = iSendingChannel;
    return data;
  }

  String timeStampToDateConverterSince1970(int timeStamp) {
    return DateFormat('dd MMM yyyy HH:mm:ss').format(DateTime.fromMillisecondsSinceEpoch(timeStamp * 1000));
  }
}
