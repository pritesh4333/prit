import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Notification/model/recomm_response_model.dart';
import 'package:greek_ibt_app/Screens/Profile/bloc/profile_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/no_data_with_progress_indicator.dart';

class NotificationRecommendationScreen extends StatefulWidget {
  NotificationRecommendationScreen({Key? key}) : super(key: key);

  @override
  State<NotificationRecommendationScreen> createState() => _NotificationRecommendationScreenState();
  int currentIndex = 0;
}

class _NotificationRecommendationScreenState extends State<NotificationRecommendationScreen> {
  //Text Style
  final titleTextStyle = const TextStyle(
    fontWeight: FontWeight.normal,
    fontSize: 15,
    letterSpacing: 0.5,
    fontFamily: 'Roboto',
  );

  ProfileBloc? _profileBloc;

  @override
  void initState() {
    _profileBloc = ProfileBloc();
    super.initState();
    AppFlagConstant().currentScreen = 'notification';
    receiveAdminMessage();
  }

  void receiveAdminMessage() {
    SocketIOManager().adminMessageResponseObservable?.listen((irisEvent) {
      if (irisEvent != null) {
        final keys = irisEvent.keys.toList();
        for (var item in keys) {
          switch (item.irisResponseStreamingType) {
            case IrisResponseStreamingType.AdminMessages:
              String message = irisEvent[item]['Message'];
              String decodedMessage = utf8.decode(base64.decode(message));

              //show alert
              final snackBar = SnackBar(
                backgroundColor: Colors.grey.shade400,
                elevation: 2,
                duration: const Duration(
                  seconds: 1,
                ),
                content: Text(
                  decodedMessage,
                  style: const TextStyle(color: Colors.black),
                ),
                action: SnackBarAction(
                    label: 'OK',
                    textColor: Colors.black,
                    onPressed: () {
                      setState(() {});
                    }),
              );
              setState(() {});

              ScaffoldMessenger.of(context).removeCurrentSnackBar();
              ScaffoldMessenger.of(context).showSnackBar(snackBar);
              break;

            default:
              break;
          }
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            onPressed: () {
              GreekBase().drawerKey.currentState?.openDrawer();
            },
            icon: const Icon(Icons.menu_rounded),
            iconSize: 30.0,
            color: ConstantColors.black,
          ),
          title: Align(
            alignment: Alignment.centerLeft,
            child: Text('Notification', style: GreekTextStyle.headline2),
          ),
          bottom: TabBar(
            indicatorColor: const Color(0xFF127FBA),
            labelColor: const Color(0xFF127FBA),
            unselectedLabelColor: Colors.black,
            tabs: [
              buildRecommendationTextWithCircle('Recommendation'),
              buildNotificationTextWithCircle('Notification'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // RecommendationScreen(),
            buildRecommendationTab(_profileBloc, context),
            buildNotificationTab(_profileBloc, context),
          ],
        ),
      ),
    );
  }

  Widget buildRecommendationTab(ProfileBloc? _profileBloc, BuildContext context) {
    widget.currentIndex = 0;
    double topSpace = MediaQuery.of(context).size.height / 2;
    return FutureBuilder<List<RecommendationData>?>(
      future: _profileBloc?.getRecommendations(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int dataLength = snapshot.data?.length ?? 0;

          if (dataLength <= 0) {
            return NoDatWithProgressIndicator(topSpace: topSpace, showHide: false, message: '');
          }
          _profileBloc?.recommCount.sink.add(dataLength.toString());

          return ListView.builder(
            itemCount: dataLength,
            itemBuilder: (context, index) {
              final responseObj = snapshot.data?[index];
              return Padding(
                padding: const EdgeInsets.fromLTRB(10, 12, 10, 8),
                child: ListTile(
                  shape: RoundedRectangleBorder(
                    side: BorderSide(width: 0.5, color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  title: Text(responseObj?.cSenderId ?? 'N/A'),
                  subtitle: Text(responseObj?.convertedLogTime ?? 'N/A'),
                  trailing: Container(
                    padding: const EdgeInsets.only(left: 24),
                    width: MediaQuery.of(context).size.width / 2,
                    child: Text(
                      (responseObj?.cMessage ?? ''),
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              );
            },
          );
        } else {
          return NoDatWithProgressIndicator(topSpace: topSpace, showHide: true, message: 'Fetching data');
        }
      },
    );
  }

  Widget buildNotificationTab(ProfileBloc? _profileBloc, BuildContext context) {
    widget.currentIndex = 1;
    double topSpace = MediaQuery.of(context).size.height / 2;
    return FutureBuilder<List<RecommendationData>?>(
      future: _profileBloc?.getNotification(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int dataLength = snapshot.data?.length ?? 0;

          if (dataLength <= 0) {
            return NoDatWithProgressIndicator(topSpace: topSpace, showHide: false, message: '');
          }
          _profileBloc?.notificationCount.sink.add(dataLength.toString());

          return ListView.builder(
            itemCount: dataLength,
            itemBuilder: (context, index) {
              final responseObj = snapshot.data?[index];
              return Padding(
                padding: const EdgeInsets.fromLTRB(10, 12, 10, 8),
                child: ListTile(
                  shape: RoundedRectangleBorder(
                    side: BorderSide(width: 0.5, color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  title: Text(responseObj?.cSenderId ?? 'N/A'),
                  subtitle: Text(responseObj?.convertedLogTime ?? 'N/A'),
                  trailing: Container(
                    padding: const EdgeInsets.only(left: 24),
                    width: MediaQuery.of(context).size.width / 2,
                    child: Text(
                      (responseObj?.cMessage ?? ''),
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              );
            },
          );
        } else {
          return NoDatWithProgressIndicator(topSpace: topSpace, showHide: true, message: 'Fetching data');
        }
      },
    );
  }

  Widget buildRecommendationTextWithCircle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(title, style: titleTextStyle),
        const SizedBox(width: 8),
        Container(
          margin: const EdgeInsets.only(
            bottom: 4,
          ),
          height: 28,
          width: 28,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.blueAccent),
          ),
          child: Center(
            child: StreamBuilder<String>(
              stream: _profileBloc?.recommCount.stream,
              builder: (context, snapshot) {
                if (snapshot.hasData && snapshot.data != null) {
                  return AutoSizeText(
                    snapshot.data ?? '0',
                    minFontSize: 10,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: ConstantColors.black,
                      fontFamily: 'Roboto',
                      fontSize: 12,
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget buildNotificationTextWithCircle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(title, style: titleTextStyle),
        const SizedBox(width: 8),
        Container(
          margin: const EdgeInsets.only(bottom: 4),
          height: 28,
          width: 28,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.blueAccent),
          ),
          child: Center(
            child: StreamBuilder<String>(
              stream: _profileBloc?.notificationCount.stream,
              builder: (context, snapshot) {
                if (snapshot.hasData && snapshot.data != null) {
                  return AutoSizeText(
                    snapshot.data ?? '0',
                    minFontSize: 10,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: ConstantColors.black,
                      fontFamily: 'Roboto',
                      fontSize: 13,
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        ),
      ],
    );
  }
}
