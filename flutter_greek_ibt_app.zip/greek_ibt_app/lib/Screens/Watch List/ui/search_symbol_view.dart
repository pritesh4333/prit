import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class SearchSymbolScreen extends StatefulWidget {
  const SearchSymbolScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<SearchSymbolScreen> createState() => _SearchSymbolScreenState();
}

class _SearchSymbolScreenState extends State<SearchSymbolScreen> {
  WatchListBloc? _watchListBloc;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_watchListBloc == null) {
      final argument = ModalRoute.of(context)?.settings.arguments;
      if (argument is WatchListBloc) {
        _watchListBloc = argument;
      }
    }
    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: ConstantColors.primaryColor,
        leading: IconButton(
          onPressed: () => GreekNavigator.pop(
            context: context,
            popArguments: PopAction.rebuildWidget,
          ),
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          color: ConstantColors.black,
        ),
        title: _searchAppBar(),
      ),
      body: SafeArea(
        child: StreamBuilder<List<SearchSymbolSqliteModel>?>(
          stream: _watchListBloc?.searchSymbolResultObserver,
          builder: (streamContext, snapshot) {
            if (snapshot.hasData) {
              if ((snapshot.data != null) && snapshot.data!.isNotEmpty) {
                return SizedBox(
                  height: MediaQuery.of(streamContext).size.height,
                  child: _searchResultListView(snapshot.data!),
                );
              } else {
                return SizedBox(
                  height: MediaQuery.of(context).size.height / 2,
                  child: Center(child: GreekBase().noDataAvailableView()),
                );
              }
            }

            return Container(
                /* padding: const EdgeInsets.only(top: 30.0),
              alignment: Alignment.topCenter,
              child: const CircularProgressIndicator(), */
                );
          },
        ),
      ),
    );
  }

  Widget _searchAppBar() => TextField(
        controller: _watchListBloc?.searchSymbolTextController,
        autofocus: true,
        textCapitalization: TextCapitalization.characters,
        style: GreekTextStyle.headline1,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.search_rounded),
          hintText: 'Search Stock (Like: TCS, Reliance, etc...)',
          border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide.none,
          ),
          suffixIcon: IconButton(
            onPressed: () => _watchListBloc?.clearSearchResult(),
            icon: const Icon(
              Icons.cancel_rounded,
            ),
          ),
        ),
        onChanged: (symbolName) {
          if (symbolName.length >= 3) {
            _watchListBloc?.searchSymbol(symbolName: symbolName);
          }
        },
      );

  Widget _searchResultListView(List<SearchSymbolSqliteModel> searchResult) {
    return ListView.builder(
      itemCount: searchResult.length,
      itemBuilder: (context, index) {
        return SizedBox(
          height: 80,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ListTile(
                title: InkWell(
                  onTap: () async {
                    WatchListBloc(context).unSubscribeLTPInfo();
                    final popResult = await GreekNavigator.pushNamed(
                      context: context,
                      routeName: GreekScreenNames.place_order,
                      arguments: [
                        int.parse(searchResult[index].token ?? "0"),
                        OrderAction.buy,
                        OrderMode.newOrder,
                        ScriptInfoTab.overview.index,
                      ],
                    );

                    if (popResult == PopAction.rebuildWidget) {
                      WatchListBloc(context).getWatchListDataByGroupName();
                    }
                  }, // Handle your callback
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        fit: FlexFit.loose,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  '${searchResult[index].symbol}'
                                  ' - '
                                  '${searchResult[index].seriesName}',
                                  style: GreekTextStyle.headline1,
                                  // maxLines: 3,
                                ),
                                const SizedBox(
                                  width: 20.0,
                                ),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  color: const Color(0xFFE1E1E1),
                                  child: Text(
                                    int.parse(searchResult[index].token ?? '').toExchange(),
                                    style: GreekTextStyle.headline5,
                                  ),
                                ),
                              ],
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                searchResult[index].description ?? '',
                                style: GreekTextStyle.headline1,
                                maxLines: 3,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          Container(
                            height: 35,
                            width: 30,
                            child: TextButton(
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.zero,
                              ),
                              onPressed: () async {
                                for (var item in (_watchListBloc?.currentSymbolLists ?? [])) {
                                  if (item.token == int.parse(searchResult[index].token ?? '')) {
                                    GreekDialogPopupView.messageDialog(
                                      context,
                                      ConstantMessages.GR_SYMBOL_EXIST_MSG,
                                    );
                                    return;
                                  }
                                }
                                if (_watchListBloc!.currentSymbolLists.length < int.parse(AppFlagConstant().scripCountInWatchlist)) {
                                  GreekNavigator.pop(context: context);

                                  _watchListBloc?.addSymbolintoWatchListGroup(
                                    groupName: _watchListBloc?.defaultGroupName ?? '',
                                    symbolList: [
                                      searchResult[index],
                                    ],
                                  );
                                } else {
                                  GreekDialogPopupView.messageDialog(
                                    context,
                                    "Maximum " + AppFlagConstant().scripCountInWatchlist + " can be added in single watchlist",
                                  );
                                }
                              },
                              child: Text(
                                "+",
                                style: GreekTextStyle.headline25,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: ConstantColors.primaryColor,
                              borderRadius: BorderRadius.circular(8.0),
                              border: Border.all(
                                color: ConstantColors.buyColor,
                                width: 1,
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 10.0,
                          ),
                          Container(
                            height: 35,
                            width: 30,
                            child: TextButton(
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.zero,
                              ),
                              onPressed: () async {
                                GreekNavigator.pushNamed(
                                  context: context,
                                  routeName: GreekScreenNames.place_order,
                                  arguments: [
                                    int.parse(searchResult[index].token ?? ''),
                                    OrderAction.buy,
                                    OrderMode.newOrder,
                                    ScriptInfoTab.order.index,
                                  ],
                                );
                              },
                              child: Text(
                                "B",
                                style: GreekTextStyle.headline21,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: ConstantColors.primaryColor,
                              borderRadius: BorderRadius.circular(8.0),
                              border: Border.all(
                                color: ConstantColors.buyColor,
                                width: 1,
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 10.0,
                          ),
                          Container(
                            height: 35,
                            width: 30,
                            child: TextButton(
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.zero,
                              ),
                              onPressed: () async {
                                GreekNavigator.pushNamed(
                                  context: context,
                                  routeName: GreekScreenNames.place_order,
                                  arguments: [
                                    int.parse(searchResult[index].token ?? ''),
                                    OrderAction.sell,
                                    OrderMode.newOrder,
                                    ScriptInfoTab.order.index,
                                  ],
                                );
                              },
                              child: Text(
                                "S",
                                style: GreekTextStyle.headline21,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            decoration: BoxDecoration(
                              color: ConstantColors.primaryColor,
                              borderRadius: BorderRadius.circular(8.0),
                              border: Border.all(
                                color: ConstantColors.sellColor,
                                width: 1,
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              const Divider(
                color: ConstantColors.dividerColor,
                height: 8,
              ),
            ],
          ),
        );
      },
    );
  }
}
