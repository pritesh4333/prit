class WatchlistResponseModel {
  List<Getwatchlistdata>? getwatchlistdata;

  WatchlistResponseModel({required this.getwatchlistdata});

  WatchlistResponseModel.fromJson(Map<String, dynamic> json) {
    if (json['getwatchlistdata'] != null) {
      getwatchlistdata = <Getwatchlistdata>[];
      json['getwatchlistdata'].forEach((v) {
        getwatchlistdata!.add(Getwatchlistdata.fromJson(v));
      });
    }
  }
}

class WatchListGroupNamesModel {
  List<Getwatchlistdata>? getwatchlistdata;

  WatchListGroupNamesModel({required this.getwatchlistdata});

  WatchListGroupNamesModel.fromJson(Map<String, dynamic> json) {
    if (json['getwatchlistdata'] != null) {
      getwatchlistdata = <Getwatchlistdata>[];
      json['getwatchlistdata'].forEach((v) {
        getwatchlistdata?.add(Getwatchlistdata.fromJson(v));
      });
    }
  }
}

class Getwatchlistdata {
  String? watchtype;
  String? watchlistName;
  List<SymbolList>? symbolList;
  bool? defaultWatchList;
  int? watchlistSeq;

  Getwatchlistdata({
    required this.watchtype,
    required this.watchlistName,
    required this.symbolList,
    required this.defaultWatchList,
    required this.watchlistSeq,
  });

  Getwatchlistdata.fromJson(Map<String, dynamic> json) {
    watchtype = json['watchtype'];
    watchlistName = json['watchlistName'];
    watchlistSeq = json['watchlistSeq'];
    if (json['symbolList'] != null) {
      symbolList = <SymbolList>[];
      json['symbolList'].forEach(
        (v) {
          symbolList!
              .add(SymbolList.fromJson(json: v, isWatchListScreen: true));
        },
      );
    }
    defaultWatchList = (json['default'].toString() == 'true');
  }
}

class SymbolList {
  int? token;
  String? symbol;
  String? description;
  String? seriesName;
  double? ltp;
  double? pChange;
  double? change;
  int? seqNo;
  bool isAdd = false;

  SymbolList({
    required this.token,
    required this.symbol,
    required this.description,
    required this.seriesName,
    required this.ltp,
    required this.pChange,
    required this.change,
  });

  SymbolList.fromJson(
      {required Map<String, dynamic> json, bool isWatchListScreen = false}) {
    if (isWatchListScreen) {
      token = int.parse(json['token']?.toString() ?? '0');
      symbol = json['tradeSymbol']?.toString() ?? '';
      description = json['description']?.toString() ?? '';
      seriesName = json['instrumentName']?.toString() ?? '';
      ltp = double.parse(json['ltp']?.toString() ?? '0');
      pChange = double.parse(json['p_change']?.toString() ?? '0');
      change = double.parse(json['change']?.toString() ?? '0');
      seqNo = int.parse(json['seqNo']?.toString() ?? '0');
      isAdd = true;
    } else {
      token = int.parse(json['token']?.toString() ?? '0');
      symbol = json['symbol']?.toString() ?? '';
      description = json['description']?.toString() ?? '';
      seriesName = json['instrumentname']?.toString() ?? '';
      ltp = double.parse(json['ltp']?.toString() ?? '0');
      pChange = double.parse(json['perchange']?.toString() ?? '0');
      change = double.parse(json['change']?.toString() ?? '0');
    }
  }
}
