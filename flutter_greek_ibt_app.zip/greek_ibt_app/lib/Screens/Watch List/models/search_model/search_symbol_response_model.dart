class SearchSymbolResponseModel {
  int? lourtoken;
  String? symbol;
  String? description;
  String? seriesInstname;
  bool isAdded = false;

  SearchSymbolResponseModel({
    this.lourtoken,
    this.symbol,
    this.description,
    this.seriesInstname,
  });

  SearchSymbolResponseModel.fromJson(Map<String, dynamic> json) {
    lourtoken = json['lourtoken'];
    symbol = json['symbol'];
    description = json['description'];
    seriesInstname = json['series_instname'];
  }
}
