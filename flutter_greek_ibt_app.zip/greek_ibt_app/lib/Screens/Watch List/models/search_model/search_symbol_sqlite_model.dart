class SearchSymbolSqliteModel {
  String? token;
  String? symbol;
  String? description;
  String? seriesName;
  bool isAdded = false;

  SearchSymbolSqliteModel({
    this.token,
    this.symbol,
    this.description,
    this.seriesName,
  });

  SearchSymbolSqliteModel.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    symbol = json['symbol'];
    description = json['description'];
    seriesName = json['series_name'];
  }
}
