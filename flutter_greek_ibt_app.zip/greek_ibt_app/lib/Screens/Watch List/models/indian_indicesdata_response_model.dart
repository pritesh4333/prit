class IndianIndicesResponseModel {
  String? exchange;
  String? exchangeGroup;
  String? token;
  double? last;
  double? pChange;
  double? change;
  int? indexCode;
  double? high;
  double? low;
  int? seqNo;

  IndianIndicesResponseModel(
      {required this.exchange,
      required this.exchangeGroup,
      required this.token,
      required this.last,
      required this.pChange,
      required this.change,
      required this.indexCode,
      required this.high,
      required this.low,
      required this.seqNo});

  IndianIndicesResponseModel.fromJson(Map<String, dynamic> json) {
    exchange = json['exchange'].toString();
    exchangeGroup = json['exchangeGroup'].toString();
    token = json['token'].toString();
    last = double.parse(json['last'].toString());
    pChange = double.parse(json['p_change'].toString());
    change = double.parse(json['change'].toString());
    indexCode = int.parse(json['indexCode'].toString());
    high = double.parse(json['high'].toString());
    low = double.parse(json['low'].toString());
    seqNo = int.parse(json['seqNo'].toString());
  }
}
