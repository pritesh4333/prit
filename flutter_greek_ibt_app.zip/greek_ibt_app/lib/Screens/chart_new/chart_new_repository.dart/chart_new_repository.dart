import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class ChartNewRepository {
  Future<List> fetchChartDataAPI({
    required BuildContext context,
    required String token,
    required String date,
  }) async {
    final response = await NetworkManager().postAPIEncrypted(
      apiName: APIName.jhistorical_New,
      postBody: {
        "token": token,
        "interval": "1",
        "noofdays": "1",
        "date": date,
        "time": "0",
      },
    );

    if ((response != null) && (response is Map<String, dynamic>)) {
      //Parse the Data
    }
    return [];
  }
}
