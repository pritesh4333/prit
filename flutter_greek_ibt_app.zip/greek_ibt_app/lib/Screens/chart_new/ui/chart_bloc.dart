import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/graph_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/repository/watchlist_repository.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/rxdart.dart';

class ChartBloc extends GreekBlocs {
  final BuildContext _context;

  final _watchListRepository = WatchListRepository();
  final chartDataStream = BehaviorSubject<bool>.seeded(false);
  Stream<bool> get chartDataObservable => chartDataStream.stream;
  List<GraphResponseModel>? tempList;

  final dropdownButtonDuration = BehaviorSubject<String>.seeded('1Min');
  final dropdownButtonChartTypes =
      BehaviorSubject<AssetImage>.seeded(const AssetImage('chart_candle.png'));

// Constructor
  ChartBloc(this._context);

  @override
  void disposeBloc() {}

  Future<List<GraphResponseModel?>> callChartData(String token) async {
    var formatter = DateFormat('yyyy-MM-dd');
    var formattedDate = formatter.format(DateTime.now()).replaceAll('-', '');
    final response = await _watchListRepository.getGraphData(
        context: _context, token: token, date: formattedDate);
    return response;
  }
}
