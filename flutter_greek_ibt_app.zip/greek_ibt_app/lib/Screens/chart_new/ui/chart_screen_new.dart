import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/graph_model.dart';
import 'package:greek_ibt_app/Screens/chart_new/ui/chart_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../Portfolio/repository/watchlist_repository.dart';

class ChartScreenNew extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;
  final TabController? controller;
  const ChartScreenNew({
    Key? key,
    required this.token,
    this.placeOrderBloc,
    this.controller,
  }) : super(key: key);

  final String token;
  @override
  State<ChartScreenNew> createState() => _ChartScreenNewState();
}

class _ChartScreenNewState extends State<ChartScreenNew> {
  List<GraphResponseModel>? growableChartData;
  List<String> chartDurationItems = ['1Min', '2Min', '5Min', '10Min', '15Min', 'day', 'week', 'month', 'year'];
  String dropdownValueChartDuration = '1Min';

  List<AssetImage> chartTypeImageItems = [
    const AssetImage('assets/images/chart_candle.png'),
    const AssetImage('assets/images/chart_line.png'),
    const AssetImage('assets/images/area_chart.png'),
    const AssetImage('assets/images/bar_chart.png'),
  ];

  // IconData defaultChartTypeDropdownData = Icons.arrow_back_ios;
  AssetImage defaultChartTypeDropdownData = const AssetImage('assets/images/chart_candle.png');
  double buttonWidthSize = 60.0;

  //chart Presetting
  ChartSeriesController? seriesController;
  final List<GraphResponseModel> chartData = <GraphResponseModel>[];
  late bool isLoadMoreView, isNeedToUpdateView, isDataUpdated;
  double? oldAxisVisibleMin, oldAxisVisibleMax;

  late GlobalKey<State> globalKey;

  WatchListBloc? _watchListBloc;
  final _watchListRepository = WatchListRepository();
  ChartBloc? _chartBloc;

  int endIndex = 0;
  late ZoomPanBehavior _zoomPanBehavior;
  late TooltipBehavior _tooltipBehavior;
  late CrosshairBehavior _crosshairBehavior;
  late TrackballBehavior _trackballBehavior;

  // Constant To Handle Dropdown Events
  String selectedDurationDropdown = '1m';
  String selectedDurationBottomLine = '1day';
  int totalChartDataPlotted = 0;
  TabController? tabController;

  //Previous Date when Load more
  String loadMorePreviousDate = '';
  bool isLoadMoreApicall = false;
  String currentDate = '';

  // Interval dynamic for Y-Axis
  double yAxisInterval = 0.5;

  //Date Time Formatter
  String xAxisDateFormatter = 'HH:mm';

  String globalInterval = '1';
  String globalNoOfDays = '1';
  bool isLoadMoreApiCalledOnce = true;
  bool oddFlagXAxis = true;
  bool oddFlagYAxis = true;

  //Area Series Gradient Color
  final List<Color> areaColor = <Color>[];
  final List<double> areaStops = <double>[];

  //Chart Selection Index
  int selectedChartIndex = 0;

  @override
  void initState() {
    super.initState();
    widget.placeOrderBloc!.appBarSizeSubject.sink.add(false);

    _chartBloc = ChartBloc(context);
    _initializeVariables();
    _initializeColorGradient();

    // Firs time request call at the time of Launch [1M]
    callChartDatajhistoricalNew(
      token: widget.token,
      chartType: AppFlagConstant().chartSetting,
      interval: '1',
      noOfDays: '1',
      date: currentDate,
    );
    tabController = widget.controller;
  }

  void _initializeVariables() {
    // chartData = <GraphResponseModel>[];

    isLoadMoreView = false;
    isNeedToUpdateView = false;
    isDataUpdated = true;
    globalKey = GlobalKey<State>();
    _zoomPanBehavior = ZoomPanBehavior(
      enablePanning: true,
      // enableMouseWheelZooming: true,
      maximumZoomLevel: 0.04,
      zoomMode: ZoomMode.x,
      enableDoubleTapZooming: true,
      enablePinching: true,
      enableSelectionZooming: false,
    );
    _tooltipBehavior = TooltipBehavior(
      enable: true,
      shouldAlwaysShow: true,
      header: '',
      canShowMarker: true,
      tooltipPosition: TooltipPosition.pointer,
      activationMode: ActivationMode.singleTap,
    );
    _crosshairBehavior = CrosshairBehavior(
      enable: true,
      activationMode: ActivationMode.longPress,
    );
    _trackballBehavior = TrackballBehavior(
      enable: true,
      activationMode: ActivationMode.none,
    );

    var formatter = DateFormat('yyyy-MM-dd');
    currentDate = formatter.format(DateTime.now()).replaceAll('-', '');
  }

  void _initializeColorGradient() {
    areaColor.add(Colors.blue[50]!);
    areaColor.add(Colors.blue[200]!);
    areaColor.add(Colors.blue);

    areaStops.add(0.0);
    areaStops.add(0.5);
    areaStops.add(1.0);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Flexible(
          fit: FlexFit.tight,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.fromLTRB(8.0, 15.0, 0, 0.0),
                  child: Row(
                    children: [
                      Container(
                        width: 40.0,
                        height: 40.0,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1),
                          border: Border.all(color: Colors.grey, width: 1),
                        ),
                        child: StreamBuilder<String>(
                            stream: _chartBloc?.dropdownButtonDuration.stream,
                            builder: (context, snapshot) {
                              if (snapshot.hasData) {
                                return DropdownButton(
                                  style: const TextStyle(
                                    color: Colors.black,
                                    letterSpacing: 0.2,
                                    fontFamily: '',
                                    fontSize: 11.0,
                                  ),
                                  elevation: 16,
                                  iconSize: 0.0,
                                  underline: const SizedBox(),
                                  value: snapshot.data.toString(),
                                  onChanged: (var value) {
                                    _chartBloc?.dropdownButtonDuration.sink.add(value as String);
                                    selectedDurationDropdown = value as String;
                                    prepareChartRequestMethodCall(duration: selectedDurationDropdown);
                                  },
                                  items: chartDurationItems.map<DropdownMenuItem<String>>((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                );
                              } else {
                                return const SizedBox(width: 30);
                              }
                            }),
                      ),
                      GestureDetector(
                        onTap: () {
                          // Firs time request call at the time of Launch [1M]
                          _chartBloc?.dropdownButtonDuration.sink.add('1Min');
                          yAxisInterval = 0.5;
                          callChartDatajhistoricalNew(
                            token: widget.token,
                            chartType: AppFlagConstant().chartSetting,
                            interval: '1',
                            noOfDays: '1',
                            date: currentDate,
                          );
                        },
                        child: Container(
                          margin: const EdgeInsets.only(left: 10.0),
                          width: 40.0,
                          height: 40.0,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1),
                            border: Border.all(color: Colors.grey, width: 1),
                          ),
                          child: Icon(
                            Icons.refresh_outlined,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 10.0),
                        width: 40,
                        height: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1),
                          border: Border.all(color: Colors.grey, width: 1),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: StreamBuilder<AssetImage>(
                              stream: _chartBloc?.dropdownButtonChartTypes.stream,
                              builder: (context, snapshot) {
                                if (snapshot.hasData) {
                                  return DropdownButton(
                                    elevation: 10,
                                    iconSize: 0.0,
                                    underline: const SizedBox(),
                                    value: defaultChartTypeDropdownData,
                                    onChanged: (AssetImage? value) {
                                      _chartBloc?.dropdownButtonChartTypes.sink.add(value!);
                                      defaultChartTypeDropdownData = value!;
                                      selectedChartIndex = chartTypeImageItems.indexOf(value);
                                      int dataLength = chartData.length;

                                      //This will notifies the Stream block wheather data should update or not.
                                      if (dataLength > 0) {
                                        _chartBloc?.chartDataStream.sink.add(true);
                                      } else {
                                        _chartBloc?.chartDataStream.sink.add(false);
                                      }
                                    },
                                    items: chartTypeImageItems.map<DropdownMenuItem<AssetImage>>((AssetImage value) {
                                      return DropdownMenuItem<AssetImage>(
                                        value: value,
                                        child: Image(
                                          image: value,
                                          width: 22,
                                          height: 22,
                                        ),
                                      );
                                    }).toList(),
                                  );
                                } else {
                                  return const SizedBox.shrink();
                                }
                              }),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4.0),
                  height: MediaQuery.of(context).size.height / 1.8,
                  child: Stack(
                    children: [
                      _buildInfiniteScrollingCandleChart(),
                      // Positioned(
                      //   bottom: MediaQuery.of(context).size.height / 15,
                      //   left: MediaQuery.of(context).size.width / 2.7,
                      //   child: Row(
                      //     children: [
                      //       const SizedBox(width: 6.0),
                      //       Container(
                      //         decoration: BoxDecoration(color: Colors.grey[200]),
                      //         child: IconButton(
                      //           padding: const EdgeInsets.only(left: 10.0),
                      //           constraints: const BoxConstraints(minHeight: 35, minWidth: 35),
                      //           onPressed: () {
                      //             _zoomPanBehavior.zoomOut();
                      //           },
                      //           icon: const Icon(Icons.add, color: Color.fromARGB(255, 95, 91, 91)),
                      //           iconSize: 25.0,
                      //         ),
                      //       ),
                      //       const SizedBox(width: 6.0),
                      //       Container(
                      //         decoration: BoxDecoration(color: Colors.grey[200]),
                      //         child: IconButton(
                      //           padding: const EdgeInsets.only(left: 10.0),
                      //           constraints: const BoxConstraints(minHeight: 35, minWidth: 35),
                      //           onPressed: () {
                      //             _zoomPanBehavior.zoomIn();
                      //           },
                      //           icon: const Icon(Icons.add, color: Color.fromARGB(255, 95, 91, 91)),
                      //           iconSize: 25.0,
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),
                    ],
                  ),
                ),
                Visibility(
                  visible: false,
                  child: Container(
                    height: 30.0,
                    color: Colors.white,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: buttonWidthSize - 25,
                              child: TextButton(
                                onPressed: () {
                                  //Call Chart API
                                  prepareChartRequestMethodCall(duration: 'day');
                                },
                                child: Text(
                                  '1D',
                                  style: GreekTextStyle.heading7,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: buttonWidthSize - 25,
                              child: TextButton(
                                onPressed: () {
                                  // print('1Month');
                                  selectedDurationDropdown = '1m';
                                },
                                child: Text(
                                  '1M',
                                  style: GreekTextStyle.heading7,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: buttonWidthSize - 25,
                              child: TextButton(
                                onPressed: () {
                                  // print('3Month');
                                },
                                child: Text(
                                  '3M',
                                  style: GreekTextStyle.heading7,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: buttonWidthSize - 25,
                              child: TextButton(
                                onPressed: () {
                                  // print('6Month');
                                },
                                child: Text(
                                  '6M',
                                  style: GreekTextStyle.heading7,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: buttonWidthSize - 15,
                              child: TextButton(
                                onPressed: () {
                                  // print('MAX');
                                },
                                child: Text('MAX', style: GreekTextStyle.heading7),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(color: Colors.grey[200]),
                                child: TextButton(
                                  onPressed: () {
                                    // print('MAX');
                                  },
                                  child: const Text(
                                    '10MAR2022',
                                    style: TextStyle(
                                      fontFamily: 'CenturyGothic',
                                      color: ConstantColors.primaryColorVitt,
                                      fontSize: 10.0,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 2.0),
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(color: Colors.grey[200]),
                                child: TextButton(
                                  onPressed: () {
                                    // print('MAX');
                                  },
                                  child: const Text(
                                    '10MAR2022',
                                    style: TextStyle(
                                      fontFamily: 'CenturyGothic',
                                      color: ConstantColors.primaryColorVitt,
                                      fontSize: 10.0,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Visibility(
          visible: widget.placeOrderBloc?.orderMode == OrderMode.newOrder ? true : false,
          child: _containerFour(),
        ),
      ],
    );
  }

//Handling Dropdown change value method
  void prepareChartRequestMethodCall({required String duration}) {
    yAxisInterval = 10.0;
    isLoadMoreView = false;
    switch (duration.toLowerCase()) {
      case '1min':
        globalInterval = '1';
        globalNoOfDays = '1';
        yAxisInterval = 0.5;
        xAxisDateFormatter = 'HH:mm';
        break;
      case '2min':
        globalInterval = '2';
        globalNoOfDays = '2';
        yAxisInterval = 0.5;
        xAxisDateFormatter = 'HH:mm';
        break;
      case '5min':
        globalInterval = '5';
        globalNoOfDays = '5';
        yAxisInterval = 0.5;
        xAxisDateFormatter = 'HH:mm';
        break;
      case '10min':
        globalInterval = '10';
        globalNoOfDays = '10';
        yAxisInterval = 0.5;
        xAxisDateFormatter = 'HH:mm';
        break;
      case '15min':
        globalInterval = '15';
        globalNoOfDays = '15';
        yAxisInterval = 1.0;
        xAxisDateFormatter = 'HH:mm';
        break;
      case '30min':
        globalInterval = '30';
        globalNoOfDays = '30';
        yAxisInterval = 1.0;
        break;
      case '45min':
        globalInterval = '45';
        globalNoOfDays = '45';
        yAxisInterval = 3.0;
        xAxisDateFormatter = 'HH:mm';
        break;
      case 'hour':
        globalInterval = '60';
        globalNoOfDays = '60';
        yAxisInterval = 5.0;
        xAxisDateFormatter = 'HH:mm';
        break;
      case 'day':
        globalInterval = 'day';
        globalNoOfDays = '';
        yAxisInterval = 25.0;
        xAxisDateFormatter = 'dd/MM';
        break;
      case 'week':
        globalInterval = 'week';
        globalNoOfDays = '';
        yAxisInterval = 50.0;
        xAxisDateFormatter = 'dd/MM';
        break;
      case 'month':
        globalInterval = 'month';
        globalNoOfDays = '';
        xAxisDateFormatter = 'dd MMM';
        break;
      case 'year':
        globalInterval = 'year';
        globalNoOfDays = '';
        break;
      default:
    }

    if (duration.toLowerCase() == 'day') {
      callChartjDailyNew(
        token: widget.token,
        startTime: '0',
        endTime: currentDate,
        interval: globalInterval,
      );
    } else if (duration.toLowerCase() == 'week' || duration.toLowerCase() == 'month' || duration.toLowerCase() == 'year') {
      callChartjWeeklyNew(
        token: widget.token,
        startTime: '0',
        endTime: currentDate,
        interval: globalInterval,
      );
    } else {
      callChartDatajhistoricalNew(
        token: widget.token,
        chartType: AppFlagConstant().chartSetting,
        interval: globalInterval,
        noOfDays: globalNoOfDays,
        date: currentDate,
      );
    }
  }

//Fetching chartData '[jhistorical_New]'
  Future<List<GraphResponseModel>> callChartDatajhistoricalNew({
    required String token,
    required String chartType,
    required String interval,
    required String noOfDays,
    required String date,
  }) async {
    final List<GraphResponseModel> response;
    //Check what flag is Received
    response = await _watchListRepository.getChartDataHistoricalNew(
      context: context,
      token: token,
      date: date,
      interval: interval,
      noofdays: noOfDays,
    );
    //Managing Response
    int length = response.length;
    if (length > 0) {
      prepareChartData(dataList: response);
      return response;
    }
    return [];
  }

  //Fetching chartData '[jDaily_New]'
  //Sample Request :
  //{"request":{"svcName":"jDaily_New","svcVersion":"1.0.0","svcGroup":"jDaily_New","data":
  //{"token":"101011536","endTime":"20220705","interval":"day","startTime":"0"}}}
  Future<List<GraphResponseModel>> callChartjDailyNew({
    required String token,
    required String startTime,
    required String endTime,
    required String interval,
  }) async {
    var formatter = DateFormat('yyyy-MM-dd');
    var formattedDate = formatter.format(DateTime.now()).replaceAll('-', '');
    endTime = formattedDate;
    final List<GraphResponseModel> response;
    response = await _watchListRepository.getChartDataDailyNew(
      context: context,
      token: token,
      startTime: startTime,
      endTime: endTime,
      interval: interval,
    );

    //Managing Response
    int length = response.length;
    if (length > 0) {
      prepareChartData(dataList: response);
      return response;
    }
    return [];
  }

  //week
// {"request":{"svcName":"jWeekly_New","svcGroup":"jWeekly_New","svcVersion":"1.0.0","data":
// {"endTime":"20220705","token":"101011536","interval":"week","startTime":"0"}}}

// month
// {"request":{"svcGroup":"jWeekly_New","data":
// {"startTime":"0","token":"101011536","interval":"month","endTime":"20220705"},"svcVersion":"1.0.0","svcName":"jWeekly_New"}}

// year
// {"request":{"svcGroup":"jWeekly_New","svcName":"jWeekly_New","data":
// {"token":"101011536","endTime":"20220705","interval":"year","startTime":"0"},"svcVersion":"1.0.0"}}

  Future<List<GraphResponseModel>> callChartjWeeklyNew({
    required String token,
    required String startTime,
    required String endTime,
    required String interval,
  }) async {
    var formatter = DateFormat('yyyy-MM-dd');
    var formattedDate = formatter.format(DateTime.now()).replaceAll('-', '');
    endTime = formattedDate;
    final List<GraphResponseModel> response;
    response = await _watchListRepository.getChartDatajWeeklyNew(
      context: context,
      token: token,
      startTime: startTime,
      endTime: endTime,
      interval: interval,
    );

    //Managing Response
    int length = response.length;
    if (length > 0) {
      prepareChartData(dataList: response);
      return response;
    }
    return [];
  }

  void prepareChartData({required List<GraphResponseModel> dataList}) {
    //This block will perform operation to get last date of chart data
    int timeStamp = int.parse(dataList[0].lDate.toString());
    final date = DateFormat('yyyy-MM-dd').format(DateTime.fromMillisecondsSinceEpoch((timeStamp + 315513000) * 1000));
    var formatter = DateFormat('yyyy-MM-dd');
    DateTime d = formatter.parse(date);
    var previousDate = formatter.format(d.subtract(const Duration(days: 1))).replaceAll('-', '');
    loadMorePreviousDate = previousDate;
    //END

    if (isLoadMoreView) {
      // print(dataList);
      _chartBloc?.tempList?.addAll(dataList.reversed);

      isLoadMoreView = true;
      int dataLength = dataList.length;
      for (var i = 0; i < dataLength; i++) {
        chartData.add(dataList[i]);
        endIndex = i;
        totalChartDataPlotted = totalChartDataPlotted + 1;
      }
      // print('chart data length = ${chartData.length}');
      _updateView(dataList.length);
    } else {
      _chartBloc?.tempList?.clear();
      chartData.clear();
      _chartBloc?.tempList = List<GraphResponseModel>.from(dataList.reversed);
      // print('Received chart data length = ${_chartBloc?.tempList?.length}');
      int dataLength = _chartBloc?.tempList?.length as int;
      // int pointLength = 0;
      // if (dataLength >= 30) {
      //   pointLength = 30;
      // } else {
      //   pointLength = dataLength;
      // }

      for (var i = 0; i < dataLength; i++) {
        chartData.add(_chartBloc!.tempList![i]);
        endIndex = i;
        totalChartDataPlotted = totalChartDataPlotted + 1;
      }

      //This will notifies the Stream block wheather data should update or not.
      if (dataLength > 0) {
        _chartBloc?.chartDataStream.sink.add(true);
      } else {
        _chartBloc?.chartDataStream.sink.add(false);
      }
    }
  }

  Widget _buildInfiniteScrollingCandleChart() {
    return StreamBuilder<bool>(
      stream: _chartBloc?.chartDataStream.stream,
      builder: (context, snapshot) {
        if (snapshot.data ?? false) {
          return SfCartesianChart(
            key: GlobalKey<State>(),
            onActualRangeChanged: (ActualRangeChangedArgs args) {
              if (args.orientation == AxisOrientation.horizontal) {
                if (isLoadMoreView) {
                  args.visibleMin = oldAxisVisibleMin;
                  args.visibleMax = oldAxisVisibleMax;
                }

                oldAxisVisibleMin = args.visibleMin as double;
                oldAxisVisibleMax = args.visibleMax as double;
              }
              isLoadMoreView = false;
            },
            plotAreaBorderWidth: 2,
            plotAreaBorderColor: const Color.fromARGB(31, 85, 83, 83),
            // title: ChartTitle(text: 'Candle'),
            tooltipBehavior: _tooltipBehavior,
            crosshairBehavior: _crosshairBehavior,
            zoomPanBehavior: _zoomPanBehavior,
            trackballBehavior: _trackballBehavior,
            enableAxisAnimation: false,

            primaryXAxis: CategoryAxis(
              name: 'XAxis',
              visibleMinimum: 1,
              visibleMaximum: 21,
              interval: 1,
              plotOffset: 10.0,
              majorGridLines: const MajorGridLines(width: 0.25),
              labelPlacement: LabelPlacement.onTicks,
              axisLabelFormatter: (AxisLabelRenderDetails details) {
                var detailList = details.text.split(' Vol.');
                // var formatter = DateFormat('HH:mm');
                var formatter = DateFormat(xAxisDateFormatter);
                var dateFromStr = DateTime.parse(detailList[0]);
                var time = formatter.format(dateFromStr);
                return ChartAxisLabel(
                  time,
                  TextStyle(
                    color: Colors.grey.shade800,
                    fontSize: 10.0,
                    fontWeight: FontWeight.w400,
                  ),
                );
                // if (oddFlagXAxis) {
                //   oddFlagXAxis = false;
                //   return ChartAxisLabel(
                //     time,
                //     TextStyle(
                //       color: Colors.grey.shade800,
                //       fontSize: 10.0,
                //       fontWeight: FontWeight.w400,
                //     ),
                //   );
                // }
                // oddFlagXAxis = true;
                // return ChartAxisLabel('', null);
              },
              isInversed: true,
              isVisible: true,
              placeLabelsNearAxisLine: true,
              labelAlignment: LabelAlignment.center,
              rangePadding: ChartRangePadding.normal,
              // plotOffset: 4.0,
              majorTickLines: MajorTickLines(color: Colors.grey.shade400),
            ),
            primaryYAxis: NumericAxis(
              opposedPosition: true,
              name: 'YAxis',
              interval: yAxisInterval,
              axisLine: const AxisLine(width: 2),
              rangePadding: ChartRangePadding.normal,
              majorGridLines: const MajorGridLines(width: 0.25),
              majorTickLines: MajorTickLines(color: Colors.grey.shade400),
              axisLabelFormatter: (AxisLabelRenderDetails details) {
                return ChartAxisLabel(details.text, null);
              },
              placeLabelsNearAxisLine: true,
              labelAlignment: LabelAlignment.center,
              anchorRangeToVisiblePoints: true,
              enableAutoIntervalOnZooming: true,
            ),

            series: _getChartAsPerSelection(),

            // loadMoreIndicatorBuilder: (BuildContext context, ChartSwipeDirection direction) => getloadMoreIndicatorBuilder(
            //   context,
            //   direction,
            // ),
            // loadMoreIndicatorBuilder: (BuildContext context, ChartSwipeDirection direction) {
            //   if (direction == ChartSwipeDirection.end) {
            //     isLoadMoreView = true;
            //     //   //Call API
            //     // if (isLoadMoreApiCalledOnce) {
            //     //   isLoadMoreApiCalledOnce = false;
            //     //   callApiFunction();
            //     // }

            //     // seriesController?.updateDataSource(addedDataIndexes: _getIndexes(additionalPlotCount));
            //   }
            //   return SizedBox.fromSize(
            //     size: Size.zero,
            //   );
            // },
          );
        } else {
          return Container();
        }
      },
    );
  }

  List<ChartSeries<GraphResponseModel, String>> _getChartAsPerSelection() {
    switch (selectedChartIndex) {
      case 0:
        //Candle
        return _getCandleSeries();
      case 1:
        //Line
        return _getLineSeries();
      case 2:
        //Area
        return _getAreaSeries();
      case 3:
        //Bar
        return _getHiLowOpenSeries();
      default:
        return _getCandleSeries();
    }
  }

  callApiFunction() {
    callChartDatajhistoricalNew(
      token: widget.token,
      chartType: AppFlagConstant().chartSetting,
      interval: '1',
      noOfDays: '1',
      date: loadMorePreviousDate,
    );
  }

  //=====================================================================
  ///
  /// SFCartesian Chart
  /// Candle Series Showing
  //
  ///Author : Sushant Patil
  //=====================================================================
  List<ChartSeries<GraphResponseModel, String>> _getCandleSeries() {
    return <ChartSeries<GraphResponseModel, String>>[
      CandleSeries<GraphResponseModel, String>(
        enableSolidCandles: true,
        enableTooltip: true,
        dataSource: chartData,
        animationDuration: 0,
        animationDelay: 0,
        emptyPointSettings: EmptyPointSettings(mode: EmptyPointMode.average),
        xValueMapper: (GraphResponseModel graph, _) => graph.lDateConverted,
        yAxisName: 'Vol',
        lowValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lLow ?? '0'),
        highValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lHigh ?? '0'),
        openValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lOpen ?? '0'),
        closeValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lClose ?? '0'),
        onRendererCreated: (ChartSeriesController controller) {
          seriesController = controller;
        },
      )
    ];
  }

//=====================================================================
  ///
  /// SFCartesian Chart
  /// Candle Series Showing
  //
  /// Author : Sushant Patil
  //=====================================================================
  List<ChartSeries<GraphResponseModel, String>> _getLineSeries() {
    return <ChartSeries<GraphResponseModel, String>>[
      LineSeries<GraphResponseModel, String>(
        enableTooltip: true,
        animationDuration: 0,
        animationDelay: 0,
        dataSource: chartData,
        xValueMapper: (GraphResponseModel graph, _) => graph.lDateConverted,
        yValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lClose ?? '0'),
        width: 2,
      ),
    ];
  }

//=====================================================================
  ///
  /// SFCartesian Chart
  /// Column Series Showing
  //
  /// Author : Sushant Patil
  //=====================================================================
  List<ChartSeries<GraphResponseModel, String>> _getHiLowOpenSeries() {
    return <ChartSeries<GraphResponseModel, String>>[
      HiloOpenCloseSeries<GraphResponseModel, String>(
        enableTooltip: true,
        animationDuration: 0,
        animationDelay: 0,
        dataSource: chartData,
        xValueMapper: (GraphResponseModel graph, _) => graph.lDateConverted,
        lowValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lLow ?? '0'),
        highValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lHigh ?? '0'),
        openValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lOpen ?? '0'),
        closeValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lClose ?? '0'),

        // dataLabelSettings:
      )
    ];
  }

//=====================================================================
  ///
  /// SFCartesian Chart
  /// Area Series Showing
  //
  /// Author : Sushant Patil
  //=====================================================================
  List<ChartSeries<GraphResponseModel, String>> _getAreaSeries() {
    return <ChartSeries<GraphResponseModel, String>>[
      AreaSeries<GraphResponseModel, String>(
        animationDuration: 0,
        animationDelay: 0,
        enableTooltip: true,
        dataSource: chartData,
        xValueMapper: (GraphResponseModel graph, _) => graph.lDateConverted,
        yValueMapper: (GraphResponseModel graph, _) => double.parse(graph.lClose ?? '0'),
        borderWidth: 2,
        borderColor: Colors.blue,
        gradient: LinearGradient(colors: areaColor, stops: areaStops),
      ),
    ];
  }

  Widget getloadMoreIndicatorBuilder(BuildContext context, ChartSwipeDirection direction) {
    if (direction == ChartSwipeDirection.end) {
      isNeedToUpdateView = true;
      globalKey = GlobalKey<State>();
      return StatefulBuilder(
          key: globalKey,
          builder: (BuildContext context, StateSetter stateSetter) {
            Widget widgetss;
            if (isNeedToUpdateView) {
              widgetss = getProgressIndicator();
              // _updateView(additionalCount)
              isLoadMoreView = true;
            } else {
              widgetss = const SizedBox.shrink();
            }
            return widgetss;
          });
    } else {
      return SizedBox.fromSize(size: Size.zero);
    }
  }

  List<int> _getIndexes(int length) {
    final List<int> indexes = <int>[];
    /*for (int i = length - 1; i >= 0; i--) {
      indexes.add(chartData.length - 1 - i);
    }*/
    for (int i = 0; chartData.length > i; i++) {
      indexes.add(i);
    }
    return indexes;
  }

  Widget getProgressIndicator() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 22),
        child: Container(
          width: 50,
          alignment: Alignment.centerLeft,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: <Color>[Colors.white.withOpacity(0.0), Colors.white.withOpacity(0.74)],
              stops: const <double>[0.0, 1],
            ),
          ),
          child: const SizedBox(
            height: 35,
            width: 35,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color.fromRGBO(0, 116, 227, 1)),
              backgroundColor: Colors.transparent,
              strokeWidth: 3,
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _updateView(int additionalCount) async {
    await Future<void>.delayed(
      const Duration(seconds: 1),
      () {
        isNeedToUpdateView = false;
        if (isDataUpdated) {
          _updateDataNew(additionalCount);
          isDataUpdated = false;
        }
      },
    );
  }

  _updateDataNew(int additionalCount) {
    isLoadMoreView = true;
    isLoadMoreApiCalledOnce = true;
    seriesController?.updateDataSource(addedDataIndexes: _getIndexes(additionalCount));
  }

  // void _updateData() {
  //   final loopCount = endIndex + 1;
  //   int totalChartDataCount = _chartBloc?.tempList?.length as int;
  //   int additionalPlotCount = totalChartDataCount - totalChartDataPlotted;

  //   if (additionalPlotCount >= 20) {
  //     additionalPlotCount = 20;
  //   }

  //   for (var i = loopCount; i < (loopCount + additionalPlotCount); i++) {
  //     chartData.add(_chartBloc!.tempList![i]);
  //     endIndex = i;
  //     totalChartDataPlotted = totalChartDataPlotted;
  //   }

  //   isLoadMoreView = true;
  //   seriesController?.updateDataSource(addedDataIndexes: _getIndexes(additionalPlotCount));
  // }

  @override
  void dispose() {
    seriesController = null;
    _watchListBloc?.disposeBloc();
    _watchListBloc = null;
    super.dispose();
  }

  Widget _containerFour() {
    return SafeArea(
      child: Container(
        // height: 80,
        color: Colors.white,
        margin: const EdgeInsets.only(top: 5.0),
        padding: const EdgeInsets.only(top: 15, bottom: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: const Color(0xFF33CC33),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.buy;
                    tabController?.animateTo(0);
                    widget.placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink.add(true);
                  },
                  child: const Text(
                    "BUY",
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: ConstantColors.sellColor,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.sell;
                    tabController?.animateTo(0);
                    widget.placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink.add(true);
                  },
                  child: const Text(
                    "SELL",
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
