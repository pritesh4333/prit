// ignore_for_file: avoid_print

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/repository/password_screens_repository.dart';

class PasswordScreensBloc extends GreekBlocs {
  final _passwordRepository = PasswordScreensRepository();
  final BuildContext _passwordBlocContext;
  String? _gscid;

  final _panNoRegExp = RegExp(r"^[A-Z]{5}[0-9]{4}[A-Z]{1}");
  final _emailRegExp = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
  final _validCharacters = RegExp(r'^[a-zA-Z]');
  final _validNumbers = RegExp(r'[0-9]');
  // final _validSplCharacters = RegExp(r'^[!@#$%^&*~?._-]+$');
  //RegExp(r'^[a-zA-Z0-9&%=]+$')

  final clientIDTextfieldController = TextEditingController(text: AppConfig().gscid);
  final panTextfieldController = TextEditingController();
  final emailIDTextfieldController = TextEditingController();

  final oldPassTextfieldController = TextEditingController();
  final newPassTextfieldController = TextEditingController();
  final confirmPassTextfieldController = TextEditingController();

  final _otpTextfieldController = TextEditingController();

  PasswordScreensBloc(this._passwordBlocContext, {String? gscid}) {
    _gscid = gscid;
  }

  @override
  void disposeBloc() {
    clientIDTextfieldController.dispose();
    panTextfieldController.dispose();
    emailIDTextfieldController.dispose();

    oldPassTextfieldController.dispose();
    newPassTextfieldController.dispose();
    confirmPassTextfieldController.dispose();

    _otpTextfieldController.dispose();
  }

  void clearAllTextField() {
    clientIDTextfieldController.clear();
    clientIDTextfieldController.text = '';

    panTextfieldController.clear();
    panTextfieldController.text = '';

    emailIDTextfieldController.clear();
    emailIDTextfieldController.text = '';

    oldPassTextfieldController.clear();
    oldPassTextfieldController.text = '';

    newPassTextfieldController.clear();
    newPassTextfieldController.text = '';

    confirmPassTextfieldController.clear();
    confirmPassTextfieldController.text = '';

    _otpTextfieldController.clear();
    _otpTextfieldController.text = '';
  }

  Future<void> changePassword() async {
    FocusScope.of(_passwordBlocContext).unfocus();

    if (oldPassTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_OLD_PASSWORD_EMPTY_ALERT,
      );
    } else if (newPassTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_NEW_PASSWORD_EMPTY_ALERT,
      );
    } else if (confirmPassTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_CONFIRM_PASSWORD_EMPTY_ALERT,
      );
    } else if (!newPassTextfieldController.text.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_SYMBOL_MSG,
      );
    } else if (newPassTextfieldController.text.toLowerCase().compareTo(confirmPassTextfieldController.text.toLowerCase()) != 0) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_CONFIRM_NEW_PASSWORD_MSG,
      );
    } else {
      final errorCode = await _passwordRepository.jChangePassword(
        context: _passwordBlocContext,
        oldPass: oldPassTextfieldController.text,
        newPass: newPassTextfieldController.text,
      );

      switch (errorCode) {
        case 0:
          clearAllTextField();
          GreekDialogPopupView.customeCallBackDialog(
            context: _passwordBlocContext,
            message: ConstantMessages.PASSWORD_UPDATED,
            onPressed: (callBackContext) => GreekNavigator.popUntil(
              context: callBackContext,
              routeName: GreekScreenNames.login,
            ),
          );

          break;

        case 2:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.GREEK_INCORRECT_PASSWORD_MSG,
          );
          break;

        case 4:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.GREEK_DUPLICATE_PASSWORD_MSG,
          );
          break;

        case 5:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.GREEK_MAX_MSG,
          );
          break;

        case 9:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.GREEK_ID_PASS_MSG,
          );
          break;

        default:
          break;
      }
    }
  }

  Future<void> resetPassword() async {
    FocusScope.of(_passwordBlocContext).unfocus();
    log('Password Validation - ${_validCharacters.hasMatch(newPassTextfieldController.text)}');

    if (newPassTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_NEW_PASSWORD_EMPTY_ALERT,
      );
    } else if (confirmPassTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_CONFIRM_PASSWORD_EMPTY_ALERT,
      );
    } else if (newPassTextfieldController.text.toLowerCase().compareTo(confirmPassTextfieldController.text.toLowerCase()) != 0) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_CONFIRM_NEW_PASSWORD_MSG,
      );
    } else if (!newPassTextfieldController.text.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_SYMBOL_MSG,
      );
    } else if (!_validNumbers.hasMatch(newPassTextfieldController.text)) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_NUMBER_MSG,
      );
    } else if (!_validCharacters.hasMatch(newPassTextfieldController.text)) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_ALPHANUMERIC_MSG,
      );
    } else if (newPassTextfieldController.text.length < 8 || newPassTextfieldController.text.length > 12) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.CP_LIMIT_PASSWORD_EMPTY_MSG,
      );
    } else {
      final errorCode = await _passwordRepository.jSetPasswordMF(
        context: _passwordBlocContext,
        gscid: _gscid!,
        newPass: newPassTextfieldController.text,
      );

      switch (errorCode) {
        case 0:
          clearAllTextField();

          GreekDialogPopupView.customeCallBackDialog(
            context: _passwordBlocContext,
            message: ConstantMessages.PASSWORD_UPDATED,
            onPressed: (callBackContext) {
              GreekNavigator.popUntil(
                context: callBackContext,
                routeName: GreekScreenNames.login,
              );
            },
          );
          break;

        case 4:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.GREEK_DUPLICATE_PASSWORD_MSG,
          );
          break;

        default:
          break;
      }
    }
  }

  Future<void> forgetPassword() async {
    FocusScope.of(_passwordBlocContext).unfocus();

    final gscid = clientIDTextfieldController.text.toUpperCase();

    if (clientIDTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.FP_USER_ID_EMPTY_MSG,
      );
    } else if (panTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.FP_PAN_NO_EMPTY,
      );
    } else if (!_panNoRegExp.hasMatch(panTextfieldController.text)) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.FP_PAN_NO_INVALID,
      );
    } else if (emailIDTextfieldController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.FP_EMAIL_ID_EMPTY,
      );
    } else if (!_emailRegExp.hasMatch(emailIDTextfieldController.text)) {
      GreekDialogPopupView.messageDialog(
        _passwordBlocContext,
        ConstantMessages.FP_EMAIL_ID_PROPER_FORMAT,
      );
    } else {
      final errorCode = await _passwordRepository.verifyPanEmail(
        context: _passwordBlocContext,
        userID: gscid,
        panNo: panTextfieldController.text,
        emailID: emailIDTextfieldController.text,
      );

      switch (errorCode) {
        case 0:
          _otpTextfieldController.clear();
          _otpTextfieldController.text = '';
          _showOTPPopup(gscid);
          break;

        case 13:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.LP_INVALID_CLIENT_NAME,
          );
          break;

        default:
          GreekDialogPopupView.messageDialog(
            _passwordBlocContext,
            ConstantMessages.INVALID_CREDENTIALS,
          );
          break;
      }
    }
  }

  void _showOTPPopup(String gscid) {
    FocusScope.of(_passwordBlocContext).unfocus();

    GreekDialogPopupView.otpDialog(
      context: _passwordBlocContext,
      child: TextFormField(
        controller: _otpTextfieldController,
        autofocus: false,
        keyboardType: TextInputType.number,
        maxLength: 6,
        decoration: const InputDecoration(
          hintText: ConstantMessages.OTP_HINT,
        ),
      ),
      sendPressed: (sendContext) {
        FocusScope.of(sendContext).unfocus();

        GreekNavigator.pop(context: sendContext);
        _validateEnteredOTP(gscid);
      },
      resendPressed: (resendContext) {
        GreekNavigator.pop(context: resendContext);
        forgetPassword();
      },
    );
  }

  void _validateEnteredOTP(String gscid) async {
    FocusScope.of(_passwordBlocContext).unfocus();

    if (_otpTextfieldController.text.isEmpty) {
      GreekDialogPopupView.customeCallBackDialog(
        context: _passwordBlocContext,
        message: ConstantMessages.CP_OTP_EMPTY_MSG,
        onPressed: (callBackContext) {
          GreekNavigator.pop(context: callBackContext);
          _showOTPPopup(gscid);
        },
      );
    } else {
      final errorCode = await _passwordRepository.jValidateOTPMF(
        context: _passwordBlocContext,
        userID: gscid,
        otp: _otpTextfieldController.text,
      );

      switch (errorCode) {
        case 0:
          clearAllTextField();
          GreekNavigator.pushNamed(
            context: _passwordBlocContext,
            routeName: GreekScreenNames.reset_password,
            arguments: gscid,
          );
          break;

        default:
          GreekDialogPopupView.customeCallBackDialog(
            context: _passwordBlocContext,
            message: ConstantMessages.CP_OTP_INVALID_MSG,
            onPressed: (callBackContext) {
              GreekNavigator.pop(context: callBackContext);
              _showOTPPopup(gscid);
            },
          );
          break;
      }
    }
  }
}
