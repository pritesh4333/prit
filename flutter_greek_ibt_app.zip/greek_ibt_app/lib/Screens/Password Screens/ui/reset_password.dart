import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/bloc/password_screens_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class ResetPassword extends StatefulWidget {
  const ResetPassword({Key? key}) : super(key: key);

  @override
  _ResetPasswordState createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {
  PasswordScreensBloc? _passwordBloc;

  var _isObscureNewPassword = true, _isObscureConfirmPassword = true;

  @override
  void dispose() {
    _passwordBloc?.disposeBloc();
    _passwordBloc = null;

    super.dispose();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (_passwordBloc == null) {
      final gscid = ModalRoute.of(context)?.settings.arguments as String;
      _passwordBloc = PasswordScreensBloc(context, gscid: gscid);
    }

    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: ConstantColors.primaryColor,
        title: Text(
          ConstantMessages.CP_RESET_PASSWORD_LBL_TXT,
          style: GreekTextStyle.headline2,
        ),
        leading: TextButton(
          onPressed: () {
            GreekNavigator.popUntil(
              context: context,
              routeName: GreekScreenNames.login,
            );
          },
          child: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: ConstantColors.black,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 30.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _passwordBloc?.newPassTextfieldController,
                  autofocus: false,
                  obscureText: _isObscureNewPassword,
                  keyboardType: TextInputType.text,
                  maxLength: 12,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.CP_NEW_PASSWORD_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
                    suffixIcon: IconButton(
                      onPressed: () => setState(
                        () => _isObscureNewPassword = !_isObscureNewPassword,
                      ),
                      icon: Icon(
                        _isObscureNewPassword ? Icons.visibility : Icons.visibility_off,
                        semanticLabel: _isObscureNewPassword ? 'show password' : 'hide password',
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  controller: _passwordBloc?.confirmPassTextfieldController,
                  autofocus: false,
                  obscureText: _isObscureConfirmPassword,
                  keyboardType: TextInputType.text,
                  maxLength: 12,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.CP_Confirm_PASSWORD_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
                    suffixIcon: IconButton(
                      onPressed: () => setState(
                        () => _isObscureConfirmPassword = !_isObscureConfirmPassword,
                      ),
                      icon: Icon(
                        _isObscureConfirmPassword ? Icons.visibility : Icons.visibility_off,
                        semanticLabel: _isObscureConfirmPassword ? 'show password' : 'hide password',
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextButton(
                  onPressed: () => _passwordBloc?.resetPassword(),
                  child: Text(
                    ConstantMessages.CP_SUBMIT_BTN,
                    style: GreekTextStyle.heading11,
                  ),
                  style: TextButton.styleFrom(
                    backgroundColor: ConstantColors.primaryColorLight,
                    fixedSize: Size(
                      MediaQuery.of(context).size.width,
                      50.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
