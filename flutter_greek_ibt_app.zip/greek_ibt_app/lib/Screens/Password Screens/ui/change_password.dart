import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/bloc/password_screens_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  PasswordScreensBloc? _passwordBloc;

  var _isObscureOldPassword = true, _isObscureNewPassword = true, _isObscureConfirmPassword = true;

  @override
  void dispose() {
    _passwordBloc?.disposeBloc();
    _passwordBloc = null;

    super.dispose();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (_passwordBloc == null) {
      final gscid = ModalRoute.of(context)?.settings.arguments as String;
      _passwordBloc = PasswordScreensBloc(context, gscid: gscid);
    }

    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: ConstantColors.primaryColor,
        title: Text(
          ConstantMessages.GREEK_MENU_CHANGE_PASSWORD_TXT,
          style: GreekTextStyle.headline2,
        ),
        leading: TextButton(
          onPressed: () {
            GreekNavigator.pop(
              context: context,
            );
          },
          child: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: ConstantColors.black,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 30.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _passwordBloc?.oldPassTextfieldController,
                  autofocus: false,
                  obscureText: _isObscureOldPassword,
                  keyboardType: TextInputType.text,
                  maxLength: 12,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.CP_OLD_PASSWORD_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
                    suffixIcon: GestureDetector(
                      onTap: () {
                        setState(() {
                          _isObscureOldPassword = !_isObscureOldPassword;
                        });
                      },
                      child: Icon(
                        _isObscureOldPassword ? Icons.visibility : Icons.visibility_off,
                        semanticLabel: _isObscureOldPassword ? 'show password' : 'hide password',
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  controller: _passwordBloc?.newPassTextfieldController,
                  autofocus: false,
                  obscureText: _isObscureNewPassword,
                  keyboardType: TextInputType.text,
                  maxLength: 12,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.CP_NEW_PASSWORD_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
                    suffixIcon: GestureDetector(
                      onTap: () {
                        setState(() {
                          _isObscureNewPassword = !_isObscureNewPassword;
                        });
                      },
                      child: Icon(
                        _isObscureNewPassword ? Icons.visibility : Icons.visibility_off,
                        semanticLabel: _isObscureNewPassword ? 'show password' : 'hide password',
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  controller: _passwordBloc?.confirmPassTextfieldController,
                  autofocus: false,
                  obscureText: _isObscureConfirmPassword,
                  keyboardType: TextInputType.text,
                  maxLength: 12,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.CP_Confirm_PASSWORD_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
                    suffixIcon: GestureDetector(
                      onTap: () {
                        setState(() {
                          _isObscureConfirmPassword = !_isObscureConfirmPassword;
                        });
                      },
                      child: Icon(
                        _isObscureConfirmPassword ? Icons.visibility : Icons.visibility_off,
                        semanticLabel: _isObscureConfirmPassword ? 'show password' : 'hide password',
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextButton(
                  onPressed: () => _passwordBloc?.changePassword(),
                  child: Text(
                    ConstantMessages.CP_SUBMIT_BTN1,
                    style: GreekTextStyle.optionChainHeading,
                  ),
                  style: TextButton.styleFrom(
                    backgroundColor: ConstantColors.primaryColorLight,
                    fixedSize: Size(
                      MediaQuery.of(context).size.width,
                      50.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
