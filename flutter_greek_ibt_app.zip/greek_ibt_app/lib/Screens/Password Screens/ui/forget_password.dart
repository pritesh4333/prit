import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/bloc/password_screens_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/greek_utility.dart';

class ForgetPassword extends StatefulWidget {
  const ForgetPassword({Key? key}) : super(key: key);

  @override
  _ForgetPasswordState createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  PasswordScreensBloc? _passwordBloc;

  @override
  void dispose() {
    _passwordBloc?.disposeBloc();
    _passwordBloc = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _passwordBloc ??= PasswordScreensBloc(context);

    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: ConstantColors.primaryColor,
        title: Text(
          ConstantMessages.FP_HEADER_TXT,
          style: GreekTextStyle.headline2,
        ),
        leading: TextButton(
          onPressed: () {
            GreekNavigator.pop(context: context);
          },
          child: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: ConstantColors.black,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 30.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _passwordBloc?.clientIDTextfieldController,
                  autofocus: false,
                  maxLength: 15,
                  textCapitalization: TextCapitalization.characters,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.CLIENT_ID,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25.0),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  controller: _passwordBloc?.panTextfieldController,
                  autofocus: false,
                  keyboardType: TextInputType.text,
                  maxLength: 10,
                  textCapitalization: TextCapitalization.characters,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.FP_PAN_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25.0),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextFormField(
                  controller: _passwordBloc?.emailIDTextfieldController,
                  autofocus: false,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    hintText: ConstantMessages.FP_EMAIL_LBL_TXT,
                    contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25.0),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                TextButton(
                  onPressed: () => _passwordBloc?.forgetPassword(),
                  child: Text(
                    ConstantMessages.CP_SUBMIT_BTN1,
                    style: GreekThemeUtility.lightTheme.textTheme.button,
                  ),
                  style: TextButton.styleFrom(
                    backgroundColor: ConstantColors.primaryColorLight,
                    fixedSize: Size(
                      MediaQuery.of(context).size.width,
                      50.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
