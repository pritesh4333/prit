import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/contract_model.dart';
import 'package:greek_ibt_app/sqlite/datahelper.dart';
import 'package:path/path.dart';

import '../../../Configuration/app_config.dart';

class LoginRepository {
  Future<LoginResponseModel> callLoginAPI({
    required BuildContext context,
    required String versionNo,
    required String gscid,
    required String pass,
    required String deviceDetails,
    required String deviceId,
    required String transPass,
  }) =>
      NetworkManager().authenticateUser(
        context: context,
        versionNo: versionNo,
        gscid: gscid,
        pass: pass,
        deviceDetails: deviceDetails,
        deviceId: deviceId,
        transPass: transPass,
      );

  Future<Object?> getFlagvalueAPI({required String deviceId}) async {
    final response = await NetworkManager().postAPIEncrypted(
      apiName: APIName.getFlagValues,
      postBody: {
        'deviceId': deviceId,
      },
    );

    return response;
  }

  Future<Object?> getContractDetailsAPi() async {
    final contractResponse = await NetworkManager().getAPIEncrypted(
        apiName: APIName.get_all_contracts_table_data, query: '');
    if (contractResponse is List) {
      final obj =
          contractResponse.map((e) => ContractDataModel.fromJson(e)).toList();

      final _ = await DBHelper.insertContractTableData(obj);
    }
    return contractResponse;
  }

  Future<int?> callLoginOTP(BuildContext context) async =>
      await NetworkManager().postAPIEncryptedOnlyForErrorCode(
        context: context,
        apiName: APIName.jLoginWithOTP,
        postBody: {
          'gscid': AppConfig().gscid,
          'version_no': AppConfig().version_no,
        },
      );
}
