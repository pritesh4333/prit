import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Login/repository/login_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_urls.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Extension_Enum/string_extension.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tuple/tuple.dart';

class LoginBloc extends GreekBlocs {
  final BuildContext _context;
  var otp;

  LoginBloc(this._context) {
    getotp();
  }

  final _repository = LoginRepository();

  final userTextController = TextEditingController(text: AppConfig().gscid);
  final passwordTextController = TextEditingController();

  @override
  void disposeBloc() {
    userTextController.dispose();
    passwordTextController.dispose();
  }

  Future<String> getotp() async {
    otp = await AppConfig().getOTP() ?? '';
    return otp;
  }

  @override
  void activateBloc() {}

  @override
  void deactivateBloc() {
    passwordTextController.clear();
  }

  callLoginAPI() async {
    FocusScope.of(_context).unfocus();

    if (userTextController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _context,
        ConstantMessages.FP_USER_ID_EMPTY_MSG,
      );
    } else if (passwordTextController.text.isEmpty) {
      GreekDialogPopupView.messageDialog(
        _context,
        ConstantMessages.GREEK_PASSWORD_EMPTY_MSG,
      );
    } else {
      AppConfig().gscid = userTextController.text.toUpperCase();

      LoginResponseModel obj = await _repository.callLoginAPI(
        context: _context,
        versionNo: AppConfig().internalVersionNO,
        gscid: AppConfig().gscid,
        pass: passwordTextController.text.toMD5String(),
        deviceDetails: AppConfig().deviceDetails ?? 'unknown',
        deviceId: AppConfig().deviceID,
        transPass: '',
      );

      if (obj.errorCode == UserAuthenticationCode.success) {
        AppConfig().deleteUser();
        GreekBase().mapData.clear();
        AppConfig().islogoff = false;

        AppConfig()
            .saveUser(userTextController.text, passwordTextController.text);

        for (var item in (obj.allowedMarket ?? <AllowedMarket>[])) {
          switch ((item.marketId ?? -1)) {
            case 1:
              GreekBase().marketSegments.add(MarketSegment.nseeq);
              break;
            case 2:
              GreekBase().marketSegments.add(MarketSegment.nsefo);
              break;
            case 3:
              GreekBase().marketSegments.add(MarketSegment.nsecd);
              break;
            case 4:
              GreekBase().marketSegments.add(MarketSegment.bseeq);
              break;
            case 5:
              GreekBase().marketSegments.add(MarketSegment.bsefo);
              break;
            case 6:
              GreekBase().marketSegments.add(MarketSegment.bsecd);
              break;
            case 7:
              GreekBase().marketSegments.add(MarketSegment.ncdex);
              break;
            case 9:
              GreekBase().marketSegments.add(MarketSegment.mcx);
              break;
            case 16:
              GreekBase().marketSegments.add(MarketSegment.nsecomm);
              break;
            case 17:
              GreekBase().marketSegments.add(MarketSegment.bsecomm);
              break;

            default:
              break;
          }
        }
        AppConfig().gcid = obj.clientCode!.toString();
        AppConfig().sessionID = obj.sessionID!.trim();
        AppConfig().clientName = obj.clientName.toString();
        SharedPreferences sp = await SharedPreferences.getInstance();
        sp.setString('clientname', AppConfig().clientName);

        AppConfig().isMPinSet =
            (obj.isMPINSet!.toLowerCase().compareTo('true') == 0);

        AppConfig().serverInfo = Tuple5(
          AppConfig().isSecureGlobal,
          obj.arachneIP!,
          obj.arachnePort!,
          obj.socketPort!,
          GreekURLs.currentServerInfo.item5,
        );

        NetworkManager().setupNetwork(serverInfo: AppConfig().serverInfo);

        passwordTextController.clear();
        if (AppFlagConstant().loginCompliance == "0") {
          GreekNavigator.pushReplacementNamed(
            context: _context,
            routeName: GreekScreenNames.mpin,
          );
        } else if (AppFlagConstant().loginCompliance == "1") {
          if (otp == '') {
            final errorCode = await _repository.callLoginOTP(_context);

            switch (errorCode) {
              case 0:
                Fluttertoast.showToast(
                  msg: "OTP Sent to Your Registered Mobile Number / Email",
                  toastLength: Toast.LENGTH_LONG,
                );
                GreekNavigator.pushReplacementNamed(
                  context: _context,
                  routeName: GreekScreenNames.otp,
                );
                break;
            }
            /* }  else {
            GreekNavigator.pushReplacementNamed(
              context: _context,
              routeName: GreekScreenNames.otp,
            ); */
          } else {
            GreekNavigator.pushReplacementNamed(
              context: _context,
              routeName: GreekScreenNames.otp,
            );
          }
        }
      } else if (obj.errorCode ==
          UserAuthenticationCode.loginPasswordExpiredError) {
        passwordTextController.clear();

        GreekDialogPopupView.customeCallBackDialog(
          context: _context,
          message: obj.errorResone,
          onPressed: (callBackContext) {
            GreekNavigator.pop(context: callBackContext);
            GreekNavigator.pushNamed(
              context: callBackContext,
              routeName: GreekScreenNames.change_password,
              arguments: AppConfig().gscid,
            );
          },
        );
      } else {
        GreekDialogPopupView.messageDialog(
          _context,
          obj.errorResone,
        );
      }
    }
  }
}
