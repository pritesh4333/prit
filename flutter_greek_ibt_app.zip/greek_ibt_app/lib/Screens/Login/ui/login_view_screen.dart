import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Screens/Login/bloc/login_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/greek_urls.dart';
import 'package:greek_ibt_app/Utilities/size_config.dart';
import 'package:url_launcher/url_launcher.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  LoginBloc? _loginBloc;
  bool _obscureText = true;
  double mainContainerConstant = 0.0;
  double textFieldHeightConstant = 0.0;
  bool isContentPadding = false;
  double widthLogo = 0.0;
  double bannerTextWidth = 0.0;
  double loginButtonWidth = 0.0;
  double loginButtonHeight = 0.0;
  double firstHalfFont = 0.0;
  double topSpace = 0.0;

  @override
  void dispose() {
    _loginBloc?.disposeBloc();
    _loginBloc = null;
    super.dispose();
  }

  @override
  void activate() {
    super.activate();
    _loginBloc?.activateBloc();
  }

  @override
  void deactivate() {
    _loginBloc?.deactivateBloc();
    super.deactivate();
  }

  @override
  void initState() {
    super.initState();
    SocketIOManager().disposeSocketIO();
    AppConfig().deleteOTP();
  }

  void setAlignmentConstant() {
    if (Platform.isIOS) {
      double screenWidth = SizeConfig.screenWidth!;
      if (screenWidth == 320) {
        mainContainerConstant = 50;
      } else if (screenWidth == 375) {
        mainContainerConstant = 68;
        isContentPadding = true;
        textFieldHeightConstant = 5.5;
        widthLogo = SizeConfig.blockSizeHorizontal! * 55;
        bannerTextWidth = SizeConfig.blockSizeHorizontal! * 50;
        loginButtonWidth = SizeConfig.blockSizeHorizontal! * 50;
        loginButtonHeight = SizeConfig.blockSizeVertical! * 6.5;
        firstHalfFont = 12.0;
        topSpace = SizeConfig.safeBlockVertical! * 20;
      } else if (screenWidth == 414) {
        mainContainerConstant = 60;
      } else if (screenWidth == 428) {
        mainContainerConstant = 75;
        isContentPadding = false;
        textFieldHeightConstant = 5.5;
        widthLogo = SizeConfig.blockSizeHorizontal! * 65;
        bannerTextWidth = SizeConfig.blockSizeHorizontal! * 80;
        loginButtonWidth = SizeConfig.blockSizeHorizontal! * 70;
        loginButtonHeight = SizeConfig.blockSizeVertical! * 7.3;
        firstHalfFont = 14.0;
        topSpace = SizeConfig.safeBlockVertical! * 20;
      } else {
        mainContainerConstant = 75;
        isContentPadding = false;
        textFieldHeightConstant = 5.5;
        widthLogo = SizeConfig.blockSizeHorizontal! * 65;
        bannerTextWidth = SizeConfig.blockSizeHorizontal! * 80;
        loginButtonWidth = SizeConfig.blockSizeHorizontal! * 70;
        loginButtonHeight = SizeConfig.blockSizeVertical! * 7.3;
        firstHalfFont = 14.0;
        topSpace = SizeConfig.safeBlockVertical! * 20;
      }
    } else if (Platform.isAndroid) {
      mainContainerConstant = 75;
      isContentPadding = false;
      textFieldHeightConstant = 5.5;
      widthLogo = SizeConfig.blockSizeHorizontal! * 65;
      bannerTextWidth = SizeConfig.blockSizeHorizontal! * 80;
      loginButtonWidth = SizeConfig.blockSizeHorizontal! * 70;
      loginButtonHeight = SizeConfig.blockSizeVertical! * 7.3;
      firstHalfFont = 14.0;
      topSpace = SizeConfig.safeBlockVertical! * 20;
    }
  }

  @override
  Widget build(BuildContext context) {
    _loginBloc ??= LoginBloc(context);
    SizeConfig().init(context);
    setAlignmentConstant();

    return Scaffold(
      backgroundColor: ConstantColors.primaryColor,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: SizedBox(
                width: SizeConfig.blockSizeHorizontal! * mainContainerConstant,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: topSpace),
                    _buildLogo(),
                    const SizedBox(height: 40),
                    SizedBox(
                      width: bannerTextWidth,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'Welcome ! Please Login',
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              color: Colors.black87,
                              fontSize: 16,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 50),
                    _buildUserIdRow(),
                    const SizedBox(height: 35),
                    _buildPasswordRow(),
                    const SizedBox(height: 8),
                    _buildDisclaimerWidget(context),
                    const SizedBox(height: 50),
                    _buildLoginButton(context),
                    const SizedBox(height: 30),
                    _buildSignUpWidget(context),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Padding _buildDisclaimerWidget(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: () {
              _loginBloc?.passwordTextController.clear();
              GreekDialogPopupView.messageDialogDisclaimer(
                  context, ConstantMessages.GS_DISCLAIMER);
            },
            child: Text('Disclaimer', style: GreekTextStyle.loginText1),
          ),
          InkWell(
            onTap: () {
              _loginBloc?.passwordTextController.clear();
              GreekNavigator.pushNamed(
                context: context,
                routeName: GreekScreenNames.forgot_password,
              );
            },
            child: Text(ConstantMessages.FP_HEADER_ALERT,
                style: GreekTextStyle.loginText1),
          ),
        ],
      ),
    );
  }

  Widget _buildLogo() {
    return Center(
      child: Image.asset(
        'assets/images/flutter_logo.png',
        fit: BoxFit.fitWidth,
        width: widthLogo,
      ),
    );
  }

  Widget _buildUserIdRow() {
    return SizedBox(
      height: SizeConfig.blockSizeVertical! * textFieldHeightConstant,
      child: Center(
        child: TextFormField(
          inputFormatters: [
            FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))
          ],
          controller: _loginBloc?.userTextController,
          keyboardType: TextInputType.text,
          maxLength: 15,
          style: const TextStyle(
            fontFamily: 'Roboto',
            color: ConstantColors.black,
            fontSize: 14,
            letterSpacing: 1.2,
          ),
          textCapitalization: TextCapitalization.characters,
          autofocus: false,
          decoration: InputDecoration(
            contentPadding: isContentPadding ? EdgeInsets.zero : null,
            counterText: '',
            isDense: true,
            hintText: ConstantMessages.CLIENT_ID,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
            prefixIcon: const ImageIcon(
              AssetImage("assets/images/user_icon.png"),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPasswordRow() {
    return SizedBox(
      height: SizeConfig.blockSizeVertical! * textFieldHeightConstant,
      child: Center(
        child: TextFormField(
          controller: _loginBloc?.passwordTextController,
          autofocus: false,
          obscureText: _obscureText,
          keyboardType: TextInputType.text,
          maxLength: 12,
          style: const TextStyle(
            fontFamily: 'Roboto',
            color: ConstantColors.black,
            fontSize: 14,
            letterSpacing: 1.2,
          ),
          decoration: InputDecoration(
            contentPadding:
                isContentPadding ? EdgeInsets.zero : EdgeInsets.zero,
            counterText: '',
            prefixIcon: const ImageIcon(
              AssetImage("assets/images/password.png"),
            ),
            hintText: ConstantMessages.GS_PASSWORD,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(25.0)),
            suffixIcon: GestureDetector(
              onTap: () {
                setState(() {
                  _obscureText = !_obscureText;
                });
              },
              child: Icon(
                _obscureText ? Icons.visibility : Icons.visibility_off,
                semanticLabel: _obscureText ? 'show password' : 'hide password',
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoginButton(BuildContext context) {
    return Container(
      height: loginButtonHeight,
      width: loginButtonWidth,
      child: TextButton(
        onPressed: _loginBloc?.callLoginAPI,
        child: Text(
          ConstantMessages.LOGIN_HEADER_TXT,
          textScaleFactor: 1.0,
          style: GreekTextStyle.loginButtonText,
        ),
      ),
      decoration: BoxDecoration(
        color: const Color(0xFF127FBA),
        borderRadius: BorderRadius.circular(33.0),
        boxShadow: const [
          BoxShadow(color: Colors.black12, spreadRadius: 2),
        ],
      ),
    );
  }

  Widget _buildSignUpWidget(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: InkWell(
        onTap: () async {
          if (await canLaunchUrl(Uri.parse(GreekURLs.eKycUrl))) {
            await launchUrl(Uri.parse(GreekURLs.eKycUrl));
          } else {
            GreekDialogPopupView.messageDialog(
              context,
              'Could not open url [${GreekURLs.eKycUrl}]',
            );
          }
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FittedBox(
              fit: BoxFit.fitWidth,
              child: Text(
                'Don\'t have an account?',
                style: TextStyle(
                  fontFamily: 'Roboto',
                  color: ConstantColors.primaryColorVitt,
                  fontSize: firstHalfFont,
                ),
              ),
            ),
            const SizedBox(width: 4),
            FittedBox(
              fit: BoxFit.fitWidth,
              child: Text(
                'Open Demat Account',
                style: TextStyle(
                  fontFamily: 'Roboto',
                  color: Color(0xFFFF6600),
                  fontSize: firstHalfFont,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
