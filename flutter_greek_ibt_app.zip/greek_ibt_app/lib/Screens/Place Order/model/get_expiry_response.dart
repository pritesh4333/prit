class GetExpiryResponseModel {
  String? expiry;
  String? lourtoken;

  GetExpiryResponseModel({this.expiry, this.lourtoken});

  GetExpiryResponseModel.fromJson(Map<String, dynamic> json) {
    expiry = json['expiry'].toString();
    lourtoken = json['lourtoken'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['expiry'] = expiry;
    data['lourtoken'] = lourtoken;
    return data;
  }
}
