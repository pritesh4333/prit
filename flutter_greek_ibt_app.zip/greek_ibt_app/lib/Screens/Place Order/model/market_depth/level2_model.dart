import 'package:greek_ibt_app/Screens/Place%20Order/model/market_depth/ask_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/market_depth/bid_model.dart';

class Level2 {
  Ask? ask;
  Bid? bid;

  Bid? getBid() {
    return bid;
  }

  Ask? getAsk() {
    return ask;
  }
}
