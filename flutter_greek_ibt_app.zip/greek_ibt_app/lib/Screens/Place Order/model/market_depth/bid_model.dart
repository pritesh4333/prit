
class Bid{
  String? price;
  String? no;
  String? qty;
  String? total;


  Bid(this.price, this.no, this.qty, this.total);

  Bid.fromJson(Map<String, dynamic> json) {
    price = json['price'].toString();
    no = json['no'].toString();
    qty = json['qty'].toString();
    total = json['total'].toString();
  }
}