
class Ask{
  String? price;
  String? no;
  String? qty;
  String? total;


  Ask(this.price, this.no, this.qty, this.total);

  Ask.fromJson(Map<String, dynamic> json) {
    price = json['price'].toString();
    no = json['no'].toString();
    qty = json['qty'].toString();
    total = json['total'].toString();
  }
}