class ScripInfoResponseModel {
  String? faceValue;
  String? freezeQty;
  String? recordDate;
  String? isin;
  String? symbol;
  String? corpAction;

  ScripInfoResponseModel(
      {this.faceValue,
        this.freezeQty,
        this.recordDate,
        this.isin,
        this.symbol,
        this.corpAction});

  ScripInfoResponseModel.fromJson(Map<String, dynamic> json) {
    faceValue = json['FaceValue'].toString();
    freezeQty = json['FreezeQty'].toString();
    recordDate = json['RecordDate'].toString();
    isin = json['isin'].toString();
    symbol = json['symbol'].toString();
    corpAction = json['CorpAction'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['FaceValue'] = faceValue;
    data['FreezeQty'] = freezeQty;
    data['RecordDate'] = recordDate;
    data['isin'] = isin;
    data['symbol'] = symbol;
    data['CorpAction'] = corpAction;
    return data;
  }
}
