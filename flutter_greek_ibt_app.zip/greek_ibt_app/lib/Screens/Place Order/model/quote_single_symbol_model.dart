class QuoteForSingleSymbolModel {
  double? ylow;
  int? lot;
  String? instrument;
  double? yhigh;
  double? pChange;
  double? last;
  double? high;
  double? change;
  String? open;
  String? oi;
  double? close;
  String? totVol;
  String? symbol;
  double? low;
  String? description;
  int? token;
  String? expiryDate;
  String? strikeprice;
  String? optiontype;
  List<QuoteForSingleSymbolModelLevel2>? level2;
  String? lowRange;
  String? highRange;
  String? isinumber;
  String? atp;
  String? assetToken;
  String? assetLtp;
  String? oiPChange;
  double? ask;
  double? bid;
  String? freezQty;
  String? sqOffQty;
  String? authorizedQty;
  String? totBuyQty;
  String? totSellQty;
  double? tickSize;
  String? ltt;
  String? reason;
  String? ltq;
  String? scripname;

  QuoteForSingleSymbolModel({
    this.ylow,
    this.lot,
    this.instrument,
    this.yhigh,
    this.pChange,
    this.last,
    this.high,
    this.change,
    this.open,
    this.oi,
    this.close,
    this.totVol,
    this.symbol,
    this.low,
    this.description,
    this.token,
    this.expiryDate,
    this.strikeprice,
    this.optiontype,
    this.level2,
    this.lowRange,
    this.highRange,
    this.isinumber,
    this.atp,
    this.assetToken,
    this.assetLtp,
    this.oiPChange,
    this.ask,
    this.bid,
    this.freezQty,
    this.sqOffQty,
    this.authorizedQty,
    this.totBuyQty,
    this.totSellQty,
    this.tickSize,
    this.ltt,
    this.reason,
    this.ltq,
    this.scripname,
  });

  QuoteForSingleSymbolModel.fromJson(Map<String, dynamic> json) {
    ylow = double.parse(json['ylow'].toString());
    lot = int.parse(json['lot'].toString());
    instrument = json['instrument'].toString();
    yhigh = double.parse(json['yhigh'].toString());
    pChange = double.parse(json['p_change'].toString());
    last = double.parse(json['last'].toString());
    high = double.parse(json['high'].toString());
    change = double.parse(json['change'].toString());
    open = json['open'].toString();
    oi = json['oi'].toString();
    close = double.parse(json['close'].toString());
    totVol = json['tot_vol'].toString();
    symbol = json['symbol'].toString();
    low = double.parse(json['low'].toString());
    description = json['description'].toString();
    token = int.parse(json['token'].toString());
    expiryDate = json['expiryDate'].toString();
    strikeprice = json['strikeprice'].toString();
    optiontype = json['optiontype'].toString();
    lowRange = json['lowRange'].toString();
    highRange = json['highRange'].toString();
    isinumber = json['isinumber'].toString();
    atp = json['atp'].toString();
    assetToken = json['assetToken'].toString();
    assetLtp = json['assetLtp'].toString();
    oiPChange = json['oi_pChange'].toString();
    ask = double.parse(json['ask'].toString());
    bid = double.parse(json['bid'].toString());
    freezQty = json['freezQty'].toString();
    sqOffQty = json['sqOffQty'].toString();
    authorizedQty = json['authorizedQty'].toString();
    totBuyQty = json['tot_buyQty'].toString();
    totSellQty = json['tot_sellQty'].toString();
    tickSize = double.parse(json['tickSize'].toString());
    ltt = json['ltt'].toString();
    reason = json['reason'].toString();
    ltq = json['ltq'].toString();
    scripname = json['scripname'].toString();
    if (scripname == '' || scripname == null) {
      scripname = description;
    }
    if (json['level2'] != null) {
      level2 = <QuoteForSingleSymbolModelLevel2>[];
      json['level2'].forEach((v) {
        level2?.add(QuoteForSingleSymbolModelLevel2.fromJson(v));
      });
    }
  }
}

class QuoteForSingleSymbolModelLevel2 {
  QuoteForSingleSymbolModelBidAsk? bid;
  QuoteForSingleSymbolModelBidAsk? ask;

  QuoteForSingleSymbolModelLevel2({this.bid, this.ask});

  QuoteForSingleSymbolModelLevel2.fromJson(Map<String, dynamic> json) {
    bid = json['bid'] != null ? QuoteForSingleSymbolModelBidAsk.fromJson(json['bid']) : null;
    ask = json['ask'] != null ? QuoteForSingleSymbolModelBidAsk.fromJson(json['ask']) : null;
  }
}

class QuoteForSingleSymbolModelBidAsk {
  double? price;
  int? no;
  int? qty;

  QuoteForSingleSymbolModelBidAsk({this.price, this.no, this.qty});

  QuoteForSingleSymbolModelBidAsk.fromJson(Map<String, dynamic> json) {
    price = double.parse(json['price']?.toString() ?? '0');
    no = int.parse(json['no']?.toString() ?? '0');
    qty = int.parse(json['qty']?.toString() ?? '0');
  }
}
