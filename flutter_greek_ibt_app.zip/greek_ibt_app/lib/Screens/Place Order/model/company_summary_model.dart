class CompanySummaryModel {
  String? bsecode;
  String? symbol;
  String? coCode;
  String? coName;
  String? complongname;
  String? isin;
  String? industryname;
  String? eps;
  String? pe;
  String? pb;

  String? divyield;
  String? bsemcap;
  String? nsemcap;
  String? fv;
  String? bv;

  CompanySummaryModel.fromJson(Map<String, dynamic> json) {
    bsecode = json['bsecode'].toString();
    symbol = json['symbol'].toString();
    coCode = json['co_code'].toString();
    coName = json['co_name'].toString();
    complongname = json['complongname'].toString();
    isin = json['isin'].toString();
    industryname = json['industryname'].toString();
    eps = json['eps'].toString();
    pe = json['pe'].toString();
    pb = json['pb'].toString();
    divyield = json['divyield'].toString();
    bsemcap = json['bsemcap'].toString();
    nsemcap = json['nsemcap'].toString();
    fv = json['fv'].toString();
    bv = json['bv'].toString();
  }
}
