class GetStrikeResponseModel {
  String? lourtoken;
  String? strikeprice;

  GetStrikeResponseModel({this.lourtoken, this.strikeprice});

  GetStrikeResponseModel.fromJson(Map<String, dynamic> json) {
    lourtoken = json['lourtoken'].toString();
    strikeprice = json['strikeprice'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lourtoken'] = lourtoken;
    data['strikeprice'] = strikeprice;
    return data;
  }
}
