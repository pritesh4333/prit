class TechnicalsModel{

  String? pivot;
  String? support1;
  String? support2;
  String? support3;
  String? resist1;
  String? resist2;
  String? resist3;


  TechnicalsModel.fromJson(Map<String, dynamic> json) {
    pivot = json['pivot'].toString();
    support1 = json['support1'].toString();
    support2 = json['support2'].toString();
    support3 = json['support3'].toString();
    resist1 = json['resist1'].toString();
    resist2 = json['resist2'].toString();
    resist3 = json['resist3'].toString();
  }
}