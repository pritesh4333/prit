class OptionChainResponseModel {
  List<Data>? data;

  OptionChainResponseModel({this.data});

  OptionChainResponseModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? lOurToken;
  String? lOpenInterest;
  String? lPrevOpenInterest;
  String? lVolume;
  String? dNetChange;
  String? lBidQty;
  String? lBidPrice;
  String? lAskQty;
  String? askPrice;
  String? lClosingPrice;
  String? strike;
  String? callput;
  String? expiryDate;

  Data({this.lOurToken, this.lOpenInterest, this.lPrevOpenInterest, this.lVolume, this.dNetChange, this.lBidQty, this.lBidPrice, this.lAskQty, this.askPrice, this.lClosingPrice, this.strike, this.callput, this.expiryDate});

  Data.fromJson(Map<String, dynamic> json) {
    lOurToken = json['lOurToken'].toString();
    lOpenInterest = json['lOpenInterest'].toString();
    lPrevOpenInterest = json['lPrevOpenInterest'].toString();
    lVolume = json['lVolume'].toString();
    dNetChange = json['dNetChange'].toString();
    lBidQty = json['lBidQty'].toString();
    lBidPrice = json['lBidPrice'].toString();
    lAskQty = json['lAskQty'].toString();
    askPrice = json['AskPrice'].toString();
    lClosingPrice = json['lClosingPrice'].toString();
    strike = json['strike'].toString();
    callput = json['callput'].toString();
    expiryDate = json['expiryDate'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lOurToken'] = lOurToken;
    data['lOpenInterest'] = lOpenInterest;
    data['lPrevOpenInterest'] = lPrevOpenInterest;
    data['lVolume'] = lVolume;
    data['dNetChange'] = dNetChange;
    data['lBidQty'] = lBidQty;
    data['lBidPrice'] = lBidPrice;
    data['lAskQty'] = lAskQty;
    data['AskPrice'] = askPrice;
    data['lClosingPrice'] = lClosingPrice;
    data['strike'] = strike;
    data['callput'] = callput;
    data['expiryDate'] = expiryDate;
    return data;
  }
}
