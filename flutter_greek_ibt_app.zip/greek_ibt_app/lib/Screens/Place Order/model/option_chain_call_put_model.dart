import 'package:intl/intl.dart';

class OptionChainResponseModel {
  double? strikePrice;
  OptionChainResponseCallPutModel? call;
  OptionChainResponseCallPutModel? put;

  OptionChainResponseModel.fromJson(List<Map<String, dynamic>> json) {
    call = OptionChainResponseCallPutModel.fromJson(json.first);
    put = OptionChainResponseCallPutModel.fromJson(json.last);

    strikePrice = call?.strike ?? put?.strike;
  }
}

class OptionChainResponseCallPutModel {
  int? lOurToken;
  double? lOpenInterest;
  double? lPrevOpenInterest;
  double? lVolume;
  double? dNetChange;
  int? lBidQty;
  double? lBidPrice;
  int? lAskQty;
  double? askPrice;
  double? lClosingPrice;
  double? strike;
  String? callput;
  String? expiryDate;

  double? oiChange;
  double? change;
  double ltp = 0.00;

  OptionChainResponseCallPutModel.fromJson(Map<String, dynamic> json) {
    lOurToken = int.parse(json['lOurToken']?.toString() ?? '');
    lOpenInterest = double.parse(json['lOpenInterest']?.toString() ?? '');
    lPrevOpenInterest =
        double.parse(json['lPrevOpenInterest']?.toString() ?? '');
    lVolume = double.parse(json['lVolume']?.toString() ?? '');
    dNetChange = double.parse(json['dNetChange']?.toString() ?? '');
    lBidQty = int.parse(json['lBidQty']?.toString() ?? '');
    lBidPrice = double.parse(json['lBidPrice']?.toString() ?? '');
    lAskQty = int.parse(json['lAskQty']?.toString() ?? '');
    askPrice = double.parse(json['AskPrice']?.toString() ?? '');
    lClosingPrice = double.parse(json['lClosingPrice']?.toString() ?? '');
    strike = double.parse(json['strike']?.toString() ?? '');
    callput = json['callput']?.toString();
    callput = json['ltp']?.toString();

    final timestamp = int.parse(json['expiryDate']?.toString() ?? '');
    expiryDate = DateFormat('ddMMMyyyy')
        .format(DateTime.fromMillisecondsSinceEpoch(timestamp * 1000));

    change = (lOpenInterest ?? 0.00) - (lPrevOpenInterest ?? 0.00);

    ltpCalculate();
  }

  void ltpCalculate() {
    double diffCall = (lOpenInterest ?? 0.00) - (lPrevOpenInterest ?? 0.00);
    double abschange = 0.00;
    if (diffCall < 0) {
      abschange = diffCall.abs();
    } else {
      abschange = diffCall;
    }

    double? oIChangePerCall =
        (abschange * 100) / double.parse(lPrevOpenInterest.toString());

    if (!(((abschange * 100) / double.parse(lPrevOpenInterest.toString()))
        .isNaN)) {
      if (oIChangePerCall.toStringAsFixed(2) != "infinity") {
        oiChange = double.parse(oIChangePerCall.toStringAsFixed(2));
      } else {
        oiChange = 0.00;
      }
    } else {
      oiChange = 0.00;
    }
  }
}
