// ignore_for_file: non_constant_identifier_names

import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';

class OrderDetailsModel {
  //  For Confirm Dialog Only
  String? productType;
  OrderAction? orderAction;
  String? disQuantity;
  String? orderPrice;

  //  For cancel Order request only
  String? gorderid_Cancel;
  String? lexchangeOrderNo1_Cancel;
  String? pending_qty_Cancel;
  String? eorderid_Cancel;
  String? qty_filled_today_Cancel;
  String? lu_time_exchange_Cancel;
  String? pending_disclosed_qty_Cancel;

  //for Modify order
  String? gorderid_Modify;
  String? lexchangeOrderNo1_Modify;
  String? pending_qty_Modify;
  String? eorderid_Modify;
  String? qty_filled_today_Modify;
  String? lu_time_exchange_Modify;
  String? iomRuleNo;
  String? pending_disclosed_qty_Modify;
  bool? isSqOffOrder = false;
  String? TickSize;
  String? Multiplier;
  String? NetQty;

  // for newOrder and Common
  String? gcid;
  String? trigger_price;
  String? gtoken;
  String? is_preopen_order;
  String? exchange;
  String? is_post_closed;
  String? amo;
  String? qty;
  String? lot;
  String? tradeSymbol;
  String? offline;
  String? gtdExpiry;
  String? validity;
  String? disclosed_qty;
  String? price;
  String? order_type;
  String? OrderStatuse;

  bool isModifyObj = false;

  Map<String, dynamic> toConfirmDialog() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Product type'] = productType;
    data['Action'] = (orderAction == OrderAction.buy) ? 'BUY' : 'SELL';
    data['qty'] = qty;
    data['lot'] = lot;
    data['Order type'] = order_type;
    data['DisQuantity'] = disQuantity;
    data['Price'] = orderPrice;
    data['SL Trigger Price'] = trigger_price;
    data['Validity'] = validity;

    /*final keys = data.keys.toList();

    final titleKey = keys[index];
    final titlevalue = data[titleKey];*/

    data.removeWhere((key, value) => (value == null));
    return data;
  }

  Map<String, dynamic> toNewOrder() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gcid'] = gcid;
    data['trigger_price'] = ((trigger_price != null) && (trigger_price!.isNotEmpty)) ? double.parse(trigger_price!).toStringAsFixed(2) : '0';
    data['side'] = (orderAction == OrderAction.buy) ? '1' : '2';
    data['gtoken'] = gtoken;
    data['is_preopen_order'] = is_preopen_order;
    data['exchange'] = exchange;
    data['is_post_closed'] = is_post_closed;
    data['amo'] = amo;
    data['qty'] = qty;
    data['lot'] = lot;
    data['tradeSymbol'] = tradeSymbol;
    data['offline'] = offline;
    data['gtdExpiry'] = gtdExpiry;
    data['validity'] = GreekBase().getValidityTypeFromValidityName(validity!);
    data['product'] = GreekBase().getProductTokenFromProductName(productType!);
    data['order_type'] = GreekBase().getOrderTypeFromShortOrderName(order_type!);
    data['disclosed_qty'] = (disclosed_qty?.isEmpty ?? true) ? '0' : disclosed_qty;
    data['price'] = ((orderPrice != null) && (orderPrice!.isNotEmpty)) ? double.parse(orderPrice!).toStringAsFixed(2) : '';
    return data;
  }

  Map<String, dynamic> toCancelOrder() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gcid'] = gcid;
    data['trigger_price'] = ((trigger_price != null) && (trigger_price!.isNotEmpty)) ? double.parse(trigger_price!).toStringAsFixed(2).toString() : '0';
    data['side'] = (orderAction == OrderAction.buy) ? '1' : '2';
    data['gtoken'] = gtoken;
    data['is_preopen_order'] = is_preopen_order;
    data['exchange'] = exchange;
    data['is_post_closed'] = is_post_closed;
    data['amo'] = amo;
    data['qty'] = qty;
    data['lot'] = lot;
    data['tradeSymbol'] = tradeSymbol;
    data['offline'] = offline;
    data['gtdExpiry'] = gtdExpiry;
    /*data['validity'] = GreekBase().getValidityTypeFromValidityName(validity!);
    data['product'] = GreekBase().getProductTokenFromProductName(productType!);
    data['order_type'] = GreekBase().getOrderTypeFromOrderName(order_type!);*/
    data['validity'] = validity; //GreekBase().getValidityTypeFromValidityName(validity!);
    data['product'] = productType;
    data['order_type'] = order_type;
    data['disclosed_qty'] = (disclosed_qty?.isEmpty ?? true) ? '0' : disclosed_qty;
    data['price'] = ((price != null) && (price!.isNotEmpty)) ? double.parse(price!).toStringAsFixed(2) : '';
    data['gorderid'] = gorderid_Cancel;
    data['lexchangeOrderNo1'] = lexchangeOrderNo1_Cancel;
    data['pending_qty'] = pending_qty_Cancel;
    data['eorderid'] = eorderid_Cancel;
    data['qty_filled_today'] = qty_filled_today_Cancel;
    data['lu_time_exchange'] = lu_time_exchange_Cancel;
    data['pending_disclosed_qty'] = pending_disclosed_qty_Cancel;

    return data;
  }

  Map<String, dynamic> toModifyOrder() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gcid'] = gcid;
    data['trigger_price'] = ((trigger_price != null) && (trigger_price!.isNotEmpty)) ? double.parse(trigger_price!).toStringAsFixed(2) : '0';
    data['side'] = (orderAction == OrderAction.buy) ? '1' : '2';
    data['gtoken'] = gtoken;
    data['is_preopen_order'] = is_preopen_order;
    data['exchange'] = exchange;
    data['is_post_closed'] = is_post_closed;
    data['amo'] = amo ?? '0';
    data['qty'] = qty;
    data['lot'] = lot;
    data['tradeSymbol'] = tradeSymbol;
    data['offline'] = offline;
    data['gtdExpiry'] = gtdExpiry; //gtdExpiry;
    data['validity'] = GreekBase().getValidityTypeFromValidityName(validity!);
    data['product'] = GreekBase().getProductTokenFromProductName(productType ?? "");
    data['order_type'] = GreekBase().getOrderTypeFromShortOrderName(order_type ?? "");
    data['disclosed_qty'] = (disclosed_qty?.isEmpty ?? true) ? "0" : disclosed_qty;
    data['price'] = ((price != null) && (price!.isNotEmpty)) ? double.parse(price!).toStringAsFixed(2) : '';
    data['gorderid'] = gorderid_Modify;
    data['lexchangeOrderNo1'] = lexchangeOrderNo1_Modify ?? '0';
    data['pending_qty'] = pending_qty_Modify;
    data['eorderid'] = eorderid_Modify;
    data['qty_filled_today'] = qty_filled_today_Modify;
    data['lu_time_exchange'] = lu_time_exchange_Modify;
    data['iomRuleNo'] = iomRuleNo;
    data['pending_disclosed_qty'] = (pending_disclosed_qty_Modify == null) ? "" : pending_disclosed_qty_Modify;
    data['iStrategyNo'] = '0';
    data['isSqOffOrder'] = isSqOffOrder;
    data['TickSize'] = TickSize;
    data['Multiplier'] = Multiplier;
    data['NetQty'] = NetQty;

    return data;
  }
}
