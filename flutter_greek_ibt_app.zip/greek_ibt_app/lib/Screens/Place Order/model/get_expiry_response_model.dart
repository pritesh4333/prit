import 'package:intl/intl.dart';

class GetExpiryResponseModel {
  String? expiry;
  String? lourtoken;
  double? ltp;
  double? change;
  double? pChange;
  String formatedDate = "";

  GetExpiryResponseModel({
    this.expiry,
    this.lourtoken,
    this.ltp = 0.00,
    this.change = 0.00,
    this.pChange = 0.00,
  });

  GetExpiryResponseModel.fromJson(Map<String, dynamic> json) {
    expiry = json['expiry'].toString();
    formatedDate = DateFormat('dd MMM').format(DateTime.fromMillisecondsSinceEpoch(int.parse(expiry ?? '') * 1000));
    lourtoken = json['lourtoken'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['expiry'] = expiry;
    data['lourtoken'] = lourtoken;
    return data;
  }
}
