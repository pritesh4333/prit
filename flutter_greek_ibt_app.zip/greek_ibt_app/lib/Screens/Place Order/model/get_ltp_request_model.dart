class GetLTPModel {
  String? ltp;
  String? change;
  String? closingprice;

  GetLTPModel({this.ltp, this.change, this.closingprice});

  GetLTPModel.fromJson(Map<String, dynamic> json) {
    ltp = json['ltp'];
    change = json['change'];
    closingprice = json['closingprice'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ltp'] = ltp;
    data['change'] = change;
    data['closingprice'] = closingprice;
    return data;
  }
}
