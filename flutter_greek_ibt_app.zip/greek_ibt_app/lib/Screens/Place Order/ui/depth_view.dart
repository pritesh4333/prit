import 'dart:developer';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/bloc/overview_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/srip_info_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/technicals_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/quote_single_symbol_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';

class OverviewDepthScreen extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;
  final TabController? controller;

  const OverviewDepthScreen({Key? key, this.placeOrderBloc, this.controller})
      : super(key: key);

  @override
  _OverviewDepthScreenState createState() => _OverviewDepthScreenState();
}

class _OverviewDepthScreenState extends State<OverviewDepthScreen> {
  OverviewBloc? _overviewBloc;

  String? varValue;
  String? varPercentValue;
  String? elmValue;
  String? elmPercentValue;

  String? varTxt;
  String? varPercentTxt;
  String? elmTxt;
  String? elmPercentTxt;
  String? resist1, resist2, resist3, pivot, support1, support2, support3;
  TabController? tabController;
  @override
  void initState() {
    super.initState();
    widget.placeOrderBloc!.appBarSizeSubject.sink.add(false);

    _overviewBloc ??= OverviewBloc(
        context: context,
        orderMode: widget.placeOrderBloc?.orderMode,
        orderAction: widget.placeOrderBloc?.orderAction,
        orderToken: widget.placeOrderBloc?.orderToken);
    tabController = widget.controller;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Flexible(
          fit: FlexFit.tight,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Column(
                  children: [
                    marketDepthView(context),
                    overviewContent(context),
                    pivotlevle(context),
                  ],
                ),
              ],
            ),
          ),
        ),
        Visibility(
          visible: widget.placeOrderBloc?.orderMode == OrderMode.newOrder
              ? true
              : false,
          child: _containerFour(),
        ),
      ],
    );
  }

  Widget overviewContent(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: StreamBuilder<QuoteForSingleSymbolModel?>(
        stream: widget.placeOrderBloc?.marketPictureObserver,
        builder: (ltpContext, snapshot) {
          if (snapshot.hasData) {
            SocketIOManager()
                .securityInfoRequest(snapshot.data?.token.toString() ?? '');
            return ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(), //Optional
                children: [
                  stockDetailView(snapshot),
                ]);
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget stockDetailView(AsyncSnapshot<QuoteForSingleSymbolModel?> snapshot1) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        stockDetailViewTitle(),
        /*Container(
          margin: EdgeInsets.only(left: 5, right: 2),
          height: 1,
          color: Colors.grey,
        ),*/
        const SizedBox(height: 10),
        stockDetailViewTwo(snapshot1),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }

  Widget stockDetailViewTitle() {
    return Container(
      padding: const EdgeInsets.only(left: 5, top: 10),
      margin: const EdgeInsets.only(left: 5, right: 5, top: 10),
      width: MediaQuery.of(context).size.width,
      color: const Color(0xffF6F6F6),
      child: Text(
        "Stock Details",
        style: GreekTextStyle.heading18,
      ),
    );
  }

  Widget stockDetailViewTwo(
      AsyncSnapshot<QuoteForSingleSymbolModel?> snapshot1) {
    String isinumber = widget
            .placeOrderBloc
            ?.orderResponseArray[
                widget.placeOrderBloc?.currentExchangeIndex ?? 0]
            ?.isinumber
            .toString()
            .trim() ??
        '0';
    if (isinumber == "") {
      isinumber = "0";
    }
    return FutureBuilder<List<ScripInfoResponseModel?>>(
      future: _overviewBloc?.callScripInfo(),
      builder: (context, snapshot) {
        int snapshotLength = 0;
        snapshotLength = snapshot.hasData ? snapshot.data?.length ?? 0 : 0;
        for (int i = 0; i <= snapshotLength; i++) {
          String close = '${snapshot1.data?.close ?? '0'}';
          String fiftytwoweeklow = '${snapshot1.data?.ylow ?? '0'}';
          String fiftytwoweekhigh = '${snapshot1.data?.yhigh ?? '0'}';
          String upcircuit = snapshot1.data?.highRange ?? '0';
          String lowcircuit = snapshot1.data?.lowRange ?? '0';
          String daylow = '${snapshot1.data?.low ?? '0'}';
          String ltq = snapshot1.data?.ltq ?? '0';
          fiftytwoweeklow =
              double.parse(fiftytwoweeklow) == 0.0 ? daylow : fiftytwoweeklow;

          return Container(
            height: 140,
            margin: const EdgeInsets.only(left: 5, right: 5, top: 2),
            color: Colors.white,
            child: Row(
              children: [
                Flexible(
                  flex: 1,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5, right: 5, top: 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: ((widget.placeOrderBloc?.orderToken
                                            .toAssetType() ==
                                        "fno") ||
                                    (widget.placeOrderBloc?.orderToken
                                            .toAssetType() ==
                                        "commodity") ||
                                    (widget.placeOrderBloc?.orderToken
                                            .toAssetType() ==
                                        "currency"))
                                ? [
                                    Text(
                                      "Open",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "Day's High",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "Volume",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "Upper Circuit",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "ATP",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                  ]
                                : [
                                    Text(
                                      "Open",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "Day's High",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "Volume",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "Upper Circuit",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    AutoSizeText(
                                      "52 Week High",
                                      minFontSize: 13,
                                      maxLines: 1,
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                    Text(
                                      "ATP",
                                      style: GreekTextStyle
                                          .overview_stockdetails_info,
                                    ),
                                  ],
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: ((widget.placeOrderBloc?.orderToken
                                            .toAssetType() ==
                                        "fno") ||
                                    (widget.placeOrderBloc?.orderToken
                                            .toAssetType() ==
                                        "commodity") ||
                                    (widget.placeOrderBloc?.orderToken
                                            .toAssetType() ==
                                        "currency"))
                                ? [
                                    Text(
                                      double.parse(
                                              snapshot1.data?.open ?? "0.00")
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot1.data?.high.toString() ??
                                                  '0.00')
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot1.data?.totVol ?? '0')
                                          .toString(),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(upcircuit)
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot1.data?.atp.toString() ??
                                                  '0.00')
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                  ]
                                : [
                                    Text(
                                      double.parse(
                                              snapshot1.data?.open ?? "0.00")
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot1.data?.high.toString() ??
                                                  '0.00')
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot1.data?.totVol ?? '0')
                                          .toInt()
                                          .toString(),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(upcircuit)
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(fiftytwoweekhigh)
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot1.data?.atp.toString() ??
                                                  '0.00')
                                          .toFormateDicemalPoint(
                                              token: widget
                                                  .placeOrderBloc?.orderToken),
                                      style: GreekTextStyle
                                          .overview_stockdetails_infoValue,
                                    ),
                                  ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: 1,
                  height: MediaQuery.of(context).size.height,
                  margin: const EdgeInsets.only(top: 2.0, bottom: 2.0),
                  color: Colors.grey,
                ),
                Flexible(
                  flex: 1,
                  child: StreamBuilder<Map<String, dynamic>?>(
                    stream: SocketIOManager().orderResponseObservable,
                    builder: (streamContext, snapshot) {
                      if (snapshot.data != null) {
                        final keys = snapshot.data?.keys.toList();
                        int keyLength = keys?.length ?? 0;

                        if (keyLength > 0) {
                          for (var item in keys ?? []) {
                            if (item ==
                                IrisResponseStreamingType
                                    .SymbolVarMarginResponse) {
                              final symbolVarMarginResponse =
                                  snapshot.data?[item];
                              if (symbolVarMarginResponse != null) {
                                if (_overviewBloc?.orderToken
                                        .toAssetType()
                                        .toString()
                                        .toUpperCase()
                                        .compareTo('EQUITY') ==
                                    0) {
                                  varValue =
                                      symbolVarMarginResponse['VARMargin'];
                                  varPercentValue =
                                      symbolVarMarginResponse['VARPercentage'];
                                  elmValue =
                                      symbolVarMarginResponse['ELMMargin'];
                                  elmPercentValue =
                                      symbolVarMarginResponse['ELMPercentage'];

                                  varTxt = 'Var';
                                  varPercentTxt = 'Var%';
                                  elmTxt = 'ELM';
                                  elmPercentTxt = 'ELM%';
                                } else {
                                  varValue =
                                      symbolVarMarginResponse['ExposMargin'];
                                  varPercentValue = symbolVarMarginResponse[
                                      'ExposMargin_Per'];
                                  elmValue =
                                      symbolVarMarginResponse['SPANMargin_Buy'];
                                  elmPercentValue = symbolVarMarginResponse[
                                      'SPANMargin_Sell'];

                                  varTxt = 'ExposureMargin';
                                  varPercentTxt = 'ExposureMargin(%)';
                                  elmTxt = 'SpanMargin(Buy)';
                                  elmPercentTxt = 'SpanMargin(Sell)';
                                }

                                log('symbolVar =====>' +
                                    symbolVarMarginResponse.toString());
                                log('Var =====>' + varValue!);
                                // HoldingResponseModel.fromJson(holdingResponse);
                              }
                            }
                          }
                        }
                      } else {
                        if (_overviewBloc?.orderToken
                                .toAssetType()
                                .toString()
                                .toUpperCase()
                                .compareTo('EQUITY') ==
                            0) {
                          varTxt = 'Var';
                          varPercentTxt = 'Var%';
                          elmTxt = 'ELM';
                          elmPercentTxt = 'ELM%';
                        } else {
                          varTxt = 'ExposureMargin';
                          varPercentTxt = 'ExposureMargin(%)';
                          elmTxt = 'SpanMargin(Buy)';
                          elmPercentTxt = 'SpanMargin(Sell)';
                        }
                      }
                      return Padding(
                        padding:
                            const EdgeInsets.only(left: 5, right: 5, top: 2),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: ((widget.placeOrderBloc?.orderToken
                                          .toAssetType() ==
                                      "fno") ||
                                  (widget.placeOrderBloc?.orderToken
                                          .toAssetType() ==
                                      "commodity") ||
                                  (widget.placeOrderBloc?.orderToken
                                          .toAssetType() ==
                                      "currency"))
                              ? [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Close",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        close == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(close)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Day's Low",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        daylow == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(daylow)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "LTQ",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        ltq == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(ltq)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Lower Circuit",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        lowcircuit == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(lowcircuit)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "ISIN",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        isinumber,
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                ]
                              : [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Close",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        close == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(close)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Day Low",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        daylow == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(daylow)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "LTQ",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        ltq == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(ltq)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Lower Circuit",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        lowcircuit == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(lowcircuit)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "52 Week Low",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        fiftytwoweeklow == "null"
                                            ? double.parse("0.00")
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken)
                                            : double.parse(fiftytwoweeklow)
                                                .toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken),
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "ISIN",
                                        style: GreekTextStyle
                                            .overview_stockdetails_info,
                                      ),
                                      Text(
                                        isinumber,
                                        style: GreekTextStyle
                                            .overview_stockdetails_infoValue,
                                      ),
                                    ],
                                  ),
                                ],
                        ),
                      );

                      /* Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "ISIN",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  "FACE VALUE",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${varTxt}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${varPercentTxt}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${ELMTxt}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${ELMPercentTxt}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                              ],
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  '${isinumber}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  faceValue != '' ? faceValue : '',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${varValue ?? ''}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${varPercentValue ?? ''}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${ELMValue ?? ''}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                                Text(
                                  '${ELMPercentValue ?? ''}',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.normal),
                                ),
                              ],
                            )
                          ],
                        ), */
                    },
                  ),
                ),
              ],
            ),
          );
        }
        return Container();
      },
    );
  }

  Widget marketDepthView(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(5),
          margin: const EdgeInsets.only(left: 5, right: 0, top: 10),
          width: MediaQuery.of(context).size.width,
          color: const Color(0xffF6F6F6),
          child: Text(
            "Depth",
            style: GreekTextStyle.heading18,
          ),
        ),
        /* Container(
          margin: EdgeInsets.only(left: 0, right: 0),
          height: 1,
          color: Colors.grey,
        ),*/
        Container(
          margin: const EdgeInsets.only(left: 0, right: 0),
          color: ConstantColors.white,
          child: StreamBuilder<QuoteForSingleSymbolModel?>(
            stream: widget.placeOrderBloc?.marketPictureObserver,
            builder: (streamContext, snapshot) {
              if ((snapshot.data?.level2?.length ?? 0) <= 0) {
                return SizedBox(
                  height: 135,
                  child: Center(child: GreekBase().noDataAvailableView()),
                );
              }

              return Column(
                children: [
                  Container(
                    margin: const EdgeInsets.all(0.0),
                    child: ListView.separated(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: (snapshot.data?.level2?.length ?? 0) + 1,
                      separatorBuilder: (_, index) => (index != 0)
                          ? const SizedBox(height: 3)
                          : const SizedBox(height: 0, width: 0),
                      itemBuilder: (itemContext, index) {
                        int decimal = 2;
                        (widget
                                    .placeOrderBloc
                                    ?.orderResponseArray[widget.placeOrderBloc
                                            ?.currentExchangeIndex ??
                                        0]
                                    ?.token
                                    ?.toAssetType()
                                    .toString() ==
                                'currency')
                            ? decimal = 4
                            : decimal = 2;
                        switch (index) {
                          case 0:
                            return Container(
                              color: const Color(0xffF6F6F6),
                              padding: const EdgeInsets.all(5),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        'Buyers',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.center,
                                      child: Text(
                                        'QTY',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        'Price',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10.0,
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        'Price',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.center,
                                      child: Text(
                                        'QTY',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        'Seller',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );

                          default:
                            return Container(
                              height: 25,
                              padding:
                                  const EdgeInsets.only(left: 8.0, right: 8.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerLeft,
                                      color: index % 2 == 0
                                          ? const Color(0xFFF1F1F1)
                                              .withOpacity(1)
                                          : const Color(0xFFFFFFFF)
                                              .withOpacity(0.4),
                                      child: AutoSizeText(
                                        snapshot.data?.level2
                                                ?.elementAt(index - 1)
                                                .bid
                                                ?.no
                                                ?.toString() ??
                                            '0',
                                        minFontSize: 13,
                                        maxLines: 1,
                                        style: GreekTextStyle
                                            .market_depth_row_text_style2,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.center,
                                      color: index % 2 == 0
                                          ? const Color(0xFFF1F1F1)
                                              .withOpacity(1)
                                          : const Color(0xFFFFFFFF)
                                              .withOpacity(0.4),
                                      child: AutoSizeText(
                                        snapshot.data?.level2
                                                ?.elementAt(index - 1)
                                                .bid
                                                ?.qty
                                                ?.toString() ??
                                            '0',
                                        minFontSize: 13,
                                        maxLines: 1,
                                        style: GreekTextStyle
                                            .market_depth_row_text_style2,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    fit: FlexFit.loose,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerRight,
                                      color: index % 2 == 0
                                          ? const Color(0xFFF1F1F1)
                                              .withOpacity(1)
                                          : const Color(0xFFFFFFFF)
                                              .withOpacity(0.4),
                                      child: AutoSizeText(
                                        snapshot.data?.level2
                                                ?.elementAt(index - 1)
                                                .bid
                                                ?.price
                                                ?.toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken) ??
                                            '0.00',
                                        style: GreekTextStyle
                                            .market_depth_row_text_style2,
                                        maxLines: 1,
                                        minFontSize: 13,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 10.0,
                                    color: index % 2 == 0
                                        ? const Color(0xFFF1F1F1).withOpacity(1)
                                        : const Color(0xFFFFFFFF)
                                            .withOpacity(0.4),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerLeft,
                                      color: index % 2 == 0
                                          ? const Color(0xFFF1F1F1)
                                              .withOpacity(1)
                                          : const Color(0xFFFFFFFF)
                                              .withOpacity(0.4),
                                      child: AutoSizeText(
                                        snapshot.data?.level2
                                                ?.elementAt(index - 1)
                                                .ask
                                                ?.price
                                                ?.toFormateDicemalPoint(
                                                    token: widget.placeOrderBloc
                                                        ?.orderToken) ??
                                            '0.00',
                                        minFontSize: 13,
                                        maxLines: 1,
                                        style: GreekTextStyle
                                            .market_depth_row_text_style1,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.center,
                                      color: index % 2 == 0
                                          ? const Color(0xFFF1F1F1)
                                              .withOpacity(1)
                                          : const Color(0xFFFFFFFF)
                                              .withOpacity(0.4),
                                      child: AutoSizeText(
                                        snapshot.data?.level2
                                                ?.elementAt(index - 1)
                                                .ask
                                                ?.qty
                                                ?.toString() ??
                                            '0',
                                        minFontSize: 13,
                                        maxLines: 1,
                                        style: GreekTextStyle
                                            .market_depth_row_text_style1,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      padding: const EdgeInsets.all(0.0),
                                      alignment: Alignment.centerRight,
                                      color: index % 2 == 0
                                          ? const Color(0xFFF1F1F1)
                                              .withOpacity(1)
                                          : const Color(0xFFFFFFFF)
                                              .withOpacity(0.4),
                                      child: AutoSizeText(
                                        snapshot.data?.level2
                                                ?.elementAt(index - 1)
                                                .ask
                                                ?.no
                                                ?.toString() ??
                                            '0',
                                        minFontSize: 13,
                                        maxLines: 1,
                                        style: GreekTextStyle
                                            .market_depth_row_text_style1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                        }
                      },
                    ),
                  ),
                  Container(
                    color: const Color(0xffF6F6F6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          margin: const EdgeInsets.all(0.0),
                          padding:
                              const EdgeInsets.only(left: 0, right: 0, top: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Text(
                                'Total Buy Qty  ',
                                style: GreekTextStyle.marketDepthTotal,
                              ),
                              Text(
                                double.parse(widget
                                            .placeOrderBloc
                                            ?.orderResponseArray[widget
                                                .placeOrderBloc!
                                                .currentExchangeIndex]
                                            ?.totBuyQty ??
                                        "0")
                                    .toInt()
                                    .toString(),
                                style: GreekTextStyle.headline20,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.all(0.0),
                          padding: const EdgeInsets.only(
                              left: 0, right: 10, top: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Text(
                                'Total Sell Qty  ',
                                style: GreekTextStyle.marketDepthTotal,
                              ),
                              Text(
                                double.parse(widget
                                            .placeOrderBloc
                                            ?.orderResponseArray[widget
                                                .placeOrderBloc!
                                                .currentExchangeIndex]
                                            ?.totSellQty ??
                                        "0")
                                    .toInt()
                                    .toString(),
                                style: GreekTextStyle.headline20,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  pivotlevle(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        pivotlevleTitle(),
        /* Container(
          margin: EdgeInsets.only(left: 10, right: 10),
          height: 1,
          color: Colors.grey,
        ),*/
        const SizedBox(height: 10),
        pivotDetailView(context),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }

  pivotlevleTitle() {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: const EdgeInsets.only(
        left: 5,
        right: 5,
      ),
      width: MediaQuery.of(context).size.width,
      color: const Color(0xffF6F6F6),
      child: Text(
        "Pivot Level",
        style: GreekTextStyle.heading18,
      ),
    );
  }

  pivotDetailView(BuildContext context) {
    return FutureBuilder<List<TechnicalsModel?>>(
      future: widget.placeOrderBloc?.getTechnicalDetails(widget
              .placeOrderBloc
              ?.orderResponseArray[
                  widget.placeOrderBloc?.currentExchangeIndex ?? 0]
              ?.token ??
          0),
      builder: (futureContext, snapshot) {
        if (snapshot.hasData) {
          final dataList = snapshot.data;
          getTechnicalData(dataList!);
          return Container(
            color: Colors.white,
            height: 100,
            margin: const EdgeInsets.only(
              left: 13,
              right: 13,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              "R1",
                              style: GreekTextStyle.overview_stockdetails_info,
                            ),
                            Text(
                              "R2",
                              style: GreekTextStyle.overview_stockdetails_info,
                            ),
                            Text(
                              "R3",
                              style: GreekTextStyle.overview_stockdetails_info,
                            ),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              resist1 ?? '0',
                              style: GreekTextStyle
                                  .overview_stockdetails_infoValue,
                            ),
                            Text(
                              resist2 ?? '0',
                              style: GreekTextStyle
                                  .overview_stockdetails_infoValue,
                            ),
                            Text(
                              resist3 ?? '0',
                              style: GreekTextStyle
                                  .overview_stockdetails_infoValue,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: 80,
                  height: MediaQuery.of(context).size.height,
                  padding: const EdgeInsets.only(left: 5.0, right: 5.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        "PIVOT",
                        style: GreekTextStyle.overview_stockdetails_info,
                      ),
                      Text(
                        pivot ?? '',
                        style: GreekTextStyle.overview_stockdetails_infoValue,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "S1",
                              style: GreekTextStyle
                                  .overview_stockdetails_infoValue,
                            ),
                            Text(
                              "S2",
                              style: GreekTextStyle
                                  .overview_stockdetails_infoValue,
                            ),
                            Text(
                              "S3",
                              style: GreekTextStyle
                                  .overview_stockdetails_infoValue,
                            ),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              support1 ?? '0',
                              style: GreekTextStyle.overview_stockdetails_info,
                            ),
                            Text(
                              support2 ?? '0',
                              style: GreekTextStyle.overview_stockdetails_info,
                            ),
                            Text(
                              support3 ?? '0',
                              style: GreekTextStyle.overview_stockdetails_info,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        return SizedBox(
          height: MediaQuery.of(context).size.height / 2,
          child: Center(child: GreekBase().noDataAvailableView()),
        );
      },
    );
  }

  void getTechnicalData(List<TechnicalsModel?> dataList) {
    for (var item in dataList) {
      resist1 = double.parse(item?.resist1 ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
      resist2 = double.parse(item?.resist2 ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
      resist3 = double.parse(item?.resist3 ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
      support1 = double.parse(item?.support1 ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
      support2 = double.parse(item?.support2 ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
      support3 = double.parse(item?.support3 ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
      pivot = double.parse(item?.pivot ?? '')
          .toFormateDicemalPoint(token: widget.placeOrderBloc?.orderToken);
    }
  }

  Widget _containerFour() {
    return SafeArea(
      child: Container(
        // height: 80,
        color: Colors.white,
        margin: const EdgeInsets.only(top: 5.0),
        padding: const EdgeInsets.only(top: 15, bottom: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: const Color(0xFF33CC33),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.buy;
                    tabController?.animateTo(0);
                    widget
                        .placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink
                        .add(true);
                  },
                  child: const Text(
                    "BUY",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: ConstantColors.sellColor,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.sell;
                    tabController?.animateTo(0);
                    widget
                        .placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink
                        .add(true);
                  },
                  child: const Text(
                    "SELL",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =================================

}
