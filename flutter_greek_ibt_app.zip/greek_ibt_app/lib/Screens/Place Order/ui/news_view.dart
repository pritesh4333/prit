import 'dart:async';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Market/bloc/market_map_bloc.dart';
import 'package:greek_ibt_app/Screens/Market/models/get_news_response.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:intl/intl.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class NewsScreen extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;
  final TabController? controller;

  const NewsScreen({
    Key? key,
    this.controller,
    this.placeOrderBloc,
  }) : super(key: key);

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  MarketMapBloc? _marketBloc;
  TabController? tabController;
  Timer? timer;

  @override
  void dispose() {
// Cancel timer, callback never called.
    timer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    widget.placeOrderBloc!.appBarSizeSubject.sink.add(false);
    tabController = widget.controller;
    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        /*   Future.delayed(const Duration(milliseconds: 850)).then(
          (value) {
            _marketBloc?.getPortfolioNewsData(widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .symbol ??
                "");
          }, */

        Future.delayed(const Duration(milliseconds: 850)).then((value) =>
            timer = Timer.periodic(
                const Duration(seconds: 10),
                (Timer t) => _marketBloc?.getPortfolioNewsData(widget
                        .placeOrderBloc!
                        .orderResponseArray[
                            widget.placeOrderBloc!.currentExchangeIndex]!
                        .symbol ??
                    "")));
        // );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    _marketBloc ??= MarketMapBloc();
    return SafeArea(
      child: Column(
        children: [
          Flexible(
            fit: FlexFit.tight,
            child: SingleChildScrollView(
              physics: const ScrollPhysics(),
              child: Column(
                children: [
                  getPortfolioNewsSymbol(),
                ],
              ),
            ),
          ),
          Visibility(
            visible: widget.placeOrderBloc?.orderMode == OrderMode.newOrder
                ? true
                : false,
            child: _containerFour(),
          ),
        ],
      ),
    );
  }

  getPortfolioNewsSymbol() {
    return Container(
      margin: const EdgeInsets.all(5),
      child: Padding(
        padding: const EdgeInsets.all(2.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              decoration: _createBoxDecoration(),
              child: Padding(
                padding:
                    const EdgeInsets.only(top: 0.0, bottom: 0.0, right: 0.0),
                child: StreamBuilder<List<GetNewsResponse>>(
                    stream: _marketBloc!.getPortfolionewsSubject.stream,
                    builder: (context, snapshot) {
                      if ((snapshot.hasData) &&
                          (snapshot.data?.isNotEmpty ?? false)) {
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              decoration: _createBoxDecoration(),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 10, top: 15, bottom: 15),
                                    child: Text(
                                      "News & Media",
                                      style: GreekTextStyle.marketmapnewsheader,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              child: ListView.builder(
                                shrinkWrap: true,
                                physics:
                                    const NeverScrollableScrollPhysics(), //Optional
                                itemCount: snapshot.data?.length,
                                itemBuilder: (context, index) {
                                  if ((snapshot.hasData) &&
                                      (snapshot.data?.isNotEmpty ?? false)) {
                                    var date = DateFormat('dd MMM yyyy HH:mm')
                                        .format(
                                            DateTime.fromMillisecondsSinceEpoch(
                                                int.parse(snapshot
                                                            .data?.first.date
                                                            .toString() ??
                                                        '') *
                                                    1000));
                                    return Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 5,
                                              right: 5,
                                              top: 10,
                                              bottom: 0),
                                          child: Container(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              "${snapshot.data?[index].arttext}",
                                              style: GreekTextStyle
                                                  .marketmapnewsdata,
                                              maxLines: 6,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 8.0,
                                              right: 10,
                                              bottom: 5,
                                              top: 5),
                                          child: Container(
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              date,
                                              style: const TextStyle(
                                                fontSize: 10.0,
                                              ),
                                              maxLines: 2,
                                            ),
                                          ),
                                        ),
                                        const Divider(
                                          thickness: 1,
                                        )
                                      ],
                                    );
                                  } else {
                                    return SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height /
                                              2,
                                      child: Center(
                                          child: GreekBase()
                                              .noDataAvailableView()),
                                    );
                                  }
                                },
                              ),
                            ),
                          ],
                        );
                      } else {
                        return SizedBox(
                          height: MediaQuery.of(context).size.height / 2,
                          child: const Center(
                            child: SizedBox.square(
                              dimension: 40.0,
                              child: CircularProgressIndicator(),
                            ),
                          ),
                        );
                      }
                    }),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _containerFour() {
    return SafeArea(
      child: Container(
        color: Colors.white,
        margin: const EdgeInsets.only(top: 5.0),
        padding: const EdgeInsets.only(top: 15, bottom: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: const Color(0xFF33CC33),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.buy;
                    tabController?.animateTo(0);
                    widget
                        .placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink
                        .add(true);
                  },
                  child: const Text(
                    "BUY",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: ConstantColors.sellColor,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.sell;
                    tabController?.animateTo(0);
                    widget
                        .placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink
                        .add(true);
                  },
                  child: const Text(
                    "SELL",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  _createBoxDecoration() => BoxDecoration(
        color: Colors.white,
        border: Border.all(
          // color: const Color(0xFFE3E3E3),
          color: ConstantColors.borderColor,
          width: 1,
        ),
        // boxShadow: const [
        //   BoxShadow(
        //       color: Color(0xff00000029), offset: Offset(1, -2), blurRadius: 3),
        //   BoxShadow(
        //       color: Color(0xff00000029), offset: Offset(-1, 2), blurRadius: 3)
        // ],
        borderRadius: BorderRadius.circular(2),
      );
}
