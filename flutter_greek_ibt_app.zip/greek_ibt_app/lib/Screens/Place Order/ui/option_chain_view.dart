import 'dart:async';

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/bloc/option_chain_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_expiry_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/option_chain_call_put_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Utilities/no_data_with_progress_indicator.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OptionchainScreen extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;
  final TabController? controller;

  const OptionchainScreen({
    Key? key,
    this.controller,
    this.placeOrderBloc,
  }) : super(key: key);

  @override
  _OptionchainScreenState createState() => _OptionchainScreenState();
}

class _OptionchainScreenState extends State<OptionchainScreen> {
  SharedPreferences? sp;
  OptionChainBloc? optionChainBlocs;
  String dropdownvalue = 'Item 1';
  final niftyController = TextEditingController();
  String? expiryDropdownValue;

  // List of items in our dropdown menu
  var items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
  ];

  String globalVisibility = 'callput';
  TabController? tabController;

  String currentExchange = '';
  double topSpace = 0;

  @override
  void initState() {
    super.initState();
    optionChainBlocs ??= OptionChainBloc(
        context: context,
        orderMode: widget.placeOrderBloc?.orderMode,
        orderAction: widget.placeOrderBloc?.orderAction,
        orderToken: widget.placeOrderBloc?.orderToken);

    niftyController.text =
        '${widget.placeOrderBloc?.orderResponseArray[widget.placeOrderBloc?.currentExchangeIndex ?? 0]?.symbol}';

    int token = int.parse(
        '${widget.placeOrderBloc?.orderResponseArray[widget.placeOrderBloc?.currentExchangeIndex ?? 0]?.token}');
    currentExchange = token.toExchange();

    optionChainBlocs?.callExpiryAPI(niftyController.text).then((value) {
      optionChainBlocs?.callStrikeAPI(
        niftyController.text,
        expiryDropdownValue ??
            DateFormat('ddMMMyyyy')
                .format(DateTime.fromMillisecondsSinceEpoch(int.parse(
                        optionChainBlocs?.getExpiryResponseArray
                                .elementAt(0)
                                ?.expiry
                                .toString() ??
                            '') *
                    1000))
                .toString(),
        currentExchange,
      );
    });
    tabController = widget.controller;

    // _setcolumn();
    SharedPreferences.getInstance().then((value) {
      sp = value;
      getdefaultvalues();
    });
  }

  getdefaultvalues() {
    optionChainBlocs!.isvolume = sp?.getBool("volume") ?? false;
    optionChainBlocs!.iv = sp?.getBool("iv") ?? false;
    optionChainBlocs!.greeks = sp?.getBool("greeks") ?? false;
    optionChainBlocs!.delta = sp?.getBool("delta") ?? false;
    optionChainBlocs!.gama = sp?.getBool("gama") ?? false;
    optionChainBlocs!.vega = sp?.getBool("vega") ?? false;

    _setcolumn();

    // setState(() {});
  }

  void _setcolumn() {
    if (optionChainBlocs?.iv ?? false) {
      if (!optionChainBlocs!.headings.contains("IV")) {
        optionChainBlocs!.headings.insert(0, "IV");
        optionChainBlocs!.heading1.insert(0, "");
        optionChainBlocs!.headings.add("IV");
        optionChainBlocs!.heading1.add("");
      }
    } else {
      if (optionChainBlocs!.headings.contains("IV")) {
        int index = optionChainBlocs!.headings.indexOf("IV");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("IV");
      }
      if (optionChainBlocs!.headings.contains("IV")) {
        int index = optionChainBlocs!.headings.indexOf("IV");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("IV");
      }
    }

    if (optionChainBlocs!.isvolume) {
      if (!optionChainBlocs!.headings.contains("Volume")) {
        optionChainBlocs!.headings.insert(0, "Volume");
        optionChainBlocs!.heading1.insert(0, "");
        optionChainBlocs!.headings.add("Volume");
        optionChainBlocs!.heading1.add("");
      }
    } else {
      if (optionChainBlocs!.headings.contains("Volume")) {
        int index = optionChainBlocs!.headings.indexOf("Volume");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("Volume");
      }
      if (optionChainBlocs!.headings.contains("Volume")) {
        int index = optionChainBlocs!.headings.indexOf("Volume");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("Volume");
      }
    }

    if (optionChainBlocs!.greeks) {
      if (!optionChainBlocs!.headings.contains("GREEKS")) {
        optionChainBlocs!.headings.insert(0, "GREEKS");
        optionChainBlocs!.heading1.insert(0, "");
        optionChainBlocs!.headings.add("GREEKS");
        optionChainBlocs!.heading1.add("");
      }
    } else {
      if (optionChainBlocs!.headings.contains("GREEKS")) {
        int index = optionChainBlocs!.headings.indexOf("GREEKS");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("GREEKS");
      }
      if (optionChainBlocs!.headings.contains("GREEKS")) {
        int index = optionChainBlocs!.headings.indexOf("GREEKS");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("GREEKS");
      }
    }

    if (optionChainBlocs!.delta) {
      if (!optionChainBlocs!.headings.contains("DELTA")) {
        optionChainBlocs!.headings.insert(0, "DELTA");
        optionChainBlocs!.heading1.insert(0, "");

        optionChainBlocs!.headings.add("DELTA");
        optionChainBlocs!.heading1.add("");
      }
    } else {
      if (optionChainBlocs!.headings.contains("DELTA")) {
        int index = optionChainBlocs!.headings.indexOf("DELTA");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("DELTA");
      }
      if (optionChainBlocs!.headings.contains("DELTA")) {
        int index = optionChainBlocs!.headings.indexOf("DELTA");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("DELTA");
      }
    }

    if (optionChainBlocs!.gama) {
      if (!optionChainBlocs!.headings.contains("GAMA")) {
        optionChainBlocs!.headings.insert(0, "GAMA");
        optionChainBlocs!.heading1.insert(0, "");

        optionChainBlocs!.headings.add("GAMA");
        optionChainBlocs!.heading1.add("");
      }
    } else {
      if (optionChainBlocs!.headings.contains("GAMA")) {
        int index = optionChainBlocs!.headings.indexOf("GAMA");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("GAMA");
      }
      if (optionChainBlocs!.headings.contains("GAMA")) {
        int index = optionChainBlocs!.headings.indexOf("GAMA");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("GAMA");
      }
    }

    if (optionChainBlocs!.vega) {
      if (!optionChainBlocs!.headings.contains("VEGA")) {
        optionChainBlocs!.headings.insert(0, "VEGA");
        optionChainBlocs!.heading1.insert(0, "");

        optionChainBlocs!.headings.add("VEGA");
        optionChainBlocs!.heading1.add("");
      }
    } else {
      if (optionChainBlocs!.headings.contains("VEGA")) {
        int index = optionChainBlocs!.headings.indexOf("VEGA");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("VEGA");
      }
      if (optionChainBlocs!.headings.contains("VEGA")) {
        int index = optionChainBlocs!.headings.indexOf("VEGA");
        optionChainBlocs!.heading1.removeAt(index);

        optionChainBlocs!.headings.remove("VEGA");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    topSpace = MediaQuery.of(context).size.height / 2;
    return Scaffold(
      body: Column(
        children: [
          Flexible(
            fit: FlexFit.tight,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 50,
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Container(
                            height: 35,
                            // padding: EdgeInsets.all(8.0),
                            color: Colors.green[200],
                            child: Container(
                              // color: Colors.amber,
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: Colors.green[200],
                                borderRadius: BorderRadius.circular(5),
                                boxShadow: const [
                                  BoxShadow(
                                    blurRadius: 4.5,
                                    offset: Offset(1, 1),
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  const Icon(Icons.arrow_left_sharp, size: 30),
                                  TextButton(
                                    child: const Text('Call'),
                                    onPressed: () {
                                      if (globalVisibility == 'callput') {
                                        globalVisibility = 'call';
                                      } else if (globalVisibility == 'put') {
                                        globalVisibility = 'callput';
                                      } else {
                                        globalVisibility = 'call';
                                      }
                                      setState(() {});
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                          FutureBuilder<List<GetExpiryResponseModel?>>(
                            future: optionChainBlocs
                                ?.callExpiryAPI(niftyController.text),
                            builder: (context, snapshot) {
                              return DropdownButton<String>(
                                // Initial Value
                                value: expiryDropdownValue ??
                                    ((snapshot.data?.length ?? 0) > 0
                                        ? DateFormat('ddMMMyyyy')
                                            .format(DateTime
                                                .fromMillisecondsSinceEpoch(
                                                    int.parse(snapshot.data
                                                                ?.elementAt(0)
                                                                ?.expiry
                                                                .toString() ??
                                                            '') *
                                                        1000))
                                            .toString()
                                        : ''),

                                // Down Arrow Icon
                                icon: const Icon(Icons.keyboard_arrow_down),

                                // Array list of items
                                items: snapshot.data?.map((item) {
                                      return DropdownMenuItem(
                                        child: Text(DateFormat('ddMMMyyyy')
                                            .format(DateTime
                                                .fromMillisecondsSinceEpoch(
                                                    int.parse(item?.expiry
                                                                .toString() ??
                                                            '') *
                                                        1000))),
                                        value: DateFormat('ddMMMyyyy').format(
                                            DateTime.fromMillisecondsSinceEpoch(
                                                int.parse(item?.expiry
                                                            .toString() ??
                                                        '') *
                                                    1000)),
                                      );
                                    }).toList() ??
                                    [],
                                // After selecting the desired option,it will
                                // change button value to selected value
                                onChanged: (String? newValue) {
                                  setState(() {
                                    expiryDropdownValue = newValue!;
                                  });
                                  optionChainBlocs?.callStrikeAPI(
                                      niftyController.text,
                                      expiryDropdownValue ?? '',
                                      currentExchange);
                                },
                              );
                            },
                          ),
                          IconButton(
                            onPressed: () async {
                              final popupResult = await GreekDialogPopupView
                                  .optionChainSettingDialog(
                                popContext: context,
                                ordermode: widget.placeOrderBloc?.orderMode,
                                action: widget.placeOrderBloc?.orderAction,
                                token: widget.placeOrderBloc?.orderToken,
                                optionChainBloc: optionChainBlocs,
                              );

                              if (popupResult != null) {
                                setState(() {
                                  if (optionChainBlocs?.noofStrike == "10" ||
                                      optionChainBlocs?.noofStrike == "5" ||
                                      optionChainBlocs?.noofStrike == "15" ||
                                      optionChainBlocs?.noofStrike == "20" ||
                                      optionChainBlocs?.noofStrike == "All") {
                                    optionChainBlocs
                                        ?.callExpiryAPI(niftyController.text)
                                        .then((value) {
                                      optionChainBlocs?.callStrikeAPI(
                                          niftyController.text,
                                          expiryDropdownValue ??
                                              DateFormat('ddMMMyyyy')
                                                  .format(DateTime.fromMillisecondsSinceEpoch(
                                                      int.parse(optionChainBlocs
                                                                  ?.getExpiryResponseArray
                                                                  .elementAt(0)
                                                                  ?.expiry
                                                                  .toString() ??
                                                              '') *
                                                          1000))
                                                  .toString(),
                                          currentExchange);
                                    });
                                  }
                                });
                              }
                            },
                            iconSize: 30,
                            color: ConstantColors.black,
                            icon: Image.asset(
                              'assets/images/setting.png',
                              fit: BoxFit.fitWidth,
                              width: 50,
                              height: 50,
                            ),
                          ),
                          SizedBox(
                            height: 35,
                            // padding: EdgeInsets.all(8.0),
                            // color: Colors.green[200],
                            child: Container(
                              // color: Colors.amber,
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: Colors.pink[200],
                                borderRadius: BorderRadius.circular(5),
                                boxShadow: const [
                                  BoxShadow(
                                    // color: Colors.green[200],
                                    // spreadRadius: 1.2,
                                    blurRadius: 4.5,
                                    offset: Offset(1, 1),
                                  ),
                                ],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextButton(
                                    child: const Text('Put'),
                                    onPressed: () {
                                      if (globalVisibility == 'callput') {
                                        globalVisibility = 'put';
                                      } else if (globalVisibility == 'call') {
                                        globalVisibility = 'callput';
                                      } else {
                                        globalVisibility = 'put';
                                      }
                                      setState(() {});
                                    },
                                  ),
                                  const Icon(
                                    Icons.arrow_right_sharp,
                                    size: 30,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ]),
                  ),
                  globalVisibility == 'callput'
                      ? buildMainOptionChain(true)
                      : globalVisibility == 'call'
                          ? buildMainOptionChainCall()
                          : buildMainOptionChainPut(),
                ],
              ),
            ),
          ),
          Visibility(
            visible: widget.placeOrderBloc?.orderMode == OrderMode.newOrder
                ? true
                : false,
            child: _containerFour(),
          ),
        ],
      ),
    );
  }

  Widget _containerFour() {
    return SafeArea(
      child: Container(
        // height: 40.0,
        color: Colors.white,
        margin: const EdgeInsets.only(top: 5.0),
        padding: const EdgeInsets.only(top: 15, bottom: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: const Color(0xFF33CC33),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.buy;
                    tabController?.animateTo(0);
                    widget
                        .placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink
                        .add(true);
                  },
                  child: const Text(
                    "BUY",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: ConstantColors.sellColor,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc?.orderAction = OrderAction.sell;
                    tabController?.animateTo(0);
                    widget
                        .placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink
                        .add(true);
                  },
                  child: const Text(
                    "SELL",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //
  StreamBuilder<List<OptionChainResponseModel?>> buildMainOptionChain(
      bool visibility) {
    return StreamBuilder<List<OptionChainResponseModel?>>(
      stream: optionChainBlocs?.optionChainObserverable,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int lengthData = snapshot.data?.length ?? 0;
          if (lengthData <= 0) {
            return NoDatWithProgressIndicator(
              topSpace: topSpace,
              showHide: false,
              message: '',
            );
          }
          num length =
              int.parse(optionChainBlocs?.headings.length.toString() ?? "0");

          return Visibility(
            visible: visibility,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              reverse: true,
              child: Column(
                children: [
                  SizedBox(
                    height: 35,
                    width: length * 84,
                    child: StreamBuilder<bool>(
                      stream: optionChainBlocs?.settingObserver,
                      builder: (context, snapshot) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: _buildRowList(from: 'callput'),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height - 320,
                    width: length * 84,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: (snapshot.data?.length),
                      itemBuilder: (context, index) {
                        return Container(
                          // width: MediaQuery.of(context).size.width * 0.25,
                          alignment: Alignment.center,
                          color: ConstantColors.white,
                          child: Row(
                            children: index > 0
                                ? _builddataRow(snapshot.data?[index], index,
                                    snapshot.data?[index - 1]?.strikePrice)
                                : _builddataRow(snapshot.data?[index], index,
                                    snapshot.data?[index]?.strikePrice),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        } else {
          return NoDatWithProgressIndicator(
            topSpace: topSpace,
            showHide: true,
            message: 'Fetching data',
          );
        }
      },
    );
  }

  StreamBuilder<List<OptionChainResponseModel?>> buildMainOptionChainCall() {
    return StreamBuilder<List<OptionChainResponseModel?>>(
      stream: optionChainBlocs?.optionChainObserverable,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int lengthData = snapshot.data?.length ?? 0;
          if (lengthData <= 0) {
            return NoDatWithProgressIndicator(
              topSpace: topSpace,
              showHide: false,
              message: '',
            );
          }
          num length =
              int.parse(optionChainBlocs?.headings.length.toString() ?? "0");
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Column(
              children: [
                SizedBox(
                  height: 35,
                  width: MediaQuery.of(context).size.width,
                  child: StreamBuilder<bool>(
                      stream: optionChainBlocs?.settingObserver,
                      builder: (context, snapshot) {
                        return Row(
                          children: _buildRowList(from: 'call'),
                        );
                      }),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: snapshot.data?.length,
                    itemBuilder: (context, index) {
                      return Container(
                        width: length < 5
                            ? MediaQuery.of(context).size.width
                            : MediaQuery.of(context).size.width * 0.25,
                        alignment: Alignment.center,
                        color: ConstantColors.white,
                        child: Row(
                          children: _builddataRow(snapshot.data?[index], index),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        } else {
          return NoDatWithProgressIndicator(
            topSpace: topSpace,
            showHide: true,
            message: 'Fetching data',
          );
        }
      },
    );
  }

  StreamBuilder<List<OptionChainResponseModel?>> buildMainOptionChainPut() {
    return StreamBuilder<List<OptionChainResponseModel?>>(
      stream: optionChainBlocs?.optionChainObserverable,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          int lengthData = snapshot.data?.length ?? 0;
          if (lengthData <= 0) {
            return NoDatWithProgressIndicator(
              topSpace: topSpace,
              showHide: false,
              message: '',
            );
          }
          num length = 0;
          if (globalVisibility == "callput") {
            length =
                int.parse(optionChainBlocs?.headings.length.toString() ?? "0");
          } else if (globalVisibility == "call") {
            length = int.parse(
                optionChainBlocs?.headingsCall.length.toString() ?? "0");
          } else if (globalVisibility == "put") {
            length = int.parse(
                optionChainBlocs?.headingCallPut.length.toString() ?? "0");
          }

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Column(
              children: [
                StreamBuilder<bool>(
                    stream: optionChainBlocs?.settingObserver,
                    builder: (context, snapshot) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: _buildRowList(from: 'put'),
                          ),
                        ],
                      );
                    }),
                SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: snapshot.data?.length,
                    itemBuilder: (context, index) {
                      return Container(
                        width: length < 5
                            ? MediaQuery.of(context).size.width
                            : MediaQuery.of(context).size.width * 0.25,
                        alignment: Alignment.center,
                        color: ConstantColors.white,
                        child: Row(
                          children: _builddataRow(snapshot.data?[index], index),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        } else {
          return NoDatWithProgressIndicator(
            topSpace: topSpace,
            showHide: true,
            message: 'Fetching details',
          );
        }
      },
    );
  }

  Widget callputButtonView(BuildContext context) {
    return Row();
  }

  List<Widget> _builddataRow(param0, int index, [double? strikePrice]) {
    List<Widget> places = [];
    if (globalVisibility == "callput") {
      num length =
          int.parse(optionChainBlocs?.headings.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildDataRow(param0, i, strikePrice));
      }
    } else if (globalVisibility == "put") {
      num length =
          int.parse(optionChainBlocs?.headingsPut.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildDataRowput(param0, i));
      }
    } else if (globalVisibility == "call") {
      num length =
          int.parse(optionChainBlocs?.headingsCall.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildDataRowCall(param0, i));
      }
    }
    return places;
  }

  Widget _buildDataRow(var data, int index, [double? previousstrike]) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        (data?.strikePrice > double.parse(optionChainBlocs?.ltp ?? "") / 100) &&
                (previousstrike! <
                    double.parse(optionChainBlocs?.ltp ?? "") / 100)
            ? SizedBox(
                // color: Colors.grey[350],
                height: 30,
                width: 80,
                child: optionChainBlocs?.headings[index]
                            .toString()
                            .toLowerCase() ==
                        "strike"
                    ? Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                              color: const Color.fromARGB(54, 54, 54, 1),
                              width: 1),
                          color: const Color(0xFF127FBA),
                        ),
                        // color: Color(0xFF127FBA),
                        child: Center(
                          child: Text(
                            (double.parse(optionChainBlocs?.ltp ?? "") / 100)
                                .toStringAsFixed(2),
                            style: GreekTextStyle.optionChainStrikeDispaly,
                          ),
                        ))
                    : optionChainBlocs!.headings.indexOf("Strike") > index
                        ? Text(
                            "",
                            style: GreekTextStyle.optionChainStrikecallputText,
                            textAlign: TextAlign.right,
                          )
                        : Text(
                            "",
                            style: GreekTextStyle.optionChainStrikecallputText,
                            textAlign: TextAlign.right,
                          ),
              )
            : Container(),
        Row(
          children: [
            GestureDetector(
              onTap: () async {
                GreekNavigator.pop(context: context);
                await GreekNavigator.pushNamed(
                  context: context,
                  routeName: GreekScreenNames.place_order,
                  arguments: [
                    optionChainBlocs!.headings.indexOf("Strike") > index
                        ? data?.call?.lOurToken
                        : data?.put?.lOurToken,
                    OrderAction.buy,
                    OrderMode.newOrder,
                    ScriptInfoTab.overview.index,
                  ],
                );
              },
              child: Container(
                  color: optionChainBlocs!.headings.indexOf("Strike") > index
                      ? const Color.fromRGBO(203, 234, 203, 1)
                      : Colors.white,
                  width: 80,
                  height: 50,
                  alignment: Alignment.centerRight,
                  child: optionChainBlocs?.heading1[index] != ""
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            optionChainBlocs?.headings[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? optionChainBlocs!.headings.indexOf("Strike") >
                                        index
                                    ? lopeninterest(
                                        (data?.call?.lOpenInterest / 100000)
                                            .toString())
                                    : lopeninterest(
                                        (data?.put?.lOpenInterest / 100000)
                                            .toString())
                                : optionChainBlocs?.headings[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? optionChainBlocs!.headings
                                                .indexOf("Strike") >
                                            index
                                        ? lopeninterest(
                                            "${data?.call?.ltp ?? ''}")
                                        : lopeninterest(
                                            "${data?.put?.ltp ?? ''}")
                                    : optionChainBlocs?.headings[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? optionChainBlocs!.headings
                                                    .indexOf("Strike") >
                                                index
                                            ? lopeninterest("0")
                                            : lopeninterest("0")
                                        : optionChainBlocs?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "volume"
                                            ? optionChainBlocs!.headings
                                                        .indexOf("Strike") >
                                                    index
                                                ? lopeninterest("${data?.call?.lVolume ?? ''}")
                                                : lopeninterest("${data?.put?.lVolume ?? ''}")
                                            : optionChainBlocs?.headings[index].toString().toLowerCase() == "gama"
                                                ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                    ? lopeninterest("0")
                                                    : lopeninterest("0")
                                                : optionChainBlocs?.headings[index].toString().toLowerCase() == "vega"
                                                    ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                        ? lopeninterest("0")
                                                        : lopeninterest("0")
                                                    : optionChainBlocs?.headings[index].toString().toLowerCase() == "iv"
                                                        ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                            ? lopeninterest("0")
                                                            : lopeninterest("0")
                                                        : optionChainBlocs?.headings[index].toString().toLowerCase() == "Strike"
                                                            ? Container(color: const Color.fromARGB(54, 54, 54, 1), child: lopeninterest("${data?.strikePrice ?? ''}"))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                )),
                            optionChainBlocs?.headings[index].toString().toLowerCase() ==
                                    "oi"
                                ? optionChainBlocs!.headings.indexOf("Strike") >
                                        index
                                    ? changetextview(
                                        "${data?.call?.oiChange ?? ''}")
                                    : changetextview(
                                        "${data?.put?.oiChange ?? ''}")
                                : optionChainBlocs?.headings[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? optionChainBlocs!.headings.indexOf("Strike") >
                                            index
                                        ? changetextview(
                                            "${data?.call?.change ?? ''}")
                                        : changetextview(
                                            "${data?.put?.change ?? ''}")
                                    : optionChainBlocs?.headings[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? optionChainBlocs!.headings.indexOf("Strike") >
                                                index
                                            ? changetextview("0")
                                            : changetextview("0")
                                        : optionChainBlocs?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "gama"
                                            ? optionChainBlocs!.headings.indexOf("Strike") >
                                                    index
                                                ? changetextview("0")
                                                : changetextview("0")
                                            : optionChainBlocs?.headings[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "vega"
                                                ? optionChainBlocs!.headings
                                                            .indexOf("Strike") >
                                                        index
                                                    ? changetextview("0")
                                                    : changetextview("0")
                                                : optionChainBlocs?.headings[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "iv"
                                                    ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                        ? changetextview("0")
                                                        : changetextview("0")
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        )),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            optionChainBlocs?.headings[index].toString().toLowerCase() ==
                                    "oi"
                                ? optionChainBlocs!.headings.indexOf("Strike") >
                                        index
                                    ? lopeninterest(
                                        (data?.call?.lOpenInterest / 100000)
                                            .toString())
                                    : lopeninterest(
                                        (data?.put?.lOpenInterest / 100000)
                                            .toString())
                                : optionChainBlocs?.headings[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? optionChainBlocs!.headings.indexOf("Strike") >
                                            index
                                        ? Text("${data?.call?.ltp ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                        : Text("${data?.put?.ltp ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                    : optionChainBlocs?.headings[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "volume"
                                        ? optionChainBlocs!.headings.indexOf("Strike") >
                                                index
                                            ? Text(
                                                "${data?.call?.lVolume ?? ''}",
                                                style: const TextStyle(
                                                  fontSize: 12.0,
                                                ))
                                            : Text(
                                                "${data?.put?.lVolume ?? ''}",
                                                style: const TextStyle(
                                                  fontSize: 12.0,
                                                ))
                                        : optionChainBlocs?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "delta"
                                            ? optionChainBlocs!.headings.indexOf("Strike") >
                                                    index
                                                ? const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                                : const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                            : optionChainBlocs?.headings[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "iv"
                                                ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                    ? const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                : optionChainBlocs?.headings[index].toString().toLowerCase() == "greeks"
                                                    ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                        ? const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                        : const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                    : optionChainBlocs?.headings[index].toString().toLowerCase() == "gama"
                                                        ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                            ? const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                            : const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                        : optionChainBlocs?.headings[index].toString().toLowerCase() == "vega"
                                                            ? optionChainBlocs!.headings.indexOf("Strike") > index
                                                                ? const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                            : optionChainBlocs?.headings[index].toString().toLowerCase() == "strike"
                                                                ? Container(
                                                                    color: const Color
                                                                            .fromRGBO(
                                                                        226,
                                                                        226,
                                                                        226,
                                                                        1),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    height: 50,
                                                                    child: Text(
                                                                        double.parse(data?.strikePrice.toString() ??
                                                                                "")
                                                                            .toStringAsFixed(
                                                                                2),
                                                                        style: GreekTextStyle
                                                                            .optionChainStrike),
                                                                  )
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    )),
                          ],
                        )),
            ),
          ],
        ),
        Container(
          height: 2,
          width: 80,
          color: const Color.fromRGBO(226, 226, 226, 1),
        ),
      ],
    );
  }

  Widget _buildDataRowput(var data, int index) {
    return SizedBox(
      width: MediaQuery.of(context).size.width /
          optionChainBlocs!.headingCallPut.length,
      child: Column(
        children: [
          Row(
            children: [
              Container(
                  color: Colors.white,
                  padding: const EdgeInsets.only(right: 5),
                  width: MediaQuery.of(context).size.width /
                      optionChainBlocs!.headingCallPut.length,
                  height: 50,
                  alignment: Alignment.centerRight,
                  child: optionChainBlocs?.headingCallPut[index] != ""
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            optionChainBlocs?.headingsPut[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? lopeninterest((data?.put?.lOpenInterest / 100000)
                                    .toString())
                                : optionChainBlocs?.headingsPut[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? lopeninterest("${data?.put?.ltp ?? ''}")
                                    : optionChainBlocs?.headingsPut[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? lopeninterest("0")
                                        : optionChainBlocs?.headingsPut[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "volume"
                                            ? lopeninterest(
                                                "${data?.put?.lVolume ?? ''}")
                                            : optionChainBlocs?.headingsPut[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "gama"
                                                ? optionChainBlocs!.headingsPut
                                                            .indexOf("Strike") >
                                                        index
                                                    ? lopeninterest("0")
                                                    : lopeninterest("0")
                                                : optionChainBlocs
                                                            ?.headingsPut[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "vega"
                                                    ? optionChainBlocs!.headingsPut.indexOf("Strike") > index
                                                        ? lopeninterest("0")
                                                        : lopeninterest("0")
                                                    : optionChainBlocs?.headingsPut[index].toString().toLowerCase() == "iv"
                                                        ? optionChainBlocs!.headingsPut.indexOf("Strike") > index
                                                            ? lopeninterest("0")
                                                            : lopeninterest("0")
                                                        : optionChainBlocs?.headingsPut[index].toString().toLowerCase() == "Strike"
                                                            ? Container(color: Colors.grey, child: lopeninterest("${data?.strikePrice ?? ''}"))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                )),
                            optionChainBlocs?.headingsPut[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? changetextview("${data?.put?.oiChange ?? ''}")
                                : optionChainBlocs?.headingsPut[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? changetextview(
                                        "${data?.put?.change ?? ''}")
                                    : optionChainBlocs?.headingsPut[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? changetextview("0")
                                        : optionChainBlocs?.headings[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "gama"
                                            ? changetextview("0")
                                            : optionChainBlocs?.headings[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "vega"
                                                ? changetextview("0")
                                                : optionChainBlocs
                                                            ?.headings[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "iv"
                                                    ? changetextview("0")
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        )),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            optionChainBlocs?.headingsPut[index].toString().toLowerCase() ==
                                    "oi"
                                ? lopeninterest((data?.put?.lOpenInterest / 100000)
                                    .toString())
                                : optionChainBlocs?.headingsPut[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? Text("${data?.put?.ltp ?? ''}",
                                        style: const TextStyle(
                                          fontSize: 12.0,
                                        ))
                                    : optionChainBlocs?.headingsPut[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "volume"
                                        ? Text("${data?.put?.lVolume ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                        : optionChainBlocs?.headingsPut[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "delta"
                                            ? optionChainBlocs!.headingsPut.indexOf("Strike") >
                                                    index
                                                ? const Text("0",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                                : const Text("0",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                            : optionChainBlocs?.headingsPut[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "iv"
                                                ? optionChainBlocs!.headingsPut
                                                            .indexOf("Strike") >
                                                        index
                                                    ? const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                : optionChainBlocs
                                                            ?.headingsPut[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "greeks"
                                                    ? optionChainBlocs!.headingsPut.indexOf("Strike") > index
                                                        ? const Text("0",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                        : const Text("0",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                    : optionChainBlocs?.headings[index].toString().toLowerCase() == "gama"
                                                        ? optionChainBlocs!.headingsPut.indexOf("Strike") > index
                                                            ? const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                        : optionChainBlocs?.headingsPut[index].toString().toLowerCase() == "vega"
                                                            ? optionChainBlocs!.headingsPut.indexOf("Strike") > index
                                                                ? const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                            : optionChainBlocs?.headingsPut[index].toString().toLowerCase() == "strike"
                                                                ? Container(
                                                                    color: const Color
                                                                            .fromRGBO(
                                                                        226,
                                                                        226,
                                                                        226,
                                                                        1),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    height: 50,
                                                                    child: Text(
                                                                        "${data?.strikePrice ?? ''}",
                                                                        style: GreekTextStyle
                                                                            .optionChainStrike),
                                                                  )
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    )),
                          ],
                        )),
            ],
          ),
          Container(
              height: 1,
              width: 140,
              color: Colors.grey,
              margin: const EdgeInsets.only(top: 2, bottom: 2))
        ],
      ),
    );
  }

  Widget _buildDataRowCall(var data, int index) {
    return Container(
      color: const Color.fromRGBO(203, 234, 203, 1),
      // decoration: BoxDecoration(color: Colors.green[50]),
      width: MediaQuery.of(context).size.width /
          optionChainBlocs!.headingCallValue.length,
      child: Column(
        children: [
          Row(
            // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                  padding: const EdgeInsets.only(right: 5),
                  width: MediaQuery.of(context).size.width /
                      optionChainBlocs!.headingsCall.length,
                  height: 50,
                  alignment: Alignment.centerRight,
                  child: optionChainBlocs?.headingCallValue[index] != ""
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            optionChainBlocs?.headingsCall[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? lopeninterest((data?.call?.lOpenInterest / 100000)
                                    .toString())
                                : optionChainBlocs?.headingsCall[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? lopeninterest("${data?.call?.ltp ?? ''}")
                                    : optionChainBlocs?.headingsCall[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? lopeninterest("0")
                                        : optionChainBlocs?.headingsCall[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "volume"
                                            ? lopeninterest(
                                                "${data?.call?.lVolume ?? ''}")
                                            : optionChainBlocs?.headingsCall[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "gama"
                                                ? optionChainBlocs!.headingsCall
                                                            .indexOf("Strike") >
                                                        index
                                                    ? lopeninterest("0")
                                                    : lopeninterest("0")
                                                : optionChainBlocs
                                                            ?.headingsCall[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "vega"
                                                    ? optionChainBlocs!.headingsCall.indexOf("Strike") > index
                                                        ? lopeninterest("0")
                                                        : lopeninterest("0")
                                                    : optionChainBlocs?.headingsPut[index].toString().toLowerCase() == "iv"
                                                        ? optionChainBlocs!.headingsCall.indexOf("Strike") > index
                                                            ? lopeninterest("0")
                                                            : lopeninterest("0")
                                                        : optionChainBlocs?.headingsPut[index].toString().toLowerCase() == "Strike"
                                                            ? Container(color: Colors.grey, child: lopeninterest("${data?.strikePrice ?? ''}"))
                                                            : const Text("0",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                )),
                            optionChainBlocs?.headingsCall[index]
                                        .toString()
                                        .toLowerCase() ==
                                    "oi"
                                ? changetextview(
                                    "${data?.call?.oiChange ?? ''}")
                                : optionChainBlocs?.headingsCall[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? changetextview(
                                        "${data?.call?.change ?? ''}")
                                    : optionChainBlocs?.headingsCall[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "delta"
                                        ? changetextview("0")
                                        : optionChainBlocs?.headingsCall[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "gama"
                                            ? changetextview("0")
                                            : optionChainBlocs
                                                        ?.headingsCall[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "vega"
                                                ? changetextview("0")
                                                : optionChainBlocs
                                                            ?.headingsCall[
                                                                index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "iv"
                                                    ? changetextview("0")
                                                    : const Text("0",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        )),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            optionChainBlocs?.headingsCall[index].toString().toLowerCase() ==
                                    "oi"
                                ? lopeninterest((data?.call?.lOpenInterest / 100000)
                                    .toString())
                                : optionChainBlocs?.headingsCall[index]
                                            .toString()
                                            .toLowerCase() ==
                                        "ltp"
                                    ? Text("${data?.call?.ltp ?? ''}",
                                        style: const TextStyle(
                                          fontSize: 12.0,
                                        ))
                                    : optionChainBlocs?.headingsCall[index]
                                                .toString()
                                                .toLowerCase() ==
                                            "volume"
                                        ? Text("${data?.call?.lVolume ?? ''}",
                                            style: const TextStyle(
                                              fontSize: 12.0,
                                            ))
                                        : optionChainBlocs?.headingsCall[index]
                                                    .toString()
                                                    .toLowerCase() ==
                                                "delta"
                                            ? optionChainBlocs!.headingsCall.indexOf("Strike") >
                                                    index
                                                ? const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                                : const Text("Delta",
                                                    style: TextStyle(
                                                      fontSize: 12.0,
                                                    ))
                                            : optionChainBlocs?.headingsCall[index]
                                                        .toString()
                                                        .toLowerCase() ==
                                                    "iv"
                                                ? optionChainBlocs!.headingsCall
                                                            .indexOf("Strike") >
                                                        index
                                                    ? const Text("Iv",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                    : const Text("Iv",
                                                        style: TextStyle(
                                                          fontSize: 12.0,
                                                        ))
                                                : optionChainBlocs
                                                            ?.headingsCall[index]
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "greeks"
                                                    ? optionChainBlocs!.headingsCall.indexOf("Strike") > index
                                                        ? const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                        : const Text("greeks",
                                                            style: TextStyle(
                                                              fontSize: 12.0,
                                                            ))
                                                    : optionChainBlocs?.headingsCall[index].toString().toLowerCase() == "gama"
                                                        ? optionChainBlocs!.headingsCall.indexOf("Strike") > index
                                                            ? const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                            : const Text("-}",
                                                                style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                ))
                                                        : optionChainBlocs?.headingsCall[index].toString().toLowerCase() == "vega"
                                                            ? optionChainBlocs!.headingsPut.indexOf("Strike") > index
                                                                ? const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    ))
                                                            : optionChainBlocs?.headingsCall[index].toString().toLowerCase() == "strike"
                                                                ? Container(
                                                                    color: const Color
                                                                            .fromRGBO(
                                                                        226,
                                                                        226,
                                                                        226,
                                                                        1),
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    height: 50,
                                                                    child: Text(
                                                                        "${data?.strikePrice ?? ''}",
                                                                        style: GreekTextStyle
                                                                            .optionChainStrike),
                                                                  )
                                                                : const Text("0",
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          12.0,
                                                                    )),
                          ],
                        )),
            ],
          ),
          Container(
              height: 1,
              width: 140,
              color: Colors.grey,
              margin: const EdgeInsets.only(top: 2, bottom: 2))
        ],
      ),
    );
    // }
    // return Container();
  }

  List<Widget> _buildRowList({required String from}) {
    List<Widget> places = [];
    //callput
    if (from == 'callput') {
      num length =
          int.parse(optionChainBlocs?.headings.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildPlace(optionChainBlocs?.headings[i] ?? "", i, length,
            optionChainBlocs?.heading1));
      }
    }
    //call
    else if (from == 'call') {
      num length =
          int.parse(optionChainBlocs?.headingsCall.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildPlacecallput(optionChainBlocs?.headingsCall[i] ?? "",
            i, length, optionChainBlocs?.headingCallValue));
      }
    } //put
    else if (from == 'put') {
      num length =
          int.parse(optionChainBlocs?.headingsPut.length.toString() ?? "0");
      for (int i = 0; i < length; i++) {
        places.add(_buildPlacecallput(optionChainBlocs?.headingsPut[i] ?? "", i,
            length, optionChainBlocs?.headingCallPut));
      }
    }

    return places;
  }

  Widget _buildPlace(
      String place, int index, num length, List<String>? heading) {
    bool checkTitle = true;
    switch (place.toLowerCase()) {
      case 'iv':
        checkTitle = false;
        break;
      case 'strike':
        checkTitle = false;
        break;
      default:
    }
    return Container(
        decoration: const BoxDecoration(
          color: Color.fromRGBO(255, 255, 255, 1),
        ),
        width: 80,
        height: 35,
        child: checkTitle
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    place,
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                  Text(
                    heading![index],
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0),
                    child: Text(
                      place,
                      style: GreekTextStyle.placeOrderAppbarHeading,
                    ),
                  ),
                ],
              ));
  }

  Widget _buildPlacecallput(
      String place, int index, num length, List<String>? heading) {
    bool checkTitle = true;
    switch (place.toLowerCase()) {
      case 'iv':
        checkTitle = false;
        break;
      case 'strike':
        checkTitle = false;
        break;
      default:
    }
    return Container(
        decoration: BoxDecoration(
          color: Colors.grey[200],
        ),
        //color: Colors.yellow,
        width: MediaQuery.of(context).size.width / heading!.length,
        height: 35,
        child: checkTitle
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    place,
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                  Text(
                    heading[index],
                    style: GreekTextStyle.placeOrderAppbarHeading,
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0),
                    child: Text(
                      place,
                      style: GreekTextStyle.placeOrderAppbarHeading,
                    ),
                  ),
                ],
              ));
  }
}

changetextview(s) {
  return Container(
    width: 80,
    padding: const EdgeInsets.only(top: 5, bottom: 5),
    // color: Color.fromRGBO(203, 234, 203, 1),
    child: Text(double.parse(s).toStringAsFixed(2),
        style: double.parse(s.toString()) >= 0.00
            ? GreekTextStyle.optionchainChangepositive
            : GreekTextStyle.optionchainChangenegative,
        textAlign: TextAlign.right),
  );
}

lopeninterest(lOpenInterest) {
  // String textval = (double.parse(lOpenInterest)).toString();
  return Flexible(
    flex: 1,
    child: Container(
      padding: const EdgeInsets.only(top: 5, bottom: 5),
      child: Text(double.parse(lOpenInterest.toString()).toStringAsFixed(2),
          style: GreekTextStyle.optionchainlist),
    ),
  );
}
