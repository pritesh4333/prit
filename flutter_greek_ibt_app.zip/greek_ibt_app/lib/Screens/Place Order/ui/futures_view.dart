import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/bloc/future_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_expiry_response_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Utilities/no_data_with_progress_indicator.dart';

class FutureScreen extends StatefulWidget {
  final PlaceOrderBloc placeOrderBloc;
  final TabController controller;

  // ignore: use_key_in_widget_constructors
  const FutureScreen({required this.controller, required this.placeOrderBloc});
  // FutureScreen({Key? key, required this.controller, required this.placeOrderBloc}) : super(key: key);

  @override
  State<FutureScreen> createState() => _FutureScreenState();
}

class _FutureScreenState extends State<FutureScreen> {
  late int index;
  WatchListBloc? watchBloc;
  bool isScrollable = true;
  final niftyController = TextEditingController();
  late FutureBloc futureBloc;
  TabController? tabController;
  String currentExchange = '';
  double topSpace = 0.0;

  @override
  void initState() {
    super.initState();
    widget.placeOrderBloc.appBarSizeSubject.sink.add(false);
    futureBloc = FutureBloc(context: context, orderMode: widget.placeOrderBloc.orderMode, orderAction: widget.placeOrderBloc.orderAction, orderToken: widget.placeOrderBloc.orderToken);
    niftyController.text = '${widget.placeOrderBloc.orderResponseArray[widget.placeOrderBloc.currentExchangeIndex]?.symbol}';
    int token = int.parse('${widget.placeOrderBloc.orderResponseArray[widget.placeOrderBloc.currentExchangeIndex]?.token}');
    currentExchange = token.toExchange();
    futureBloc.callExpiryAPI(niftyController.text, currentExchange);
    tabController = widget.controller;
  }

  @override
  Widget build(BuildContext context) {
    topSpace = MediaQuery.of(context).size.height / 2;
    return Column(
      children: [
        Flexible(
          fit: FlexFit.tight,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 1, top: 10, right: 1),
                  child: SizedBox(
                    child: StreamBuilder<bool>(
                      stream: futureBloc.mainStream.stream,
                      builder: (context, snapshot) {
                        if (snapshot.hasData && snapshot.data == true) {
                          if (futureBloc.getExpiryResponseArray.isEmpty) {
                            return NoDatWithProgressIndicator(
                              topSpace: topSpace,
                              showHide: false,
                              message: '',
                            );
                          }
                          return ListView.builder(
                              shrinkWrap: true,
                              itemCount: futureBloc.getExpiryResponseArray.length,
                              itemBuilder: (context, index) {
                                if (futureBloc.getExpiryResponseArray.isNotEmpty) {
                                  return StreamBuilder<GetExpiryResponseModel>(
                                      stream: futureBloc.futureStream[index].stream,
                                      builder: (context, snapshot) {
                                        if (snapshot.data == null) {
                                          return Container();
                                        }
                                        return TextButton(
                                          onPressed: () {},
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            children: [
                                              Container(
                                                margin: const EdgeInsets.only(left: 1, top: 0, right: 1),
                                                padding: const EdgeInsets.all(5),
                                                decoration: BoxDecoration(
                                                  color: ConstantColors.white,
                                                  borderRadius: BorderRadius.circular(8.0),
                                                  boxShadow: const [
                                                    BoxShadow(color: Colors.black12, spreadRadius: 1),
                                                  ],
                                                ),
                                                child: TextButton(
                                                  onPressed: () async {
                                                    futureBloc.unsubscribeFutureDetailsLTPinfo();
                                                    tabController?.animateTo(widget.placeOrderBloc.initialTab ?? ScriptInfoTab.overview.index);
                                                    widget.placeOrderBloc.reloadStateForChangeBuySellSwitch.sink.add(true);
                                                    widget.placeOrderBloc.orderToken = int.parse(snapshot.data?.lourtoken ?? '');
                                                    widget.placeOrderBloc.orderAction = OrderAction.buy;
                                                    widget.placeOrderBloc.orderMode = OrderMode.newOrder;

                                                    // GreekNavigator.pop(context: context);
                                                    // final popResult = await GreekNavigator.pushNamed(
                                                    //   context: context,
                                                    //   routeName: GreekScreenNames.place_order,
                                                    //   arguments: [
                                                    //     int.parse(snapshot.data?.lourtoken ?? ""),
                                                    //     OrderAction.buy,
                                                    //     OrderMode.newOrder,
                                                    //     ScriptInfoTab.overview.index,
                                                    //   ],
                                                    // );
                                                  },
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        children: [
                                                          Text(
                                                            '${snapshot.data!.formatedDate.toString()} Futures',
                                                            style: GreekTextStyle.watchlistText,
                                                          ),
                                                          const SizedBox(width: 0.0),
                                                          Text(
                                                            '${int.parse(snapshot.data?.lourtoken ?? "0").toExchange().toString() == "currency" ? snapshot.data?.ltp?.toStringAsFixed(4) ?? 0.00 : snapshot.data?.ltp?.toStringAsFixed(2) ?? 0.00}',
                                                            style: GreekTextStyle.watchlistText,
                                                          ),
                                                        ],
                                                      ),
                                                      const SizedBox(
                                                        height: 5.0,
                                                      ),
                                                      Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        children: [
                                                          Text(
                                                            int.parse(snapshot.data?.lourtoken ?? "0").toExchange().toString(),
                                                            style: GreekTextStyle.watchlistSubText,
                                                          ),
                                                          Text(
                                                            '${(int.parse(snapshot.data?.lourtoken ?? "0").toExchange().toString() == "currency" ? snapshot.data?.change?.toStringAsFixed(4) ?? 0.00 : snapshot.data?.change?.toStringAsFixed(2) ?? 0.00)}(${int.parse(snapshot.data?.lourtoken ?? "0").toExchange().toString() == "currency" ? snapshot.data?.pChange?.toStringAsFixed(4) ?? 0.00 : snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.00}%)',
                                                            style: ((snapshot.data?.change ?? 0.00) >= 0) ? GreekTextStyle.headingWatchlistLTPGreen : GreekTextStyle.headingWatchlistLTPRed,
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      });
                                } else {
                                  return SizedBox(
                                    height: MediaQuery.of(context).size.height / 2,
                                    child: Center(child: GreekBase().noDataAvailableView()),
                                  );
                                }
                              });
                        } else {
                          return NoDatWithProgressIndicator(
                            topSpace: topSpace,
                            showHide: true,
                            message: 'Fetching data...',
                          );
                        }
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Visibility(
          visible: widget.placeOrderBloc.orderMode == OrderMode.newOrder ? true : false,
          child: _containerFour(),
        ),
      ],
    );
  }

  Widget _containerFour() {
    return SafeArea(
      child: Container(
        // height: 40.0,
        color: Colors.white,
        margin: const EdgeInsets.only(top: 5.0),
        padding: const EdgeInsets.only(top: 15, bottom: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: const Color(0xFF33CC33),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc.orderAction = OrderAction.buy;
                    tabController?.animateTo(0);
                    widget.placeOrderBloc.reloadStateForChangeBuySellSwitch.sink.add(true);
                  },
                  child: const Text(
                    "BUY",
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
            Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                color: ConstantColors.sellColor,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: TextButton(
                  onPressed: () {
                    widget.placeOrderBloc.orderAction = OrderAction.sell;
                    tabController?.animateTo(0);
                    widget.placeOrderBloc.reloadStateForChangeBuySellSwitch.sink.add(true);
                  },
                  child: const Text(
                    "SELL",
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =================================

}
