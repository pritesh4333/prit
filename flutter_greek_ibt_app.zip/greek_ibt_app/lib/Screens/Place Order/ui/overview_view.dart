// ignore_for_file: import_of_legacy_library_into_null_safe

import 'package:flutter/material.dart';
import 'package:flutter_xlider/flutter_xlider.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/bloc/overview_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/chartModel/model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/quote_single_symbol_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/technicals_model.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class ChartScreen extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;
  final TabController? controller;

  const ChartScreen({Key? key, this.placeOrderBloc, this.controller}) : super(key: key);

  @override
  _ChartScreenState createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late GlobalKey<State> chartKey;
  late num left, top;
  late List<ChartSampleData> randomData;

  String dropdownValue = 'Daily';
  TabController? tabController;
  OverviewBloc? _overviewBloc;

  String? varValue;
  String? varPercentValue;
  String? elmValue;
  String? elmPercentValue;

  String? varTxt;
  String? varPercentTxt;
  String? elmTxt;
  String? elmPercentTxt;
  String? resist1, resist2, resist3, pivot, support1, support2, support3;
  @override
  void initState() {
    super.initState();

    _overviewBloc?.getDateTimeData();
    _overviewBloc ??= OverviewBloc(context: context, orderMode: widget.placeOrderBloc?.orderMode, orderAction: widget.placeOrderBloc?.orderAction, orderToken: widget.placeOrderBloc?.orderToken);
    tabController = widget.controller;

    // overviewBloc?.getTechnicalDetails();
    // overviewBloc?.callScripInfo();
    // _overviewBloc?.callChartData();

    // overviewBloc?.callCompanySummary(int.parse(isinumber));
    chartKey = GlobalKey<State>();
    left = 0;
    top = 0;
    // _overviewBloc?.getDateTimeData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
        height: MediaQuery.of(context).size.height,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            overviewContent(),
            Visibility(
              visible: widget.placeOrderBloc?.orderMode == OrderMode.newOrder ? true : false,
              child: buySellContainer(),
            ),
          ],
        ),
      ),
    );
  }

  Widget overviewContent() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: StreamBuilder<QuoteForSingleSymbolModel?>(
          stream: widget.placeOrderBloc?.marketPictureObserver,
          builder: (ltpContext, snapshot) {
            // SocketIOManager()
            //     .securityInfoRequest(snapshot.data?.token.toString() ?? '');
            return ListView(shrinkWrap: true, children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  //graphView(),
                  performanceView(snapshot),
                  //StockDetailView(snapshot),
                  //TechnicalView(),
                ],
              ),
            ]);
          },
        ),
      ),
    );
  }

  Widget buySellContainer() {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 5.0),
      padding: const EdgeInsets.only(top: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 40,
            width: 140,
            decoration: BoxDecoration(
              color: Colors.green,
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Center(
              child: TextButton(
                onPressed: () {
                  widget.placeOrderBloc?.orderAction = OrderAction.buy;
                  tabController?.animateTo(0);
                  widget.placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink.add(true);
                },
                child: const Text(
                  "BUY",
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.normal),
                ),
              ),
            ),
          ),
          Container(
            height: 40,
            width: 140,
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Center(
              child: TextButton(
                onPressed: () {
                  widget.placeOrderBloc?.orderAction = OrderAction.sell;
                  tabController?.animateTo(0);
                  widget.placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink.add(true);
                },
                child: const Text(
                  "SELL",
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.normal),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

// ============================================

// ============================================

  Widget performanceView(AsyncSnapshot<QuoteForSingleSymbolModel?> snapshot) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        performanceViewOne(),
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Today’s Low",
                    style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.normal),
                  ),
                  Text(
                    snapshot.data?.low?.toStringAsFixed(2) ?? '0.00',
                    style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.normal),
                  ),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text(
                    "Today’s High",
                    style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.normal),
                  ),
                  Text(
                    snapshot.data?.high?.toStringAsFixed(2) ?? '0.00',
                    style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.normal),
                  ),
                ],
              ),
            ],
          ),
        ),
        FlutterSlider(
          values: [snapshot.data?.last ?? 0.0],
          max: double.parse(snapshot.data?.high?.toStringAsFixed(2) ?? '0.00'),
          min: double.parse(snapshot.data?.low?.toStringAsFixed(2) ?? '0.00'),
          tooltip: FlutterSliderTooltip(
            disabled: true,
          ),
          trackBar: const FlutterSliderTrackBar(
            inactiveTrackBarHeight: 10,
            activeTrackBarHeight: 10,
            inactiveTrackBar: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.yellow,
                  Colors.green,
                  Colors.green,
                ],
              ),
            ),
            activeTrackBar: BoxDecoration(
                gradient: LinearGradient(
              colors: [
                Colors.red,
                Colors.red,
                Colors.yellow,
              ],
            )),
          ),
          handler: FlutterSliderHandler(
            decoration: const BoxDecoration(),
            child: Image.asset(
              'assets/images/triangle_shape.png',
              fit: BoxFit.fitWidth,
              height: 35,
              width: 35,
            ),
          ),
          disabled: true,
          onDragging: (handlerIndex, lowerValue, upperValue) {
            /* _lowerValue = lowerValue;
        _upperValue = upperValue;
        setState(() {});*/
          },
        ),
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "52 Week Low",
                    style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.normal),
                  ),
                  Text(
                    snapshot.data?.ylow?.toStringAsFixed(2) ?? '0.00',
                    style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.normal),
                  ),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text(
                    "52 Week High",
                    style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.normal),
                  ),
                  Text(
                    snapshot.data?.yhigh?.toStringAsFixed(2) ?? '0.00',
                    style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.normal),
                  ),
                ],
              ),
            ],
          ),
        ),
        FlutterSlider(
          axis: Axis.horizontal,
          values: [snapshot.data?.last ?? 0.00],
          max: double.parse(snapshot.data?.yhigh?.toStringAsFixed(2) ?? '0.00'),
          min: double.parse(snapshot.data?.ylow?.toStringAsFixed(2) ?? '0.00'),
          tooltip: FlutterSliderTooltip(
            disabled: true,
          ),
          handler: FlutterSliderHandler(
            decoration: const BoxDecoration(),
            child: Image.asset(
              'assets/images/triangle_shape.png',
              fit: BoxFit.fitWidth,
              height: 35,
              width: 35,
            ),
          ),
          trackBar: const FlutterSliderTrackBar(
            inactiveTrackBarHeight: 10,
            activeTrackBarHeight: 10,
            inactiveTrackBar: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.yellow,
                  Colors.green,
                  Colors.green,
                ],
              ),
            ),
            activeTrackBar: BoxDecoration(
                gradient: LinearGradient(
              colors: [
                Colors.red,
                Colors.red,
                Colors.yellow,
              ],
            )),
          ),
          disabled: true,
          onDragging: (handlerIndex, lowerValue, upperValue) {},
        ),
      ],
    );
  }

// ============================================
// ============================================

  Widget performanceViewOne() {
    return Row(
      children: [
        Text(
          "Performance",
          style: GreekTextStyle.OverviewTitleTxt,
          textAlign: TextAlign.start,
        ),
      ],
    );
  }

  // ---------------------------------------------

// ---------------------------------------------

  Widget technicalViewOne() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "Technicals",
          style: GreekTextStyle.OverviewTitleTxt,
          textAlign: TextAlign.start,
        ),
        /* Container(
          height: 35,
          width: 100,
          padding: EdgeInsets.only(left: 10.0),
          margin: EdgeInsets.only(left: 15.0),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(
              color: Colors.grey,
              width: 0.5,
            ),
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 5.0,
              ),
            ],
          ),
          child: DropdownButton<String>(
            value: dropdownValue,
            icon: Icon(Icons.keyboard_arrow_down),
            iconSize: 24,
            elevation: 16,
            style: const TextStyle(color: Colors.black),
            underline: Container(
              height: 0.0,
            ),
            onChanged: (String? newValue) {
              setState(() {
                dropdownValue = newValue!;
              });
            },
            items:
                <String>['Daily'].map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ),*/
      ],
    );
  }

  Widget technicalViewTwo() {
    return FutureBuilder<List<TechnicalsModel?>>(
      future: _overviewBloc?.getTechnicalDetails(),
      builder: (futureContext, snapshot) {
        if (snapshot.hasData) {
          final dataList = snapshot.data;
          getTechnicalData(dataList!);
          return Container(
            height: 100,
            margin: const EdgeInsets.only(bottom: 10.0),
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: const [
                            Text(
                              "R1",
                              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "R2",
                              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "R3",
                              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              resist1 ?? '',
                              style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              resist2 ?? '',
                              style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              resist3 ?? '',
                              style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: 80,
                  height: MediaQuery.of(context).size.height,
                  padding: const EdgeInsets.only(left: 5.0, right: 5.0),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey,
                        blurRadius: 5.0,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        "Pivot",
                        style: TextStyle(color: Colors.blue, fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        pivot ?? '',
                        style: const TextStyle(color: Colors.blue, fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "S1",
                              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "S2",
                              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "S3",
                              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              support1 ?? '',
                              style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              support2 ?? '',
                              style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              support3 ?? '',
                              style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        return SizedBox(
          height: MediaQuery.of(context).size.height / 2,
          child: Center(child: GreekBase().noDataAvailableView()),
        );
      },
    );
  }

  void getTechnicalData(List<TechnicalsModel?> dataList) {
    for (var item in dataList) {
      if (widget.placeOrderBloc?.orderResponseArray[widget.placeOrderBloc?.currentExchangeIndex ?? 0]?.token?.toAssetType().toString() == 'currency') {
        resist1 = double.parse(item?.resist1 ?? '').toStringAsFixed(4);
        resist2 = double.parse(item?.resist2 ?? '').toStringAsFixed(4);
        resist3 = double.parse(item?.resist3 ?? '').toStringAsFixed(4);
        support1 = double.parse(item?.support1 ?? '').toStringAsFixed(4);
        support2 = double.parse(item?.support2 ?? '').toStringAsFixed(4);
        support3 = double.parse(item?.support3 ?? '').toStringAsFixed(4);
        pivot = double.parse(item?.pivot ?? '').toStringAsFixed(4);
      } else {
        resist1 = double.parse(item?.resist1 ?? '').toStringAsFixed(2);
        resist2 = double.parse(item?.resist2 ?? '').toStringAsFixed(2);
        resist3 = double.parse(item?.resist3 ?? '').toStringAsFixed(2);
        support1 = double.parse(item?.support1 ?? '').toStringAsFixed(2);
        support2 = double.parse(item?.support2 ?? '').toStringAsFixed(2);
        support3 = double.parse(item?.support3 ?? '').toStringAsFixed(2);
        pivot = double.parse(item?.pivot ?? '').toStringAsFixed(2);
      }
    }
  }

// ============================================

// ============================================

  Widget verticalDivider() {
    return Container(
      width: 1,
      height: MediaQuery.of(context).size.height,
      margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
      color: Colors.grey,
    );
  }

  Widget technicalProgress() {
    return Stack(
      fit: StackFit.passthrough,
      children: [
        Center(
          child: Image.asset(
            'assets/images/technical_indicator.png',
            fit: BoxFit.contain,
          ),
        ),
        FlutterSlider(
          values: [double.parse(pivot ?? '0.0')],
          max: double.parse(resist1 ?? '10.0'),
          min: double.parse(support3 ?? '0.0'),
          trackBar: const FlutterSliderTrackBar(
            inactiveTrackBarHeight: 5,
            activeTrackBarHeight: 5,
            inactiveTrackBar: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  Colors.transparent,
                ],
              ),
            ),
            activeTrackBar: BoxDecoration(
                gradient: LinearGradient(
              colors: [
                Colors.transparent,
                Colors.transparent,
              ],
            )),
          ),
          handlerHeight: 67.0,
          handler: FlutterSliderHandler(
            decoration: const BoxDecoration(),
            child: Column(
              children: [
                Image.asset(
                  'assets/images/triangle_shape.png',
                  fit: BoxFit.contain,
                  height: 40,
                  width: 40,
                ),
                Container(
                    color: Colors.white,
                    child: Text(
                      '${double.parse(pivot ?? '0.0')}',
                      style: const TextStyle(color: Colors.blue),
                    ))
              ],
            ),
          ),
          tooltip: FlutterSliderTooltip(
            disabled: true,
          ),
          disabled: true,
          onDragging: (handlerIndex, lowerValue, upperValue) {
            /* _lowerValue = lowerValue;
        _upperValue = upperValue;
        setState(() {});*/
          },
        ),
      ],
    );
  }

// ============================================
}
