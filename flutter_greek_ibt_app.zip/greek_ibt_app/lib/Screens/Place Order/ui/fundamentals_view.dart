import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';

class FundamentalsScreen extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;

  const FundamentalsScreen({Key? key, TabController? controller, this.placeOrderBloc}) : super(key: key);

  @override
  State<FundamentalsScreen> createState() => _FundamentalsScreenState();
}

class _FundamentalsScreenState extends State<FundamentalsScreen> {
  @override
  void initState() {
    super.initState();
    widget.placeOrderBloc!.appBarSizeSubject.sink.add(false);
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width / 2,
        height: 35,
        child: const Center(
            child: Text(
          "Coming Soon",
          style: TextStyle(),
        )),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          color: Colors.white,
          boxShadow: const [
            BoxShadow(
              color: Colors.black38,
              offset: Offset(0, 1),
            )
          ],
        ),
      ),
    );
  }
}
