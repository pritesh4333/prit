import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_expiry_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_strike_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/option_chain_call_put_model.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/ui/option_chain_view.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/rxdart.dart';

class OptionChainBloc extends PlaceOrderBloc {
  final BuildContext context;
/*   OptionChainBloc({
    required this.context,
  }) : super(context, 0, "", ""); */

  OptionChainBloc({required this.context, required orderMode, required orderAction, obj, required orderToken})
      : super(
          context,
          orderMode: orderMode,
          orderAction: orderAction,
          obj: obj,
          orderToken: orderToken,
        ) {
    registerCommonAppListener();
    registerOptionChainAppListener();
  }

  List<GetExpiryResponseModel?> getExpiryResponseArray = <GetExpiryResponseModel?>[];
  List<GetStrikeResponseModel?> getStrikeResponseArray = <GetStrikeResponseModel?>[];

  List<double?> getupperStrikeResponseArray = <double?>[];

  List<double?> getlowerStrikeResponseArray = <double?>[];

  List<String> _subscribeTouchlineToken = [];
  List<String> _subscribeputTouchlineToken = [];
  List<String> _unsubscribeTouchlineToken = [];

  final _items = <String>[];
  final _itemsput = <String>[];

  List<OptionChainResponseModel?> filterArray = [];

  var timemap = {};

  String? ltp = "";

  bool isvolume = false;
  bool oi = false;
  bool oIChange = false;
  bool iv = false;
  bool greeks = false;
  bool delta = false;
  bool gama = false;
  bool vega = false;
  // bool isvolume = true;
  var headings = [
    'Oi',
    'LTP',
    'Strike',
    'LTP',
    'Oi',
  ];
  var heading1 = [
    'Change',
    'Change',
    '',
    'Change',
    'Change',
  ];

  //call table
  var headingsCall = [
    'Oi',
    'LTP',
    'Strike',
  ];
  var headingCallValue = [
    'Change',
    'Change',
    '',
  ];
  var noofStrike = "10";

  //put table
  var headingsPut = [
    'Strike',
    'LTP',
    'Oi',
  ];
  var headingCallPut = [
    '',
    'Change',
    'Change',
  ];

  @override
  void disposeBloc() {
    _unsubscribeTouchlineToken;
    orderResponseArray.clear();
    _optionChainDataSubject.close();
  }

  final expiryDataSubject = BehaviorSubject<List<GetExpiryResponseModel>>();
  Stream<List<GetExpiryResponseModel>> get expiryObserver => expiryDataSubject.stream;

  final PublishSubject<List<OptionChainResponseModel?>> _optionChainDataSubject = PublishSubject();
  Stream<List<OptionChainResponseModel?>> get optionChainObserverable => _optionChainDataSubject.stream;

  final settingchangeSubject = BehaviorSubject<bool>();
  Stream<bool> get settingObserver => settingchangeSubject.stream;
  // BehaviorSubject settingChange = BehaviorSubject.seeded(true);

  Future<List<GetExpiryResponseModel?>> callExpiryAPI(String symbol) async {
    List<GetExpiryResponseModel> tempExpiryList = [];
    expiryDataSubject.sink.add([]);

    final getExpiryResponse = await super.repository.getExpiryAPI(context, symbol: symbol);
    expiryDataSubject.sink.add(getExpiryResponse);
    int length = getExpiryResponse.length;

    if (length > 0) {
      for (var item in getExpiryResponse) {
        tempExpiryList.add(item);
      }
      getExpiryResponseArray = tempExpiryList;

      for (int i = 0; i < getExpiryResponseArray.length; i++) {
        timemap[DateFormat('ddMMMyyyy').format(DateTime.fromMillisecondsSinceEpoch(int.parse(getExpiryResponseArray.elementAt(i)?.expiry ?? '') * 1000))] = getExpiryResponseArray.elementAt(i)?.expiry.toString();
      }

      return getExpiryResponseArray;
    }
    return [];
  }

  void callStrikeAPI(String symbol, String expiry, String currentExchange) async {
    final ltpResponse = await repository.getLTP(context, symbol: symbol, expiry: timemap[expiry]);

    ltp = ltpResponse['ltp'].toString();

    List<GetStrikeResponseModel> tempStrikeList = [];

    final getStrikeResponse = await super.repository.getStrikeAPI(context, symbol: symbol, expiry: timemap[expiry]);
    int length = getStrikeResponse.length;
    if (length > 0) {
      for (var item in getStrikeResponse) {
        // tempStrikeList.add(item);
        int lourToken = int.parse(item.lourtoken ?? '0');
        if (lourToken.toExchange().toString().toLowerCase().compareTo(currentExchange.toLowerCase()) == 0) {
          tempStrikeList.add(item);
        }
        // someObjects.sort((a, b) => a.someProperty.compareTo(b.someProperty));
      }

      for (var item in tempStrikeList) {
        if ((double.parse(ltp!) / 100) > double.parse(item.strikeprice ?? "")) {
          getlowerStrikeResponseArray.add(double.parse(item.strikeprice ?? ""));
        } else {
          getupperStrikeResponseArray.add(double.parse(item.strikeprice ?? ""));
        }
      }
      /* getlowerStrikeResponseArray.sort();
      getupperStrikeResponseArray.sort(); */
      // String fromStrikr, tostrike;

      // [Added By Sushant]
      int lengthLowerStrike = getlowerStrikeResponseArray.length;
      int lengthUpperStrike = getupperStrikeResponseArray.length;

      List<double?> templower = [];
      List<double?> tempupper = [];

      if (noofStrike != "All") {
        if (lengthLowerStrike > 0) {
          for (int i = getlowerStrikeResponseArray.length - 1; i >= getlowerStrikeResponseArray.length - int.parse(noofStrike); i--) {
            templower.add(getlowerStrikeResponseArray[i]);
          }
        }

        if (lengthUpperStrike > 0) {
          for (int i = 0; i < int.parse(noofStrike); i++) {
            tempupper.add(getupperStrikeResponseArray[i]);
          }
        }
      } else {
        templower.addAll(getlowerStrikeResponseArray);
        tempupper.addAll(getupperStrikeResponseArray);
      }

      int tempLowerLength = templower.length;
      int tempUpperLength = tempupper.length;

      if (tempLowerLength > 0) {
        templower.sort();
      }
      if (tempUpperLength > 0) {
        tempupper.sort();
      }

      if (tempLowerLength > 0 && tempUpperLength > 0) {
        callOptionChainAPIS(
          symbol: symbol,
          expiry: expiry,
          fromStrike: '${templower[0]}',
          //getStrikeResponseArray.first?.strikeprice.toString() ?? '',
          toStrike: '${tempupper[tempupper.length - 1]}',
          // getStrikeResponseArray.last?.strikeprice.toString() ?? '',
        );
        // subscribeTouchLine();
      } else {
        _optionChainDataSubject.sink.add([]);
      }
    }
  }

  void callOptionChainAPIS({
    required String symbol,
    required String expiry,
    required String fromStrike,
    required String toStrike,
  }) async {
    List<OptionChainResponseModel?> mainObj = await super.repository.getOptionChainAPI(
          context: context,
          exchange: orderToken.toExchange().toString().toUpperCase(),
          symbol: symbol,
          fromStrike: fromStrike,
          toStrike: toStrike,
          expiry: expiry,
        );

    filterArray = mainObj
        .where(
          (element) => (expiry.toLowerCase().compareTo(element?.call?.expiryDate?.toLowerCase() ?? '') == 0),
        )
        .toList();

    filterArray.sort((a, b) => (double.parse(a!.strikePrice.toString())).compareTo(double.parse(b!.strikePrice.toString())));
    // players.sort((a, b) => a.gameID.compareTo(b.gameID));

    _optionChainDataSubject.sink.add(filterArray);
    for (var item in filterArray) {
      _items.add(item?.call?.lOurToken.toString() ?? '');
      _itemsput.add(item?.put?.lOurToken.toString() ?? '');
    }
    subscribeTouchLine();
  }

  void registerOptionChainAppListener() {
    //SocketIOManager().brodcastResponseObservable.listen((event) {
    SocketIOManager().brodcastResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.apolloResponseStreamingType == ApolloResponseStreamingType.touchline) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              final token = int.parse('${responseDic['symbol']}');

              final ltp = double.parse('${responseDic['ltp']}');
              final pChange = double.parse('${responseDic['p_change']}');
              final volume = double.parse('${responseDic['tot_vol']}');
              for (int i = 0; i < _items.length; i++) {
                if (token.toString() == _items[i].toString()) {
                  int foundindex = _items.indexOf(token.toString());
                  filterArray[foundindex]?.call?.ltp = ltp;
                  filterArray[foundindex]?.call?.lVolume = volume;
                  filterArray[foundindex]?.call?.change = pChange;
                  _optionChainDataSubject.sink.add(filterArray);
                  break;
                }
              }

              for (int i = 0; i < _itemsput.length; i++) {
                if (token.toString() == _itemsput[i].toString()) {
                  int foundindexput = _itemsput.indexOf(token.toString());
                  filterArray[foundindexput]?.put?.ltp = ltp;
                  filterArray[foundindexput]?.put?.lVolume = volume;
                  filterArray[foundindexput]?.put?.change = pChange;
                  _optionChainDataSubject.sink.add(filterArray);
                  break;
                }
              }
            }
          }
        }
      }
    });
  }

  void subscribeTouchLine() {
    if (_unsubscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().unSubscribeTouchLineTokens(_items);
      SocketIOManager().unSubscribeTouchLineTokens(_itemsput);
    }

    _subscribeTouchlineToken = _items;
    _subscribeputTouchlineToken = _itemsput;
    if (_subscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().subscribeTouchLineTokens(_subscribeTouchlineToken);
      SocketIOManager().subscribeTouchLineTokens(_subscribeputTouchlineToken);
      _unsubscribeTouchlineToken = _subscribeTouchlineToken;
    }
  }

  void unSubscribeTouchLine() {
    if (_unsubscribeTouchlineToken.isNotEmpty) {
      SocketIOManager().unSubscribeTouchLineTokens(_items);
    }
  }
}

void callLTPAPI(String symbol, String? string) {}
