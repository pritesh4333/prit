// ignore: implementation_imports
import 'package:flutter/src/widgets/framework.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_expiry_response_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';

class FutureBloc extends PlaceOrderBloc {
  final BuildContext context;

  List<String> subscribeFutureDetailsTokens = [];
  List<String> unSubscribeFutureDetailsTokens = [];

  final mainStream = BehaviorSubject.seeded(false);

  List<GetExpiryResponseModel?> getExpiryResponseArray = <GetExpiryResponseModel?>[];

  List<BehaviorSubject<GetExpiryResponseModel>> futureStream = <BehaviorSubject<GetExpiryResponseModel>>[];
  var timemap = {};

  FutureBloc({required this.context, required orderMode, required orderAction, obj, required orderToken}) : super(context, orderMode: orderMode, orderAction: orderAction, obj: obj, orderToken: orderToken) {
    SocketIOManager().brodcastResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();

          for (var item in keys) {
            if (item.apolloResponseStreamingType == ApolloResponseStreamingType.marketPicture) {
              final responseDic = event[item];
              // print(responseDic);
              if (responseDic is Map<String, dynamic>) {
                if ((responseDic['symbol'] != null) && (responseDic['ltp'] != null) && (responseDic['change'] != null) && (responseDic['p_change'] != null)) {
                  final token = int.parse(responseDic['symbol'].toString());
                  final ltp = double.parse(responseDic['ltp'].toString());
                  final change = double.parse(responseDic['change'].toString());
                  var pChange = 0.0;
                  try {
                    pChange = double.parse(responseDic['p_change'].toString());
                  } catch (e) {
                    // print("p_chnage " + e.toString());
                  }

                  for (var item in getExpiryResponseArray) {
                    if ((item!.lourtoken ?? -1) == token.toString()) {
                      var obj = item;
                      obj.ltp = ltp;
                      obj.change = change;
                      obj.pChange = pChange;

                      final foundedIndex = getExpiryResponseArray.indexOf(item);
                      if (foundedIndex >= 0) {
                        getExpiryResponseArray[foundedIndex] = obj;
                        futureStream[foundedIndex].sink.add(obj);
                        break;
                      }
                    }
                  }
                }
                break;
              }
            } else if (item.apolloResponseStreamingType == ApolloResponseStreamingType.ltpinfo) {
              final responseDic = event[item];
              // print(responseDic);
              if (responseDic is Map<String, dynamic>) {
                if ((responseDic['symbol'] != null) && (responseDic['ltp'] != null) && (responseDic['change'] != null) && (responseDic['p_change'] != null)) {
                  final token = int.parse(responseDic['symbol'].toString());
                  final ltp = double.parse(responseDic['ltp'].toString());
                  final change = double.parse(responseDic['change'].toString());
                  var pChange = 0.0;
                  try {
                    pChange = double.parse(responseDic['p_change'].toString());
                  } catch (e) {
                    // print("p_chnage " + e.toString());
                  }

                  for (var item in getExpiryResponseArray) {
                    if ((item!.lourtoken ?? -1) == token.toString()) {
                      var obj = item;
                      obj.ltp = ltp;
                      obj.change = change;
                      obj.pChange = pChange;

                      final foundedIndex = getExpiryResponseArray.indexOf(item);
                      if (foundedIndex >= 0) {
                        getExpiryResponseArray[foundedIndex] = obj;
                        futureStream[foundedIndex].sink.add(obj);
                        break;
                      }
                    }
                  }
                }
                break;
              }
            }
          }
        }
      },
    );
  }

  callExpiryAPI(String symbol, String currentExchange) async {
    List<GetExpiryResponseModel> tempExpiryList = [];

    final getExpiryResponse = await super.repository.getExpiryAPI(context, symbol: symbol);

    List<GetExpiryResponseModel> dataTemp = [];

    int length = getExpiryResponse.length;

    if (length > 0) {
      for (var item in getExpiryResponse) {
        int lourToken = int.parse(item.lourtoken ?? '0');
        if (lourToken.toExchange().toString().toLowerCase().compareTo(currentExchange.toLowerCase()) == 0) {
          tempExpiryList.add(item);
        }
      }
      getExpiryResponseArray = tempExpiryList;
      futureStream = List.generate(
        getExpiryResponseArray.length,
        (index) {
          return BehaviorSubject<GetExpiryResponseModel>.seeded(getExpiryResponseArray[index]!);
        },
      );
      mainStream.sink.add(true);

      subscribeFutureDetailsLTPInfoTokensHolding();
    }
  }

  void subscribeFutureDetailsLTPInfoTokensHolding() {
    if (unSubscribeFutureDetailsTokens.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(unSubscribeFutureDetailsTokens);
    }

    subscribeFutureDetailsTokens = getExpiryResponseArray.map((e) => (e!.lourtoken.toString())).toList();

    subscribeFutureDetailsTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeFutureDetailsTokens);

    unSubscribeFutureDetailsTokens = subscribeFutureDetailsTokens;
  }

  void unsubscribeFutureDetailsLTPinfo() {
    if (unSubscribeFutureDetailsTokens.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(unSubscribeFutureDetailsTokens);
    }
  }
}
