import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/graph_model.dart';
import 'package:greek_ibt_app/Screens/Watch List/models/search_model/search_symbol_response_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';

class WatchListRepository {
  Future<List<Getwatchlistdata>> watchListGroupNames(
    BuildContext context,
  ) async {
    final response = await NetworkManager().postAPIEncrypted(
      context: context,
      apiName: APIName.getWatchlistNamesForFlutter,
      postBody: {
        'gscid': AppConfig().gscid,
      },
    );

    if ((response != null) && (response is Map<String, dynamic>)) {
      final modelObj = WatchListGroupNamesModel.fromJson(response);
      return modelObj.getwatchlistdata ?? [];
    }

    return [];
  }

  Future<List<SymbolList>> watchListDataByGroupName({
    required BuildContext context,
    required String name,
  }) async {
    {
      final response = await NetworkManager().postAPIEncrypted(
        context: context,
        apiName: APIName.getWatchlistDataByGroupName_MobileV2,
        postBody: {
          'gscid': AppConfig().gscid,
          'WatchListType': 'user',
          'WatchListGroup': name,
        },
      );

      if ((response != null) && (response is Map<String, dynamic>)) {
        final modelObj = WatchlistResponseModel.fromJson(response);

        if (modelObj.getwatchlistdata != null) {
          for (var item in modelObj.getwatchlistdata!) {
            if (item.watchlistName == name) return item.symbolList ?? [];
          }
        }
      }
      return [];
    }
  }

  Future<Object?> renameWatchlistGroup({
    required BuildContext context,
    required String oldGroupName,
    required String newGroupName,
  }) async {
    final response = await NetworkManager().postAPIEncrypted(
      apiName: APIName.updateWatchlistName,
      context: context,
      postBody: {
        'gcid': AppConfig().gcid,
        'gscid': AppConfig().gscid,
        'oldWatchListName': oldGroupName,
        'newWatchListName': newGroupName,
      },
    );

    return response;
  }

  Future<int?> createWatchListGroup({
    required BuildContext context,
    required String name,
  }) async {
    final requestQuery =
        'clientCode=${AppConfig().gcid}&gscid=${AppConfig().gscid}&groupName=$name&watchlistType=user';
    final errorCode = await NetworkManager().getAPIEncryptedOnlyForErrorCode(
      context: context,
      apiName: APIName.createGroupForWatchlist,
      query: requestQuery,
    );
    return errorCode;
  }

//This is for Flutter Watchlist creation which consist sequence no.
  Future<int?> createWatchListGroupFlutter({
    required BuildContext context,
    required String name,
    required String watchlistSeq,
  }) async {
    final requestQuery =
        'clientCode=${AppConfig().gcid}&gscid=${AppConfig().gscid}&groupName=$name&watchlistType=user&watchlistSeq=${int.parse(watchlistSeq)}';
    final errorCode = await NetworkManager().getAPIEncryptedOnlyForErrorCode(
      context: context,
      apiName: APIName.createWatchlistFlutter,
      query: requestQuery,
    );
    return errorCode;
  }

  Future<int?> deleteWatchListGroup(
      {required BuildContext context, required String name}) async {
    final requestQuery =
        'clientCode=${AppConfig().gcid}&gscid=${AppConfig().gscid}&groupName=$name&watchlistType=user';
    final errorCode = await NetworkManager().getAPIEncryptedOnlyForErrorCode(
      context: context,
      apiName: APIName.deleteGroupForWatchlistV2,
      query: requestQuery,
    );
    return errorCode;
  }

  Future<List<SearchSymbolResponseModel>> searchSymbol(
      {required String symbol}) async {
    final result = await NetworkManager().searchSymbolAPI(symbolName: symbol);

    if ((result is List) && (result.isNotEmpty)) {
      final objects =
          result.map((e) => SearchSymbolResponseModel.fromJson(e)).toList();
      return objects;
    }

    return [];
  }

  Future<int?> addSymbolIntoWatchGroup({
    required BuildContext context,
    required String groupName,
    //required int listCount,
    required List<SearchSymbolSqliteModel> symbolList,
  }) async {
    //var seqNo = listCount;
    final symbolDetail = symbolList.map(
      (symbol) {
        final dic = {
          "exchange": int.parse(symbol.token ?? '').toExchange(),
          "assetType": int.parse(symbol.token ?? '').toAssetType(),
          "token": int.parse(symbol.token ?? '').toString(),
          "tradeSymbol": symbol.description ?? '',
          "seqNo": "0" // Need to Change
        };
        //seqNo++;
        return dic;
      },
    ).toList();
    final requestBody = {
      "gcid": AppConfig().gcid,
      "strToken": AppConfig().sessionID,
      "groupName": groupName,
      "watchlistType": "user",
      "gscid": AppConfig().gscid,
      "symbolDetails": symbolDetail,
    };
    return await NetworkManager().postAPIEncryptedOnlyForErrorCode(
      context: context,
      apiName: APIName.addNewScriptToWatchlistGroupV2,
      postBody: requestBody,
    );
  }

  Future<int?> deleteSymbolIntoWatchGroup({
    required BuildContext context,
    required String groupName,
    required List<SymbolList> symbolList,
  }) async {
    final symbolDetail = symbolList
        .map(
          (symbol) => {
            "exchange": symbol.token?.toExchange().toString() ?? '',
            "assetType": symbol.seriesName ?? '',
            "token": symbol.token.toString(),
            "tradeSymbol": symbol.symbol ?? '',
          },
        )
        .toList();
    final requestBody = {
      "gscid": AppConfig().gscid,
      "watchlistType": "user",
      "groupName": groupName,
      "symbolDetails": symbolDetail
    };
    return await NetworkManager().postAPIEncryptedOnlyForErrorCode(
      context: context,
      apiName: APIName.deleteScriptFromWatchlistGroupV2,
      postBody: requestBody,
    );
  }

  Future<List<GraphResponseModel>> getGraphData({
    required BuildContext context,
    required String token,
    required String date,
  }) async {
    final response = await NetworkManager()
        .postAPIEncrypted(apiName: APIName.jhistorical_New, postBody: {
      "token": token,
      "interval": "1",
      "date": date,
      "time": "0",
      "noofdays": "1",
    });

    if (response is Map) {
      final responseData = response['data'];

      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj =
            responseData.map((e) => GraphResponseModel.fromJson(e)).toList();

        return obj;
      }
    }
    return [];
  }

  //jhistorical_New
  Future<List<GraphResponseModel>> getChartDataHistoricalNew({
    required BuildContext context,
    required String token,
    required String date,
    required String interval,
    required String noofdays,
  }) async {
    final response = await NetworkManager()
        .postAPIEncrypted(apiName: APIName.jhistorical_New, postBody: {
      "token": token,
      "interval": interval,
      "date": date,
      "time": "0",
      "noofdays": noofdays,
    });

    if (response is Map) {
      final responseData = response['data'];
      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj =
            responseData.map((e) => GraphResponseModel.fromJson(e)).toList();
        return obj;
      }
    }
    return [];
  }

  //jDaily_New
  Future<List<GraphResponseModel>> getChartDataDailyNew({
    required BuildContext context,
    required String token,
    required String startTime,
    required String endTime,
    required String interval,
  }) async {
    final response = await NetworkManager()
        .postAPIEncrypted(apiName: APIName.jDaily_New, postBody: {
      "token": token,
      "interval": interval,
      "startTime": startTime,
      "endTime": endTime,
    });

    if (response is Map) {
      final responseData = response['data'];
      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj =
            responseData.map((e) => GraphResponseModel.fromJson(e)).toList();
        return obj;
      }
    }
    return [];
  }

//jWeekly_New
  Future<List<GraphResponseModel>> getChartDatajWeeklyNew({
    required BuildContext context,
    required String token,
    required String startTime,
    required String endTime,
    required String interval,
  }) async {
    final response = await NetworkManager()
        .postAPIEncrypted(apiName: APIName.jWeekly_New, postBody: {
      "token": token,
      "interval": interval,
      "startTime": startTime,
      "endTime": endTime,
    });

    if (response is Map) {
      final responseData = response['data'];
      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj =
            responseData.map((e) => GraphResponseModel.fromJson(e)).toList();
        return obj;
      }
    }
    return [];
  }
}
