import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/graph_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/company_summary_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_expiry_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/get_strike_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/option_chain_call_put_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/quote_single_symbol_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/srip_info_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/technicals_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class BuySellRepository {
  Future<List<QuoteForSingleSymbolModel?>> getBuySellAPI({required BuildContext context, required int orderToken}) async {
    final responseData = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.getQuoteForSingleSymbol_V3,
        postBody: {
          'token': orderToken.toString(),
          'assetType': orderToken.toAssetType(),
          'gscid': AppConfig().gscid,
          'gcid': AppConfig().gcid,
        });

    if (responseData is List) {
      final obj = responseData.map((e) => QuoteForSingleSymbolModel.fromJson(e)).toList();
      return obj;
    } else if (responseData is Map<String, dynamic>) {
      final obj = QuoteForSingleSymbolModel.fromJson(responseData);
      return [obj];
    }

    return [];
  }

  //=======================  Overview Request  ========================

  Future<List<TechnicalsModel>> getTechnicalAPI(
    BuildContext context, {
    required int token,
  }) async {
    final requestQuery = "token=" + token.toString();

    final val = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getTechnicalDetailsForScript,
      query: requestQuery,
    );

    List<TechnicalsModel> objList = <TechnicalsModel>[];

    if (val is List) {
      objList = val
          .map(
            (e) => TechnicalsModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<List<CompanySummaryModel>> getCompanySummaryAPI(
    BuildContext context, {
    required int isinumber,
  }) async {
    final requestQuery = "isin=" + isinumber.toString();

    final val = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getCompanySummary,
      query: requestQuery,
    );

    List<CompanySummaryModel> objList = <CompanySummaryModel>[];

    if (val is List) {
      objList = val
          .map(
            (e) => CompanySummaryModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<List<ScripInfoResponseModel>> getSctiptInfoAPI(
    BuildContext context, {
    required int token,
    required String assetType,
    required String exchange,
  }) async {
    final requestQuery = "token=" + token.toString() + '&assetType=' + assetType + '&exchange=' + exchange;

    final valSripInfo = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getScripInfo,
      query: requestQuery,
    );

    List<ScripInfoResponseModel> objList = <ScripInfoResponseModel>[];

    if (valSripInfo is List) {
      objList = valSripInfo
          .map(
            (e) => ScripInfoResponseModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<List<GraphResponseModel>> getGraphData({required BuildContext context, required String token}) async {
    // var modelArray = <GraphResponseModel>[];
    final response = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.jhistorical_New,
        postBody: {
          "token": token,
          "interval": "1",
          "date": "20220225",
          "time": "0",
          "noofdays": "1",
        });

    if (response is Map) {
      final responseData = response['data'];

      if ((responseData is List) && (responseData.isNotEmpty)) {
        final obj = responseData.map((e) => GraphResponseModel.fromJson(e)).toList();

        return obj;
      }
    }
    return [];
  }

  //====================================================================

  //=======================  Option Chain Request  =====================

  Future<List<OptionChainResponseModel?>> getOptionChainAPI({required BuildContext context, required String exchange, required String symbol, required String fromStrike, required String toStrike, required String expiry}) async {
    final responseOptionChain = await NetworkManager().postAPIEncrypted(
        //context: context,
        apiName: APIName.OptionChainRequest,
        postBody: {
          'cExchange': exchange,
          'cSymbol': symbol,
          'dFromStrike': fromStrike,
          'dToStrike': toStrike,
          'cExpiry': expiry,
        });

    var modelObjArray = <OptionChainResponseModel>[];
    if (responseOptionChain is Map) {
      final mapObj = responseOptionChain['data'];

      if (mapObj is List) {
        var index = 0;

        while (index < mapObj.length) {
          final callMap = mapObj.elementAt(index);
          final putMap = mapObj.elementAt(index + 1);

          final obj = OptionChainResponseModel.fromJson([callMap, putMap]);
          modelObjArray.add(obj);

          index += 2;
        }
      }
    }

    return modelObjArray;
  }

  Future<List<GetExpiryResponseModel>> getExpiryAPI(
    BuildContext context, {
    required String symbol,
  }) async {
    final requestQuery = "cSymbol=" + symbol;

    final valGetExpiry = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getexpiryRequest,
      query: requestQuery,
    );

    List<GetExpiryResponseModel> objList = <GetExpiryResponseModel>[];

    if (valGetExpiry is List) {
      objList = valGetExpiry
          .map(
            (e) => GetExpiryResponseModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<List<GetStrikeResponseModel>> getStrikeAPI(
    BuildContext context, {
    required String symbol,
    required String expiry,
  }) async {
    final requestQuery = "cSymbol=" + symbol + "&lExpiry=" + expiry;

    final valGetStrike = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getstrikeRequest,
      query: requestQuery,
    );

    List<GetStrikeResponseModel> objList = <GetStrikeResponseModel>[];

    if (valGetStrike is List) {
      objList = valGetStrike
          .map(
            (e) => GetStrikeResponseModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }

  Future<dynamic> getLTP(BuildContext context, {required String symbol, required String expiry}) async {
    final requestQuery = "symbol=" + symbol + "&expiry=" + expiry;

    final valLTP = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getFutLTP,
      query: requestQuery,
    );

    if (valLTP is Map<String, dynamic>) {
      //final obj = GetLTPModel.fromJson(valLTP);
      return valLTP;
    }
  }
}
