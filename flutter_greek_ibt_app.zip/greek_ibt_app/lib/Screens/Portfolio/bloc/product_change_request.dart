class ProductChangeRequestModel {
  String? gscid;
  String? gtoken;
  String? qty;
  String? product;
  String? tradedQty;
  String? iGiveUpStatus;
  String? reason;
  String? gorderid;
  String? tradeid;
  String? eorderid;
  String? side;

  ProductChangeRequestModel(
      {this.gscid,
      this.gtoken,
      this.qty,
      this.product,
      this.tradedQty,
      this.iGiveUpStatus,
      this.reason,
      this.gorderid,
      this.tradeid,
      this.eorderid,
      this.side});

  ProductChangeRequestModel.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    gtoken = json['gtoken'];
    qty = json['qty'];
    product = json['product'];
    tradedQty = json['traded_qty'];
    iGiveUpStatus = json['iGiveUpStatus'];
    reason = json['reason'];
    gorderid = json['gorderid'];
    tradeid = json['tradeid'];
    eorderid = json['eorderid'];
    side = json['side'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    data['gtoken'] = gtoken;
    data['qty'] = qty;
    data['product'] = product;
    data['traded_qty'] = tradedQty;
    data['iGiveUpStatus'] = iGiveUpStatus;
    data['reason'] = reason;
    data['gorderid'] = gorderid;
    data['tradeid'] = tradeid;
    data['eorderid'] = eorderid;
    data['side'] = side;
    return data;
  }
}