import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/order_details_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/quote_single_symbol_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/technicals_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/repository/place_order_repository.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';

class PlaceOrderBloc extends GreekBlocs {
  final repository = BuySellRepository();

  BuildContext context;
  OrderMode orderMode;
  OrderAction orderAction;
  late final int? initialTab;
  OrderDetailsModel? obj;

  int orderToken;

  double? currentLtp;

  PublishSubject<bool> reloadStateForChangeBuySellSwitch = PublishSubject<bool>();
  PublishSubject<bool> refreshPrice = PublishSubject<bool>();
  BehaviorSubject<bool> appBarSizeSubject = BehaviorSubject<bool>.seeded(false);
  BehaviorSubject<QuoteForSingleSymbolModel?>? _marketPictureSubject = BehaviorSubject<QuoteForSingleSymbolModel?>.seeded(null);
  Stream<QuoteForSingleSymbolModel?>? get marketPictureObserver => _marketPictureSubject?.stream;
  String _subscribeMarketPictureToken = '';
  String _unSubscribeMarketPictureToken = '';

  List<QuoteForSingleSymbolModel?> orderResponseArray = <QuoteForSingleSymbolModel?>[];

  int currentExchangeIndex = 0;

  PlaceOrderBloc(
    this.context, {
    required this.orderToken,
    required this.orderAction,
    required this.orderMode,
    this.initialTab,
    this.obj,
  }) {
    if (orderToken.toExchange().compareTo('BSE') == 0) {
      currentExchangeIndex = 1;
    }
    registerCommonAppListener();
  }

  @override
  void disposeBloc() {
    unSubscribeMarketPicture();

    orderResponseArray.clear();
    _marketPictureSubject?.close();
    _marketPictureSubject = null;
  }

  Future<List<TechnicalsModel?>> getTechnicalDetails(int? token) async {
    final technicalResponse = await repository.getTechnicalAPI(context, token: token ?? 0);
    int length = technicalResponse.length;
    if (length > 0) {
      return technicalResponse;
    }
    return [];
  }

  Future<List<QuoteForSingleSymbolModel?>> callBuySellAPIS() async {
    List<QuoteForSingleSymbolModel?> tempList = <QuoteForSingleSymbolModel?>[];
    final response = await repository.getBuySellAPI(
      context: context,
      orderToken: orderToken,
    );

    // ignore: unnecessary_type_check
    if (response is List<dynamic>) {
      // final obj = response..map((e) => QuoteForSingleSymbolModel.fromJson(e)).toList();

      for (var item in response) {
        item?.level2?.removeWhere(
          (element) {
            final askNo = element.ask?.no ?? 0;
            final bidNo = element.bid?.no ?? 0;

            return ((askNo <= 0) && (bidNo <= 0));
          },
        );

        final exch = item?.token?.toExchange().toUpperCase() ?? '';

        if (exch.contains('NSE')) {
          tempList.insert(0, item);
        } else {
          tempList.add(item);
        }
      }
    }

    if (orderToken.toExchange().compareTo('BSE') == 0) {
      if (tempList.length == 1) {
        tempList.insert(0, QuoteForSingleSymbolModel());
      }
    }

    List<QuoteForSingleSymbolModel> tem = [];
    for (var element in tempList) {
      int level2Length = element?.level2?.length ?? 0;
      int totalDepth = 5;
      if (level2Length < totalDepth) {
        int depthToAdd = totalDepth - level2Length;
        for (int i = 0; i < depthToAdd; i++) {
          element?.level2?.add(QuoteForSingleSymbolModelLevel2());
        }
      }
      tem.add(element!);
    }

    tempList = tem;

    orderResponseArray = tempList;
    _marketPictureSubject?.sink.add(orderResponseArray[currentExchangeIndex]);
    subscribeMarketPicture();

    return orderResponseArray;
  }

  void registerCommonAppListener() {
    //SocketIOManager().brodcastResponseObservable.listen((event) {
    SocketIOManager().brodcastResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.apolloResponseStreamingType == ApolloResponseStreamingType.marketPicture) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              final token = int.parse('${responseDic['symbol']}');
              if (_subscribeMarketPictureToken.toUpperCase().compareTo(token.toString().toUpperCase()) == 0) {
                final ltp = double.parse('${responseDic['ltp']}');
                final change = double.parse('${responseDic['change']}');
                final pChange = double.parse('${responseDic['p_change']}');

                final totBuyQty = double.parse('${responseDic['tot_buyQty']}');
                final totSellQty = double.parse('${responseDic['tot_sellQty']}');
                final totVol = double.parse('${responseDic['tot_vol']}');
                final high = double.parse('${responseDic['high']}');
                final low = double.parse('${responseDic['low']}');
                final ltq = ('${responseDic['ltq']}');

                if (orderResponseArray.isNotEmpty) {
                  orderResponseArray[currentExchangeIndex]?.ltq = ltq;
                  orderResponseArray[currentExchangeIndex]?.last = ltp;
                  orderResponseArray[currentExchangeIndex]?.change = change;
                  orderResponseArray[currentExchangeIndex]?.pChange = pChange;

                  orderResponseArray[currentExchangeIndex]?.totBuyQty = totBuyQty.toString();
                  orderResponseArray[currentExchangeIndex]?.totSellQty = totSellQty.toString();
                  orderResponseArray[currentExchangeIndex]?.totVol = totVol.toString();

                  if ((orderResponseArray[currentExchangeIndex]?.low ?? 0.0) > low) {
                    orderResponseArray[currentExchangeIndex]?.low = low;
                  }

                  if ((orderResponseArray[currentExchangeIndex]?.high ?? 0.0) < high) {
                    orderResponseArray[currentExchangeIndex]?.high = high;
                  }

                  if (high > (orderResponseArray[currentExchangeIndex]?.yhigh ?? 0.0)) {
                    orderResponseArray[currentExchangeIndex]?.yhigh = high;
                  }

                  if (low < (orderResponseArray[currentExchangeIndex]?.ylow ?? 0.0)) {
                    orderResponseArray[currentExchangeIndex]?.ylow = low;
                  }
                }
                if (responseDic['level2'] != null) {
                  final newLevel2 = <QuoteForSingleSymbolModelLevel2>[];
                  responseDic['level2'].forEach((v) {
                    newLevel2.add(QuoteForSingleSymbolModelLevel2.fromJson(v));
                  });
                  int totalDepth = 5;
                  int level2Length = newLevel2.length;
                  int depthToAdd = totalDepth - level2Length;

                  if (orderResponseArray.isNotEmpty) {
                    for (int i = 0; i < depthToAdd; i++) {
                      newLevel2.add(QuoteForSingleSymbolModelLevel2());
                    }
                    orderResponseArray[currentExchangeIndex]?.level2 = newLevel2;
                  }
                }

                if (orderResponseArray.isNotEmpty) {
                  _marketPictureSubject?.sink.add(orderResponseArray[currentExchangeIndex]);
                }
                break;
              }

              break;
            }
          }
        }
      }
    });
  }

  void subscribeMarketPicture() {
    if (_unSubscribeMarketPictureToken.isNotEmpty) {
      SocketIOManager().unSubscribeMarketPictureTokens([_unSubscribeMarketPictureToken]);
    }

    _subscribeMarketPictureToken = orderResponseArray.elementAt(currentExchangeIndex)?.token?.toString() ?? '';
    if (_subscribeMarketPictureToken.isNotEmpty) {
      SocketIOManager().subscribeMarketPictureTokens([_subscribeMarketPictureToken]);
      _unSubscribeMarketPictureToken = _subscribeMarketPictureToken;
    }
  }

  void unSubscribeMarketPicture() {
    if (_unSubscribeMarketPictureToken.isNotEmpty) {
      SocketIOManager().unSubscribeMarketPictureTokens([_unSubscribeMarketPictureToken]);
    }
  }
}
