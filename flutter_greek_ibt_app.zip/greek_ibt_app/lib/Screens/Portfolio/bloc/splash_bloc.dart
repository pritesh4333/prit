import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/string_extension.dart';
import 'package:greek_ibt_app/Helper/app_flag_constant.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/1_Splash%20Screen/models/get_flag_value_response_model.dart';
import 'package:greek_ibt_app/Screens/Login/repository/login_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_urls.dart';
import 'package:greek_ibt_app/sqlite/datahelper.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Models/login_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/rxdart.dart';
import 'package:tuple/tuple.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/contract_model.dart';

class SplashBloc extends GreekBlocs {
  final _repository = LoginRepository();
  final BuildContext _splashContext;
  String retrieveUsername = '';
  String retrievePassword = '';
  String retrieveDefaultScreen = '';
  String? otp;
  String? otpDate;
  String currentDate = "";

  static List<String> finalMenuList = [];

  ContractDataModel? model;
  List<ContractDataModel>? modelList;

  BehaviorSubject<int> percentage = BehaviorSubject();

  SplashBloc(this._splashContext) {
    getotp();
    DBHelper.createDatabase();
    NetworkManager().setupNetwork(serverInfo: AppConfig().serverInfo);
  }

  @override
  void disposeBloc() {}

  Future<Object?> callContractDetailsAPIS() async {
    final responseMap = await _repository.getContractDetailsAPi();
    return responseMap;
  }

  Future<String?> getotp() async {
    otp = await AppConfig().getOTP() ?? '';
    return otp;
  }

  Future<void> callSplashAPIS({required String deviceId}) async {
    percentage.sink.add(40);
    final responseMap = await _repository.getFlagvalueAPI(deviceId: deviceId);
    percentage.sink.add(60);
    if ((responseMap != null) && (responseMap is Map)) {
      final obj =
          GetFlagResponseModel.fromJson(responseMap as Map<String, dynamic>);
      AppConfig().heartBeatInterval = obj.heartbeatIntervals ?? 10;
      AppConfig().reconnection_attempts = obj.reconnectionAttempts ?? 180;

      // Flag Keeper [AppFlagConstant]
      AppFlagConstant().validateTransaction = obj.validateTransaction ?? '';
      AppFlagConstant().defaultProduct = obj.defaultProduct ?? '';
      AppFlagConstant().validate2FA = obj.validate2FA ?? '';
      AppFlagConstant().holdingFlag = obj.holdingFlag ?? '';
      AppFlagConstant().validateGuest = obj.validateGuest ?? '';
      AppFlagConstant().validateThrough = obj.validateThrough ?? '';
      AppFlagConstant().showLogin = obj.showLogin ?? '';
      AppFlagConstant().heartbeatIntervals = obj.heartbeatIntervals.toString();
      AppFlagConstant().reconnectionAttempts =
          obj.reconnectionAttempts.toString();
      AppFlagConstant().showDescription = '';
      AppFlagConstant().validatePasswordOnce = obj.validatePasswordOnce ?? '';
      AppFlagConstant().ftTestingBypass = obj.ftTestingBypass ?? '';
      AppFlagConstant().isSecure = obj.isSecure.toString();
      AppFlagConstant().arachneIP = obj.arachneIP ?? '';
      AppFlagConstant().apolloIP = obj.apolloIP ?? '';
      AppFlagConstant().irisIP = obj.irisIP ?? '';
      AppFlagConstant().arachnePort = obj.arachnePort.toString();
      AppFlagConstant().orderSenderPort = obj.orderSenderPort.toString();
      AppFlagConstant().broadcastSenderPort =
          obj.broadcastSenderPort.toString();
      AppFlagConstant().irisPort = obj.irisPort.toString();
      AppFlagConstant().apolloPort = obj.apolloPort.toString();
      AppFlagConstant().chartSetting = obj.chartSetting ?? '';
      AppFlagConstant().isStrategyProduct = obj.isStrategyProduct ?? '';
      AppFlagConstant().isEDISProduct = obj.isEDISProduct ?? '';
      AppFlagConstant().isRedisEnabled = obj.isRedisEnabled ?? '';
      AppFlagConstant().aprVersion = obj.aprVersion ?? '';
      AppFlagConstant().isBOReport = obj.isBOReport ?? '';
      AppFlagConstant().paymentGateway = obj.paymentGateway ?? '';
      AppFlagConstant().upiPaymentEnabled = obj.upiPaymentEnabled ?? '';
      AppFlagConstant().ftLink = obj.ftLink ?? '';
      AppFlagConstant().ftLinkUpi = obj.ftLinkUpi ?? '';
      AppFlagConstant().pledgeOffline = obj.pledgeOffline ?? '';
      AppFlagConstant().isPledgeProduct = obj.isPledgeProduct ?? '';
      AppFlagConstant().dpType = obj.dPType ?? '';
      AppFlagConstant().sslUrl = obj.sslUrl ?? '';
      AppFlagConstant().loginCompliance = obj.loginCompliance ?? '0';
      if (obj.showTradeAlert == 'null' || obj.showTradeAlert == 'undefined') {
        AppFlagConstant().showTradeAlert = 'false';
      } else {
        AppFlagConstant().showTradeAlert = obj.showTradeAlert ?? 'false';
      }
      AppFlagConstant().scripCountInWatchlist = obj.scripCountInWatchlist ?? '';
      AppFlagConstant().eKycSignUpUrl = obj.eKycSignUpUrl ?? '';
      AppFlagConstant().eKycSignUpPort = obj.eKycSignUpPort ?? '';
      percentage.sink.add(70);
      //Call [PREPARE MENU LIST WIDGETS]
      prepareListofMenuItems();
      percentage.sink.add(90);
      AppConfig().isSecureGlobal = obj.isSecure!;
      AppConfig().serverInfo = Tuple5(
        obj.isSecure!,
        obj.arachneIP!,
        obj.arachnePort!,
        obj.socketPort!,
        GreekURLs.currentServerInfo.item5,
      );

      retrieveUsername = await AppConfig().getUsername() ?? "";
      retrievePassword = await AppConfig().getPassword() ?? "";
      retrieveDefaultScreen = await AppConfig().getDefaultScreen() ?? '';
      if (retrieveDefaultScreen == '') {
        AppConfig().saveDefaultScreen();
      }
      retrieveDefaultScreen = await AppConfig().getDefaultScreen() ?? '';

      switch (retrieveDefaultScreen.toLowerCase()) {
        case 'market':
          AppFlagConstant().defaultScreenIndex = '0';
          break;
        case 'watchlist':
          AppFlagConstant().defaultScreenIndex = '1';
          break;
        case 'order':
          AppFlagConstant().defaultScreenIndex = '2';
          break;
        case 'portfolio':
          AppFlagConstant().defaultScreenIndex = '3';
          break;
        case 'funds':
          AppFlagConstant().defaultScreenIndex = '4';
          break;
        default:
      }

      AppConfig().clientName = await AppConfig().getClientName() ?? '';

      if (obj.showLogin == 'true') {
        percentage.sink.add(99);
        Timer(
          const Duration(seconds: 1),
          () {
            percentage.sink.add(100);
            if (retrieveUsername.isNotEmpty && retrieveUsername.isNotEmpty) {
              _callsplashLoginAPI();
            } else {
              GreekNavigator.pushReplacementNamed(
                context: _splashContext,
                routeName: GreekScreenNames.login,
              );
            }
          },
        );
      } else {
        GreekDialogPopupView.messageDialog(
          _splashContext,
          ConstantMessages.SOMETHING_WENT_WRONG,
        );
      }
    }
  }

  void _callsplashLoginAPI() async {
    AppConfig().gscid = retrieveUsername;

    LoginResponseModel obj = await _repository.callLoginAPI(
      context: _splashContext,
      versionNo: AppConfig().internalVersionNO,
      gscid: AppConfig().gscid,
      pass: retrievePassword.toMD5String(),
      deviceDetails: AppConfig().deviceDetails ?? 'unknown',
      deviceId: AppConfig().deviceID,
      transPass: '',
    );

    if (obj.errorCode == UserAuthenticationCode.success) {
      for (var item in (obj.allowedMarket ?? <AllowedMarket>[])) {
        switch ((item.marketId ?? -1)) {
          case 1:
            GreekBase().marketSegments.add(MarketSegment.nseeq);
            break;
          case 2:
            GreekBase().marketSegments.add(MarketSegment.nsefo);
            break;
          case 3:
            GreekBase().marketSegments.add(MarketSegment.nsecd);
            break;
          case 4:
            GreekBase().marketSegments.add(MarketSegment.bseeq);
            break;
          case 5:
            GreekBase().marketSegments.add(MarketSegment.bsefo);
            break;
          case 6:
            GreekBase().marketSegments.add(MarketSegment.bsecd);
            break;
          case 7:
            GreekBase().marketSegments.add(MarketSegment.ncdex);
            break;
          case 9:
            GreekBase().marketSegments.add(MarketSegment.mcx);
            break;
          case 16:
            GreekBase().marketSegments.add(MarketSegment.nsecomm);
            break;
          case 17:
            GreekBase().marketSegments.add(MarketSegment.bsecomm);
            break;

          default:
            break;
        }
      }
      AppConfig().gcid = obj.clientCode!.toString();
      AppConfig().sessionID = obj.sessionID!.trim();

      AppConfig().isMPinSet =
          (obj.isMPINSet!.toLowerCase().compareTo('true') == 0);

      AppConfig().serverInfo = Tuple5(
        AppConfig().isSecureGlobal,
        obj.arachneIP!,
        obj.arachnePort!,
        obj.socketPort!,
        GreekURLs.currentServerInfo.item5,
      );

      NetworkManager().setupNetwork(serverInfo: AppConfig().serverInfo);
      if (AppFlagConstant().loginCompliance == "0") {
        GreekNavigator.pushReplacementNamed(
          context: _splashContext,
          routeName: GreekScreenNames.mpin,
        );
      } else if (AppFlagConstant().loginCompliance == "1") {
        otpDate = await AppConfig().getOTPdate() ?? "";
        currentDate = DateFormat("yyyy-MM-dd").format(DateTime.now());
        print(otpDate);

        if (otp == '' || otpDate != currentDate) {
          final errorCode = await _repository.callLoginOTP(_splashContext);

          switch (errorCode) {
            case 0:
              Fluttertoast.showToast(
                msg: "OTP Sent to Your Registered Mobile Number / Email",
                toastLength: Toast.LENGTH_LONG,
              );
              GreekNavigator.pushReplacementNamed(
                context: _splashContext,
                routeName: GreekScreenNames.otp,
              );
              break;
          }
        } else {
          GreekNavigator.pushReplacementNamed(
            context: _splashContext,
            routeName: GreekScreenNames.otp,
          );
        }
      }
    } else {
      GreekNavigator.pushReplacementNamed(
        context: _splashContext,
        routeName: GreekScreenNames.login,
      );
    }
  }

  //Prepare List Of Widgets for Left Menu and Kept in 'Splash_bloc' According to Flag
  Future<void> prepareListofMenuItems() async {
    List<String> mainMenuItem = [];
    final jsonString = await rootBundle.loadString('assets/LeftmenuModel.json');
    final menuList = json.decode(jsonString);

    menuList.toList().asMap().forEach(
      (index, element) {
        //For getting Sub Menu Items.
        if (element['subMenu'].length > 0) {
          for (int i = 0; i < element['subMenu'].length; i++) {
            mainMenuItem.add(element['subMenu'][i]);
          }
        }
        //For getting Main Menu Items.
        else {
          mainMenuItem.add(element['name']);
        }
      },
    );

    createActiveMenuItemsWidgetList(menuList);
  }

  createActiveMenuItemsWidgetList(List<dynamic> alteredMenuList) {
    //This is for Widget List

    alteredMenuList.toList().asMap().forEach(
      (index, element) {
        //For getting Sub Menu Items.
        if (element['subMenu'].length > 0) {
          for (int i = 0; i < element['subMenu'].length; i++) {
            if (element['name'].toString() == 'Fund Transfer') {
              finalMenuList.add(element['subMenu'][i]);
            } else if (element['name'].toString() == 'Back Office Reports') {
              finalMenuList.add(element['subMenu'][i]);
            } else if (element['name'].toString() == 'E-DIS') {
              String edisProduct = AppFlagConstant().isEDISProduct;
              if (edisProduct == 'true') {
                finalMenuList.add(element['subMenu'][i]);
              }
            }
          }
        }
        //For getting Main Menu Items.
        else {
          if (element['name'].toString().toLowerCase().compareTo('profile') ==
              0) {
            finalMenuList.add(element['name']);
          } else if (element['name'].toString() == 'Fund Transfer') {
            finalMenuList.add(element['name']);
          } else if (element['name'].toString() == 'Back Office Reports') {
            finalMenuList.add(element['name']);
          } else if (element['name'].toString() == 'Strategy Finder') {
            String isStrategyProduct = AppFlagConstant().isStrategyProduct;
            if (isStrategyProduct == 'true') {
              finalMenuList.add(element['name']);
            }
          } else if (element['name'].toString() == 'Strategy Builder') {
            String isStrategyProduct = AppFlagConstant().isStrategyProduct;
            if (isStrategyProduct == 'true') {
              finalMenuList.add(element['name']);
            }
          } else if (element['name'].toString() == 'E-DIS') {
            String edisProduct = AppFlagConstant().isEDISProduct;
            if (edisProduct == 'true') {
              finalMenuList.add(element['name']);
            }
          } else if (element['name']
                  .toString()
                  .toLowerCase()
                  .compareTo('notification') ==
              0) {
            finalMenuList.add(element['name']);
          } else if (element['name']
                  .toString()
                  .toLowerCase()
                  .compareTo('stock alert') ==
              0) {
            finalMenuList.add(element['name']);
          } else if (element['name']
                  .toString()
                  .toLowerCase()
                  .compareTo('settings') ==
              0) {
            finalMenuList.add(element['name']);
          } else if (element['name'].toString() == 'Logout') {
            finalMenuList.add(element['name']);
          }
        }
      },
    );

    log('\nFinal Menu List to navigate [WIDGETS] : $finalMenuList');
  }
}
