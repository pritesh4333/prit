// ignore_for_file: avoid_print

import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/repository/watchlist_repository.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/sqlite/datahelper.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:intl/intl.dart';
import 'package:rect_getter/rect_getter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/graph_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/search_model/search_symbol_sqlite_model.dart';

class WatchListBloc extends GreekBlocs {
  final BuildContext _context;

  final listTileRectKey = {};
  final listViewRectKey = RectGetter.createGlobalKey();

  List<String> watchNamePersist = [];
  int isFromWatchTab = 6;
  bool isRenameCalled = false;
  bool isFromSearch = false;
  bool isDeletedSymbol = false;

  bool isacendingchange = false;
  bool isacendingalphabet = false;
  bool isacendingLTP = false;

  final _watchListRepository = WatchListRepository();

  final _groupNametextController = TextEditingController();
  final searchSymbolTextController = TextEditingController();

  var defaultGroupName = ConstantMessages.GREEK_DEFAULT_WATCHLIST_NAME;

  final _watchListDefaultNameStream = BehaviorSubject<String>();
  Stream<String> get watchListDefaultNameStream =>
      _watchListDefaultNameStream.stream;

  BehaviorSubject<Color> watchlistColorStream1 =
      BehaviorSubject<Color>.seeded(Colors.grey);
  BehaviorSubject<Color> watchlistColorStream2 =
      BehaviorSubject<Color>.seeded(Colors.grey);
  BehaviorSubject<Color> watchlistColorStream3 =
      BehaviorSubject<Color>.seeded(Colors.grey);
  BehaviorSubject<Color> watchlistColorStream4 =
      BehaviorSubject<Color>.seeded(Colors.grey);
  BehaviorSubject<Color> watchlistColorStream5 =
      BehaviorSubject<Color>.seeded(Colors.grey);

  final _watchListStream = BehaviorSubject<List<SymbolList>>();
  Stream<List<SymbolList>> get symbolListObservable => _watchListStream.stream;

  final defaultWatchlistStream = BehaviorSubject<List<String>>();
  Stream<List<String>> get defaultWatchlistObservable =>
      defaultWatchlistStream.stream;

  List<BehaviorSubject<SymbolList>?> ltpInfoStream =
      <BehaviorSubject<SymbolList>>[];

  List<SymbolList> currentSymbolLists = <SymbolList>[];
  List<SymbolList> actualResponseSymbolList = <SymbolList>[];
  List<String> arrGroupNames = <String>[];
  List<String> defaultGroupNameGlobalForRename = <String>[];
  List<String> _subscribeLTPInfoTokenArray = <String>[];
  List<String> _unSubscribeLTPInfoTokenArray = <String>[];

  static List<dynamic> listOfSymbolList = [];

  final _searchSymbolSubject = BehaviorSubject<List<SearchSymbolSqliteModel>>();

  Stream<List<SearchSymbolSqliteModel>> get searchSymbolResultObserver =>
      _searchSymbolSubject.stream;

  bool sortByChange = false;
  bool sortAlphabetically = false;
  bool sortByLTP = false;

  bool pchangeascending = false;
  bool alphabetascending = false;
  bool lastascending = false;

  bool filterClick = false;

  bool nseclick = false;
  bool bseclick = false;
  bool mcxclick = false;
  bool ncdexclick = false;

  int? sortValueIndex;

  DBHelper? dbHelper;

  @override
  void disposeBloc() {
    _groupNametextController.dispose();
    searchSymbolTextController.dispose();

    unSubscribeLTPInfo();
  }

  WatchListBloc(this._context) {
    dbHelper = DBHelper();
    SocketIOManager().brodcastResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();

          for (var item in keys) {
            if (item.apolloResponseStreamingType ==
                ApolloResponseStreamingType.ltpinfo) {
              final responseDic = event[item];
              if (responseDic is Map<String, dynamic>) {
                if ((responseDic['symbol'] != null) &&
                    (responseDic['ltp'] != null) &&
                    (responseDic['change'] != null) &&
                    (responseDic['p_change'] != null)) {
                  final token = int.parse(responseDic['symbol'].toString());
                  final ltp = double.parse(responseDic['ltp'].toString());
                  final change = double.parse(responseDic['change'].toString());
                  double pChange = 0.00;
                  try {
                    if (responseDic['p_change'].toString().toLowerCase() !=
                        "-nan") {
                      pChange =
                          double.parse(responseDic['p_change'].toString());
                    }
                  } catch (e) {
                    print("p_chnage " + e.toString());
                  }
                  for (var item in currentSymbolLists) {
                    if ((item.token ?? -1) == token) {
                      var obj = item;
                      obj.ltp = ltp;
                      obj.change = change;
                      obj.pChange = pChange;

                      final foundedIndex = currentSymbolLists.indexOf(item);
                      if ((foundedIndex >= 0) && (ltpInfoStream.isNotEmpty)) {
                        currentSymbolLists[foundedIndex] = obj;
                        ltpInfoStream.elementAt(foundedIndex)?.sink.add(obj);
                        break;
                      }
                    }
                  }
                }
                break;
              }
            }
          }
        }
      },
    );

    GreekBase().userActionForWatchListCreateObserver.stream.listen(
          _showCreateWatchListGroupPopup,
        );

    GreekBase().userActionForWatchListSelectObserver.stream.listen(
          _changeWatchlistGroupname,
        );

    GreekBase().userActionForWatchListDeleteObserver.stream.listen(
          _showDeleteWatchListGroupPopup,
        );

    GreekBase().userActionForWatchListRenameObserver.stream.listen(
          renameWatchListGroupPopup,
        );

    GreekBase().userActionForSymbolDeleteObserver.stream.listen(
          _showDeleteDialogSymbolIntoWatchlistPopup,
        );
  }

  Future<List<GraphResponseModel?>> callChartData(String token) async {
    var formatter = DateFormat('yyyy-MM-dd');
    var formattedDate = formatter.format(DateTime.now()).replaceAll('-', '');
    final response = await _watchListRepository.getGraphData(
        context: _context, token: token, date: formattedDate);
    return response;
  }

  /// Used to RENAME Watchlist Name
  void renameWatchListGroupPopup(String event) {
    if (event != '') {
      GreekBase().userActionForWatchListRenameObserver.sink.add('');
      _groupNametextController.text = event;
      GreekDialogPopupView.textfieldDialogRename(
        context: _context,
        title: 'Rename Watchlist Name',
        child: TextField(
          onChanged: (value) {},
          maxLength: 12,
          controller: _groupNametextController,
          decoration: const InputDecoration(
            hintText: 'Enter Here',
          ),
          inputFormatters: <TextInputFormatter>[
            FilteringTextInputFormatter.allow(RegExp("[0-9a-zA-Z]")),
          ],
        ),
        confirmPressed: (textfieldContext) {
          GreekNavigator.pop(context: textfieldContext);

          final groupName = _groupNametextController.text.toLowerCase();
          _groupNametextController.text = '';
          if (groupName.isEmpty) {
            GreekDialogPopupView.customeCallBackDialog(
              context: textfieldContext,
              message: ConstantMessages.GREEK_WATCHLIST_EMPTY_TXT,
              onPressed: (callBackContext) {
                GreekNavigator.pop(context: callBackContext);
                renameWatchListGroupPopup(event);
              },
            );
          } else {
            if (defaultGroupNameGlobalForRename.contains(groupName)) {
              GreekDialogPopupView.customeCallBackDialog(
                context: textfieldContext,
                message: ConstantMessages.GREEK_WATCHLIST_DUPLICATE_TXT,
                onPressed: (callBackContext) {
                  GreekNavigator.pop(context: callBackContext);
                  renameWatchListGroupPopup(event);
                },
              );
            } else {
              //Rename Watchlist
              _watchListRepository
                  .renameWatchlistGroup(
                context: _context,
                oldGroupName: event,
                newGroupName: groupName,
              )
                  .then(
                (response) {
                  if ((response != null) &&
                      (response is Map<String, dynamic>)) {
                    int? errorCode = response['ErrorCode'];

                    if (errorCode == 0) {
                      isRenameCalled = true;
                      GreekBase().mapData.clear();
                      GreekBase().mapData = List<List<SymbolList>>.generate(
                          5, (index) => <SymbolList>[]);
                      getWatchListGroupNames();
                    } else {
                      String message = response['data'];
                      GreekDialogPopupView.messageDialogWatchlistRename(
                          _context, message);
                    }
                  }
                },
              );
            }
          }
        },
      );
    }
  }

  bool onChangeListViewScroll(ScrollNotification? notification) {
    if ((notification == null) || (notification is ScrollEndNotification)) {
      log('\n------------- Scroll End -------------\n');

      var rect = RectGetter.getRectFromKey(listViewRectKey);
      var _items = <int>[];
      listTileRectKey.forEach((index, key) {
        var itemRect = RectGetter.getRectFromKey(key);
        if (itemRect != null &&
            !(itemRect.top > rect!.bottom || itemRect.bottom < rect.top)) {
          _items.add(index);
        }
      });

      subscribeLTPInfo(_items);
    }
    return true;
  }

  void _showCreateWatchListGroupPopup(bool event) {
    if (event) {
      GreekBase().userActionForWatchListCreateObserver.sink.add(false);
      GreekDialogPopupView.textfieldDialog(
        context: _context,
        title: ConstantMessages.GREEK_CREATE_NEW_WATCHLIST_TXT,
        child: TextField(
          onChanged: (value) {},
          maxLength: 20,
          controller: _groupNametextController,
          decoration: const InputDecoration(
            hintText: ConstantMessages.ENTER_WATCHLIST_TXT,
          ),
        ),
        confirmPressed: (textfieldContext) {
          GreekNavigator.pop(context: textfieldContext);

          final groupName = _groupNametextController.text;

          if (groupName.isEmpty) {
            GreekDialogPopupView.customeCallBackDialog(
              context: textfieldContext,
              message: ConstantMessages.GREEK_WATCHLIST_EMPTY_TXT,
              onPressed: (callBackContext) {
                GreekNavigator.pop(context: callBackContext);
                _showCreateWatchListGroupPopup(true);
              },
            );
          } else {
            // _watchListRepository.createWatchListGroup(context: _context, name: groupName).then(
            //   (errorCode) {
            //     if ((errorCode != null) && (errorCode == 0)) {
            //       GreekDialogPopupView.customeCallBackDialog(
            //         context: _context,
            //         message: ConstantMessages.GREEK_CREATE_WATCHLIST_TXT,
            //         onPressed: (pressContext) async {
            //           GreekNavigator.pop(context: pressContext);
            //           arrGroupNames.add(groupName);
            //           defaultGroupName = groupName;
            //           getWatchListDataByGroupName();
            //         },
            //       );
            //     }
            //   },
            // );
          }
        },
      );
    }
  }

  void createWatchlist(
      {required String groupName, required String watchlistSeq}) {
    int index = int.parse(watchlistSeq);
    _watchListRepository
        .createWatchListGroupFlutter(
      context: _context,
      name: groupName,
      watchlistSeq: watchlistSeq,
    )
        .then(
      (errorCode) {
        if ((errorCode != null) && (errorCode == 0)) {
          print('Watchlist created');
          arrGroupNames.add(groupName);
          if (arrGroupNames.length >= 5) {
            defaultGroupName = arrGroupNames[0];
            defaultWatchlistStream.sink.add(watchNamePersist);
            getWatchListDataByGroupName();
            return;
          } else {
            createWatchlist(
                groupName: watchNamePersist[index + 1],
                watchlistSeq: '${index + 1}');
          }
        }
      },
    );
  }

  void _changeWatchlistGroupname(int? changeIndex) {
    // (userData?.length > 0 ? userData[0]['userName'] : '')
    if (changeIndex != null) {
      if (arrGroupNames.length > changeIndex) {
        if (arrGroupNames[changeIndex].isNotEmpty) {
          defaultGroupName = arrGroupNames[changeIndex];
          getWatchListDataByGroupName();
        }
      }
    }
    // if ((changeIndex != null) && (arrGroupNames[changeIndex].isNotEmpty)) {
    //   defaultGroupName = arrGroupNames[changeIndex];
    //   getWatchListDataByGroupName();
    // }
  }

  void _showDeleteWatchListGroupPopup(int? deleteIndex) {
    if ((deleteIndex != null) && (arrGroupNames[deleteIndex].isNotEmpty)) {
      GreekDialogPopupView.customeCallBackWithCancelButtonDialog(
        context: _context,
        message: ConstantMessages.GR_ASK_TO_DELETE_MSG,
        onPressed: (callBackContext) {
          _watchListRepository
              .deleteWatchListGroup(
                  context: _context, name: arrGroupNames[deleteIndex])
              .then(
            (errorCode) {
              if ((errorCode != null) && (errorCode == 0)) {
                GreekNavigator.pop(context: _context);
                GreekDialogPopupView.customeCallBackDialog(
                  context: callBackContext,
                  message:
                      ConstantMessages.GREEK_DELETE_WATCHLIST_SUCESFULLY_TXT,
                  onPressed: (pressContext) {
                    GreekNavigator.pop(context: pressContext);
                    arrGroupNames.removeAt(deleteIndex);
                    getWatchListGroupNames();
                  },
                );
              }
            },
          );
        },
      );
    }
  }

  void _showDeleteDialogSymbolIntoWatchlistPopup(int? deleteIndex) {
    if (deleteIndex != null) {
      List<SymbolList> symbolListToDelete = [];
      symbolListToDelete.add(currentSymbolLists[deleteIndex]);
      print(symbolListToDelete);

      deleteSymbolintoWatchListGroup(
          groupName: defaultGroupName,
          symbolList: symbolListToDelete,
          deleteIndex: deleteIndex);
    }
  }

  // Fetching Available Watchlist Names.
  void getWatchListGroupNames() {
    arrGroupNames.clear();
    watchNamePersist.clear();

    _watchListRepository.watchListGroupNames(_context).then((value) {
      List<String> watchName = [];
      if (value.isNotEmpty) {
        for (var item in value) {
          watchName.add(item.watchlistName ?? '');
          if (item.defaultWatchList ?? false) {
            log('Default Watch List Group Name - ${item.watchlistName}');
            defaultGroupName = item.watchlistName ??
                ConstantMessages.GREEK_DEFAULT_WATCHLIST_NAME;
            _watchListDefaultNameStream.sink.add(defaultGroupName);
            currentSymbolLists = item.symbolList ?? [];
            actualResponseSymbolList = item.symbolList ?? [];
            /*if(sortByChange == true){
              currentSymbolLists.sort(
                    (a, b) => ((a.change ?? 0).compareTo(b.change ?? 0)),
              );
            } else if(sortAlphabetically == true){
              currentSymbolLists.sort(
                    (a, b) => ((a.description.toString().toLowerCase()).compareTo(b.description.toString().toLowerCase())),
              );
            } else if(sortByLTP == true){
              currentSymbolLists.sort(
                    (a, b) => ((a.ltp ?? 0).compareTo(b.ltp ?? 0)),
              );
            }else{
              currentSymbolLists.sort(
                    (a, b) => ((a.seqNo ?? 0).compareTo(b.seqNo ?? 0)),
              );
            }*/
            break;
          }
        }

        //Check what data has came from watchlist name
        int totalWatchlistCount = 5;
        int receivedWatchCount = watchName.length;
        var watchNameTemp = watchName;
        arrGroupNames = List<String>.from(watchNameTemp);
        if (totalWatchlistCount > watchName.length) {
          for (int i = watchName.length; i < totalWatchlistCount; i++) {
            if (receivedWatchCount < 5) {
              List<String> defaultWatchList = [
                'watchlist1',
                'watchlist2',
                'watchlist3',
                'watchlist4',
                'watchlist5',
              ];
              for (int j = 0; j < defaultWatchList.length; j++) {
                bool result =
                    watchNameTemp.contains(defaultWatchList[j].toLowerCase());
                String tempStr = defaultWatchList[j];
                if (result) {
                  print('${defaultWatchList[j]} is present');
                } else {
                  print(
                      '${defaultWatchList[j]} is not present ....prepare for Request Creation Watch');
                  int aStr =
                      int.parse(tempStr.replaceAll(RegExp(r'[^0-9]'), ''));
                  var watchlistName = 'watchlist$aStr';
                  watchName.add(watchlistName);
                }
              }
            } else {
              var watchlistName = 'watchlist${watchName.length + 1}';
              watchName.add(watchlistName);
            }
          }
          watchNamePersist = watchName;
          createWatchlist(
              groupName: watchName[receivedWatchCount],
              watchlistSeq: '$receivedWatchCount');
        } else {
          arrGroupNames.clear();
          arrGroupNames = watchName;
        }
        watchNamePersist = watchName;
        defaultWatchlistStream.sink.add(watchName);

        if (isRenameCalled) {
          watchlistColorStream1.sink.add(ConstantColors.primaryColorVitt);
          watchlistColorStream2.sink.add(Colors.grey);
          watchlistColorStream3.sink.add(Colors.grey);
          watchlistColorStream4.sink.add(Colors.grey);
          watchlistColorStream5.sink.add(Colors.grey);
        } else {
          watchlistColorStream1.sink.add(ConstantColors.primaryColorVitt);
        }
        defaultGroupName = arrGroupNames[0];
        getWatchListDataByGroupName();
      } else {
        //This will perform when there is no watchlist present
        _watchListDefaultNameStream.sink
            .add(ConstantMessages.GREEK_DEFAULT_WATCHLIST_NAME);
        //Check what data has came from watchlist name
        int totalWatchlistCount = 5;
        int watchNameLength = totalWatchlistCount - watchName.length;
        if (totalWatchlistCount != watchName.length) {
          for (int i = 0; i < watchNameLength; i++) {
            var watchlistName = 'Watchlist${watchName.length + 1}';
            watchName.add(watchlistName);
          }
        }

        // Need to Send Default request of watchlist
        watchNamePersist = watchName;
        createWatchlist(groupName: watchName[0], watchlistSeq: '0');
        defaultWatchlistStream.sink.add(watchName);
        watchlistColorStream1.sink.add(ConstantColors.primaryColorVitt);
        currentSymbolLists = [];
        actualResponseSymbolList = [];
      }

      //Commented by sushant [Good Cause]
      // preparSymbolList();
      defaultGroupNameGlobalForRename = arrGroupNames;
    });
  }

  void getWatchListDataByGroupName() {
    _clearLTPInfoList();
    //currentSymbolLists.clear();
    unSubscribeLTPInfo();
    _watchListDefaultNameStream.sink.add(defaultGroupName);
    //Check if data is present in the Map for selected Watchlist the avoid api call to fetch data
    var indexWatchlist =
        arrGroupNames.indexWhere((element) => defaultGroupName == element);
    if (GreekBase().mapData.isNotEmpty) {
      List<SymbolList> mapListData = GreekBase().mapData[indexWatchlist];
      if (isFromSearch || isDeletedSymbol || isRenameCalled) {
        isFromSearch = false;
        isDeletedSymbol = false;

        callWatchilstMethod();
      } else {
        var dataLength = mapListData.length;
        if (dataLength > 0) {
          currentSymbolLists = GreekBase().mapData[indexWatchlist];
          actualResponseSymbolList = GreekBase().mapData[indexWatchlist];
          preparSymbolList();
        } else {
          callWatchilstMethod();
        }
      }
    } else {
      callWatchilstMethod();
    }
  }

  void callWatchilstMethod() {
    _watchListRepository
        .watchListDataByGroupName(context: _context, name: defaultGroupName)
        .then(
      (value) {
        currentSymbolLists = value;
        actualResponseSymbolList = value;

        /* if(sortByChange == true){
          currentSymbolLists.sort(
                (a, b) => ((a.change ?? 0).compareTo(b.change ?? 0)),
          );
        } else if(sortAlphabetically == true){
          currentSymbolLists.sort(
                (a, b) => ((a.description.toString().toLowerCase()).compareTo(b.description.toString().toLowerCase())),
          );
        } else if(sortByLTP == true){
          currentSymbolLists.sort(
                (a, b) => ((a.ltp ?? 0).compareTo(b.ltp ?? 0)),
          );
        }else{
          */ /*currentSymbolLists.map((e) {
            if(e.exchange.toString().toUpperCase().contains("BSE")){
              return  currentSymbolLists.sort(
                (a, b) => ((a.seqNo ?? 0).compareTo(b.seqNo ?? 0)));
            }
          }*/ /*
          currentSymbolLists.sort(
                (a, b) => ((a.seqNo ?? 0).compareTo(b.seqNo ?? 0)),
          );
        }*/
        //first time calling
        preparSymbolList();
      },
    );
  }

  void clearSearchResult() {
    searchSymbolTextController.clear();
    _searchSymbolSubject.sink.add([]);
  }

  Future<void> searchSymbol({required String symbolName}) async {
    final result = await DBHelper.searchSymbolByCode(symbolCode: symbolName);
    log("query result  $result");
    List<SearchSymbolSqliteModel> objects;
    if ((result is List) && (result.isNotEmpty)) {
      // _searchSymbolSubject.sink.add(result);
      objects = result.map((e) => SearchSymbolSqliteModel.fromJson(e)).toList();
      _searchSymbolSubject.sink.add(objects);
    }
  }

  bool isNumeric(String? strarray) {
    if (strarray == null) {
      return false;
    }
    return double.tryParse(strarray) != null;
  }

  void addSymbolintoWatchListGroup({
    required String groupName,
    //required int listCount,
    required List<SearchSymbolSqliteModel> symbolList,
  }) {
    _watchListRepository
        .addSymbolIntoWatchGroup(
            context: _context,
            groupName: groupName,
            //listCount: listCount,
            symbolList: symbolList)
        .then((errorCode) {
      if (errorCode == 0) {
        GreekDialogPopupView.customeCallBackDialog(
          context: _context,
          message: ConstantMessages.GR_ADDED_SUCCESS_MSG,
          onPressed: (pressContext) {
            GreekNavigator.pop(context: pressContext);
            // sendsequence
            isFromSearch = true;
            getWatchListDataByGroupName();
          },
        );
      }
    });
  }

  void deleteSymbolintoWatchListGroup({
    required String groupName,
    required List<SymbolList> symbolList,
    required int deleteIndex,
  }) {
    GreekDialogPopupView.customeCallBackWithCancelButtonDialog(
      context: _context,
      message: ConstantMessages.DELETE_SCRIP_MSG,
      onPressed: (returnContext) {
        GreekNavigator.pop(context: returnContext);
        _watchListRepository
            .deleteSymbolIntoWatchGroup(
          context: _context,
          groupName: groupName,
          symbolList: symbolList,
        )
            .then((errorCode) {
          if (errorCode == 0) {
            var indexWatchlist = arrGroupNames
                .indexWhere((element) => defaultGroupName == element);
            // List<SymbolList> mapListData = GreekBase().mapData[indexWatchlist];
            if (deleteIndex > 0) {
              GreekBase().mapData[indexWatchlist].removeAt(deleteIndex);
            }
            GreekDialogPopupView.customeCallBackDialog(
              context: _context,
              message: ConstantMessages.GR_DELETE_SUCCESS_MSG,
              onPressed: (pressContext) {
                GreekNavigator.pop(context: pressContext);
                isDeletedSymbol = true;
                getWatchListDataByGroupName();
              },
            );
          }
        });
      },
    );
  }

  void _clearLTPInfoList() {
    for (var element in ltpInfoStream) {
      element?.close();
    }
    ltpInfoStream.clear();
  }

  void preparSymbolList() {
    _clearLTPInfoList();

    if (filterClick) {
      if (nseclick) {
        currentSymbolLists = actualResponseSymbolList;
        currentSymbolLists = currentSymbolLists
            .where(
              (list) => ((list.token?.toExchange().compareTo("NSE") == 0) ||
                  (list.token?.toExchange().compareTo("NSECURR") == 0) ||
                  (list.token?.toExchange().compareTo("NSECOMM") == 0)),
            )
            .toList();
      }
      if (bseclick) {
        currentSymbolLists = actualResponseSymbolList;
        currentSymbolLists = currentSymbolLists
            .where(
              (list) => ((list.token?.toExchange().compareTo("BSE") == 0) ||
                  (list.token?.toExchange().compareTo("BSECURR") == 0) ||
                  (list.token?.toExchange().compareTo("BSECOMM") == 0)),
            )
            .toList();
      }

      if (mcxclick) {
        currentSymbolLists = actualResponseSymbolList;
        currentSymbolLists = currentSymbolLists
            .where((list) => (list.token?.toExchange().compareTo("MCX") == 0))
            .toList();
      }
      if (ncdexclick) {
        currentSymbolLists = actualResponseSymbolList;
        currentSymbolLists = currentSymbolLists
            .where((list) => (list.token?.toExchange().compareTo("NCDEX") == 0))
            .toList();
      }
    } else {
      if (sortByChange == true) {
        if (pchangeascending) {
          currentSymbolLists.sort(
            (a, b) => ((a.pChange ?? 0).compareTo(b.pChange ?? 0)),
          );
        } else {
          currentSymbolLists.sort(
            (a, b) => ((a.pChange ?? 0).compareTo(b.pChange ?? 0)),
          );
          log("Curent revers list ${currentSymbolLists.first.pChange}");
          currentSymbolLists = List.from(currentSymbolLists.reversed.toList());
          log("revers list ${currentSymbolLists.first.pChange}");
        }
      } else if (sortAlphabetically == true) {
        if (alphabetascending) {
          currentSymbolLists.sort(
            (a, b) => ((a.description.toString().toLowerCase())
                .compareTo(b.description.toString().toLowerCase())),
          );
        } else {
          currentSymbolLists.sort(
            (a, b) => ((a.description.toString().toLowerCase())
                .compareTo(b.description.toString().toLowerCase())),
          );
          currentSymbolLists = List.from(currentSymbolLists.reversed.toList());
          log("revers list ${currentSymbolLists.first.symbol}");
        }
      } else if (sortByLTP == true) {
        if (lastascending) {
          currentSymbolLists.sort(
            (a, b) => ((a.ltp ?? 0).compareTo(b.ltp ?? 0)),
          );
        } else {
          currentSymbolLists.sort(
            (a, b) => ((a.ltp ?? 0).compareTo(b.ltp ?? 0)),
          );
          currentSymbolLists = List.from(currentSymbolLists.reversed.toList());
          log("revers list ${currentSymbolLists.first.symbol}");
        }
      }
    } /*  else {
      /*  ltpInfoStream.sort(
        (a, b) => ((a.valueOrNull.seqNo ?? 0)
            .compareTo(b.valueOrNull.seqNo ?? 0)),
      ); */
      currentSymbolLists.sort(
        (a, b) => ((a.description.toString().toLowerCase()).compareTo(b.description.toString().toLowerCase())),
      );
    } */

    ltpInfoStream = List<BehaviorSubject<SymbolList>>.generate(
      currentSymbolLists.length,
      (index) => BehaviorSubject<SymbolList>.seeded(
        currentSymbolLists[index],
      ),
    );
    _watchListStream.sink.add(currentSymbolLists);

    currentSymbolLists = actualResponseSymbolList;

    //Saving data to Map to Prevent API call
    int indexWatchlist = -1;
    for (var i = 0; i < arrGroupNames.length; i++) {
      final watchName = arrGroupNames[i].toLowerCase();
      if (defaultGroupName.toLowerCase().compareTo(watchName) == 0) {
        indexWatchlist = i;
        break;
      }
    }

    final tempList = List<SymbolList>.from(currentSymbolLists);

    if (GreekBase().mapData.isEmpty) {
      GreekBase().mapData =
          List<List<SymbolList>>.generate(5, (index) => <SymbolList>[]);
    }

    if (GreekBase().mapData.isEmpty) {
      GreekBase().mapData =
          List<List<SymbolList>>.generate(5, (index) => <SymbolList>[]);
    }
    GreekBase().mapData[indexWatchlist] = tempList;

    List<SymbolList> object = GreekBase().mapData[indexWatchlist];
    if (object.isNotEmpty) {
      currentSymbolLists = GreekBase().mapData[indexWatchlist];
    }

    // _watchListStream.sink.add(currentSymbolLists);

    /*if (currentSymbolLists.length > 10) {
      subscribeLTPInfo();
    } else {
      subscribeLTPInfo();
    }*/

    if (currentSymbolLists.length > 10) {
      subscribeLTPInfo(List.generate(10, (index) => index));
    } else {
      subscribeLTPInfo(
          List.generate(currentSymbolLists.length, (index) => index));
    }
  }

  /*void subscribeLTPInfo() {
    if (_unSubscribeLTPInfoTokenArray.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(_unSubscribeLTPInfoTokenArray);
    }

    if (currentSymbolLists.isNotEmpty) {
      final result = currentSymbolLists
          .map(
            (e) => e.token!.toString(),
          )
          .toList();
      _subscribeLTPInfoTokenArray = result;
      SocketIOManager().subscribeLTPInfoTokens(_subscribeLTPInfoTokenArray);
      _unSubscribeLTPInfoTokenArray = _subscribeLTPInfoTokenArray;
    }
  }*/

  void subscribeLTPInfo(List<int> tokenRanges) {
    if (_unSubscribeLTPInfoTokenArray.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(_unSubscribeLTPInfoTokenArray);
    }

    if (tokenRanges.isNotEmpty) {
      final result = tokenRanges
          .map(
            (i) => currentSymbolLists.elementAt(i).token!.toString(),
          )
          .toList();

      _subscribeLTPInfoTokenArray = result;
      SocketIOManager().subscribeLTPInfoTokens(_subscribeLTPInfoTokenArray);
      _unSubscribeLTPInfoTokenArray = _subscribeLTPInfoTokenArray;
    }
  }

  void unSubscribeLTPInfo() {
    if (_unSubscribeLTPInfoTokenArray.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(_unSubscribeLTPInfoTokenArray);
      _unSubscribeLTPInfoTokenArray.clear();
    }
  }
}
