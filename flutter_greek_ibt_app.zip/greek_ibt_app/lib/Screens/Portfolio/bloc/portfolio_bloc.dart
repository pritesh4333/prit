import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/order_details_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/product_change_request.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_list_response_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_scrip_detail_info.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/np_details_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Network_Manager/Helper/network_extension.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/Enums/socket_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_response_data_new_model.dart'
    as holding_models;
import 'package:greek_ibt_app/Screens/Edis/Model/edis_authorization_response.dart'
    as edis_authorize_holding;
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';

class PortfolioBloc extends GreekBlocs {
  // late BuildContext _portfolioContext;
  List<HoldingDetailsResponseModel> holdingDetailsDataList = [];
  final holdingDetailsSubject =
      BehaviorSubject<List<BehaviorSubject<HoldingDetailsResponseModel>>>();
  List<BehaviorSubject<HoldingDetailsResponseModel>> holdingDetailsStreamList =
      [];
  List<String> subscribeholdingDetailsTokens = [];
  List<String> unSubscribeholdingDetailsTokens = [];

  BehaviorSubject<String> totalInvested = BehaviorSubject<String>();
  BehaviorSubject<String> currentValue = BehaviorSubject<String>();
  BehaviorSubject<String> currentBalance = BehaviorSubject<String>();
  BehaviorSubject<String> todaysPnL = BehaviorSubject<String>();
  BehaviorSubject<String> positionPnL = BehaviorSubject<String>();

  BehaviorSubject<String> update = BehaviorSubject<String>();
  late BuildContext context;

  //For Broadcast
  final searchTextFieldController = TextEditingController(text: "");
  List<StockDetailss> actualportfolipositionlist = [];
  List<StockDetailss> tempactualportfolipositionlist = [];
  List<BehaviorSubject<StockDetailss>> positionStream =
      <BehaviorSubject<StockDetailss>>[];

  final List<String> _unSubscribeLTPInfoTokenArray = <String>[];

  final mainStream = BehaviorSubject.seeded(true);
  final edisAuthorizationmainStream = BehaviorSubject.seeded(true);
  BehaviorSubject<bool> hasHoldingData = BehaviorSubject.seeded(false);
  BehaviorSubject<bool> hasPositionData = BehaviorSubject.seeded(false);
  //For Broadcast Holding

  List<holding_models.StockDetails> actualHoldingDataList = [];
  List<holding_models.StockDetails> tempactualHoldingDataList = [];
  List<edis_authorize_holding.StockDetails> edisactualHoldingDataList = [];

  List<BehaviorSubject<holding_models.StockDetails>> holdingDataStream =
      <BehaviorSubject<holding_models.StockDetails>>[];

  int selectedIndexGlobal = 0;
  static BehaviorSubject<bool> searchWidgitVisiblity =
      BehaviorSubject.seeded(true);
  var lTPChangesort = false;
  var perChangeSort = false;
  var alphabetChangesort = false;
  BehaviorSubject<HoldingScripDetailsInfoResponseModel> holdingScripInfoStream =
      BehaviorSubject<HoldingScripDetailsInfoResponseModel>();

  @override
  void disposeBloc() {
    searchTextFieldController.clear();
    searchTextFieldController.dispose();
  }

  PortfolioBloc() {
    GreekBase().portfolioScreenState.listen(
      (value) {
        if (GreekBase.portfolioStateObject == PortfolioScreenState.holding) {
          SocketIOManager().holdingDataListRequest();
        } else if (GreekBase.portfolioStateObject ==
            PortfolioScreenState.position) {
          SocketIOManager().npDetailsRequest();
        }
      },
    );

    SocketIOManager().brodcastResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();

          for (var item in keys) {
            if (item.apolloResponseStreamingType ==
                ApolloResponseStreamingType.ltpinfo) {
              final responseDic = event[item];
              if (selectedIndexGlobal == 1) {
                if (responseDic is Map<String, dynamic>) {
                  if ((responseDic['symbol'] != null) &&
                      (responseDic['ltp'] != null) &&
                      (responseDic['change'] != null) &&
                      (responseDic['p_change'] != null)) {
                    final token = int.parse(responseDic['symbol'].toString());
                    final ltp = double.parse(responseDic['ltp'].toString());

                    for (var item in actualportfolipositionlist) {
                      if ((item.nSEToken ?? -1) == token.toString()) {
                        var obj = item;
                        obj.ltp = ltp.toString();
                        // obj.change = change;
                        // obj.pChange = pChange;

                        final foundedIndex =
                            actualportfolipositionlist.indexOf(item);
                        if (foundedIndex >= 0) {
                          actualportfolipositionlist[foundedIndex] = obj;
                          positionStream[foundedIndex].sink.add(obj);
                          break;
                        }
                      }
                    }
                  }
                  break;
                }
              } else if (selectedIndexGlobal == 0) {
                //Show Holding broadcast.

                if (responseDic is Map<String, dynamic>) {
                  if ((responseDic['symbol'] != null) &&
                      (responseDic['ltp'] != null) &&
                      (responseDic['change'] != null) &&
                      (responseDic['p_change'] != null)) {
                    final token = int.parse(responseDic['symbol'].toString());
                    final ltp = double.parse(responseDic['ltp'].toString());

                    for (var item in actualHoldingDataList) {
                      if ((item.nSEToken ?? -1) == token.toString()) {
                        final obj = item;

                        obj.ltp = ltp.toString();

                        final foundedIndex =
                            actualHoldingDataList.indexOf(item);

                        if (foundedIndex >= 0) {
                          actualHoldingDataList[foundedIndex] = obj;

                          holdingDataStream[foundedIndex].sink.add(obj);

                          break;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
    );
    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType ==
              IrisResponseStreamingType.NPDetailResponse) {
            final responseDic = event[item];
            if (responseDic is Map<String, dynamic>) {
              var modelObj = NpDetailsResponseModel.fromJson(responseDic);

              if (modelObj.stockDetails != null) {
                if (int.parse(modelObj.noofrecords.toString()) > 0 ||
                    int.parse(modelObj.noofrecords.toString()) > 0) {
                  if (int.parse(modelObj.islast ?? "") == 1 ||
                      (int.parse(modelObj.stockDetails?.length.toString() ??
                                  "") ==
                              int.parse(modelObj.noofrecords ?? "") &&
                          int.parse(modelObj.islast ?? "") == 2)) {
                    if (int.parse(modelObj.noofrecords.toString()) > 0) {
                      actualportfolipositionlist.clear();
                      tempactualportfolipositionlist.clear();
                      for (int i = 0;
                          i <
                              int.parse(
                                  modelObj.stockDetails?.length.toString() ??
                                      "0");
                          i++) {
                        int netQty;
                        if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                    .toExchange()
                                    .toString() ==
                                "MCX" ||
                            int.parse(modelObj.stockDetails?[i].token ?? "")
                                    .toExchange()
                                    .toString() ==
                                "NCDEX") {
                          netQty = int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") -
                              int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0");
                          netQty = netQty ~/
                              int.parse(
                                  modelObj.stockDetails?[i].lotQty ?? "0");
                          var prenqty = int.parse(
                                  modelObj.stockDetails?[i].preNetQty ?? "0") ~/
                              int.parse(
                                  modelObj.stockDetails?[i].lotQty ?? "0");
                          modelObj.stockDetails?[i].preNetQty =
                              prenqty.toString();
                        } else if (int.parse(
                                    modelObj.stockDetails?[i].token ?? "")
                                .toAssetType()
                                .toString() ==
                            "currency") {
                          netQty = int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") -
                              int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0");
                          netQty = netQty ~/
                              int.parse(
                                  modelObj.stockDetails?[i].multiplier ?? "0");
                          var prenetqty = int.parse(
                                  modelObj.stockDetails?[i].preNetQty ?? "0") ~/
                              int.parse(
                                  modelObj.stockDetails?[i].multiplier ?? "0");
                          modelObj.stockDetails?[i].preNetQty =
                              prenetqty.toString();
                        } else {
                          netQty = int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") -
                              int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0");
                        }
                        modelObj.stockDetails?[i].netQty = netQty.toString();
                        double netAmt = double.parse(
                                modelObj.stockDetails?[i].buyAmt ?? "0.00") -
                            double.parse(
                                modelObj.stockDetails?[i].sellAmt ?? "0.00");
                        modelObj.stockDetails?[i].dayNetAmt = netAmt.toString();
                        modelObj.stockDetails?[i].sqoffToken =
                            modelObj.stockDetails?[i].sqoffToken;
                        if (netQty != 0) {
                          //Pravin Pasi Shared Logic for more info Directly call him.
                          if (int.parse(modelObj.stockDetails?[i].token ?? "0")
                                      .toExchange()
                                      .toString() ==
                                  "MCX" ||
                              int.parse(modelObj.stockDetails?[i].token ?? "0")
                                      .toExchange()
                                      .toString() ==
                                  "NCDEX") {
                            var netavgvalue = ((netAmt ~/ netQty) ~/
                                    double.parse(modelObj
                                            .stockDetails?[i].priceMultiplier ??
                                        "0.00")) ~/
                                int.parse(
                                    modelObj.stockDetails?[i].lotQty ?? "0");
                            if (netavgvalue.toString() == "NaN") {
                              modelObj.stockDetails?[i].netAvg = "0.00";
                            } else {
                              modelObj.stockDetails?[i].netAvg =
                                  netavgvalue.toString();
                            }

                            if (int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0") >
                                0) {
                              var buyavgvalue = ((double.parse(
                                          modelObj.stockDetails?[i].buyAmt ??
                                              "0.00") /
                                      int.parse(
                                          modelObj.stockDetails?[i].buyQty ??
                                              "0")) /
                                  double.parse(modelObj
                                          .stockDetails?[i].priceMultiplier ??
                                      "0.00"));
                              modelObj.stockDetails?[i].buyAvg =
                                  buyavgvalue.toString();
                            } else {
                              modelObj.stockDetails?[i].buyAvg = "0";
                            }

                            if (int.parse(
                                    modelObj.stockDetails?[i].sellQty ?? "0") >
                                0) {
                              var sellavgvalue = ((double.parse(
                                          modelObj.stockDetails?[i].sellAmt ??
                                              "0.00") /
                                      int.parse(
                                          modelObj.stockDetails?[i].sellQty ??
                                              "0")) /
                                  double.parse(modelObj
                                          .stockDetails?[i].priceMultiplier ??
                                      "0.00"));
                              modelObj.stockDetails?[i].sellAvg =
                                  sellavgvalue.toString();
                            } else {
                              modelObj.stockDetails?[i].sellAvg = "0";
                            }
                          } else if (int.parse(
                                      modelObj.stockDetails?[i].token ?? "")
                                  .toAssetType()
                                  .toString() ==
                              "currency") {
                            var netavgvalue = ((netAmt ~/ netQty) /
                                double.parse(
                                    modelObj.stockDetails?[i].multiplier ??
                                        "0.00"));
                            if (netavgvalue.toString() == "NaN") {
                              modelObj.stockDetails?[i].netAvg = "0.00";
                            } else {
                              modelObj.stockDetails?[i].netAvg =
                                  netavgvalue.toString();
                            }

                            double buyAvg = double.parse(
                                    modelObj.stockDetails?[i].buyAmt ??
                                        "0.00") /
                                int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0.00");
                            double sellAvg = double.parse(
                                    modelObj.stockDetails?[i].sellAmt ??
                                        "0.00") /
                                int.parse(modelObj.stockDetails?[i].sellQty ??
                                    "0.00");

                            if (int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0") >
                                0) {
                              modelObj.stockDetails?[i].buyAvg =
                                  buyAvg.toString();
                            } else {
                              modelObj.stockDetails?[i].buyAvg = "0";
                            }

                            if (int.parse(modelObj.stockDetails?[i].sellQty ??
                                    "0.00") >
                                0) {
                              modelObj.stockDetails?[i].sellAvg =
                                  sellAvg.toString();
                            } else {
                              modelObj.stockDetails?[i].sellAvg = "0";
                            }
                          } else {
                            modelObj.stockDetails?[i].netAvg =
                                (netAmt / netQty).toString();

                            double buyAvg = double.parse(
                                    modelObj.stockDetails?[i].buyAmt ??
                                        "0.00") /
                                int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0.00");
                            double sellAvg = double.parse(
                                    modelObj.stockDetails?[i].sellAmt ??
                                        "0.00") /
                                int.parse(modelObj.stockDetails?[i].sellQty ??
                                    "0.00");

                            if (int.parse(modelObj.stockDetails?[i].buyQty ??
                                    "0.00") >
                                0) {
                              modelObj.stockDetails?[i].buyAvg =
                                  buyAvg.toString();
                            } else {
                              modelObj.stockDetails?[i].buyAvg = "0";
                            }

                            if (int.parse(modelObj.stockDetails?[i].sellQty ??
                                    "0.00") >
                                0) {
                              modelObj.stockDetails?[i].sellAvg =
                                  sellAvg.toString();
                            } else {
                              modelObj.stockDetails?[i].sellAvg = "0";
                            }
                          }
                        } else {
                          if (int.parse(modelObj.stockDetails?[i].token ?? "0")
                                      .toExchange()
                                      .toString() ==
                                  "MCX" ||
                              int.parse(modelObj.stockDetails?[i].token ?? "0")
                                      .toExchange()
                                      .toString() ==
                                  "NCDEX") {
                            var setvegvalues = ((netAmt / netQty) /
                                    double.parse(modelObj
                                            .stockDetails?[i].priceMultiplier ??
                                        "0.00")) /
                                int.parse(
                                    modelObj.stockDetails?[i].lotQty ?? "0");
                            if (setvegvalues.toString() == "NaN") {
                              modelObj.stockDetails?[i].netAvg = "0.00";
                            } else {
                              modelObj.stockDetails?[i].netAvg =
                                  setvegvalues.toString();
                            }

                            if (int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0") >
                                0) {
                              var buyavgvalues = ((double.parse(
                                          modelObj.stockDetails?[i].buyAmt ??
                                              "0.00") /
                                      int.parse(
                                          modelObj.stockDetails?[i].buyQty ??
                                              "0")) /
                                  double.parse(modelObj
                                          .stockDetails?[i].priceMultiplier ??
                                      "0.00"));
                              modelObj.stockDetails?[i].buyAvg =
                                  buyavgvalues.toString();
                            } else {
                              modelObj.stockDetails?[i].buyAvg = "0";
                            }

                            if (int.parse(
                                    modelObj.stockDetails?[i].sellQty ?? "0") >
                                0) {
                              var sellavgvalu = ((double.parse(
                                          modelObj.stockDetails?[i].sellAmt ??
                                              "0.00") /
                                      int.parse(
                                          modelObj.stockDetails?[i].sellQty ??
                                              "0")) /
                                  double.parse(modelObj
                                          .stockDetails?[i].priceMultiplier ??
                                      "0.00"));
                              modelObj.stockDetails?[i].sellAvg =
                                  sellavgvalu.toString();
                            } else {
                              modelObj.stockDetails?[i].sellAvg = "0";
                            }
                          } else {
                            modelObj.stockDetails?[i].netAvg = "0.00";

                            double buyAvg = double.parse(
                                    modelObj.stockDetails?[i].buyAmt ??
                                        "0.00") /
                                int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0");
                            double sellAvg = double.parse(
                                    modelObj.stockDetails?[i].sellAmt ??
                                        "0.00") /
                                int.parse(
                                    modelObj.stockDetails?[i].sellQty ?? "0");

                            if (int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0") >
                                0) {
                              modelObj.stockDetails?[i].buyAvg =
                                  buyAvg.toString();
                            } else {
                              modelObj.stockDetails?[i].buyAvg = "0";
                            }

                            if (int.parse(
                                    modelObj.stockDetails?[i].sellQty ?? "0") >
                                0) {
                              modelObj.stockDetails?[i].sellAvg =
                                  sellAvg.toString();
                            } else {
                              modelObj.stockDetails?[i].sellAvg = "0";
                            }
                          }
                        }
                        // calculate qty validation start
                        if (int.parse(modelObj.stockDetails?[i].token ?? "0")
                                    .toExchange()
                                    .toString() ==
                                "MCX" ||
                            int.parse(modelObj.stockDetails?[i].token ?? "0")
                                    .toExchange()
                                    .toString() ==
                                "NCDEX") {
                          /*double totalQty = double.parse(
                                  modelObj.stockDetails?[i].preNetQty ?? "0") +
                              double.parse(
                                  modelObj.stockDetails?[i].netQty ?? "0");*/
                          double totalQty = double.parse(
                              modelObj.stockDetails?[i].netQty ?? "0");
                          modelObj.stockDetails?[i].buysellqty =
                              totalQty.toString();
                        } else if (int.parse(
                                    modelObj.stockDetails?[i].token ?? "0")
                                .toExchange()
                                .toString() ==
                            "currency") {
                          /*double totalQty = double.parse(modelObj.stockDetails?[i].preNetQty ?? "0") +
                              double.parse(modelObj.stockDetails?[i].netQty ?? "0");*/
                          double totalQty = double.parse(
                              modelObj.stockDetails?[i].netQty ?? "0");
                          modelObj.stockDetails?[i].buysellqty =
                              totalQty.toString();
                        } else {
                          /*double totalQty = double.parse(
                                  modelObj.stockDetails?[i].preNetQty ?? "0") +
                              double.parse(
                                  modelObj.stockDetails?[i].netQty ?? "0");*/
                          double totalQty = double.parse(
                              modelObj.stockDetails?[i].netQty ?? "0");
                          modelObj.stockDetails?[i].buysellqty =
                              totalQty.toString();
                        }
                        // calculate qty validation stop

                        //calculate mtm and price start
                        double netPrice, todayMTM, mtm;
                        netAmt = double.parse(
                            modelObj.stockDetails?[i].dayNetAmt ?? "0");
                        netQty =
                            int.parse(modelObj.stockDetails?[i].netQty ?? "0");

                        if (netQty != 0) {
                          if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                  .toAssetType()
                                  .toString() ==
                              "currency") {
                            netPrice = double.parse(double.parse(
                                    modelObj.stockDetails?[i].netAvg ?? "")
                                .toStringAsFixed(4)
                                .toString());
                          } else {
                            netPrice = double.parse(double.parse(
                                    modelObj.stockDetails?[i].netAvg ?? "")
                                .toStringAsFixed(2)
                                .toString());
                          }
                        } else {
                          netPrice = 0.0;
                        }

                        if (netQty != 0) {
                          double ltpClose = double.parse(
                                      modelObj.stockDetails?[i].ltp ?? "0") >
                                  0
                              ? double.parse(
                                  modelObj.stockDetails?[i].ltp ?? "0")
                              : double.parse(modelObj.stockDetails?[i].close ??
                                          "0") >
                                      0
                                  ? double.parse(
                                      modelObj.stockDetails?[i].close ?? "0")
                                  : 0.0;
                          double price = netPrice;

                          if (price != 0) {
                            if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                    .toAssetType()
                                    .toString() ==
                                "MCX") {
                              todayMTM = (ltpClose - price) *
                                  ((netQty *
                                      double.parse(modelObj.stockDetails?[i]
                                              .priceMultiplier ??
                                          "0") *
                                      int.parse(
                                          modelObj.stockDetails?[i].lotQty ??
                                              "0")));
                            } else if (int.parse(
                                        modelObj.stockDetails?[i].token ?? "")
                                    .toAssetType()
                                    .toString() ==
                                "NCDEX") {
                              todayMTM = (ltpClose - price) *
                                  ((netQty *
                                      double.parse(modelObj.stockDetails?[i]
                                              .priceMultiplier ??
                                          "0") *
                                      int.parse(
                                          modelObj.stockDetails?[i].lotQty ??
                                              "0")));
                            } else {
                              todayMTM = (ltpClose - price) *
                                  ((netQty *
                                      double.parse(modelObj
                                              .stockDetails?[i].multiplier ??
                                          "0")));
                            }
                          } else {
                            todayMTM = 0.0;
                          }
                        } else {
                          if (netAmt == 0.0) {
                            todayMTM = netAmt;
                          } else {
                            todayMTM = netAmt * (-1);
                          }
                        }

                        // if (int.parse(modelObj.stockDetails?[i].token ?? "").toAssetType().toString() =="currency") {
                        //   holder.txt_Todaymtm=StringStuff.commaINRDecorator(String.format("%.4f", todayMTM)));
                        // } else {
                        //   holder.txt_Todaymtm=StringStuff.commaDecorator(String.format("%.2f", todayMTM)));
                        // }

                        double preAmount = double.parse(
                                modelObj.stockDetails?[i].pAmt ?? "0.00") +
                            double.parse(
                                modelObj.stockDetails?[i].dayNetAmt ?? "0.00");

                        /*double PrevNetQty = double.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "0.00") +
                            double.parse(
                                modelObj.stockDetails?[i].netQty ?? "0");
                                */
                        double prevNetQty = double.parse(
                            modelObj.stockDetails?[i].netQty ?? "0");

                        if (prevNetQty != 0) {
                          double price = 0.0;

                          double ltpClose = double.parse(
                                      modelObj.stockDetails?[i].ltp ?? "0.00") >
                                  0
                              ? double.parse(
                                  modelObj.stockDetails?[i].ltp ?? "0.00")
                              : double.parse(modelObj.stockDetails?[i].close ??
                                          "0.00") >
                                      0
                                  ? double.parse(
                                      modelObj.stockDetails?[i].close ?? "0.00")
                                  : 0.0;
                          if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                  .toAssetType()
                                  .toString() ==
                              "commodity") {
                            if (prevNetQty != 0) {
                              price = (preAmount ~/
                                      (prevNetQty *
                                          double.parse(modelObj.stockDetails?[i]
                                                  .priceMultiplier ??
                                              "0.00") *
                                          int.parse(modelObj
                                                  .stockDetails?[i].lotQty ??
                                              "0")))
                                  .abs()
                                  .toDouble();
                            } else {
                              price = 0.0;
                            }
                          } else if (int.parse(
                                      modelObj.stockDetails?[i].token ?? "")
                                  .toAssetType()
                                  .toString() ==
                              "currency") {
                            if (prevNetQty != 0) {
                              price = (preAmount ~/
                                      (prevNetQty *
                                          double.parse(modelObj.stockDetails?[i]
                                                  .multiplier ??
                                              "0.00")))
                                  .abs()
                                  .toDouble();
                            } else {
                              price = 0.0;
                            }
                          } else {
                            price = (preAmount / prevNetQty).abs();
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].preNetQty ?? "") !=
                              0) {
                            if (price != 0) {
                              if (int.parse(
                                          modelObj.stockDetails?[i].token ?? "")
                                      .toAssetType()
                                      .toString() ==
                                  "commodity") {
                                mtm = ((ltpClose - price)) *
                                    ((prevNetQty *
                                        double.parse(modelObj.stockDetails?[i]
                                                .priceMultiplier ??
                                            "0.00") *
                                        int.parse(
                                            modelObj.stockDetails?[i].lotQty ??
                                                "0.00")));
                              } else {
                                mtm = ((ltpClose - price)) *
                                    ((prevNetQty *
                                        double.parse(modelObj
                                                .stockDetails?[i].multiplier ??
                                            "0.00")));
                              }
                            } else {
                              mtm = 0.0;
                            }
                          } else {
                            mtm = todayMTM;
                          }
                        } else {
                          mtm = preAmount * (-1);
                        }

                        if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                .toAssetType()
                                .toString() ==
                            "currency") {
                          modelObj.stockDetails?[i].todayprofitandloss =
                              mtm.toStringAsFixed(4).toString();
                          // holder.txt_mtm=StringStuff.commaINRDecorator(String.format("%.4f", mtm)));
                          // holder.txt_cmp=StringStuff.commaINRDecorator(String.format("%.4f", double.parse(customNetPositionSummary.getLtp()))));

                          // if (actualportfolipositionlist.netQty??"0".equalsIgnoreCase("0")) {
                          //   holder.txt_avgPrice="0");
                          // } else {
                          //   holder.txt_avgPrice=StringStuff.commaINRDecorator(String.format("%.4f", double.parse(customNetPositionSummary.getNetAvg()))));
                          // }
                        } else {
                          modelObj.stockDetails?[i].todayprofitandloss =
                              mtm.toStringAsFixed(2).toString();

                          // holder.txt_mtm=StringStuff.commaDecorator(String.format("%.2f", mtm)));
                          // holder.txt_cmp=StringStuff.commaDecorator(String.format("%.2f", double.parse(customNetPositionSummary.getLtp()))));

                          // if (actualportfolipositionlist.netQty??"0".equalsIgnoreCase("0")) {
                          //   holder.txt_avgPrice="0");
                          // } else {
                          //   holder.txt_avgPrice=StringStuff.commaDecorator(String.format("%.2f", double.parse(customNetPositionSummary.getNetAvg()))));
                          // }
                        }

                        //calculate mtm and price close
                        // display buy or sell price and qty validation
                        if (double.parse(modelObj.stockDetails?[i].buyAmt ??
                                    "0.00") ==
                                0.00 &&
                            int.parse(
                                    modelObj.stockDetails?[i].buyQty ?? "0") ==
                                0) {
                          modelObj
                              .stockDetails?[i].buysellamount = double.parse(
                                  modelObj.stockDetails?[i].sellAmt ?? '0.00')
                              .toString();
                          //modelObj.stockDetails?[i].buysellqty = '- ${modelObj.stockDetails?[i].sellQty.toString()}';
                          modelObj.stockDetails?[i].buyselltext = 'Sell Price';
                        } else if (double.parse(
                                    modelObj.stockDetails?[i].sellAmt ??
                                        "0.00") ==
                                0.00 &&
                            int.parse(
                                    modelObj.stockDetails?[i].sellQty ?? "0") ==
                                0) {
                          modelObj
                              .stockDetails?[i].buysellamount = double.parse(
                                  modelObj.stockDetails?[i].buyAmt ?? '0.00')
                              .toString();
                          // modelObj.stockDetails?[i].buysellqty = modelObj.stockDetails?[i].buyQty;
                          modelObj.stockDetails?[i].buyselltext = 'Buy Price';
                        } else {
                          modelObj.stockDetails?[i].buysellamount =
                              double.parse("0.00").toString();
                          // modelObj.stockDetails?[i].buysellqty = '0';
                          modelObj.stockDetails?[i].buyselltext = 'Price';
                        }
                        // display buy or sell price and qty validation
                      }

                      actualportfolipositionlist = modelObj.stockDetails ?? [];
                      tempactualportfolipositionlist =
                          modelObj.stockDetails ?? [];
                    }
                  } else {
                    for (int i = 0;
                        i <
                            int.parse(
                                modelObj.stockDetails?.length.toString() ??
                                    "0");
                        i++) {
                      int netQty;
                      if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                  .toExchange()
                                  .toString() ==
                              "MCX" ||
                          int.parse(modelObj.stockDetails?[i].token ?? "")
                                  .toExchange()
                                  .toString() ==
                              "NCDEX") {
                        netQty = int.parse(
                                modelObj.stockDetails?[i].buyQty ?? "0") -
                            int.parse(modelObj.stockDetails?[i].sellQty ?? "0");
                        netQty = netQty ~/
                            int.parse(modelObj.stockDetails?[i].lotQty ?? "0");
                        var prenqty = int.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "0") ~/
                            int.parse(modelObj.stockDetails?[i].lotQty ?? "0");
                        modelObj.stockDetails?[i].preNetQty =
                            prenqty.toString();
                      } else if (int.parse(
                                  modelObj.stockDetails?[i].token ?? "")
                              .toAssetType()
                              .toString() ==
                          "currency") {
                        netQty = int.parse(
                                modelObj.stockDetails?[i].buyQty ?? "0") -
                            int.parse(modelObj.stockDetails?[i].sellQty ?? "0");
                        netQty = netQty ~/
                            int.parse(
                                modelObj.stockDetails?[i].multiplier ?? "0");
                        var prenetqty = int.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "0") ~/
                            int.parse(
                                modelObj.stockDetails?[i].multiplier ?? "0");
                        modelObj.stockDetails?[i].preNetQty =
                            prenetqty.toString();
                      } else {
                        netQty = int.parse(
                                modelObj.stockDetails?[i].buyQty ?? "0") -
                            int.parse(modelObj.stockDetails?[i].sellQty ?? "0");
                      }
                      modelObj.stockDetails?[i].netQty = netQty.toString();
                      double netAmt = double.parse(
                              modelObj.stockDetails?[i].buyAmt ?? "0.00") -
                          double.parse(
                              modelObj.stockDetails?[i].sellAmt ?? "0.00");
                      modelObj.stockDetails?[i].dayNetAmt = netAmt.toString();
                      modelObj.stockDetails?[i].sqoffToken =
                          modelObj.stockDetails?[i].sqoffToken;

                      if (netQty != 0) {
                        //Pravin Pasi Shared Logic for more info Directly call him.
                        if (int.parse(modelObj.stockDetails?[i].token ?? "0")
                                    .toExchange()
                                    .toString() ==
                                "MCX" ||
                            int.parse(modelObj.stockDetails?[i].token ?? "0")
                                    .toExchange()
                                    .toString() ==
                                "NCDEX") {
                          var netavgvalue = ((netAmt ~/ netQty) ~/
                                  double.parse(modelObj
                                          .stockDetails?[i].priceMultiplier ??
                                      "0.00")) ~/
                              int.parse(
                                  modelObj.stockDetails?[i].lotQty ?? "0");

                          if (netavgvalue.toString() == "NaN") {
                            modelObj.stockDetails?[i].netAvg = "0.00";
                          } else {
                            modelObj.stockDetails?[i].netAvg =
                                netavgvalue.toString();
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") >
                              0) {
                            var buyavgvalue = ((double.parse(
                                        modelObj.stockDetails?[i].buyAmt ??
                                            "0.00") /
                                    int.parse(
                                        modelObj.stockDetails?[i].buyQty ??
                                            "0")) /
                                double.parse(
                                    modelObj.stockDetails?[i].priceMultiplier ??
                                        "0.00"));
                            modelObj.stockDetails?[i].buyAvg =
                                buyavgvalue.toString();
                          } else {
                            modelObj.stockDetails?[i].buyAvg = "0";
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0") >
                              0) {
                            var sellavgvalue = ((double.parse(
                                        modelObj.stockDetails?[i].sellAmt ??
                                            "0.00") /
                                    int.parse(
                                        modelObj.stockDetails?[i].sellQty ??
                                            "0")) /
                                double.parse(
                                    modelObj.stockDetails?[i].priceMultiplier ??
                                        "0.00"));
                            modelObj.stockDetails?[i].sellAvg =
                                sellavgvalue.toString();
                          } else {
                            modelObj.stockDetails?[i].sellAvg = "0";
                          }
                        } else if (int.parse(
                                    modelObj.stockDetails?[i].token ?? "")
                                .toAssetType()
                                .toString() ==
                            "currency") {
                          var netavgvalue = ((netAmt ~/ netQty) ~/
                              double.parse(
                                  modelObj.stockDetails?[i].multiplier ??
                                      "0.00"));
                          if (netavgvalue.toString() == "NaN") {
                            modelObj.stockDetails?[i].netAvg = "0.00";
                          } else {
                            modelObj.stockDetails?[i].netAvg =
                                netavgvalue.toString();
                          }

                          double buyAvg = double.parse(
                                  modelObj.stockDetails?[i].buyAmt ?? "0.00") /
                              int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0.00");
                          double sellAvg = double.parse(
                                  modelObj.stockDetails?[i].sellAmt ?? "0.00") /
                              int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0.00");

                          if (int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") >
                              0) {
                            modelObj.stockDetails?[i].buyAvg =
                                buyAvg.toString();
                          } else {
                            modelObj.stockDetails?[i].buyAvg = "0";
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0.00") >
                              0) {
                            modelObj.stockDetails?[i].sellAvg =
                                sellAvg.toString();
                          } else {
                            modelObj.stockDetails?[i].sellAvg = "0";
                          }
                        } else {
                          modelObj.stockDetails?[i].netAvg =
                              (netAmt / netQty).toString();

                          double buyAvg = double.parse(
                                  modelObj.stockDetails?[i].buyAmt ?? "0.00") /
                              int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0.00");
                          double sellAvg = double.parse(
                                  modelObj.stockDetails?[i].sellAmt ?? "0.00") /
                              int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0.00");

                          if (int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0.00") >
                              0) {
                            modelObj.stockDetails?[i].buyAvg =
                                buyAvg.toString();
                          } else {
                            modelObj.stockDetails?[i].buyAvg = "0";
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0.00") >
                              0) {
                            modelObj.stockDetails?[i].sellAvg =
                                sellAvg.toString();
                          } else {
                            modelObj.stockDetails?[i].sellAvg = "0";
                          }
                        }
                      } else {
                        if (int.parse(modelObj.stockDetails?[i].token ?? "0")
                                    .toExchange()
                                    .toString() ==
                                "MCX" ||
                            int.parse(modelObj.stockDetails?[i].token ?? "0")
                                    .toExchange()
                                    .toString() ==
                                "NCDEX") {
                          var setvegvalues = ((netAmt ~/ netQty) ~/
                                  double.parse(modelObj
                                          .stockDetails?[i].priceMultiplier ??
                                      "0.00")) ~/
                              int.parse(
                                  modelObj.stockDetails?[i].lotQty ?? "0");
                          if (setvegvalues.toString() == "NaN") {
                            modelObj.stockDetails?[i].netAvg = "0.00";
                          } else {
                            modelObj.stockDetails?[i].netAvg =
                                setvegvalues.toString();
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") >
                              0) {
                            var buyavgvalues = ((double.parse(
                                        modelObj.stockDetails?[i].buyAmt ??
                                            "0.00") /
                                    int.parse(
                                        modelObj.stockDetails?[i].buyQty ??
                                            "0")) /
                                double.parse(
                                    modelObj.stockDetails?[i].priceMultiplier ??
                                        "0.00"));
                            modelObj.stockDetails?[i].buyAvg =
                                buyavgvalues.toString();
                          } else {
                            modelObj.stockDetails?[i].buyAvg = "0";
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0") >
                              0) {
                            var sellavgvalu = ((double.parse(
                                        modelObj.stockDetails?[i].sellAmt ??
                                            "0.00") /
                                    int.parse(
                                        modelObj.stockDetails?[i].sellQty ??
                                            "0")) /
                                double.parse(
                                    modelObj.stockDetails?[i].priceMultiplier ??
                                        "0.00"));
                            modelObj.stockDetails?[i].sellAvg =
                                sellavgvalu.toString();
                          } else {
                            modelObj.stockDetails?[i].sellAvg = "0";
                          }
                        } else {
                          modelObj.stockDetails?[i].netAvg = "0.00";

                          double buyAvg = double.parse(
                                  modelObj.stockDetails?[i].buyAmt ?? "0.00") /
                              int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0");
                          double sellAvg = double.parse(
                                  modelObj.stockDetails?[i].sellAmt ?? "0.00") /
                              int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0");

                          if (int.parse(
                                  modelObj.stockDetails?[i].buyQty ?? "0") >
                              0) {
                            modelObj.stockDetails?[i].buyAvg =
                                buyAvg.toString();
                          } else {
                            modelObj.stockDetails?[i].buyAvg = "0";
                          }

                          if (int.parse(
                                  modelObj.stockDetails?[i].sellQty ?? "0") >
                              0) {
                            modelObj.stockDetails?[i].sellAvg =
                                sellAvg.toString();
                          } else {
                            modelObj.stockDetails?[i].sellAvg = "0";
                          }
                        }
                      }
                      // calculate qty validation start
                      if (int.parse(modelObj.stockDetails?[i].token ?? "0")
                                  .toExchange()
                                  .toString() ==
                              "MCX" ||
                          int.parse(modelObj.stockDetails?[i].token ?? "0")
                                  .toExchange()
                                  .toString() ==
                              "NCDEX") {
                        double totalQty = double.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "0") +
                            double.parse(
                                modelObj.stockDetails?[i].netQty ?? "0");
                        modelObj.stockDetails?[i].buysellqty =
                            totalQty.toString();
                      } else if (int.parse(
                                  modelObj.stockDetails?[i].token ?? "0")
                              .toExchange()
                              .toString() ==
                          "currency") {
                        double totalQty = double.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "0") +
                            double.parse(
                                modelObj.stockDetails?[i].netQty ?? "0");
                        modelObj.stockDetails?[i].buysellqty =
                            totalQty.toString();
                      } else {
                        double totalQty = double.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "0") +
                            double.parse(
                                modelObj.stockDetails?[i].netQty ?? "0");
                        modelObj.stockDetails?[i].buysellqty =
                            totalQty.toString();
                      }
                      // calculate qty validation stop

                      //calculate mtm and price start
                      double netPrice, todayMTM, mtm;
                      netAmt = double.parse(
                          modelObj.stockDetails?[i].dayNetAmt ?? "0");
                      netQty =
                          int.parse(modelObj.stockDetails?[i].netQty ?? "0");

                      if (netQty != 0) {
                        if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                .toAssetType()
                                .toString() ==
                            "currency") {
                          netPrice = double.parse(double.parse(
                                  modelObj.stockDetails?[i].netAvg ?? "0")
                              .toStringAsFixed(4)
                              .toString());
                        } else {
                          netPrice = double.parse(double.parse(
                                  modelObj.stockDetails?[i].netAvg ?? "0")
                              .toStringAsFixed(2)
                              .toString());
                        }
                      } else {
                        netPrice = 0.0;
                      }

                      if (netQty != 0) {
                        double ltpClose = double.parse(
                                    modelObj.stockDetails?[i].ltp ?? "0") >
                                0
                            ? double.parse(modelObj.stockDetails?[i].ltp ?? "0")
                            : double.parse(modelObj.stockDetails?[i].close ??
                                        "0") >
                                    0
                                ? double.parse(
                                    modelObj.stockDetails?[i].close ?? "0")
                                : 0.0;
                        double price = netPrice;

                        if (price != 0) {
                          if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                  .toAssetType()
                                  .toString() ==
                              "MCX") {
                            todayMTM = (ltpClose - price) *
                                ((netQty *
                                    double.parse(modelObj
                                            .stockDetails?[i].priceMultiplier ??
                                        "0") *
                                    int.parse(
                                        modelObj.stockDetails?[i].lotQty ??
                                            "0")));
                          } else if (int.parse(
                                      modelObj.stockDetails?[i].token ?? "")
                                  .toAssetType()
                                  .toString() ==
                              "NCDEX") {
                            todayMTM = (ltpClose - price) *
                                ((netQty *
                                    double.parse(modelObj
                                            .stockDetails?[i].priceMultiplier ??
                                        "0") *
                                    int.parse(
                                        modelObj.stockDetails?[i].lotQty ??
                                            "0")));
                          } else {
                            todayMTM = (ltpClose - price) *
                                ((netQty *
                                    double.parse(
                                        modelObj.stockDetails?[i].multiplier ??
                                            "0")));
                          }
                        } else {
                          todayMTM = 0.0;
                        }
                      } else {
                        if (netAmt == 0.0) {
                          todayMTM = netAmt;
                        } else {
                          todayMTM = netAmt * (-1);
                        }
                      }

                      // if (int.parse(modelObj.stockDetails?[i].token ?? "").toAssetType().toString() =="currency") {
                      //   holder.txt_Todaymtm=StringStuff.commaINRDecorator(String.format("%.4f", todayMTM)));
                      // } else {
                      //   holder.txt_Todaymtm=StringStuff.commaDecorator(String.format("%.2f", todayMTM)));
                      // }

                      double preAmount = double.parse(
                              modelObj.stockDetails?[i].pAmt ?? "0.00") +
                          double.parse(
                              modelObj.stockDetails?[i].dayNetAmt ?? "0.00");

                      double prevNetQty = double.parse(
                              modelObj.stockDetails?[i].preNetQty ?? "0.00") +
                          double.parse(modelObj.stockDetails?[i].netQty ?? "0");

                      if (prevNetQty != 0) {
                        double price = 0.0;

                        double ltpClose = double.parse(
                                    modelObj.stockDetails?[i].ltp ?? "0.00") >
                                0
                            ? double.parse(
                                modelObj.stockDetails?[i].ltp ?? "0.00")
                            : double.parse(modelObj.stockDetails?[i].close ??
                                        "0.00") >
                                    0
                                ? double.parse(
                                    modelObj.stockDetails?[i].close ?? "0.00")
                                : 0.0;
                        if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                .toAssetType()
                                .toString() ==
                            "commodity") {
                          if (prevNetQty != 0) {
                            price = (preAmount ~/
                                    (prevNetQty *
                                        double.parse(modelObj.stockDetails?[i]
                                                .priceMultiplier ??
                                            "0.00") *
                                        int.parse(
                                            modelObj.stockDetails?[i].lotQty ??
                                                "0")))
                                .abs()
                                .toDouble();
                          } else {
                            price = 0.0;
                          }
                        } else if (int.parse(
                                    modelObj.stockDetails?[i].token ?? "")
                                .toAssetType()
                                .toString() ==
                            "currency") {
                          if (prevNetQty != 0) {
                            price = (preAmount ~/
                                    (prevNetQty *
                                        double.parse(modelObj
                                                .stockDetails?[i].multiplier ??
                                            "0.00")))
                                .abs()
                                .toDouble();
                          } else {
                            price = 0.0;
                          }
                        } else {
                          price = (preAmount / prevNetQty).abs();
                        }

                        if (int.parse(
                                modelObj.stockDetails?[i].preNetQty ?? "") !=
                            0) {
                          if (price != 0) {
                            if (int.parse(modelObj.stockDetails?[i].token ?? "")
                                    .toAssetType()
                                    .toString() ==
                                "commodity") {
                              mtm = ((ltpClose - price)) *
                                  ((prevNetQty *
                                      double.parse(modelObj.stockDetails?[i]
                                              .priceMultiplier ??
                                          "0.00") *
                                      int.parse(
                                          modelObj.stockDetails?[i].lotQty ??
                                              "0.00")));
                            } else {
                              mtm = ((ltpClose - price)) *
                                  ((prevNetQty *
                                      double.parse(modelObj
                                              .stockDetails?[i].multiplier ??
                                          "0.00")));
                            }
                          } else {
                            mtm = 0.0;
                          }
                        } else {
                          mtm = todayMTM;
                        }
                      } else {
                        mtm = preAmount * (-1);
                      }

                      if (int.parse(modelObj.stockDetails?[i].token ?? "")
                              .toAssetType()
                              .toString() ==
                          "currency") {
                        modelObj.stockDetails?[i].todayprofitandloss =
                            mtm.toStringAsFixed(4).toString();
                        // holder.txt_mtm=StringStuff.commaINRDecorator(String.format("%.4f", mtm)));
                        // holder.txt_cmp=StringStuff.commaINRDecorator(String.format("%.4f", double.parse(customNetPositionSummary.getLtp()))));

                        // if (actualportfolipositionlist.netQty??"0".equalsIgnoreCase("0")) {
                        //   holder.txt_avgPrice="0");
                        // } else {
                        //   holder.txt_avgPrice=StringStuff.commaINRDecorator(String.format("%.4f", double.parse(customNetPositionSummary.getNetAvg()))));
                        // }
                      } else {
                        modelObj.stockDetails?[i].todayprofitandloss =
                            mtm.toStringAsFixed(2).toString();

                        // holder.txt_mtm=StringStuff.commaDecorator(String.format("%.2f", mtm)));
                        // holder.txt_cmp=StringStuff.commaDecorator(String.format("%.2f", double.parse(customNetPositionSummary.getLtp()))));

                        // if (actualportfolipositionlist.netQty??"0".equalsIgnoreCase("0")) {
                        //   holder.txt_avgPrice="0");
                        // } else {
                        //   holder.txt_avgPrice=StringStuff.commaDecorator(String.format("%.2f", double.parse(customNetPositionSummary.getNetAvg()))));
                        // }
                      }

                      //calculate mtm and price close
                      // display buy or sell price and qty validation
                      if (double.parse(
                                  modelObj.stockDetails?[i].buyAmt ?? "0.00") ==
                              0.00 &&
                          int.parse(modelObj.stockDetails?[i].buyQty ?? "0") ==
                              0) {
                        modelObj.stockDetails?[i].buysellamount = double.parse(
                                modelObj.stockDetails?[i].sellAmt ?? '0.00')
                            .toString();
                        modelObj.stockDetails?[i].buyselltext = "Sell Price";
                      } else if (double.parse(
                                  modelObj.stockDetails?[i].sellAmt ??
                                      "0.00") ==
                              0.00 &&
                          int.parse(modelObj.stockDetails?[i].sellQty ?? "0") ==
                              0) {
                        modelObj.stockDetails?[i].buysellamount = double.parse(
                                modelObj.stockDetails?[i].buyAmt ?? '0.00')
                            .toString();
                        modelObj.stockDetails?[i].buyselltext = "Buy Price";
                      } else {
                        modelObj.stockDetails?[i].buysellamount =
                            double.parse("0.00").toString();
                        modelObj.stockDetails?[i].buyselltext = "Price";
                      }
                      // display buy or sell price and qty validation

                    }
                    actualportfolipositionlist.addAll(modelObj.stockDetails!);
                    tempactualportfolipositionlist
                        .addAll(modelObj.stockDetails!);
                  }
                  positionStream = actualportfolipositionlist
                      .map((e) => BehaviorSubject.seeded(e))
                      .toList();
                  mainStream.sink.add(true);
                  subscribeholdingDetailsLTPInfoTokens();
                }
              }
              break;
            }
          }
        }
      }
    });

    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType ==
              IrisResponseStreamingType.HoldingDetailsInfoResp) {
            final responseDic = event[item];

            if (responseDic is Map<String, dynamic>) {
              // for (var ii = 0; ii < token.length; ii++) {

              //   lists.add(token[ii]);

              // }
              // responseDic["stockDetails"].perchange = 0.00;

              var modelObj = holding_models.HoldinResponseDataNewModel.fromJson(
                  responseDic);

              if (modelObj.stockDetails != null) {
                /*   for (int i = 0; i < modelObj.stockDetails.length; i++) {
                  ((double.parse(modelObj.stockDetails![i].ltp ?? '0.00') -
                              double.parse(
                                  modelObj.stockDetails![i].hPrice ?? '0.00')) /
                          double.parse(
                              modelObj.stockDetails![i].hPrice ?? "0.00")) *
                      100;
                } */

                //Prepare the list of holding data if it receives in multi packets.

                if (modelObj.islast == 1 ||
                    (modelObj.stockDetails?.length == modelObj.noofrecords &&
                        modelObj.islast == 2)) {
                  actualHoldingDataList = modelObj.stockDetails!;
                  tempactualHoldingDataList = modelObj.stockDetails!;

                  subscribeholdingDetailsLTPInfoTokensHolding();
                } else {
                  actualHoldingDataList.addAll(modelObj.stockDetails!);
                  tempactualHoldingDataList.addAll(modelObj.stockDetails!);
                }
                holdingDataStream = actualHoldingDataList
                    .map((e) => BehaviorSubject.seeded(e))
                    .toList();

                mainStream.sink.add(true);

                break;
              }
            }
          }
        }
      }
    });
    SocketIOManager().orderResponseObservable?.listen((event) {
      if (event != null) {
        final keys = event.keys.toList();

        for (var item in keys) {
          if (item.irisResponseStreamingType ==
              IrisResponseStreamingType.EDISHoldingInfoResponse) {
            final responseDic = event[item];

            if (responseDic is Map<String, dynamic>) {
              // for (var ii = 0; ii < token.length; ii++) {

              //   lists.add(token[ii]);

              // }

              var modelObj =
                  edis_authorize_holding.EdisAuthorizationResponse.fromJson(
                      responseDic);

              if (modelObj.stockDetails != null) {
                //Prepare the list of holding data if it receives in multi packets.

                edisactualHoldingDataList = modelObj.stockDetails!;

                edisAuthorizationmainStream.sink.add(true);

                break;
              }
            }
          }
        }
      }
    });

    //Handling 'HoldingScripPositionInfoResp'
    SocketIOManager().orderResponseObservable?.listen(
      (event) {
        if (event != null) {
          final keys = event.keys.toList();
          for (var item in keys) {
            if (item.irisResponseStreamingType ==
                IrisResponseStreamingType.HoldingScripPositionInfoResp) {
              final responseDic = event[item];
              if (responseDic is Map<String, dynamic>) {
                var modelObj =
                    HoldingScripDetailsInfoResponseModel.fromJson(responseDic);
                holdingScripInfoStream.sink.add(modelObj);
              }
            }
          }
        }
      },
    );

    SocketIOManager().productChnageObservable?.listen((irisEvent) {
      if (irisEvent != null) {
        final keys = irisEvent.keys.toList();

        for (var item in keys) {
          if (item == IrisResponseStreamingType.ProductChangeResponse.name) {
            var message = irisEvent[item]?['Message']?.toString();
            SocketIOManager().npDetailsRequest();
            GreekDialogPopupView.messageDialog(
              context,
              message.toString(),
            );
          }
        }
      }
    });
  }

  //Subscribing the Tokens for LTP Broadcast.

  void subscribeholdingDetailsLTPInfoTokensHolding() {
    if (unSubscribeholdingDetailsTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeholdingDetailsTokens);
    }

    subscribeholdingDetailsTokens =
        actualHoldingDataList.map((e) => (e.nSEToken.toString())).toList();

    subscribeholdingDetailsTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeholdingDetailsTokens);

    unSubscribeholdingDetailsTokens = subscribeholdingDetailsTokens;
  }

//UnSubscribing the Tokens for LTP Broadcast.

  void unSubscribeLTPInfoHolding() {
    if (_unSubscribeLTPInfoTokenArray.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(_unSubscribeLTPInfoTokenArray);

      _unSubscribeLTPInfoTokenArray.clear();
    }
  }

//Subscribing the Tokens for LTP Broadcast.
  void subscribeholdingDetailsLTPInfoTokens() {
    if (unSubscribeholdingDetailsTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeholdingDetailsTokens);
    }

    subscribeholdingDetailsTokens =
        actualportfolipositionlist.map((e) => (e.nSEToken.toString())).toList();

    subscribeholdingDetailsTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeholdingDetailsTokens);

    unSubscribeholdingDetailsTokens = subscribeholdingDetailsTokens;
  }

  //Subscribing the Tokens for LTP Broadcast.
  void subscribePositionDetialInfoTokens() {
    if (unSubscribeholdingDetailsTokens.isNotEmpty) {
      SocketIOManager()
          .unSubscribeLTPInfoTokens(unSubscribeholdingDetailsTokens);
    }

    subscribeholdingDetailsTokens =
        actualportfolipositionlist.map((e) => (e.nSEToken.toString())).toList();

    subscribeholdingDetailsTokens.removeWhere(
      (element) => ((element.isEmpty) && (int.parse(element) <= 0)),
    );

    SocketIOManager().subscribeLTPInfoTokens(subscribeholdingDetailsTokens);

    unSubscribeholdingDetailsTokens = subscribeholdingDetailsTokens;
  }

//UnSubscribing the Tokens for LTP Broadcast.
  void unSubscribeLTPInfo() {
    if (_unSubscribeLTPInfoTokenArray.isNotEmpty) {
      SocketIOManager().unSubscribeLTPInfoTokens(_unSubscribeLTPInfoTokenArray);
      _unSubscribeLTPInfoTokenArray.clear();
    }
  }

  void showPositionDetailBottomSheet(BuildContext context,
      StockDetailss actualportfolipositionlist, int index) {
    this.context = context;
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (sheetContex) {
        return SafeArea(
          child: StreamBuilder<StockDetailss>(
              stream: positionStream[index].stream,
              builder: (context, snapshot) {
                // data display validation start
                double ltptxt;
                double mtmtxt;
                double buyAmttxt;
                double sellAmttxt;
                double buyPricetxt;
                double sellPricetxt;
                double realizedgl = 0.00;
                double unrealizedgltxt = 0.00;
                double totalgltxt;
                double buyQtytxt;
                double sellQtytxt;

                if (int.parse(actualportfolipositionlist.token ?? "")
                        .toAssetType()
                        .toString() ==
                    "currency") {
                  ltptxt = double.parse(double.parse(snapshot.data?.ltp ?? "0")
                      .toStringAsFixed(4));
                  mtmtxt = double.parse(
                      double.parse(calculateMTM(index).toString())
                          .toStringAsFixed(4));
                  buyAmttxt = double.parse(
                      double.parse(actualportfolipositionlist.buyAmt ?? "0")
                          .toStringAsFixed(4));
                  sellAmttxt = double.parse(
                      double.parse(actualportfolipositionlist.sellAmt ?? "0")
                          .toStringAsFixed(4));
                  buyPricetxt = double.parse(
                      double.parse(actualportfolipositionlist.buyAvg ?? "0")
                          .toStringAsFixed(4));
                  sellPricetxt = double.parse(
                      double.parse(actualportfolipositionlist.sellAvg ?? "0")
                          .toStringAsFixed(4));

                  double nqty = 0;

                  double qty =
                      (double.parse(actualportfolipositionlist.netQty ?? "0") +
                          double.parse(
                              actualportfolipositionlist.preNetQty ?? "0"));

                  if (int.parse(actualportfolipositionlist.token ?? "")
                          .toAssetType()
                          .toString() ==
                      "commodity") {
                    nqty = qty;
                  } else {
                    double totalQty = double.parse(
                            actualportfolipositionlist.preNetQty ?? "0") +
                        double.parse(actualportfolipositionlist.netQty ?? "0");
                    nqty = totalQty;
                  }
                  if (nqty == 0) {
                    realizedgl = double.parse(
                        double.parse(calculateMTM(index).toString())
                            .toStringAsFixed(4));
                  } else {
                    unrealizedgltxt = double.parse(
                        double.parse(calculateMTM(index).toString())
                            .toStringAsFixed(4));
                  }
                  totalgltxt = double.parse(realizedgl.toString()) +
                      double.parse(unrealizedgltxt.toString());
                } else {
                  ltptxt = double.parse(double.parse(snapshot.data?.ltp ?? "0")
                      .toStringAsFixed(2));
                  mtmtxt = double.parse(
                      double.parse(calculateMTM(index).toString())
                          .toStringAsFixed(2));
                  buyAmttxt = double.parse(
                      double.parse(actualportfolipositionlist.buyAmt ?? "0")
                          .toStringAsFixed(2));
                  sellAmttxt = double.parse(
                      double.parse(actualportfolipositionlist.sellAmt ?? "0")
                          .toStringAsFixed(2));
                  buyPricetxt = double.parse(
                      double.parse(actualportfolipositionlist.buyAvg ?? "0")
                          .toStringAsFixed(2));
                  sellPricetxt = double.parse(
                      double.parse(actualportfolipositionlist.sellAvg ?? "0")
                          .toStringAsFixed(2));

                  double nqty = 0;

                  double qty =
                      (double.parse(actualportfolipositionlist.netQty ?? "0") +
                          double.parse(
                              actualportfolipositionlist.preNetQty ?? "0"));

                  if (int.parse(actualportfolipositionlist.token ?? "")
                          .toAssetType()
                          .toString() ==
                      "commodity") {
                    nqty = qty;
                  } else {
                    double totalQty = double.parse(
                            actualportfolipositionlist.preNetQty ?? "0") +
                        double.parse(actualportfolipositionlist.netQty ?? "0");
                    nqty = totalQty;
                  }
                  if (nqty == 0) {
                    realizedgl = double.parse(
                        double.parse(calculateMTM(index).toString())
                            .toStringAsFixed(2));
                  } else {
                    unrealizedgltxt = double.parse(
                        double.parse(calculateMTM(index).toString())
                            .toStringAsFixed(2));
                  }
                  totalgltxt = double.parse(realizedgl.toString()) +
                      double.parse(unrealizedgltxt.toString());
                }

                if (int.parse(actualportfolipositionlist.token ?? "")
                            .toAssetType()
                            .toString() ==
                        "mcx" ||
                    int.parse(actualportfolipositionlist.token ?? "")
                            .toAssetType()
                            .toString() ==
                        "ncdex") {
                  buyQtytxt =
                      int.parse(actualportfolipositionlist.buyQty ?? "") /
                          int.parse(actualportfolipositionlist.lotQty ?? "");

                  sellQtytxt =
                      int.parse(actualportfolipositionlist.sellQty ?? "") /
                          int.parse(actualportfolipositionlist.lotQty ?? "");
                } else if (int.parse(actualportfolipositionlist.token ?? "")
                        .toAssetType()
                        .toString() ==
                    "currency") {
                  buyQtytxt = int.parse(
                          actualportfolipositionlist.buyQty ?? "") /
                      int.parse(actualportfolipositionlist.multiplier ?? "");

                  sellQtytxt = int.parse(
                          actualportfolipositionlist.sellQty ?? "") /
                      int.parse(actualportfolipositionlist.multiplier ?? "");
                } else {
                  buyQtytxt =
                      double.parse(actualportfolipositionlist.buyQty ?? "");
                  sellQtytxt =
                      double.parse(actualportfolipositionlist.sellQty ?? "");
                }

//For todays quantity
                if (double.parse(
                        actualportfolipositionlist.buysellqty ?? "0") ==
                    0) {}

//for cummulative quantity
                var netqty = (double.parse(
                            actualportfolipositionlist.buysellqty ?? "0") +
                        int.parse(actualportfolipositionlist.preNetQty ?? "0"))
                    .toInt();
                if (netqty == 0) {}

                // data display validation close
                return Container(
                  height: 380,
                  color: Colors.white,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 8.0),
                                child: Text(
                                  actualportfolipositionlist.tradeSymbol! +
                                      "  " +
                                      int.parse(actualportfolipositionlist
                                                  .token ??
                                              '')
                                          .toExchange()
                                          .toString(),
                                  style: GreekTextStyle.heading19,
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Container(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(right: 8.0, left: 0),
                                child: Text(
                                  "LTP \u{20B9} ${int.parse(actualportfolipositionlist.token ?? "0").toAssetType().toString() == "currency" ? double.parse(ltptxt.toString()).toStringAsFixed(4) : double.parse(ltptxt.toString()).toStringAsFixed(2)}",
                                  style: GreekTextStyle.heading19,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      Flexible(
                        fit: FlexFit.loose,
                        child: ListView(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          children: [
                            const SizedBox(height: 16.0),
                            Container(
                              height: 40.0,
                              margin: const EdgeInsets.all(5.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Buy Qty",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          double.parse(buyQtytxt.toString())
                                              .toStringAsFixed(0),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Sell Qty",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          double.parse(sellQtytxt.toString())
                                              .toStringAsFixed(0),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Buy Amt",
                                          textAlign: TextAlign.center,
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(
                                                      buyAmttxt.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(
                                                      buyAmttxt.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(
                              height: 1,
                            ),
                            Container(
                              height: 40.0,
                              margin: const EdgeInsets.all(5.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Buy Price",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(
                                                      buyPricetxt.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(
                                                      buyPricetxt.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Sell Price",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(
                                                      sellPricetxt.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(
                                                      sellPricetxt.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Sell Amt",
                                          textAlign: TextAlign.center,
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(
                                                      sellAmttxt.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(
                                                      sellAmttxt.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(
                              height: 1,
                            ),
                            Container(
                              height: 40.0,
                              margin: const EdgeInsets.all(5.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Unrealized G/L",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(unrealizedgltxt
                                                      .toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(unrealizedgltxt
                                                      .toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Realized G/L",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(
                                                      realizedgl.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(
                                                      realizedgl.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Total G/L",
                                          textAlign: TextAlign.center,
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(
                                                      totalgltxt.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(
                                                      totalgltxt.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(
                              height: 1,
                            ),
                            Container(
                              height: 40.0,
                              margin: const EdgeInsets.all(5.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Product Type",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          getProductType(
                                              actualportfolipositionlist
                                                  .productType),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          "MTM",
                                          style: GreekTextStyle.headline12,
                                        ),
                                        Text(
                                          int.parse(snapshot.data?.token ?? "0")
                                                      .toAssetType()
                                                      .toString() !=
                                                  "currency"
                                              ? double.parse(mtmtxt.toString())
                                                  .toStringAsFixed(2)
                                              : double.parse(mtmtxt.toString())
                                                  .toStringAsFixed(4),
                                          style: GreekTextStyle
                                              .market_depth_row_text_style,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(
                              height: 1,
                            ),
                            Container(
                              margin: const EdgeInsets.all(10),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: InkWell(
                                      onTap: () {
                                        if (double.parse(
                                                actualportfolipositionlist
                                                        .buysellqty ??
                                                    "0") ==
                                            0.00) {
                                        } else {
                                          if (getProductType(
                                                  actualportfolipositionlist
                                                      .productType) !=
                                              getProductType("4")) {
                                            OrderDetailsModel orderDetails =
                                                OrderDetailsModel();

                                            orderDetails.gtoken =
                                                actualportfolipositionlist
                                                    .sqoffToken;
                                            orderDetails.exchange = int.parse(
                                                    snapshot.data?.sqoffToken ??
                                                        "0")
                                                .toExchange()
                                                .toString();

                                            if (double.parse(
                                                        actualportfolipositionlist
                                                                .preNetQty ??
                                                            "0") +
                                                    double.parse(
                                                        actualportfolipositionlist
                                                                .netQty ??
                                                            "0") >=
                                                0) {
                                              orderDetails.orderAction =
                                                  OrderAction.sell;
                                            } else {
                                              orderDetails.orderAction =
                                                  OrderAction.buy;
                                            }
                                            orderDetails.tradeSymbol =
                                                actualportfolipositionlist
                                                    .tradeSymbol;

                                            orderDetails.productType =
                                                actualportfolipositionlist
                                                    .productType;

                                            double qty = double.parse(
                                                    actualportfolipositionlist
                                                            .netQty ??
                                                        "0") +
                                                int.parse(
                                                    actualportfolipositionlist
                                                            .preNetQty ??
                                                        "0");

                                            orderDetails.qty = double.parse(qty
                                                    .toString()
                                                    .replaceAll("-", ""))
                                                .toStringAsFixed(0);

                                            if (int.parse(
                                                        actualportfolipositionlist
                                                                .sqoffToken ??
                                                            "")
                                                    .toAssetType()
                                                    .toString() ==
                                                "commodity") {
                                              qty = double.parse(
                                                      actualportfolipositionlist
                                                              .netQty ??
                                                          "0") +
                                                  (int.parse(
                                                      actualportfolipositionlist
                                                              .preNetQty ??
                                                          "0"));
                                              orderDetails.NetQty =
                                                  double.parse(qty.toString())
                                                      .toStringAsFixed(0);
                                            } else if (int.parse(
                                                        actualportfolipositionlist
                                                                .sqoffToken ??
                                                            "")
                                                    .toAssetType()
                                                    .toString() ==
                                                "currency") {
                                              qty = double.parse(
                                                      actualportfolipositionlist
                                                              .netQty ??
                                                          "0") +
                                                  (int.parse(
                                                      actualportfolipositionlist
                                                              .preNetQty ??
                                                          "0"));
                                              orderDetails.NetQty =
                                                  double.parse(qty.toString())
                                                      .toStringAsFixed(0);
                                            } else {
                                              orderDetails.NetQty =
                                                  double.parse(qty.toString())
                                                      .toStringAsFixed(0);
                                            }

                                            orderDetails.tradeSymbol =
                                                actualportfolipositionlist
                                                    .tradeSymbol;
                                            orderDetails.lot =
                                                actualportfolipositionlist
                                                    .lotQty;
                                            orderDetails.isModifyObj = false;
                                            orderDetails.isSqOffOrder = true;
                                            orderDetails.TickSize =
                                                actualportfolipositionlist
                                                    .tickSize;
                                            orderDetails.Multiplier =
                                                actualportfolipositionlist
                                                    .multiplier;

                                            orderDetails.gcid =
                                                AppConfig().gcid;
                                            GreekNavigator.pop(
                                                context: context);
                                            GreekNavigator.pushNamed(
                                              context: context,
                                              routeName:
                                                  GreekScreenNames.place_order,
                                              arguments: [
                                                int.parse(orderDetails.gtoken
                                                    .toString()),
                                                orderDetails.orderAction,
                                                OrderMode.squareoffOrder,
                                                ScriptInfoTab.order.index,
                                                orderDetails,
                                              ],
                                            );
                                          } else {
                                            GreekDialogPopupView.messageDialog(
                                              context,
                                              "Could Not SquareOff Retailer Position For " +
                                                  getProductType("4") +
                                                  " Product ",
                                            );
                                          }
                                        }
                                      },
                                      child: SizedBox(
                                        height: 70,
                                        width: 150,
                                        child: Card(
                                          elevation: 5,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(15.0),
                                          ),
                                          child: const Center(
                                              child: Text(
                                            "Square Off",
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 15.0,
                                                fontWeight: FontWeight.bold),
                                          )),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: InkWell(
                                      onTap: () {
                                        if (double.parse(
                                                actualportfolipositionlist
                                                        .buysellqty ??
                                                    "0") ==
                                            0.00) {
                                        } else {
                                          GreekNavigator.pop(
                                              context: sheetContex);
                                          TextEditingController qtyController =
                                              TextEditingController(
                                                  text: double.parse(
                                                          actualportfolipositionlist
                                                              .netQty!
                                                              .replaceAll(
                                                                  "-", "")
                                                              .toString())
                                                      .toStringAsFixed(0));
                                          List<String> dropdownValues = [];
                                          var enterQty = qtyController.text;

                                          dropdownValues.clear();
                                          for (int i = 0;
                                              i <
                                                  GreekBase()
                                                      .alloedProductList
                                                      .length;
                                              i++) {
                                            if ((int.parse(snapshot.data?.token ?? "0")
                                                            .toExchange()
                                                            .toString() ==
                                                        "NSE" ||
                                                    int.parse(snapshot.data?.token ?? "0")
                                                            .toExchange()
                                                            .toString() ==
                                                        "BSE") &&
                                                int.parse(snapshot.data?.token ?? "0")
                                                        .toAssetType()
                                                        .toString() ==
                                                    "equity" &&
                                                (GreekBase()
                                                            .alloedProductList[
                                                                i]!
                                                            .cProductName
                                                            .toString() ==
                                                        getProductType("3")
                                                            .toString() ||
                                                    GreekBase()
                                                            .alloedProductList[
                                                                i]!
                                                            .cProductName
                                                            .toString() ==
                                                        getProductType("2")
                                                            .toString())) {
                                              dropdownValues.add(GreekBase()
                                                  .alloedProductList[i]!
                                                  .cProductName
                                                  .toString());
                                            } else if (GreekBase()
                                                        .alloedProductList[i]!
                                                        .cProductName
                                                        .toString() ==
                                                    getProductType("0")
                                                        .toString() ||
                                                GreekBase()
                                                        .alloedProductList[i]!
                                                        .cProductName
                                                        .toString() ==
                                                    getProductType("1")
                                                        .toString()) {
                                              dropdownValues.add(GreekBase()
                                                  .alloedProductList[i]!
                                                  .cProductName
                                                  .toString());
                                            }
                                            if (dropdownValues.length > i) {
                                              if (dropdownValues[i]
                                                      .toString()
                                                      .contains("TNC") ||
                                                  dropdownValues[i]
                                                      .toString()
                                                      .contains("TOG Super") ||
                                                  dropdownValues[i]
                                                      .toString()
                                                      .contains("SSEQ")) {
                                                dropdownValues.removeAt(i);
                                              }
                                            }
                                          }

                                          String selectedValue = getProductType(
                                              snapshot.data?.productType);
                                          showDialog(
                                              barrierDismissible: true,
                                              context: context,
                                              builder: (buildcontext) {
                                                return StatefulBuilder(builder:
                                                    (dialogContext, setState) {
                                                  return WillPopScope(
                                                    onWillPop: () async {
                                                      GreekNavigator.pop(
                                                          context:
                                                              buildcontext);
                                                      return true;
                                                    },
                                                    child: Dialog(
                                                      child: SizedBox(
                                                        height: 200.0,
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                              margin:
                                                                  const EdgeInsets
                                                                      .all(10),
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Text(
                                                                "Product Change",
                                                                style: GreekTextStyle
                                                                    .headline2,
                                                              ),
                                                            ),
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceAround,
                                                              children: [
                                                                Column(
                                                                  children: [
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .all(
                                                                          10.0),
                                                                      child:
                                                                          Text(
                                                                        "Quantity",
                                                                        style: GreekTextStyle
                                                                            .headline1,
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .all(
                                                                          10.0),
                                                                      child:
                                                                          Container(
                                                                        width:
                                                                            100,
                                                                        height:
                                                                            20,
                                                                        alignment:
                                                                            Alignment.center,
                                                                        child:
                                                                            TextField(
                                                                          controller:
                                                                              qtyController,
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          style:
                                                                              GreekTextStyle.marketDepthTotal,
                                                                          keyboardType:
                                                                              TextInputType.number,
                                                                          onChanged:
                                                                              (string) {
                                                                            enterQty =
                                                                                string;
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                Column(
                                                                  children: [
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .all(
                                                                          10.0),
                                                                      child:
                                                                          Text(
                                                                        "Product",
                                                                        style: GreekTextStyle
                                                                            .headline1,
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .all(
                                                                          10.0),
                                                                      child:
                                                                          SizedBox(
                                                                        width:
                                                                            100,
                                                                        height:
                                                                            20,
                                                                        child: DropdownButton<
                                                                            String>(
                                                                          isExpanded:
                                                                              true,
                                                                          value:
                                                                              selectedValue,
                                                                          icon:
                                                                              const Icon(Icons.arrow_drop_down),
                                                                          iconSize:
                                                                              24,
                                                                          elevation:
                                                                              16,
                                                                          style: const TextStyle(
                                                                              color: Colors.black,
                                                                              fontSize: 14),
                                                                          underline:
                                                                              Container(
                                                                            height:
                                                                                0.0,
                                                                          ),
                                                                          onChanged:
                                                                              (data) {
                                                                            setState(() {
                                                                              selectedValue = data!;
                                                                            });
                                                                          },
                                                                          items:
                                                                              dropdownValues.map<DropdownMenuItem<String>>((String value) {
                                                                            return DropdownMenuItem<String>(
                                                                              value: value,
                                                                              child: Text(
                                                                                value,
                                                                              ),
                                                                            );
                                                                          }).toList(),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceAround,
                                                              children: [
                                                                InkWell(
                                                                  onTap: () {
                                                                    if (enterQty
                                                                        .toString()
                                                                        .isNotEmpty) {
                                                                      if ((int.parse(enterQty.toString()) ==
                                                                              0) ||
                                                                          (int.parse(enterQty.toString())).abs() >
                                                                              (double.parse(snapshot.data?.netQty ?? "")).abs()) {
                                                                        GreekDialogPopupView
                                                                            .messageDialog(
                                                                          buildcontext,
                                                                          "Invalid Quantity",
                                                                        );
                                                                      } else if (selectedValue
                                                                              .toString() ==
                                                                          "Select Product") {
                                                                        GreekDialogPopupView
                                                                            .messageDialog(
                                                                          buildcontext,
                                                                          "Please select product",
                                                                        );
                                                                      } else {
                                                                        int a =
                                                                            0;
                                                                        if (int.parse(snapshot.data?.sqoffToken ?? "0").toExchange().toString().toLowerCase() ==
                                                                                "mcx" ||
                                                                            int.parse(snapshot.data?.sqoffToken ?? "0").toExchange().toString().toLowerCase() ==
                                                                                "ncdex") {
                                                                          a = int.parse(enterQty.toString()) *
                                                                              int.parse(snapshot.data?.lotQty ?? "0").abs();
                                                                        } else {
                                                                          a = int.parse(enterQty.toString())
                                                                              .abs();
                                                                        }

                                                                        int b = int.parse(snapshot.data?.lotQty ??
                                                                            "0");
                                                                        int rem =
                                                                            a % b;
                                                                        String
                                                                            previousProduct =
                                                                            snapshot.data?.productType ??
                                                                                "0";

                                                                        if (enterQty.toString().isNotEmpty &&
                                                                            (rem !=
                                                                                0)) {
                                                                          GreekDialogPopupView
                                                                              .messageDialog(
                                                                            buildcontext,
                                                                            "Entered Quantity is not in a multiple of Lot",
                                                                          );
                                                                        } else if (getProductType(previousProduct.toString()) ==
                                                                            selectedValue.toString()) {
                                                                          GreekNavigator.pop(
                                                                              context: buildcontext);
                                                                          GreekDialogPopupView
                                                                              .messageDialog(
                                                                            buildcontext,
                                                                            "Product change not allowed in same product",
                                                                          );
                                                                        } else {
                                                                          ProductChangeRequestModel
                                                                              changeRequest =
                                                                              ProductChangeRequestModel();
                                                                          changeRequest.gscid =
                                                                              AppConfig().gscid;
                                                                          changeRequest.gtoken = snapshot
                                                                              .data
                                                                              ?.token;
                                                                          if (int.parse(snapshot.data?.sqoffToken ?? "0").toExchange().toString().toLowerCase() == "mcx" ||
                                                                              int.parse(snapshot.data?.sqoffToken ?? "0").toExchange().toString().toLowerCase() == "ncdex") {
                                                                            int qtylot =
                                                                                int.parse(enterQty.toString()) * int.parse(snapshot.data?.lotQty ?? "");
                                                                            double
                                                                                tradedqtylot =
                                                                                double.parse(snapshot.data?.netQty ?? "") * int.parse(snapshot.data?.lotQty ?? "");
                                                                            changeRequest.qty =
                                                                                qtylot.toString();
                                                                            changeRequest.tradedQty =
                                                                                tradedqtylot.toString();
                                                                          } else {
                                                                            changeRequest.qty =
                                                                                enterQty.toString();
                                                                            changeRequest.tradedQty =
                                                                                snapshot.data?.netQty ?? "";
                                                                          }
                                                                          changeRequest.product = GreekBase()
                                                                              .getProductTokenFromProductName(selectedValue)
                                                                              .toString();
                                                                          changeRequest.iGiveUpStatus = snapshot
                                                                              .data
                                                                              ?.productType
                                                                              .toString();
                                                                          changeRequest.reason =
                                                                              "Netposition";
                                                                          changeRequest.gorderid =
                                                                              "";
                                                                          changeRequest.tradeid =
                                                                              "";
                                                                          changeRequest.eorderid =
                                                                              "";
                                                                          changeRequest.side =
                                                                              "";
                                                                          SocketIOManager()
                                                                              .productChangeRequestApi(changeRequest);
                                                                          GreekNavigator.pop(
                                                                              context: buildcontext);
                                                                        }
                                                                      }
                                                                    } else {
                                                                      GreekDialogPopupView.messageDialog(
                                                                          buildcontext,
                                                                          "Enter Quantity");
                                                                    }
                                                                  },
                                                                  child:
                                                                      SizedBox(
                                                                    height: 70,
                                                                    width: 120,
                                                                    child: Card(
                                                                      elevation:
                                                                          5,
                                                                      shape:
                                                                          RoundedRectangleBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(15.0),
                                                                      ),
                                                                      child: const Center(
                                                                          child: Text(
                                                                        "Submit",
                                                                        style: TextStyle(
                                                                            color: Colors
                                                                                .black,
                                                                            fontSize:
                                                                                18.0,
                                                                            fontWeight:
                                                                                FontWeight.bold),
                                                                      )),
                                                                    ),
                                                                  ),
                                                                ),
                                                                InkWell(
                                                                  onTap: () {
                                                                    GreekNavigator.pop(
                                                                        context:
                                                                            buildcontext);
                                                                  },
                                                                  child:
                                                                      SizedBox(
                                                                    height: 70,
                                                                    width: 120,
                                                                    child: Card(
                                                                      elevation:
                                                                          5,
                                                                      shape:
                                                                          RoundedRectangleBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(15.0),
                                                                      ),
                                                                      child: const Center(
                                                                          child: Text(
                                                                        "Cancel",
                                                                        style: TextStyle(
                                                                            color: Colors
                                                                                .black,
                                                                            fontSize:
                                                                                18.0,
                                                                            fontWeight:
                                                                                FontWeight.bold),
                                                                      )),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  );
                                                });
                                              });
                                        }
                                      },
                                      child: SizedBox(
                                        height: 70,
                                        width: 150,
                                        child: Card(
                                          elevation: 5,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(15.0),
                                          ),
                                          child: const Center(
                                              child: Text(
                                            "Product Change",
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 15.0,
                                                fontWeight: FontWeight.bold),
                                          )),
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }),
        );
      },
    );
  }

//====================================================================
  ///
  /// Show Model Bottom For Holding Details Info
  ///
  //=====================================================================
  void showBottomSheetForHoldingDetailsInfo(
      BuildContext holdingContext,
      holding_models.StockDetails objDetails,
      PortfolioBloc portfolioBloc,
      int index) {
    var nsetoken = int.parse(objDetails.nSEToken.toString());
    var bsetoken = int.parse(objDetails.bSEToken.toString());
    String token = ((nsetoken > 0)
            ? nsetoken.toString()
            : (bsetoken > 0)
                ? bsetoken
                : '0')
        .toString();
    int tokenType = int.parse(token);
    //API Call for fetching 'HoldingScripPositionInfo'
    SocketIOManager().getHoldingScripPositionInfo(token: token);

    String exchange = tokenType.toExchange().toString();

    showModalBottomSheet(
      context: holdingContext,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
        ),
      ),
      backgroundColor: ConstantColors.primaryColor,
      builder: (bottomsheetContext) {
        return StreamBuilder<holding_models.StockDetails>(
            stream: holdingDataStream[index].stream,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return SizedBox(
                  height: 450.0,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      10.0,
                      21.0,
                      10.0,
                      10.0,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Material(
                          child: Container(
                            color: ConstantColors.primaryColor,
                            height: 50,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      objDetails.symbol.toString(),
                                      style: GreekTextStyle.headline30,
                                    ),
                                    Text(
                                      ' - $exchange',
                                      style: GreekTextStyle.headline6,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Text(
                                      'LTP \u{20B9} ',
                                      style: GreekTextStyle.headline6,
                                    ),
                                    Text(
                                      double.parse(
                                              snapshot.data!.ltp.toString())
                                          .toStringAsFixed(2),
                                      style: GreekTextStyle.headline6,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const Divider(
                          color: ConstantColors.dividerColor,
                          height: 8,
                        ),
                        Expanded(
                          child: StreamBuilder<
                              HoldingScripDetailsInfoResponseModel>(
                            stream: portfolioBloc.holdingScripInfoStream.stream,
                            builder: (context, snapshot) {
                              if (snapshot.hasData) {
                                //Calculation Part for
                                var obj = snapshot.data!;

                                //Total Buy Qty
                                var buyQty = int.parse(obj.todayBuyQty ?? '0');
                                //Todal Buy ATP
                                var buyATP =
                                    double.parse(obj.todayBuyATP ?? '0.0');
                                //Total Buy Amt
                                var buyAMT = buyQty * buyATP;
                                //Total Sell Qty
                                var sellQty =
                                    int.parse(obj.todaySellQty ?? '0');
                                //Total Sell ATP
                                var sellATP =
                                    double.parse(obj.todaySellATP ?? '0.0');
                                //Total Sell Amt
                                var sellAMT = sellQty * sellATP;
                                //Total Net Qty
                                var netQty = int.parse(obj.todayNetQty ?? '0');
                                //Net Hol. Qty
                                var netHQty =
                                    int.parse(obj.netHoldingQty ?? '0');
                                //Net Hol. Price
                                var hPrice =
                                    double.parse(obj.netHoldingPrice ?? '0.0');
                                //Net Hol. Value
                                var holdingValue = netHQty * hPrice;
                                //Sold Qty
                                var soldQty = int.parse(obj.soldQty ?? '0');
                                //Pending Qty
                                var pendingQty =
                                    int.parse(obj.pendingQty ?? '0');
                                //Risk Block Qty
                                var riskBlockQty =
                                    int.parse(obj.riskBlockQty ?? '0');
                                //Free Hol. Qty
                                var freeHoldingQty =
                                    int.parse(obj.freeHOldingQty ?? '0');

                                return Material(
                                  child: Container(
                                    color: ConstantColors.primaryColor,
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Buy Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(buyQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Sell Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(sellQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Buy Amt',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(buyAMT.toStringAsFixed(2),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const Divider(
                                          color: ConstantColors.dividerColor,
                                          height: 30,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Buy ATP',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(buyATP.toStringAsFixed(2),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Sell ATP',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(sellATP.toStringAsFixed(2),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Sell Amt',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(sellAMT.toStringAsFixed(2),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const Divider(
                                          color: ConstantColors.dividerColor,
                                          height: 30,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Total Net Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(netQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Net Hol. Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(netHQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Net Hol. Value',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(holdingValue.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const Divider(
                                          color: ConstantColors.dividerColor,
                                          height: 30,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Net Hol. Price',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(hPrice.toStringAsFixed(2),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Sold Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(soldQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Pending Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(pendingQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const Divider(
                                          color: ConstantColors.dividerColor,
                                          height: 30,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Risk Block Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(riskBlockQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('Free Hol. Qty',
                                                    style: GreekTextStyle
                                                        .headline30),
                                                Text(freeHoldingQty.toString(),
                                                    style: GreekTextStyle
                                                        .headline6),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text('            ',
                                                    style: GreekTextStyle
                                                        .headline30),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              } else {
                                return Container();
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              } else {
                return Container();
              }
            });
      },
    );
  }

  double calculateMTM(int index) {
    //calculate mtm and price start
    int netQty;
    double netPrice, todayMTM, mtm, netAmt;
    netAmt = double.parse(positionStream[index].value.dayNetAmt ?? "0");
    netQty = int.parse(positionStream[index].value.netQty ?? "0");

    if (netQty != 0) {
      if (int.parse(positionStream[index].value.token ?? "")
              .toAssetType()
              .toString() ==
          "currency") {
        netPrice = double.parse(
            double.parse(positionStream[index].value.netAvg ?? "")
                .toStringAsFixed(4)
                .toString());
      } else {
        netPrice = double.parse(
            double.parse(positionStream[index].value.netAvg ?? "")
                .toStringAsFixed(2)
                .toString());
      }
    } else {
      netPrice = 0.0;
    }

    if (netQty != 0) {
      double ltpClose = double.parse(positionStream[index].value.ltp ?? "0") > 0
          ? double.parse(positionStream[index].value.ltp ?? "0")
          : double.parse(positionStream[index].value.close ?? "0") > 0
              ? double.parse(positionStream[index].value.close ?? "0")
              : 0.0;
      double price = netPrice;

      if (price != 0) {
        if (int.parse(positionStream[index].value.token ?? "")
                .toExchange()
                .toString() ==
            "MCX") {
          todayMTM = (ltpClose - price) *
              ((netQty *
                  double.parse(
                      positionStream[index].value.priceMultiplier ?? "0") *
                  int.parse(positionStream[index].value.lotQty ?? "0")));
        } else if (int.parse(positionStream[index].value.token ?? "")
                .toExchange()
                .toString() ==
            "NCDEX") {
          todayMTM = (ltpClose - price) *
              ((netQty *
                  double.parse(
                      positionStream[index].value.priceMultiplier ?? "0") *
                  int.parse(positionStream[index].value.lotQty ?? "0")));
        } else {
          todayMTM = (ltpClose - price) *
              ((netQty *
                  double.parse(positionStream[index].value.multiplier ?? "0")));
        }
      } else {
        todayMTM = 0.0;
      }
    } else {
      if (netAmt == 0.0) {
        todayMTM = netAmt;
      } else {
        todayMTM = netAmt * (-1);
      }
    }

    double preAmount =
        //double.parse(positionStream[index].value.pAmt ?? "0.00") +
        double.parse(positionStream[index].value.dayNetAmt ?? "0.00");

    double prevNetQty =
        //double.parse(positionStream[index].value.preNetQty ?? "0.00") +
        double.parse(positionStream[index].value.netQty ?? "0");

    if (prevNetQty != 0) {
      double price = 0.0;

      double ltpClose =
          double.parse(positionStream[index].value.ltp ?? "0.00") > 0
              ? double.parse(positionStream[index].value.ltp ?? "0.00")
              : double.parse(positionStream[index].value.close ?? "0.00") > 0
                  ? double.parse(positionStream[index].value.close ?? "0.00")
                  : 0.0;
      if (int.parse(positionStream[index].value.token ?? "")
              .toAssetType()
              .toString() ==
          "commodity") {
        if (prevNetQty != 0) {
          price = (preAmount ~/
                  (prevNetQty *
                      double.parse(
                          positionStream[index].value.priceMultiplier ??
                              "0.00") *
                      int.parse(positionStream[index].value.lotQty ?? "0")))
              .abs()
              .toDouble();
        } else {
          price = 0.0;
        }
      } else if (int.parse(positionStream[index].value.token ?? "")
              .toAssetType()
              .toString() ==
          "currency") {
        if (prevNetQty != 0) {
          price = (preAmount ~/
                  (prevNetQty *
                      double.parse(
                          positionStream[index].value.multiplier ?? "0.00")))
              .abs()
              .toDouble();
        } else {
          price = 0.0;
        }
      } else {
        price = (preAmount / prevNetQty).abs();
      }

      if (int.parse(positionStream[index].value.preNetQty ?? "") != 0) {
        if (price != 0) {
          if (int.parse(positionStream[index].value.token ?? "")
                  .toAssetType()
                  .toString() ==
              "commodity") {
            mtm = ((ltpClose - price)) *
                ((prevNetQty *
                    double.parse(
                        positionStream[index].value.priceMultiplier ?? "0.00") *
                    int.parse(positionStream[index].value.lotQty ?? "0.00")));
          } else {
            mtm = ((ltpClose - price)) *
                ((prevNetQty *
                    double.parse(
                        positionStream[index].value.multiplier ?? "0.00")));
          }
        } else {
          mtm = 0.0;
        }
      } else {
        mtm = todayMTM;
      }
    } else {
      mtm = preAmount * (-1);
    }

    //calculate mtm and price close
    return mtm;
  }

  String getProductType(String? productType) {
    for (int i = 0; i < GreekBase().alloedProductList.length; i++) {
      if (GreekBase().alloedProductList[i]?.iProductToken ==
          int.parse(productType!)) {
        return GreekBase().alloedProductList[i]?.cProductName ?? "";
      }
    }
    return "";
  }

  void filterOrderListBySearchText(String searchText) {
    if (selectedIndexGlobal == 0) {
      if (searchText.isEmpty) {
        actualHoldingDataList = tempactualHoldingDataList;
        holdingDataStream = tempactualHoldingDataList
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
        mainStream.sink.add(true);
      } else {
        final resultList = tempactualHoldingDataList
            .where((element) => (element.symbol
                    ?.toLowerCase()
                    .contains(searchText.toLowerCase()) ??
                false))
            .toList();
        holdingDataStream.clear();
        actualHoldingDataList = resultList;
        holdingDataStream =
            resultList.map((e) => BehaviorSubject.seeded(e)).toList();
        mainStream.sink.add(true);
      }
    } else {
      if (searchText.isEmpty) {
        actualportfolipositionlist = tempactualportfolipositionlist;
        positionStream = tempactualportfolipositionlist
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
        mainStream.sink.add(true);
      } else {
        final resultList = tempactualportfolipositionlist
            .where((element) => (element.symbol
                    ?.toLowerCase()
                    .contains(searchText.toLowerCase()) ??
                false))
            .toList();
        positionStream.clear();
        actualportfolipositionlist = resultList;
        positionStream =
            resultList.map((e) => BehaviorSubject.seeded(e)).toList();
        mainStream.sink.add(true);
      }
    }
  }

  void filterpopup(String selectedDropDownItem) {
    if (selectedIndexGlobal == 0) {
      if (selectedDropDownItem == "LTP" && lTPChangesort == false) {
        lTPChangesort = true;
        tempactualHoldingDataList.sort((a, b) =>
            ((double.parse(a.ltp.toString()))
                .compareTo(double.parse(b.ltp.toString()))));
        actualHoldingDataList = tempactualHoldingDataList;
        holdingDataStream = tempactualHoldingDataList
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
      } else if (selectedDropDownItem == "LTP" && lTPChangesort == true) {
        lTPChangesort = false;
        tempactualHoldingDataList.sort((a, b) =>
            ((double.parse(a.ltp.toString()))
                .compareTo(double.parse(b.ltp.toString()))));
        List<holding_models.StockDetails> tempreverse =
            List.from(tempactualHoldingDataList.reversed.toList());
        actualHoldingDataList = tempreverse;
        holdingDataStream =
            tempreverse.map((e) => BehaviorSubject.seeded(e)).toList();
      }

      if (selectedDropDownItem == "% Change" && perChangeSort == false) {
        perChangeSort = true;
        tempactualHoldingDataList.sort((a, b) =>
            ((double.parse(a.perchange.toString()))
                .compareTo(double.parse(b.perchange.toString()))));
        actualHoldingDataList = tempactualHoldingDataList;
        holdingDataStream = tempactualHoldingDataList
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
      } else if (selectedDropDownItem == "% Change" && perChangeSort == true) {
        perChangeSort = false;
        tempactualHoldingDataList.sort((a, b) =>
            ((double.parse(a.perchange.toString()))
                .compareTo(double.parse(b.perchange.toString()))));
        List<holding_models.StockDetails> tempreverse =
            List.from(tempactualHoldingDataList.reversed.toList());
        actualHoldingDataList = tempreverse;
        holdingDataStream =
            tempreverse.map((e) => BehaviorSubject.seeded(e)).toList();
      }

      if (selectedDropDownItem == "Alphabetically" &&
          alphabetChangesort == false) {
        alphabetChangesort = true;
        tempactualHoldingDataList.sort(
            (a, b) => ((a.symbol.toString()).compareTo(b.symbol.toString())));
        actualHoldingDataList = tempactualHoldingDataList;
        holdingDataStream = tempactualHoldingDataList
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
      } else {
        if (selectedDropDownItem == "Alphabetically" &&
            alphabetChangesort == true) {
          alphabetChangesort = false;
          tempactualHoldingDataList.sort(
              (a, b) => ((a.symbol.toString()).compareTo(b.symbol.toString())));
          List<holding_models.StockDetails> tempreverse =
              List.from(tempactualHoldingDataList.reversed.toList());
          actualHoldingDataList = tempreverse;
          holdingDataStream =
              tempreverse.map((e) => BehaviorSubject.seeded(e)).toList();
        }
      }
      mainStream.sink.add(true);
    } else {
      if (selectedDropDownItem == "LTP" && lTPChangesort == false) {
        lTPChangesort = true;
        tempactualportfolipositionlist.sort((a, b) =>
            ((double.parse(a.ltp.toString()))
                .compareTo(double.parse(b.ltp.toString()))));
        actualportfolipositionlist = tempactualportfolipositionlist;
        positionStream = tempactualportfolipositionlist
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
      } else if (selectedDropDownItem == "LTP" && lTPChangesort == true) {
        lTPChangesort = false;
        tempactualportfolipositionlist.sort((a, b) =>
            ((double.parse(a.ltp.toString()))
                .compareTo(double.parse(b.ltp.toString()))));
        List<StockDetailss> tempreverse =
            List.from(tempactualportfolipositionlist.reversed.toList());
        actualportfolipositionlist = tempreverse;
        positionStream =
            tempreverse.map((e) => BehaviorSubject.seeded(e)).toList();
      }
      if (selectedDropDownItem == "% Change" && perChangeSort == false) {
        perChangeSort = true;
        tempactualportfolipositionlist.sort((a, b) =>
            ((double.parse(a.perchange.toString()))
                .compareTo(double.parse(b.perchange.toString()))));
        actualportfolipositionlist = tempactualportfolipositionlist;
        positionStream = tempactualportfolipositionlist
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
      } else if (selectedDropDownItem == "% Change" && perChangeSort == true) {
        lTPChangesort = false;
        tempactualportfolipositionlist.sort((a, b) =>
            ((double.parse(a.ltp.toString()))
                .compareTo(double.parse(b.ltp.toString()))));
        List<StockDetailss> tempreverse =
            List.from(tempactualportfolipositionlist.reversed.toList());
        actualportfolipositionlist = tempreverse;
        positionStream =
            tempreverse.map((e) => BehaviorSubject.seeded(e)).toList();
      }

      if (selectedDropDownItem == "Alphabetically" &&
          alphabetChangesort == false) {
        alphabetChangesort = true;
        tempactualportfolipositionlist.sort((a, b) =>
            ((a.tradeSymbol.toString()).compareTo(b.tradeSymbol.toString())));
        actualportfolipositionlist = tempactualportfolipositionlist;
        positionStream = tempactualportfolipositionlist
            .map((e) => BehaviorSubject.seeded(e))
            .toList();
      } else {
        if (selectedDropDownItem == "Alphabetically" &&
            alphabetChangesort == true) {
          alphabetChangesort = false;
          tempactualportfolipositionlist.sort((a, b) =>
              ((a.tradeSymbol.toString()).compareTo(b.tradeSymbol.toString())));
          List<StockDetailss> tempreverse =
              List.from(tempactualportfolipositionlist.reversed.toList());
          actualportfolipositionlist = tempreverse;
          positionStream =
              tempreverse.map((e) => BehaviorSubject.seeded(e)).toList();
        }
      }
      mainStream.sink.add(true);
    }
  }

  void hideSearchandtexFieldDispose() {
    if (searchTextFieldController.text.isNotEmpty) {
      searchTextFieldController.clear();
      searchWidgitVisiblity.sink.add(false);
    }
  }
}
