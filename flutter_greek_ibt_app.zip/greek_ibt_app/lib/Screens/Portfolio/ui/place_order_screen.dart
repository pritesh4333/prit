import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/ui/depth_view.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/ui/fundamentals_view.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/ui/futures_view.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/ui/news_view.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/order_details_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/quote_single_symbol_model.dart';

import 'package:greek_ibt_app/Screens/Place%20Order/ui/option_chain_view.dart';
import 'package:greek_ibt_app/Screens/chart_new/ui/chart_screen_new.dart';
import 'package:greek_ibt_app/Screens/Portfolio/ui/order_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class PlaceOrderScreen extends StatefulWidget {
  final int? orderToken;
  final OrderAction? orderAction;
  final OrderMode? orderMode;
  final OrderDetailsModel? obj;

  const PlaceOrderScreen({
    Key? key,
    this.orderToken,
    this.orderAction,
    this.orderMode,
    this.obj,
  }) : super(key: key);

  @override
  _PlaceOrderScreenState createState() => _PlaceOrderScreenState();
}

class _PlaceOrderScreenState extends State<PlaceOrderScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  PlaceOrderBloc? _placeOrderBloc;
  TabController? tabController;

  late bool isSwitched;
  late bool nseClick;
  late bool bseClick;
  var textValue = 'NSE';
  bool exchangeVisiblity = true;
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    switch (state) {
      case AppLifecycleState.resumed:
        _placeOrderBloc?.subscribeMarketPicture();
        break;

      default:
        _placeOrderBloc?.unSubscribeMarketPicture();
        break;
    }
  }

  @override
  void dispose() {
    _placeOrderBloc?.disposeBloc();
    _placeOrderBloc = null;
    tabController?.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    tabController = TabController(initialIndex: 0, vsync: this, length: 7);

    /*  int index = widget.initialTab ?? 0;

    tabController?.animateTo(index);
    _placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink.add(true);
 */
    switch (_placeOrderBloc?.orderMode) {
      case OrderMode.newOrder:
        break;
      case OrderMode.modiftyOrder:
        break;
      case OrderMode.squareoffOrder:
        // getInitialPrice();

        break;
      default:
        break;
    }

    tabController?.addListener(
      () {
        if (tabController != null) {
          var indexChange = tabController!.indexIsChanging;
          if (indexChange) {
            FocusScope.of(context).unfocus();
          }
        }
      },
    );

    SocketIOManager().reconnectStatusObservable?.listen((status) {
      log('----------------------- Place Order Screen - reconnectStatusObservable - ${status.toString()} -----------------------');

      if (status.first) {
        setState(() => _placeOrderBloc?.subscribeMarketPicture());
      }
    });
  }

  void toggleSwitch(bool value) {
    if (widget.orderMode != OrderMode.modiftyOrder) {
      if (isSwitched == false) {
        setState(() {
          isSwitched = true;
          textValue = 'BSE';
        });

        if (_placeOrderBloc?.orderResponseArray.length == 1) {
          _placeOrderBloc?.currentExchangeIndex = 0;
        } else {
          if (_placeOrderBloc?.orderMode == OrderMode.newOrder) {
            setState(() {
              _placeOrderBloc?.currentExchangeIndex = 1;
            });
          }
        }
      } else {
        setState(() {
          isSwitched = false;
          textValue = 'NSE';
        });

        if (_placeOrderBloc?.orderResponseArray.length == 2) {
          if (_placeOrderBloc?.orderMode == OrderMode.newOrder) {
            setState(() {
              _placeOrderBloc?.currentExchangeIndex = 0;
            });
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_placeOrderBloc == null) {
      final arguments = ModalRoute.of(context)?.settings.arguments as List;
      if (arguments.length == 5) {
        _placeOrderBloc ??= PlaceOrderBloc(
          context,
          orderToken: arguments[0] as int,
          orderAction: arguments[1] as OrderAction,
          orderMode: arguments[2] as OrderMode,
          initialTab: arguments[3] as int,
          obj: arguments[4] as OrderDetailsModel,
        );
      } else {
        _placeOrderBloc ??= PlaceOrderBloc(
          context,
          orderToken: arguments[0] as int,
          orderAction: arguments[1] as OrderAction,
          orderMode: arguments[2] as OrderMode,
          initialTab: arguments[3] as int,
        );
      }

      tabController?.animateTo(
          _placeOrderBloc?.initialTab ?? ScriptInfoTab.overview.index);
      _placeOrderBloc?.reloadStateForChangeBuySellSwitch.sink.add(true);

      _placeOrderBloc?.reloadStateForChangeBuySellSwitch.stream.listen((event) {
        if (event) {
          setState(() {});
        }
      });
      if (_placeOrderBloc!.orderToken.toAssetType() == "commodity") {
        exchangeVisiblity = false;
      }
      if (_placeOrderBloc?.orderToken.toExchange().toUpperCase() == "BSE" ||
          _placeOrderBloc?.orderToken.toExchange().toUpperCase() == "BSECURR") {
        nseClick = false;
        bseClick = true;
      } else {
        nseClick = true;
        bseClick = false;
      }
    }

    return FutureBuilder<List<QuoteForSingleSymbolModel?>>(
        future: _placeOrderBloc?.callBuySellAPIS(),
        builder: (futureContext, snapshot) {
          if (snapshot.hasData) {
            if (_placeOrderBloc!.orderToken.toAssetType() == "commodity") {
              exchangeVisiblity = false;
            } else if ((snapshot.data?.length ?? 0) == 1) {
              exchangeVisiblity = false;
            }
            if (snapshot.data?[0]?.symbol == null) {
              _placeOrderBloc?.currentExchangeIndex = 1;
            }
            if (snapshot.data?.length == 1) {
              var exch =
                  snapshot.data?[0]?.token?.toExchange().toUpperCase() ?? '';
              if (exch.contains("BSE")) {
                _placeOrderBloc?.currentExchangeIndex = 0;
              }
            }
            return DefaultTabController(
              length: 7,
              initialIndex: 0,
              child: StreamBuilder<bool>(
                  stream: _placeOrderBloc?.appBarSizeSubject.stream,
                  builder: (context, appBarSnapshot) {
                    return Scaffold(
                      appBar: AppBar(
                        elevation: 1,
                        automaticallyImplyLeading: false,
                        toolbarHeight:
                            (appBarSnapshot.data ?? false) ? 150.0 : 115.0,
                        flexibleSpace: _scriptNameAndLTP(
                          context,
                          snapshot.data?.elementAt(
                                  _placeOrderBloc?.currentExchangeIndex ?? 0) ??
                              QuoteForSingleSymbolModel(),
                          (appBarSnapshot.data ?? false),
                        ),
                      ),
                      body: _tabSection(context),
                    );
                  }),
            );
          }

          return Scaffold(
            appBar: AppBar(
              elevation: 0,
              leading: IconButton(
                onPressed: () {
                  _placeOrderBloc?.unSubscribeMarketPicture();
                  GreekNavigator.pop(
                    context: futureContext,
                    popArguments: PopAction.rebuildWidget,
                  );
                },
                icon: const Icon(
                  Icons.arrow_back_ios_rounded,
                ),
              ),
            ),
            body: SizedBox(
              height: MediaQuery.of(context).size.height / 2,
              child: Center(
                child: Text(
                  "Fetching Details",
                  textAlign: TextAlign.center,
                  style: GreekTextStyle.heading18,
                ),
              ),
            ),
          );
        });
  }

  Widget _scriptNameAndLTP(BuildContext scripContext,
      QuoteForSingleSymbolModel obj, bool isshowbuysell) {
    final topPadding = MediaQuery.of(scripContext).padding.top;
    return Container(
      //Colors.blue.shade800,
      color: const Color(0xFFFFFFFF),
      padding: EdgeInsets.only(
        top: topPadding,
        left: 8.0,
        right: 8.0,
      ),
      child: Column(
        //mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(height: 5.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  IconButton(
                    padding: const EdgeInsets.only(top: 2),
                    constraints: const BoxConstraints(),
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                    color: ConstantColors.black,
                    onPressed: () => GreekNavigator.pop(context: context),
                  ),
                ],
              ),
              Flexible(
                fit: FlexFit.loose,
                child: Container(
                  height: 65.0,
                  padding: const EdgeInsets.only(left: 2.0, right: 0.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.only(left: 2.0),
                            child: Text(
                              obj.symbol ?? '',
                              style: GreekTextStyle.orderExchangeColor,
                            ),
                          ),
                          Visibility(
                            visible: exchangeVisiblity,
                            child: Container(
                              height: 30,
                              width: 40,
                              margin: const EdgeInsets.only(left: 8, top: 5),
                              decoration: BoxDecoration(
                                color: nseClick
                                    ? const Color(0xFF127FBA)
                                    : ConstantColors.white,
                                borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(5),
                                    bottomLeft: Radius.circular(5)),
                                border: Border.all(
                                    color: const Color(0xFF127FBA), width: 0.5),
                              ),
                              child: TextButton(
                                onPressed: () {
                                  if (widget.orderMode !=
                                      OrderMode.modiftyOrder) {
                                    if (_placeOrderBloc
                                            ?.orderResponseArray.length ==
                                        2) {
                                      if (_placeOrderBloc?.orderMode ==
                                          OrderMode.newOrder) {
                                        setState(() {
                                          _placeOrderBloc
                                              ?.currentExchangeIndex = 0;
                                          nseClick = true;
                                          bseClick = false;
                                        });
                                      }
                                    }
                                  }
                                },
                                child: Text(
                                  "NSE",
                                  style: nseClick
                                      ? GreekTextStyle
                                          .nse_button_click_textstyle
                                      : GreekTextStyle.nse_button_textstyle,
                                ),
                              ),
                            ),
                          ),
                          Visibility(
                            visible: exchangeVisiblity,
                            child: Container(
                              height: 30,
                              width: 40,
                              margin: const EdgeInsets.only(top: 5),
                              decoration: BoxDecoration(
                                color: bseClick
                                    ? const Color(0xFF127FBA)
                                    : ConstantColors.white,
                                borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(5),
                                    bottomRight: Radius.circular(5)),
                                border: Border.all(
                                    color: const Color(0xFF127FBA), width: 0.5),
                              ),
                              child: TextButton(
                                onPressed: () {
                                  if (widget.orderMode !=
                                      OrderMode.modiftyOrder) {
                                    if (_placeOrderBloc
                                            ?.orderResponseArray.length ==
                                        1) {
                                      _placeOrderBloc?.currentExchangeIndex = 0;
                                    } else {
                                      if (_placeOrderBloc?.orderMode ==
                                          OrderMode.newOrder) {
                                        setState(() {
                                          _placeOrderBloc
                                              ?.currentExchangeIndex = 1;
                                          bseClick = true;
                                          nseClick = false;
                                        });
                                      }
                                    }
                                  }
                                },
                                child: Text(
                                  "BSE",
                                  style: bseClick
                                      ? GreekTextStyle
                                          .bse_button_click_textstyle
                                      : GreekTextStyle.bse_button_textstyle,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30,
                        child: Padding(
                            padding: const EdgeInsets.only(top: 2, left: 3),
                            child: Text(
                              int.parse(obj.token.toString()).toAssetType() ==
                                      "fno"
                                  ? obj.description ?? ''
                                  : obj.scripname ?? '',
                              style: GreekTextStyle.watchlistSubText,
                            )),
                      ),
                    ],
                  ),

                  /* Marquee(
                    text:
                        '${obj.description ?? ''} - ${obj.instrument?.toUpperCase() ?? ''}',
                    style: GreekTextStyle.PlaceOrderheading17,
                    blankSpace: 20.0,
                    velocity: 30.0,
                    pauseAfterRound: const Duration(seconds: 3),
                  ), */
                ),
              ),

              /* _drawExchangeDropDownView(),
              Container(
                height: 40,
                width: 110.0,
                padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFFFF),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Flexible(
                      fit: FlexFit.loose,
                      child: MaterialButton(
                          minWidth: 0.0,
                          padding: EdgeInsets.zero,
                          highlightColor: Colors.transparent,
                          splashColor: Colors.transparent,
                          child: Text(
                            "BUY",
                            style: (_placeOrderBloc?.orderAction == OrderAction.buy) ? GreekTextStyle.placeOrderBuyButtonSelectedTextStyle : GreekTextStyle.placeOrderActionButtonUnselectedTextStyle,
                          ),
                          onPressed: () {
                            if (_placeOrderBloc?.orderMode == OrderMode.newOrder) {
                              setState(() {
                                _placeOrderBloc?.orderAction = OrderAction.buy;
                              });
                            } else if (_placeOrderBloc?.orderMode == OrderMode.modiftyOrder) {
                              // widget.obj?.orderAction = OrderAction.buy;
                            }
                          }),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                      child: VerticalDivider(
                        color: ConstantColors.dividerColor,
                        thickness: 1.5,
                      ),
                    ),
                    Flexible(
                      fit: FlexFit.loose,
                      child: MaterialButton(
                        minWidth: 0.0,
                        padding: EdgeInsets.zero,
                        highlightColor: Colors.transparent,
                        splashColor: Colors.transparent,
                        child: Text(
                          "SELL",
                          style: (_placeOrderBloc?.orderAction == OrderAction.sell) ? GreekTextStyle.placeOrderSellButtonSelectedTextStyle : GreekTextStyle.placeOrderActionButtonUnselectedTextStyle,
                        ),
                        onPressed: (_placeOrderBloc?.orderMode != OrderMode.newOrder) ? null : () => setState(() => _placeOrderBloc?.orderAction = OrderAction.sell),
                      ),
                    ),
                  ],
                ),
              ),

 */

              Container(
                alignment: Alignment.centerLeft,
                // margin: const EdgeInsets.only(left: 33.0),
                child: StreamBuilder<QuoteForSingleSymbolModel?>(
                    stream: _placeOrderBloc?.marketPictureObserver,
                    builder: (ltpContext, snapshot) {
                      if (snapshot.hasData) {
                        if (snapshot.data?.symbol != null) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text.rich(
                                TextSpan(
                                  text:
                                      '${snapshot.data?.token?.toAssetType() == "currency" ? snapshot.data?.last?.toStringAsFixed(4) ?? 0 : snapshot.data?.last?.toStringAsFixed(2) ?? 0}',
                                  style: GreekTextStyle.heading11,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 0.0),
                                child: Text.rich(
                                  TextSpan(
                                    text:
                                        ' ${snapshot.data?.token?.toAssetType() == "currency" ? snapshot.data?.change?.toStringAsFixed(4) ?? 0 : snapshot.data?.change?.toStringAsFixed(2) ?? 0}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                                    style: ((snapshot.data?.change ?? 0) >= 0)
                                        ? GreekTextStyle
                                            .PlaceOrderheadingLTPGreen
                                        : GreekTextStyle
                                            .PlaceOrderheadingLTPRed,
                                  ),
                                ),
                              )
                            ],
                          );
                        } else {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text.rich(
                                TextSpan(
                                  text:
                                      '${obj.last?.toStringAsFixed(2) ?? 0.0}  ',
                                  style: GreekTextStyle.heading11,
                                ),
                              ),
                              Text.rich(
                                TextSpan(
                                  text:
                                      ' ${obj.change?.toStringAsFixed(2) ?? 0.0}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                                  style: ((obj.change ?? 0) >= 0)
                                      ? GreekTextStyle.PlaceOrderheadingLTPGreen
                                      : GreekTextStyle.PlaceOrderheadingLTPRed,
                                ),
                              )
                            ],
                          );
                        }
                      } else {
                        return Text.rich(
                          TextSpan(
                            text: '${obj.last?.toStringAsFixed(2) ?? 0.0}  ',
                            style: GreekTextStyle.heading11,
                            children: [
                              TextSpan(
                                text:
                                    ' ${obj.change?.toStringAsFixed(2) ?? 0.0}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                                style: ((obj.change ?? 0) >= 0)
                                    ? GreekTextStyle.PlaceOrderheadingLTPGreen
                                    : GreekTextStyle.PlaceOrderheadingLTPRed,
                              ),
                            ],
                          ),
                        );
                      }
                    }),
              ),
              /*   Container(
                child: IconButton(
                  onPressed: () {
                    GreekNavigator.pop(context: context);
                  },
                  icon: const Icon(Icons.close),
                  iconSize: 30.0,
                  color: ConstantColors.black,
                ),
              ) */
            ],
          ),

          /*   Container(
            alignment: Alignment.centerLeft,
            margin: const EdgeInsets.only(left: 33.0),
            child: StreamBuilder<QuoteForSingleSymbolModel?>(
                stream: _placeOrderBloc?.marketPictureObserver,
                builder: (ltpContext, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data?.symbol != null) {
                      return Text.rich(
                        TextSpan(
                          text:
                              '${snapshot.data?.last?.toStringAsFixed(2) ?? 0.0}  ',
                          style: GreekTextStyle.unselected_portfolio_tab_label_blue,
                          children: [
                            TextSpan(
                              text:
                                  ' ${snapshot.data?.change?.toStringAsFixed(2) ?? 0.0}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                              style: ((snapshot.data?.change ?? 0) >= 0)
                                  ? GreekTextStyle.PlaceOrderheadingLTPGreen
                                  : GreekTextStyle.PlaceOrderheadingLTPRed,
                            ),
                          ],
                        ),
                      );
                    } else {
                      return Text.rich(
                        TextSpan(
                          text: '${obj.last?.toStringAsFixed(2) ?? 0.0}  ',
                          style: GreekTextStyle.heading11,
                          children: [
                            TextSpan(
                              text:
                                  ' ${obj.change?.toStringAsFixed(2) ?? 0.0}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                              style: ((obj.change ?? 0) >= 0)
                                  ? GreekTextStyle.PlaceOrderheadingLTPGreen
                                  : GreekTextStyle.PlaceOrderheadingLTPRed,
                            ),
                          ],
                        ),
                      );
                    }
                  } else {
                    return Text.rich(
                      TextSpan(
                        text: '${obj.last?.toStringAsFixed(2) ?? 0.0}  ',
                        style: GreekTextStyle.heading11,
                        children: [
                          TextSpan(
                            text:
                                ' ${obj.change?.toStringAsFixed(2) ?? 0.0}(${snapshot.data?.pChange?.toStringAsFixed(2) ?? 0.0}%)',
                            style: ((obj.change ?? 0) >= 0)
                                ? GreekTextStyle.PlaceOrderheadingLTPGreen
                                : GreekTextStyle.PlaceOrderheadingLTPRed,
                          ),
                        ],
                      ),
                    );
                  }
                }),
          ),
 */

          //
          SizedBox(
            height: isshowbuysell ? 5.0 : 0,
          ),
          SizedBox(
            height: isshowbuysell ? 30.0 : 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //_drawExchangeDropDownView(),
                SizedBox(
                  height: 40,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      /* Flexible(
                        fit: FlexFit.loose,
                        child: MaterialButton(
                            minWidth: 0.0,
                            padding: EdgeInsets.zero,
                            highlightColor: Colors.transparent,
                            splashColor: Colors.transparent,
                            child: Text(
                              "BUY",
                              style: (_placeOrderBloc?.orderAction ==
                                      OrderAction.buy)
                                  ? GreekTextStyle
                                      .placeOrderBuyButtonSelectedTextStyle
                                  : GreekTextStyle
                                      .placeOrderActionButtonUnselectedTextStyle,
                            ),
                            onPressed: () {
                              if (_placeOrderBloc?.orderMode ==
                                  OrderMode.newOrder) {
                                setState(() {
                                  _placeOrderBloc?.orderAction = OrderAction.buy;
                                });
                              } else if (_placeOrderBloc?.orderMode ==
                                  OrderMode.modiftyOrder) {
                                // widget.obj?.orderAction = OrderAction.buy;
                              }
                            }),
                      ), */

                      Container(
                        decoration: BoxDecoration(
                          color: _placeOrderBloc?.orderAction == OrderAction.buy
                              ? ConstantColors.buyColor
                              : ConstantColors.white,
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(5),
                              bottomLeft: Radius.circular(5)),
                          border: Border.all(color: Colors.grey, width: 0.2),
                        ),
                        child: TextButton(
                          onPressed: () {
                            if (_placeOrderBloc?.orderMode ==
                                OrderMode.newOrder) {
                              if (tabController?.index == 0) {
                                setState(() {
                                  _placeOrderBloc?.orderAction =
                                      OrderAction.buy;
                                  _placeOrderBloc?.refreshPrice.sink.add(true);
                                });
                              }
                            } else if (_placeOrderBloc?.orderMode ==
                                OrderMode.modiftyOrder) {
                              // widget.obj?.orderAction = OrderAction.buy;
                            }
                          },
                          child: Text(
                            "BUY",
                            style:
                                _placeOrderBloc?.orderAction == OrderAction.buy
                                    ? GreekTextStyle.order_tab_click_textstyle
                                    : GreekTextStyle.order_tab_textstyle,
                          ),
                        ),
                      ),
                      /* const Padding(
                        padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                        child: VerticalDivider(
                          color: ConstantColors.dividerColor,
                          thickness: 1.5,
                        ),
                      ), */
                      /* Flexible(
                        fit: FlexFit.loose,
                        child: MaterialButton(
                          minWidth: 0.0,
                          padding: EdgeInsets.zero,
                          highlightColor: Colors.transparent,
                          splashColor: Colors.transparent,
                          child: Text(
                            "SELL",
                            style: (_placeOrderBloc?.orderAction ==
                                    OrderAction.sell)
                                ? GreekTextStyle
                                    .placeOrderSellButtonSelectedTextStyle
                                : GreekTextStyle
                                    .placeOrderActionButtonUnselectedTextStyle,
                          ),
                          onPressed:
                              (_placeOrderBloc?.orderMode != OrderMode.newOrder)
                                  ? null
                                  : () => setState(() => _placeOrderBloc
                                      ?.orderAction = OrderAction.sell),
                        ),
                      ), */
                      Container(
                        decoration: BoxDecoration(
                          color:
                              _placeOrderBloc?.orderAction == OrderAction.sell
                                  ? ConstantColors.sellColor
                                  : ConstantColors.white,
                          borderRadius: const BorderRadius.only(
                              topRight: Radius.circular(5),
                              bottomRight: Radius.circular(5)),
                          border: Border.all(color: Colors.grey, width: 0.2),
                        ),
                        child: TextButton(
                          onPressed: () {
                            if (_placeOrderBloc?.orderMode ==
                                OrderMode.newOrder) {
                              if (tabController?.index == 0) {
                                setState(() {
                                  _placeOrderBloc?.orderAction =
                                      OrderAction.sell;
                                  _placeOrderBloc?.refreshPrice.sink.add(true);
                                });
                              }
                            }
                          },
                          child: Text(
                            "SELL",
                            style:
                                _placeOrderBloc?.orderAction == OrderAction.sell
                                    ? GreekTextStyle
                                        .order_sellbutton_click_textstyle
                                    : GreekTextStyle.order_sellbutton_textstyle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 35,
            color: const Color(0xFFF5F5F5),
            margin: const EdgeInsets.only(top: 10.0, bottom: 0.0),
            // padding: const EdgeInsets.only(top: 10, bottom: 10),
            child: TabBar(
              controller: tabController,
              labelStyle: GreekTextStyle.ordertabheading,
              labelColor: const Color(0xFF000000),
              unselectedLabelStyle: GreekTextStyle.ordertabheading_2,
              unselectedLabelColor: const Color(
                  0xFF000000), //unselectedLabelColor: const Color(0xFFC1D6E2),
              isScrollable: true,
              indicator: BoxDecoration(
                // color: const Color(0xFFFFFFFF),
                borderRadius: BorderRadius.circular(0.0),
              ),
              tabs: const [
                Text('Order'),
                Text('Overview'),
                Text('Chart'),
                Text('Option Chain'),
                Text('Futures'),
                Text('Fundamentals'),
                Text('News'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabSection(BuildContext context) {
    var token = "${_placeOrderBloc?.orderResponseArray[0]?.token}";
    return TabBarView(
      controller: tabController,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        OrderScreen(placeOrderBloc: _placeOrderBloc),
        OverviewDepthScreen(
            placeOrderBloc: _placeOrderBloc, controller: tabController),
        ChartScreenNew(
            placeOrderBloc: _placeOrderBloc,
            controller: tabController,
            token: token),
        OptionchainScreen(
            placeOrderBloc: _placeOrderBloc, controller: tabController),
        FutureScreen(
            placeOrderBloc: _placeOrderBloc!, controller: tabController!),
        FundamentalsScreen(
            placeOrderBloc: _placeOrderBloc, controller: tabController),
        NewsScreen(placeOrderBloc: _placeOrderBloc, controller: tabController),
        /*Container(
          color: Colors.blue,
          child: const Center(
            child: Text(
              'OptionchainClass',
              style: TextStyle(color: Colors.white, fontSize: 30),
            ),
          ),
        ),*/
      ],
    );
  }

  // Widget _drawExchangeDropDownView() {
  //   if (_placeOrderBloc?.orderResponseArray[0]?.symbol == null) {
  //     _placeOrderBloc?.orderResponseArray.removeAt(0);
  //   }
  //   final dropDownOptions = _placeOrderBloc?.orderResponseArray
  //           .map(
  //             (e) => (e?.token?.toExchange() ?? ''),
  //           )
  //           .toList() ??
  //       [];
  //   dropDownOptions.removeWhere((element) => (element.isEmpty));
  //   if (_placeOrderBloc?.orderResponseArray.length == 1) {
  //     var exch = _placeOrderBloc?.orderResponseArray[0]?.token?.toExchange().toUpperCase() ?? '';
  //     if (exch.contains("BSE")) {
  //       _placeOrderBloc?.currentExchangeIndex = 0;
  //     }
  //   }
  //   String exchangeValue = dropDownOptions.elementAt(_placeOrderBloc?.currentExchangeIndex ?? 0).toUpperCase();
  //   /*    var bseexchange = "BSE";
  //   var nseexchange = "NSE";
  //   if (exchangeValue.contains('BSE')) {
  //     bseexchange = exchangeValue;
  //   }

  //   if (exchangeValue.contains('NSE')) {
  //     isSwitched = false;
  //   } else{
  //      isSwitched = true;
  //   }*/
  //   // setState(() {
  //   (exchangeValue.contains('BSE')) ? isSwitched = true : isSwitched = false;
  //   // });

  //   // return Visibility(
  //   //   visible: exchangeVisiblity,
  //   //   child: Row(
  //   //     children: [
  //   //       Text(
  //   //         'NSE',
  //   //         /*  style: isSwitched == true
  //   //             ? TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
  //   //             : TextStyle(fontSize: 20), */
  //   //       ),
  //   //       Switch(
  //   //         onChanged: toggleSwitch,
  //   //         value: isSwitched,
  //   //         activeColor: const Color(0xff3A3A3A),
  //   //         activeTrackColor: const Color(0xffD6D6D6),
  //   //         inactiveThumbColor: const Color(0xff3A3A3A),
  //   //         inactiveTrackColor: const Color(0xffD6D6D6),
  //   //       ),
  //   //       Text(
  //   //         'BSE',
  //   //         /*  style: isSwitched == false
  //   //             ? TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
  //   //             : TextStyle(fontSize: 20), */
  //   //       ),
  //   //     ],
  //   //   ),
  //   // );
  //   /*  Container(
  //     height: 30,
  //     width: 80.0,
  //     padding: const EdgeInsets.only(left: 5.0, right: 5.0),
  //     margin: const EdgeInsets.only(right: 15.0),
  //     decoration: BoxDecoration(
  //       color: Color(0xFFFFFFF),
  //       borderRadius: BorderRadius.circular(20.0),
  //     ),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //       crossAxisAlignment: CrossAxisAlignment.stretch,
  //       children: [
  //         Flexible(
  //           fit: FlexFit.loose,
  //           child: MaterialButton(
  //               minWidth: 0.0,
  //               padding: EdgeInsets.zero,
  //               highlightColor: Colors.transparent,
  //               splashColor: Colors.transparent,
  //               child: Text(
  //                 "NSE",
  //                 // style: GreekTextStyle.heading7,
  //                 style: (exchangeValue.contains('NSE'))
  //                     ? GreekTextStyle.placeOrderExchangeSelected
  //                     : GreekTextStyle.placeOrderExchangeUnselected,
  //               ),
  //               onPressed: () {
  //                 if (_placeOrderBloc?.orderResponseArray.length == 2) {
  //                   if (_placeOrderBloc?.orderMode == OrderMode.newOrder) {
  //                     setState(() {
  //                       _placeOrderBloc?.currentExchangeIndex = 0;
  //                     });
  //                   }
  //                 }
  //               }),
  //         ),
  //         const Padding(
  //           padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
  //           child: VerticalDivider(
  //             color: ConstantColors.dividerColor,
  //             thickness: 1.5,
  //           ),
  //         ),
  //         Flexible(
  //           fit: FlexFit.loose,
  //           child: MaterialButton(
  //               minWidth: 0.0,
  //               padding: EdgeInsets.zero,
  //               highlightColor: Colors.transparent,
  //               splashColor: Colors.transparent,
  //               child: Text(
  //                 "BSE",
  //                 // style: GreekTextStyle.heading7,
  //                 style: (exchangeValue.contains('BSE'))
  //                     ? GreekTextStyle.placeOrderExchangeSelected
  //                     : GreekTextStyle.placeOrderExchangeUnselected,
  //               ),
  //               onPressed: () {
  //                 if (_placeOrderBloc?.orderResponseArray.length == 1) {
  //                   _placeOrderBloc?.currentExchangeIndex = 0;
  //                 } else {
  //                   if (_placeOrderBloc?.orderMode == OrderMode.newOrder) {
  //                     setState(() {
  //                       _placeOrderBloc?.currentExchangeIndex = 1;
  //                     });
  //                   }
  //                 }
  //               }),
  //         ),
  //       ],
  //     ),
  //   );
  // */
  // }
}
