// ignore_for_file: non_constant_identifier_names

import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Extension_Enum/marketStatus_flag.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/quote_single_symbol_model.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/place_order_bloc.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/order_details_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:intl/intl.dart';

class OrderScreen extends StatefulWidget {
  final PlaceOrderBloc? placeOrderBloc;

  const OrderScreen({Key? key, required this.placeOrderBloc}) : super(key: key);

  @override
  _OrderScreenClassState createState() => _OrderScreenClassState();
}

class _OrderScreenClassState extends State<OrderScreen> {
  bool isSetAMO = false;
  bool isPriceEnable = true;
  bool gtdVisible = false;
  bool quantityAutoFocus = false;
  bool valid_status = false;
  bool allowed_market = false;
  bool isPostOpen_status = false;
  bool isPreOpen_status = false;

  final quantityController = TextEditingController();
  final priceController = TextEditingController();
  final discQtyController = TextEditingController();
  final slTriggerController = TextEditingController();
  final setTargetController = TextEditingController();
  final setSLPriceController = TextEditingController();
  OrderDetailsModel orderDetails = OrderDetailsModel();

  String gtdSelectedDate = '';

  bool discQtyEnable = true;

  List<String> validityDropdownValues = ['Day', 'IOC', 'GTD'];
  String validitySelectedValue = 'Day';

  DateTime selectedDate = DateTime(
      DateTime.now().year, DateTime.now().month, DateTime.now().day + 1);

  List<String> productTypeDropdownValues = ['Delivery', 'Intraday', 'MTF'];

  List<String> orderTypeValues = ['Limit', 'Market', 'SL', 'SLM'];

  late DateTime dateConverted;
  late DateTime lastDateValue;

  int _productIndex = 0;
  int _orderTypeIndex = 0;

  FocusNode? quantityFocusNode;
  FocusNode? slTriggerFocusNode;
  FocusNode? pricefocusnode;
  FocusNode? slfocusnode;
  FocusNode? disqtyfocusnode;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    widget.placeOrderBloc!.appBarSizeSubject.sink.add(true);
    quantityFocusNode = FocusNode();
    slTriggerFocusNode = FocusNode();

    _productIndex = 0;
    _orderTypeIndex = 0;

    discQtyController.text = '';
    slTriggerController.text = '';
    setTargetController.text = '';
    setSLPriceController.text = '';

    switch (widget.placeOrderBloc!.orderMode) {
      case OrderMode.newOrder:
        if (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType() ==
            "commodity") {
          quantityController.text = "1";
        } else {
          quantityController.text = widget
              .placeOrderBloc!
              .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]!
              .lot!
              .toString();
        }

        getInitialPrice();

        isSetAMO = false;

        break;
      case OrderMode.modiftyOrder:
        final modifyProduct = GreekBase().getProductNameFromProductToken(
            int.parse(widget.placeOrderBloc!.obj!.productType!));

        for (var item in productTypeDropdownValues) {
          if (item.toLowerCase().compareTo(modifyProduct.toLowerCase()) == 0) {
            _productIndex = productTypeDropdownValues.indexOf(item);
            break;
          }
        }

        var modifyOrderType = GreekBase().getOrderNameFromOrderToken(
            int.parse(widget.placeOrderBloc?.obj?.order_type ?? ''));
        for (var item in orderTypeValues) {
          if ((item.toLowerCase().compareTo('sl') == 0) &&
              (modifyOrderType.toLowerCase().compareTo('stop loss') == 0)) {
            _orderTypeIndex = orderTypeValues.indexOf('SL');
            if (validityDropdownValues.contains("IOC")) {
              validityDropdownValues.remove("IOC");
            }
            break;
          } else if ((item.toLowerCase().compareTo('slm') == 0) &&
              (modifyOrderType.toLowerCase().compareTo('stoploss market') ==
                  0)) {
            if (validityDropdownValues.contains("IOC")) {
              validityDropdownValues.remove("IOC");
            }
            _orderTypeIndex = orderTypeValues.indexOf('SLM');

            isPriceEnable = false;
            break;
          } else if (item
                  .toLowerCase()
                  .compareTo(modifyOrderType.toLowerCase()) ==
              0) {
            _orderTypeIndex = orderTypeValues.indexOf(item);
            break;
          }
        }

        if (int.parse(widget.placeOrderBloc?.obj?.validity.toString() ?? '') !=
                0 &&
            int.parse(widget.placeOrderBloc?.obj?.validity.toString() ?? '') !=
                1) {
          selectedDate = DateTime.fromMillisecondsSinceEpoch(int.parse(
                  widget.placeOrderBloc?.obj?.gtdExpiry.toString() ?? '') *
              1000);
          gtdVisible = true;
          validitySelectedValue = validityDropdownValues
              .elementAt(validityDropdownValues.indexOf("GTD"));
        } else {
          if (_orderTypeIndex == 2 || _orderTypeIndex == 3) {
            if (validityDropdownValues.contains("IOC")) {
              validityDropdownValues.removeAt(1);
            }
          }
          validitySelectedValue = validityDropdownValues.elementAt(
              int.parse(widget.placeOrderBloc?.obj?.validity.toString() ?? ''));
        }
        if (widget.placeOrderBloc?.obj?.exchange.toString().toLowerCase() ==
            "mcx") {
          quantityController.text = widget.placeOrderBloc?.obj?.lot ?? '';
        } else {
          quantityController.text = widget.placeOrderBloc?.obj?.qty ?? '';
        }

        if ((int.parse(widget.placeOrderBloc?.obj?.gtoken ?? "0")
                .toAssetType()
                .toString() ==
            'currency')) {
          priceController.text =
              double.parse(widget.placeOrderBloc?.obj?.price ?? '')
                  .toStringAsFixed(4);
        } else {
          priceController.text =
              double.parse(widget.placeOrderBloc?.obj?.price ?? '')
                  .toStringAsFixed(2);
        }

        if (widget.placeOrderBloc?.obj?.exchange.toString().toLowerCase() ==
                "mcx" ||
            widget.placeOrderBloc?.obj?.exchange.toString().toLowerCase() ==
                "ncdex") {
          discQtyController.text = widget.placeOrderBloc?.obj?.lot ?? '';
        } else {
          discQtyController.text = widget.placeOrderBloc?.obj?.qty ?? '';
        }

        slTriggerController.text =
            widget.placeOrderBloc?.obj?.trigger_price ?? '';

        if (widget.placeOrderBloc?.obj?.OrderStatuse == "AMO Unconfirmed") {
          isSetAMO = true;
        }

        break;
      case OrderMode.squareoffOrder:
        final modifyProduct = GreekBase().getProductNameFromProductToken(
            int.parse(widget.placeOrderBloc!.obj!.productType!));
        for (var item in productTypeDropdownValues) {
          if (item.toLowerCase().compareTo(modifyProduct.toLowerCase()) == 0) {
            _productIndex = productTypeDropdownValues.indexOf(item);
            break;
          }
        }
        quantityController.text = widget.placeOrderBloc?.obj?.qty ?? '';
        discQtyEnable = false;
        getInitialPrice();
        break;
      default:
        break;
    }
    validateMarketStatus();
    if (isPreOpen_status == true && !valid_status) {
      discQtyEnable = false;
    } else if (isPreOpen_status == false && valid_status) {
      discQtyEnable = false;
    } else if (isPreOpen_status == true && valid_status) {
      discQtyEnable = false;
    }
    if (MarketStatusFlag.eq_post_close) {
      _orderTypeIndex = 1;
    }
  }

  void getInitialPrice() {
    isPriceEnable = true;
    var price = widget.placeOrderBloc!.orderResponseArray
        .elementAt(widget.placeOrderBloc!.currentExchangeIndex)!
        .last!;
    final ask = widget.placeOrderBloc!.orderResponseArray
        .elementAt(widget.placeOrderBloc!.currentExchangeIndex)!
        .ask!;
    final bid = widget.placeOrderBloc!.orderResponseArray
        .elementAt(widget.placeOrderBloc!.currentExchangeIndex)!
        .bid!;

    int decimal = 2;
    (widget
                .placeOrderBloc
                ?.orderResponseArray[
                    widget.placeOrderBloc?.currentExchangeIndex ?? 0]
                ?.token
                ?.toAssetType()
                .toString() ==
            'currency')
        ? decimal = 4
        : decimal = 2;

    switch (widget.placeOrderBloc?.orderAction) {
      case OrderAction.buy:
        priceController.text = (ask > 0)
            ? ask.toStringAsFixed(decimal)
            : (price > 0)
                ? price.toStringAsFixed(decimal)
                : '';
        break;
      case OrderAction.sell:
        priceController.text = (bid > 0)
            ? bid.toStringAsFixed(decimal)
            : (price > 0)
                ? price.toStringAsFixed(decimal)
                : '';
        break;
      default:
        priceController.text = '';
        break;
    }
  }

  @override
  void dispose() {
    quantityFocusNode?.dispose();
    slTriggerFocusNode?.dispose();

    super.dispose();
  }

  bool quantityselection = false;
  bool priceselection = false;
  bool slselection = false;
  bool disselection = false;

  setSelectionToTextController(TextEditingController textEditingController) {
    textEditingController.selection = TextSelection(
      baseOffset: quantityselection ? 0 : textEditingController.text.length,
      extentOffset: textEditingController.text.length,
    );
  }

  setSelectionTpriceTextController(
      TextEditingController textEditingController) {
    textEditingController.selection = TextSelection(
      baseOffset: priceselection ? 0 : textEditingController.text.length,
      extentOffset: textEditingController.text.length,
    );
  }

  setSelectionTSLTextController(TextEditingController textEditingController) {
    textEditingController.selection = TextSelection(
      baseOffset: slselection ? 0 : textEditingController.text.length,
      extentOffset: textEditingController.text.length,
    );
  }

  setSelectionTdisTextController(TextEditingController textEditingController) {
    textEditingController.selection = TextSelection(
      baseOffset: disselection ? 0 : textEditingController.text.length,
      extentOffset: textEditingController.text.length,
    );
  }

  @override
  Widget build(BuildContext context) {
    // setSelectionToTextController(quantityController);
    // setSelectionToTextController(priceController);
    // setSelectionToTextController(discQtyController);
    // setSelectionToTextController(slTriggerController);

    quantityFocusNode?.addListener(() {
      quantityFocusNode!.hasFocus
          ? quantityselection = false
          : quantityselection = true;
    });

    pricefocusnode?.addListener(() {
      pricefocusnode!.hasFocus ? priceselection = true : priceselection = false;
    });

    slfocusnode?.addListener(() {
      slfocusnode!.hasFocus ? slselection = true : slselection = false;
    });

    disqtyfocusnode?.addListener(() {
      disqtyfocusnode!.hasFocus ? disselection = true : disselection = false;
    });

    widget.placeOrderBloc?.refreshPrice.stream.listen((event) {
      if (event) {
        getInitialPrice();
      }
    });
    return Scaffold(
      appBar: null,
      key: _scaffoldKey,
      body: Container(
        color: ConstantColors.white,
        child: Column(
          children: [
            Flexible(
              fit: FlexFit.loose,
              child: ListView(
                children: [
                  _productAndOrderView(),
                  _quantityAndPriceTextfiledView(),
                  _orderType(),
                  _brackAndCoverTextfieldView(),
                  _setAMO(),
                  _gtdTextField(context),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: _submitButton(),
            ),
          ],
        ),
      ),
    );
  }

  _productAndOrderView() => SizedBox(
        height: 60.0,
        child: Column(
          children: [
            _productType(),
          ],
        ),
      );

  _productType() => Container(
        height: 60,
        padding: const EdgeInsets.all(10.0),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: productTypeDropdownValues.length,
          itemBuilder: (BuildContext context, int index) {
            return Container(
              alignment: Alignment.centerLeft,
              width: 100,
              child: TextButton(
                onPressed: () {
                  _closeKeyboard();
                  productBtnClick(index);
                },
                child: Text(
                  productTypeDropdownValues[index],
                  style: _productIndex == index
                      ? GreekTextStyle.OrderViewProductSelectedTxt
                      : GreekTextStyle.OrderViewProductUnselectedTxt,
                ),
              ),
            );
          },
        ),
      );

  _orderType() => Container(
        height: 60,
        padding: const EdgeInsets.all(10.0),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: orderTypeValues.length,
          itemBuilder: (BuildContext context, int index) {
            return Container(
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.only(left: 0.0, bottom: 0.0),
              width: 100,
              child: TextButton(
                onPressed: () {
                  _closeKeyboard();
                  orderTypeBtnClick(index);
                },
                child: Text(
                  orderTypeValues[index],
                  style: _orderTypeIndex == index
                      ? GreekTextStyle.OrderViewProductSelectedTxt
                      : GreekTextStyle.OrderViewProductUnselectedTxt,
                ),
              ),
            );
          },
        ),
      );

  _quantityAndPriceTextfiledView() => Container(
        height: 200,
        margin: const EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: const [
            BoxShadow(
              color: Colors.grey,
              blurRadius: 1.0,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.only(
              left: 8.0, right: 8.0, top: 15, bottom: 15.0),
          child: _quantityPrice(),
        ),
      );

  _brackAndCoverTextfieldView() {
    return Container(
      height: 90,
      color: Colors.white,
      padding: const EdgeInsets.only(left: 20.0, right: 25.0, bottom: 0.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  children: [
                    TextField(
                      controller: setTargetController,
                      maxLength: 12,
                      style: GreekTextStyle.OrderViewProductUnselectedTxt,
                      enabled: (widget.placeOrderBloc!.orderMode !=
                          OrderMode.squareoffOrder),
                      decoration: InputDecoration(
                        isDense: true,
                        labelText: 'Set Target price',
                        labelStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.normal,
                          color: Color(0xFF909090),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: const Color(0x00000029).withOpacity(1),
                              width: 0.5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: const Color(0x00000029).withOpacity(1),
                              width: 0.5),
                        ),
                      ),
                      inputFormatters: [
                        widget.placeOrderBloc!.orderToken.toAssetType() ==
                                "currency"
                            ? FilteringTextInputFormatter.allow(
                                RegExp(r'^\d+\.?\d{0,4}'))
                            : FilteringTextInputFormatter.allow(
                                RegExp(r'^\d+\.?\d{0,2}')),
                      ],
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                        signed: true,
                      ),
                    ),
                    /* Text(
                      '$dprLow - $dprHigh',
                      style: GreekTextStyle.headline1,
                    ),*/
                  ],
                ),
              ),
              const SizedBox(width: 20.0),
              Expanded(
                child: Column(
                  children: [
                    TextField(
                      controller: setSLPriceController,
                      onTap: () {
                        slselection = slselection
                            ? slselection = false
                            : slselection = true;
                        setSelectionTSLTextController(setSLPriceController);
                      },
                      maxLength: 12,
                      style: GreekTextStyle.OrderViewProductUnselectedTxt,
                      enabled: (widget.placeOrderBloc!.orderMode !=
                          OrderMode.squareoffOrder),
                      onChanged: (value) {
                        if (value.isEmpty && _orderTypeIndex == 2) {
                          setState(() {
                            if (validityDropdownValues.contains("IOC")) {
                              validityDropdownValues.removeAt(1);
                              validitySelectedValue = 'Day';
                            }
                          });
                        } else if (value.isNotEmpty && _orderTypeIndex == 2) {
                          setState(() {
                            if (!validityDropdownValues.contains("IOC")) {
                              validityDropdownValues.insert(1, 'IOC');
                            }
                            // validitySelectedValue = 'Day';
                          });
                        }
                      },
                      decoration: InputDecoration(
                        isDense: true,
                        labelText: 'Set Stoploss Price',
                        labelStyle: const TextStyle(
                          fontSize: 18,
                          color: Color(0xFF909090),
                          fontWeight: FontWeight.normal,
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: const Color(0x00000029).withOpacity(1),
                              width: 0.5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: const Color(0x00000029).withOpacity(1),
                              width: 0.5),
                        ),
                      ),
                      inputFormatters: [
                        widget.placeOrderBloc!.orderToken.toAssetType() ==
                                "currency"
                            ? FilteringTextInputFormatter.allow(
                                RegExp(r'^\d+\.?\d{0,4}'))
                            : FilteringTextInputFormatter.allow(
                                RegExp(r'^\d+\.?\d{0,2}')),
                      ],
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                        signed: true,
                      ),
                    ),
                    /* Text(
                      '$dprLow - $dprHigh',
                      style: GreekTextStyle.headline1,
                    ),*/
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  _setAMO() => Container(
        height: 40.0,
        padding: const EdgeInsets.only(left: 15.0, right: 15.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 40,
              width: 100,
              padding: const EdgeInsets.only(left: 10.0),
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.grey,
                  width: 0.5,
                ),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  DropdownButton<String>(
                    value: validitySelectedValue,
                    icon: Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Icon(
                        Icons.calendar_today,
                        color: validitySelectedValue == 'GTD'
                            ? Colors.black
                            : Colors.white,
                        size: 15,
                      ),
                    ),
                    elevation: 24,
                    style: const TextStyle(
                      color: Color(0xFF000000),
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    underline: Container(
                      height: 0.0,
                    ),
                    items: validityDropdownValues.map<DropdownMenuItem<String>>(
                      (String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      },
                    ).toList(),
                    onChanged: (widget.placeOrderBloc!.orderMode !=
                            OrderMode.squareoffOrder)
                        ? (data) {
                            _closeKeyboard();

                            setState(() {
                              validitySelectedValue = data!;
                              if (validitySelectedValue == "IOC") {
                                discQtyEnable = false;
                              } else {
                                if (valid_status || isPreOpen_status) {
                                  discQtyEnable = false;
                                } else {
                                  discQtyEnable = true;
                                }
                              }

                              if (validitySelectedValue == 'GTD') {
                                // selectedDate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 1);

                                gtdVisible = true;
                              } else {
                                gtdVisible = false;
                              }
                            });
                          }
                        : (null),
                  ),
                  const Icon(Icons.arrow_drop_down, color: Colors.black),
                ],
              ),
            ),
            Row(
              children: [
                const Text(
                  "AMO",
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.normal,
                      fontSize: 18),
                ),
                CupertinoSwitch(
                  activeColor: const Color(0xFFF58220),
                  value: isSetAMO,
                  onChanged: (widget.placeOrderBloc!.orderMode !=
                          OrderMode.squareoffOrder)
                      ? (bool value) {
                          _closeKeyboard();

                          if (widget.placeOrderBloc!.orderMode ==
                              OrderMode.newOrder) {
                            amoEnable(value);
                          }
                        }
                      : (null),
                ),
              ],
            ),
          ],
        ),
      );

  _gtdTextField(BuildContext context) => Visibility(
        visible: gtdVisible,
        child: Row(
          children: [
            const SizedBox(
              width: 10.0,
            ),
            Text(
              "${selectedDate.toLocal()}".split(' ')[0],
              style: const TextStyle(color: Colors.black, fontSize: 14),
            ),
            IconButton(
              icon: const Icon(
                Icons.calendar_today,
                size: 15.0,
              ),
              onPressed: () {
                _selectDate(context);
              },
            )
          ],
        ),
      );

  Future<void> _selectDate(BuildContext context) async {
    var expiryy = widget.placeOrderBloc!.orderResponseArray
            .elementAt(widget.placeOrderBloc!.currentExchangeIndex)!
            .expiryDate ??
        '';
    log('expiry == $expiryy');
    dateConverted =
        DateTime.fromMillisecondsSinceEpoch(int.parse(expiryy) * 1000);

    if (expiryy != '0') {
      lastDateValue = DateTime(
          dateConverted.year, dateConverted.month, dateConverted.day - 1);
    } else {
      lastDateValue = DateTime(DateTime.now().year + 100000);
    }

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(
          DateTime.now().year, DateTime.now().month, DateTime.now().day + 1),
      lastDate: lastDateValue,
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  //  =================================================

  _quantityPrice() {
    final tickSize = widget.placeOrderBloc!.orderResponseArray
        .elementAt(widget.placeOrderBloc!.currentExchangeIndex)!
        .tickSize!;
    final dprLow = double.parse(widget
        .placeOrderBloc!
        .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]!
        .lowRange!
        .toString());
    final dprHigh = double.parse(widget
        .placeOrderBloc!
        .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]!
        .highRange!
        .toString());
    final lotSize = int.parse(widget.placeOrderBloc!
        .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]!.lot!
        .toString());

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Flexible(
              fit: FlexFit.loose,
              child: TextField(
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: false,
                  signed: true,
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r"[0-9]"))
                ],
                //autofocus: QuantityAutoFocus,
                focusNode: quantityFocusNode,
                controller: quantityController,
                onTap: () {
                  quantityController.selection = TextSelection.fromPosition(
                      TextPosition(offset: quantityController.text.length));

                  quantityselection = quantityselection
                      ? quantityselection = false
                      : quantityselection = true;
                  setSelectionToTextController(quantityController);
                },

                maxLength: 10,
                decoration: InputDecoration(
                  hintText: '0',
                  contentPadding: const EdgeInsets.all(0),
                  counterText: "",
                  isDense: true,
                  labelText: 'Quantity',
                  labelStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.normal,
                    color: Color(0xFF909090),
                  ),
                  suffixIcon: Column(
                    children: [
                      CupertinoButton(
                        minSize: double.minPositive,
                        padding: EdgeInsets.zero,
                        child: Icon(Icons.arrow_drop_up_outlined,
                            color: Colors.black.withOpacity(0.4), size: 30),
                        onPressed: () {
                          int currentValue = int.parse(
                              (quantityController.text.isNotEmpty)
                                  ? quantityController.text
                                  : '0');
                          setState(() {
                            currentValue = currentValue + lotSize;
                            quantityController.text =
                                '$currentValue'; // incrementing value
                          });
                        },
                      ),
                      CupertinoButton(
                        minSize: double.minPositive,
                        padding: EdgeInsets.zero,
                        child: Icon(Icons.arrow_drop_down,
                            color: Colors.black.withOpacity(0.4), size: 30),
                        onPressed: () {
                          int currentValue = int.parse(
                              (quantityController.text.isNotEmpty)
                                  ? quantityController.text
                                  : '0');
                          setState(() {
                            log("Setting state");
                            currentValue = currentValue - lotSize;
                            quantityController.text =
                                (currentValue > 0 ? currentValue : 0)
                                    .toString(); // decrementing value
                          });
                        },
                      ),
                    ],
                  ),
                  suffixIconConstraints: const BoxConstraints(
                    minHeight: 0,
                    minWidth: 10,
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: const Color(0x00000029).withOpacity(1),
                        width: 0.5),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: const Color(0x00000029).withOpacity(1),
                        width: 0.5),
                  ),
                ),
                style: GreekTextStyle.OrderViewProductUnselectedTxt,
              ),
            ),
            const SizedBox(
              width: 20,
            ),
            Flexible(
              fit: FlexFit.loose,
              child: TextField(
                style: GreekTextStyle.OrderViewProductUnselectedTxt,
                enabled: isPriceEnable,
                autofocus: false,
                controller: priceController,
                focusNode: pricefocusnode,
                maxLength: 12,
                inputFormatters: [
                  widget.placeOrderBloc!.orderToken.toAssetType() == "currency"
                      ? FilteringTextInputFormatter.allow(
                          RegExp(r'^\d+\.?\d{0,4}'))
                      : FilteringTextInputFormatter.allow(
                          RegExp(r'^\d+\.?\d{0,2}')),
                ],
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                  signed: true,
                ),
                onTap: () {
                  setState(() {
                    getInitialPrice();
                    priceController.selection = TextSelection.fromPosition(
                        TextPosition(offset: priceController.text.length));
                    priceselection = priceselection
                        ? priceselection = false
                        : priceselection = true;
                    setSelectionTpriceTextController(priceController);
                    _orderTypeIndex == 1 ? _orderTypeIndex = 0 : null;
                    if (_orderTypeIndex == 3) {
                      slTriggerController.clear();
                      _orderTypeIndex = 0;
                    }
                  });
                },
                onSubmitted: (newValue) {
                  priceController.text = newValue;
                },
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(0),
                  counterText: "",
                  isDense: true,
                  hintText: '0.00',
                  labelText: 'Price',
                  labelStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.normal,
                    color: Color(0xFF909090),
                  ),
                  suffixIcon: Column(
                    children: [
                      CupertinoButton(
                        minSize: double.minPositive,
                        padding: EdgeInsets.zero,
                        child: Icon(Icons.arrow_drop_up_outlined,
                            color: Colors.black.withOpacity(0.4), size: 30),
                        onPressed: () {
                          if (priceController.text.isEmpty) {
                            setState(() {
                              if (widget.placeOrderBloc!.orderToken
                                      .toAssetType() ==
                                  "currency") {
                                priceController.text =
                                    dprHigh.toStringAsFixed(4);
                              } else {
                                priceController.text =
                                    dprHigh.toStringAsFixed(2);
                              }
                            });
                          } else {
                            double currentValue = double.parse(
                                (priceController.text.isNotEmpty)
                                    ? priceController.text
                                    : tickSize.toStringAsFixed(2));
                            if (currentValue <
                                double.parse(dprHigh.toString())) {
                              setState(() {
                                currentValue = currentValue + tickSize;
                                if (widget.placeOrderBloc!.orderToken
                                        .toAssetType() ==
                                    "currency") {
                                  priceController.text = (currentValue)
                                      .toStringAsFixed(4); // incrementing value
                                } else {
                                  priceController.text = (currentValue)
                                      .toStringAsFixed(2); // incrementing value
                                }
                              });
                            }
                          }
                        },
                      ),
                      CupertinoButton(
                        minSize: double.minPositive,
                        padding: EdgeInsets.zero,
                        child: Icon(Icons.arrow_drop_down,
                            color: Colors.black.withOpacity(0.4), size: 30),
                        onPressed: () {
                          if (priceController.text.isEmpty) {
                            setState(() {
                              if (widget.placeOrderBloc!.orderToken
                                      .toAssetType() ==
                                  "currency") {
                                priceController.text =
                                    dprLow.toStringAsFixed(4);
                              } else {
                                priceController.text =
                                    dprLow.toStringAsFixed(2);
                              }
                            });
                          } else {
                            double currentValue = double.parse(
                                (priceController.text.isNotEmpty)
                                    ? priceController.text
                                    : tickSize.toStringAsFixed(2));
                            if (currentValue >
                                double.parse(dprLow.toString())) {
                              setState(() {
                                currentValue = currentValue - tickSize;
                                if (widget.placeOrderBloc!.orderToken
                                        .toAssetType() ==
                                    "currency") {
                                  priceController.text = (currentValue > 0
                                          ? currentValue
                                          : 0)
                                      .toStringAsFixed(4); // decrementing value
                                } else {
                                  priceController.text = (currentValue > 0
                                          ? currentValue
                                          : 0)
                                      .toStringAsFixed(2); // decrementing value
                                }
                              });
                            }
                          }
                        },
                      ),
                    ],
                  ),
                  suffixIconConstraints: const BoxConstraints(
                    minHeight: 0,
                    minWidth: 10,
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: const Color(0x00000029).withOpacity(1),
                        width: 0.5),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: const Color(0x00000029).withOpacity(1),
                        width: 0.5),
                  ),
                ),
              ),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Flexible(
              fit: FlexFit.loose,
              child: TextField(
                style: GreekTextStyle.OrderViewProductUnselectedTxt,
                enabled: discQtyEnable,
                autofocus: false,
                focusNode: disqtyfocusnode,
                maxLength: 12,
                controller: discQtyController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: false,
                  signed: true,
                ),
                // onTap: () {
                //   setState(() {
                //     validitySelectedValue = "Day";
                //   });
                // },
                onTap: () {
                  disselection =
                      disselection ? disselection = false : disselection = true;
                  setSelectionTdisTextController(discQtyController);
                },
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r"[0-9]"))
                ],
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.only(bottom: 0),
                  counterText: "",
                  isDense: true,
                  labelText: 'Disc Qty',
                  labelStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.normal,
                    color: Color(0xFF909090),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: const Color(0x00000029).withOpacity(1),
                        width: 0.5),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: const Color(0x00000029).withOpacity(1),
                        width: 0.5),
                  ),
                  suffixIcon: Column(
                    children: [
                      CupertinoButton(
                        minSize: double.minPositive,
                        padding: EdgeInsets.zero,
                        child: Icon(Icons.arrow_drop_up_outlined,
                            color: Colors.black.withOpacity(0.4), size: 30),
                        onPressed: () {
                          var currentValue = int.parse(
                              (discQtyController.text.isNotEmpty)
                                  ? discQtyController.text
                                  : '0');
                          setState(() {
                            validitySelectedValue = "Day";
                            currentValue++;
                            discQtyController.text =
                                (currentValue).toString(); // incrementing value
                          });
                        },
                      ),
                      CupertinoButton(
                        minSize: double.minPositive,
                        padding: EdgeInsets.zero,
                        child: Icon(Icons.arrow_drop_down,
                            color: Colors.black.withOpacity(0.4), size: 30),
                        onPressed: () {
                          var currentValue = int.parse(
                              (discQtyController.text.isNotEmpty)
                                  ? discQtyController.text
                                  : '0');
                          setState(() {
                            validitySelectedValue = "Day";
                            log("Setting state");
                            currentValue--;
                            discQtyController.text =
                                (currentValue > 0 ? currentValue : 0)
                                    .toString(); // decrementing value
                          });
                        },
                      ),
                    ],
                  ),
                  suffixIconConstraints: const BoxConstraints(
                    minHeight: 0,
                    minWidth: 10,
                  ),
                  errorStyle: const TextStyle(color: Colors.red),
                ),
              ),
            ),
            const SizedBox(
              width: 20,
            ),
            Flexible(
              fit: FlexFit.loose,
              child: Container(
                padding: const EdgeInsets.all(5.0),
                child: TextField(
                  style: GreekTextStyle.OrderViewProductUnselectedTxt,
                  autofocus: false,
                  focusNode: slTriggerFocusNode,
                  enabled: (widget.placeOrderBloc!.orderMode !=
                      OrderMode.squareoffOrder),
                  onTap: () {
                    slselection =
                        slselection ? slselection = false : slselection = true;
                    setState(() {
                      if (_orderTypeIndex != 2 && _orderTypeIndex != 3) {
                        getInitialPrice();
                      }
                      _orderTypeIndex == 0 || _orderTypeIndex == 1
                          ? _orderTypeIndex = 2
                          : null;
                      isSetAMO = false;
                      if (validityDropdownValues.contains("IOC")) {
                        validityDropdownValues.removeAt(1);
                        validitySelectedValue = 'Day';
                        gtdVisible ? gtdVisible = false : null;
                      }
                    });
                  },
                  controller: slTriggerController,
                  maxLength: 12,
                  inputFormatters: [
                    widget.placeOrderBloc!.orderToken.toAssetType() ==
                            "currency"
                        ? FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,4}'))
                        : FilteringTextInputFormatter.allow(
                            RegExp(r'^\d+\.?\d{0,2}')),
                  ],
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: true,
                  ),

                  /* inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r"[0-9.]")),
                  ], */
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.only(bottom: 0),
                    counterText: "",
                    isDense: true,
                    hintText: '',
                    labelText: 'SL Trigger Price',
                    labelStyle: const TextStyle(
                      color: Color(0xFF909090),
                      fontSize: 18,
                      fontWeight: FontWeight.normal,
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: const Color(0x00000029).withOpacity(1),
                          width: 0.5),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: const Color(0x00000029).withOpacity(1),
                          width: 0.5),
                    ),
                    suffixIcon: Column(
                      children: [
                        CupertinoButton(
                          minSize: double.minPositive,
                          padding: EdgeInsets.zero,
                          child: Icon(Icons.arrow_drop_up_outlined,
                              color: Colors.black.withOpacity(0.4), size: 30),
                          onPressed: () {
                            var currentValue = double.parse(
                                (slTriggerController.text.isNotEmpty)
                                    ? slTriggerController.text
                                    : tickSize.toStringAsFixed(2));
                            if (currentValue < dprHigh) {
                              setState(() {
                                currentValue = currentValue + tickSize;
                                if (widget.placeOrderBloc!.orderToken
                                        .toAssetType() ==
                                    "currency") {
                                  slTriggerController.text = currentValue
                                      .toStringAsFixed(4); // incrementing value
                                } else {
                                  slTriggerController.text = currentValue
                                      .toStringAsFixed(2); // incrementing value

                                }
                              });
                            }
                          },
                        ),
                        CupertinoButton(
                          minSize: double.minPositive,
                          padding: EdgeInsets.zero,
                          child: Icon(Icons.arrow_drop_down,
                              color: Colors.black.withOpacity(0.4), size: 30),
                          onPressed: () {
                            var currentValue = double.parse(
                                (slTriggerController.text.isNotEmpty)
                                    ? slTriggerController.text
                                    : tickSize.toStringAsFixed(2));
                            if (currentValue > dprLow) {
                              setState(() {
                                currentValue = currentValue - tickSize;
                                if (widget.placeOrderBloc!.orderToken
                                        .toAssetType() ==
                                    "currency") {
                                  slTriggerController.text = (currentValue > 0
                                          ? currentValue
                                          : 0)
                                      .toStringAsFixed(4); // decrementing value
                                } else {
                                  slTriggerController.text = (currentValue > 0
                                          ? currentValue
                                          : 0)
                                      .toStringAsFixed(2); // decrementing value
                                }
                              });
                            } else {
                              setState(() {
                                currentValue = currentValue - tickSize;
                                if (widget.placeOrderBloc!.orderToken
                                        .toAssetType() ==
                                    "currency") {
                                  slTriggerController.text = (currentValue > 0
                                          ? currentValue
                                          : 0)
                                      .toStringAsFixed(4); // decrementing value
                                } else {
                                  slTriggerController.text = (currentValue > 0
                                          ? currentValue
                                          : 0)
                                      .toStringAsFixed(2); // decrementing value
                                }
                              });
                            }
                          },
                        ),
                      ],
                    ),
                    suffixIconConstraints: const BoxConstraints(
                      minHeight: 0,
                      minWidth: 10,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  _submitButton() => Container(
        height: 50,
        width: 150.0,
        margin: const EdgeInsets.only(top: 20.0, bottom: 20.0),
        decoration: BoxDecoration(
            color: widget.placeOrderBloc!.orderAction == OrderAction.buy
                ? ConstantColors.buyColor
                : ConstantColors.sellColor,
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: const [
              BoxShadow(
                  color: Colors.grey, offset: Offset(0, 0), blurRadius: 10),
            ]),
        child: TextButton(
          child: Text(
            "SUBMIT",
            style: GreekTextStyle.ordersubmit,
          ),
          onPressed: () {
            _closeKeyboard();
            validateAllowedMarket();
            if (allowed_market) {
              OrderDetailsModel orderDetails = OrderDetailsModel();
              var errorString = '';
              final tickSize = widget.placeOrderBloc!.orderResponseArray
                  .elementAt(widget.placeOrderBloc!.currentExchangeIndex)!
                  .tickSize!;
              final dprLow = double.parse(widget
                  .placeOrderBloc!
                  .orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!
                  .lowRange!
                  .toString());
              final dprHigh = double.parse(widget
                  .placeOrderBloc!
                  .orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!
                  .highRange!
                  .toString());
              final lotSize = int.parse(widget
                  .placeOrderBloc!
                  .orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!
                  .lot!
                  .toString());

              if (_orderTypeIndex != 1 && _orderTypeIndex != 3) {
                if (setTargetController.text.isNotEmpty &&
                    setSLPriceController.text.isNotEmpty) {
                  if (widget.placeOrderBloc?.orderAction == OrderAction.buy) {
                    if (double.parse(slTriggerController.text.toString()) >
                        double.parse(priceController.text.toString())) {
                      errorString =
                          'Trigger price must be less than Order price for Buy Order';
                    }
                    if (double.parse(setSLPriceController.text.toString()) >
                        double.parse(priceController.text.toString())) {
                      errorString =
                          'StopLoss price must be less than Order price for Buy Order';
                    }
                    if (double.parse(setSLPriceController.text.toString()) >
                        double.parse(slTriggerController.text.toString())) {
                      errorString =
                          'Trigger price must be more than StopLoss price for Buy Order';
                    }
                    if (double.parse(priceController.text.toString()) >
                        double.parse(setTargetController.text.toString())) {
                      errorString =
                          'Target price must be greater than or equal Order price for Buy Order';
                    }
                  } else {
                    if (double.parse(slTriggerController.text.toString()) <
                        double.parse(priceController.text.toString())) {
                      errorString =
                          'Trigger price must be more than Order price for Sell Order';
                    }
                    if (double.parse(setSLPriceController.text.toString()) <
                        double.parse(priceController.text.toString())) {
                      errorString =
                          'StopLoss price must be more than Order price for Sell Order';
                    }
                    if (double.parse(setSLPriceController.text.toString()) <
                        double.parse(slTriggerController.text.toString())) {
                      errorString =
                          'StopLoss price must be more than Trigger price for Sell Order';
                    }
                    if (double.parse(priceController.text.toString()) <
                        double.parse(setTargetController.text.toString())) {
                      errorString =
                          'Target price must be less than or equal Order price for Sell Order';
                    }
                  }
                } else if (slTriggerController.text.isNotEmpty &&
                    (_orderTypeIndex == 2 || _orderTypeIndex == 3)) {
                  if (widget.placeOrderBloc?.orderAction == OrderAction.buy) {
                    if (priceController.text.toString().isEmpty) {
                      errorString = 'Please enter the price';
                    } else if (double.parse(
                            slTriggerController.text.toString()) >
                        double.parse(priceController.text.toString())) {
                      errorString =
                          'Trigger price must be less than Order price for Buy Order';
                    }
                  } else {
                    if (priceController.text.toString().isEmpty) {
                      errorString = 'please enter the price';
                    } else if (double.parse(
                            slTriggerController.text.toString()) <
                        double.parse(priceController.text.toString())) {
                      errorString =
                          'Trigger price must be more than Order price for Sell Order';
                    }
                  }
                }
              }

              if ((_orderTypeIndex != 1) &&
                  (_orderTypeIndex != 3) &&
                  (priceController.text.isEmpty)) {
                errorString = 'Price can not be blank';
              } else {
                if ((_orderTypeIndex != 1) && (_orderTypeIndex != 3)) {
                  final limitPrice = double.parse(priceController.text);

                  if (_orderTypeIndex == 2) {
                    if (slTriggerController.text.isEmpty) {
                      errorString = 'SL Trigger price can not be blank';
                    } else if (double.parse(
                            slTriggerController.text.toString()) <=
                        0.00) {
                      errorString =
                          'SL Trigger price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    } else if ((double.parse(
                                slTriggerController.text.toString()) <
                            dprLow) ||
                        (double.parse(slTriggerController.text.toString()) >
                            dprHigh)) {
                      errorString =
                          'Trigger price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    } else {
                      orderDetails.trigger_price = slTriggerController.text;
                    }
                  } else {
                    orderDetails.trigger_price = '';
                  }
                  if (slTriggerController.text.isNotEmpty &&
                      setTargetController.text.isNotEmpty &&
                      setSLPriceController.text.isNotEmpty) {
                    final slLimitPrice =
                        double.parse(setSLPriceController.text);
                    final targetLimitPrice =
                        double.parse(setTargetController.text);
                    final triggerLimitPrice =
                        double.parse(slTriggerController.text);

                    if ((slLimitPrice < dprLow) || (slLimitPrice > dprHigh)) {
                      errorString =
                          'Stop Loss price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    } else if ((targetLimitPrice < dprLow) ||
                        (targetLimitPrice > dprHigh)) {
                      errorString =
                          'Target price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    } else if ((triggerLimitPrice < dprLow) ||
                        (triggerLimitPrice > dprHigh)) {
                      errorString =
                          'Trigger price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    }

                    final intTickSize = (tickSize * 100).toInt();
                    final intLimitPrice = (limitPrice * 100).toInt();

                    if (intLimitPrice.remainder(intTickSize) != 0) {
                      errorString =
                          'Price should be multiple of Tick Size [${tickSize.toStringAsFixed(2)}]';
                    }
                  }
                  if (slTriggerController.text.isNotEmpty &&
                      setTargetController.text.isEmpty &&
                      setSLPriceController.text.isNotEmpty) {
                    setState(() {
                      validitySelectedValue = "IOC";
                    });
                    final slLimitPrice =
                        double.parse(setSLPriceController.text);
                    final triggerLimitPrice =
                        double.parse(slTriggerController.text);

                    if ((slLimitPrice < dprLow) || (slLimitPrice > dprHigh)) {
                      errorString =
                          'Stop Loss price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    } else if ((triggerLimitPrice < dprLow) ||
                        (triggerLimitPrice > dprHigh)) {
                      errorString =
                          'Trigger price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                    }

                    final intTickSize = (tickSize * 100).toInt();
                    final intLimitPrice = (limitPrice * 100).toInt();

                    if (intLimitPrice.remainder(intTickSize) != 0) {
                      errorString =
                          'Price should be multiple of Tick Size [${tickSize.toStringAsFixed(2)}]';
                    }
                  }

                  if ((limitPrice < dprLow) || (limitPrice > dprHigh)) {
                    errorString =
                        'Price should be within DPR [${dprLow.toStringAsFixed(2)}-${dprHigh.toStringAsFixed(2)}]';
                  }

                  final intTickSize = (tickSize * 100).toDouble();
                  final intLimitPrice = (limitPrice * 100).toStringAsFixed(2);

                  if (double.parse(intLimitPrice).remainder(intTickSize) != 0) {
                    errorString =
                        'Price should be multiple of Tick Size [${tickSize.toStringAsFixed(2)}]';
                  }
                } else if (_orderTypeIndex == 3) {
                  if (slTriggerController.text.isEmpty) {
                    errorString = 'SL Trigger price can not be blank';
                  } else {
                    orderDetails.trigger_price = slTriggerController.text;
                  }
                } else {
                  orderDetails.trigger_price = '';
                }
              }

              if (discQtyController.text.isNotEmpty) {
                if (int.parse(discQtyController.text.toString().trim()) <= 0) {
                  errorString = "Disclosed Quantity should be positive number";
                } else if (int.parse(discQtyController.text.toString()) > 0) {
                  int i = int.parse(quantityController.text.toString());
                  bool result1 = (i / 10.0) >
                      (int.parse(discQtyController.text.toString()));
                  bool result2 = ((i / 10.0) ==
                      (int.parse(discQtyController.text.toString())));

                  if (result1 && !result2) {
                    errorString =
                        "Disclosed quantity is less than 10% of order quantity";
                  } else if (int.parse(quantityController.text.toString()) <
                      int.parse(discQtyController.text.toString())) {
                    errorString =
                        "Disclosed quantity should not be greater than order quantity";
                  }
                }
              } else {
                discQtyController.text = '';
              }

/*
          DateTime currentPhoneDate = DateTime.now(); //DateTime

          Timestamp myTimeStamp = Timestamp.fromDate(currentPhoneDate); //To TimeStamp*/

              /* String sdatetime = "2021-12-04";
          DateTime sdate = DateTime.parse(sdatetime);
          int stimestamp = sdate.microsecondsSinceEpoch;

          print("${stimestamp} ====Rohit Jadhav ");*/

              if (validitySelectedValue.toString().toUpperCase() == 'GTD') {
                DateTime now = DateTime.now();
                String formattedDate = DateFormat('yyyy-MM-dd').format(now);

                if (formattedDate ==
                    '${selectedDate.toLocal()}'.split(' ')[0]) {
                  errorString = 'GTD must be greater than 1 day';
                } else {
                  String sdatetime = "${selectedDate.toLocal()}";
                  DateTime sdate = DateTime.parse(sdatetime);
                  int stimestamp = (sdate.microsecondsSinceEpoch);
                  gtdSelectedDate = '${stimestamp ~/ 1000000}';
                }
              }

              if (quantityController.text.isEmpty) {
                errorString = 'Quantity can not be blank';
              } else if (int.parse(quantityController.text) <= 0) {
                errorString = 'Enter valid quantity';
              } else if (lotSize > 0) {
                if (widget
                        .placeOrderBloc!
                        .orderResponseArray[
                            widget.placeOrderBloc!.currentExchangeIndex]!
                        .token!
                        .toAssetType() !=
                    "commodity") {
                  if (int.parse(quantityController.text) % lotSize != 0) {
                    errorString = 'Enter valid quantity';
                  }
                }
              } else if (widget.placeOrderBloc?.orderMode ==
                  OrderMode.squareoffOrder) {
                if (quantityController.text.isEmpty) {
                  errorString = 'Quantity can not be blank';
                } else {}
              }

              validateMarketStatus();
              if (isPostOpen_status == false &&
                  isSetAMO == true &&
                  !valid_status) {
                errorString = 'AMO Not allowed when market is open';
              }

              if (isPreOpen_status &&
                  validitySelectedValue == "IOC" &&
                  widget.placeOrderBloc?.orderToken.toAssetType() == "equity") {
                errorString = "IOC order is not allowed in Preopen Session";
              }

              if (valid_status) {
                if (!isSetAMO &&
                    (widget.placeOrderBloc?.orderToken.toAssetType() ==
                        "equity") &&
                    validitySelectedValue == "IOC") {
                  errorString = "IOC order is not allowed in Offline Session";
                }

                if (orderTypeValues[_orderTypeIndex].toLowerCase() == "sl" &&
                    (widget.placeOrderBloc?.orderToken.toAssetType() ==
                        "equity")) {
                  errorString = "SL order is not allowed in Offline Session";
                }

                if (orderTypeValues[_orderTypeIndex].toLowerCase() == "slm" &&
                    (widget.placeOrderBloc?.orderToken.toAssetType() ==
                        "equity")) {
                  errorString = "SLM order is not allowed in Offline Session";
                }
              }

              //Data setting in OrderDetails model

              // for Confirm Order
              if (widget.placeOrderBloc?.orderMode ==
                  OrderMode.squareoffOrder) {
                if (int.parse(quantityController.text) >
                    int.parse(widget.placeOrderBloc?.obj?.qty ?? "0")) {
                  errorString = 'Qty should less than square off qty';
                } else {
                  orderDetails.qty = (int.parse(quantityController.text) *
                          int.parse(widget.placeOrderBloc?.obj?.lot ?? ""))
                      .toString();
                }
              } else {
                if (widget
                        .placeOrderBloc!
                        .orderResponseArray[
                            widget.placeOrderBloc!.currentExchangeIndex]!
                        .token!
                        .toAssetType() ==
                    "commodity") {
                  orderDetails.qty = (int.parse(quantityController.text) *
                          (widget
                                  .placeOrderBloc!
                                  .orderResponseArray[widget
                                      .placeOrderBloc!.currentExchangeIndex]!
                                  .lot ??
                              0))
                      .toString();
                } else {
                  orderDetails.qty = quantityController.text;
                }
              }
              if (errorString.isNotEmpty) {
                GreekDialogPopupView.messageDialog(context, errorString);
                return;
              }
              orderDetails.orderAction = widget.placeOrderBloc!.orderAction;
              if (widget.placeOrderBloc?.orderMode == OrderMode.newOrder ||
                  widget.placeOrderBloc?.orderMode ==
                      OrderMode.squareoffOrder) {
                if (slTriggerController.text.isNotEmpty &&
                    setTargetController.text.isNotEmpty &&
                    setSLPriceController.text.isNotEmpty) {
                  orderDetails.order_type = 'Bracket';
                } else if (slTriggerController.text.isNotEmpty &&
                    setSLPriceController.text.isNotEmpty) {
                  orderDetails.order_type = 'Cover';
                  setState(() {
                    validitySelectedValue = 'IOC';
                  });
                } else {
                  orderDetails.order_type =
                      orderTypeValues.elementAt(_orderTypeIndex);
                }
                orderDetails.productType =
                    productTypeDropdownValues.elementAt(_productIndex);
                orderDetails.validity = validitySelectedValue;
              } else if (widget.placeOrderBloc?.orderMode ==
                  OrderMode.modiftyOrder) {
                final orderName = orderTypeValues.elementAt(_orderTypeIndex);
                orderDetails.order_type = orderName;
                // GreekBase().getOrderTypeFromShortOrderName(orderName);

                final productName =
                    productTypeDropdownValues.elementAt(_productIndex);
                orderDetails.productType = productName;
                orderDetails.validity = validitySelectedValue;
              }
              orderDetails.disQuantity = discQtyController.text;

              orderDetails.orderPrice = priceController.text;

              if (!valid_status) {
                orderDetails.offline = '0';
              } else {
                orderDetails.offline = '1';
              }
              // new request parameter
              orderDetails.gtoken = widget
                  .placeOrderBloc!
                  .orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!
                  .token!
                  .toString(); // passed token from V3 service
              orderDetails.tradeSymbol = widget
                  .placeOrderBloc!
                  .orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!
                  .description; //common in confirm nd new request
              if (isPreOpen_status) {
                orderDetails.is_preopen_order = '1';
              } else {
                orderDetails.is_preopen_order = '0';
              }
              if (isPostOpen_status) {
                orderDetails.is_post_closed = '1';
                if ((widget.placeOrderBloc!.orderMode !=
                    OrderMode.modiftyOrder)) {
                  if (isSetAMO) {
                    orderDetails.offline = '0';
                    orderDetails.amo = "1";
                  } else {
                    orderDetails.offline = '1';
                    orderDetails.amo = "0";
                  }
                } else {
                  if (widget.placeOrderBloc!.obj?.offline == "1") {
                    orderDetails.offline = '1';
                  } else if (widget.placeOrderBloc!.obj?.amo == "1") {
                    orderDetails.amo = "1";
                  } else {
                    orderDetails.offline = '0';
                  }
                }
              } else {
                orderDetails.is_post_closed = '0';
              }

              // orderDetails.is_post_closed = '0'; //need to be chnage
              // orderDetails.is_preopen_order = '1'; //need to be chnage
              orderDetails.disclosed_qty = discQtyController.text;
              QuoteForSingleSymbolModel orderResponseObj =
                  widget.placeOrderBloc!.orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!;
              if (orderResponseObj.token!.toAssetType().toUpperCase() !=
                      "EQUITY" &&
                  orderResponseObj.token!.toAssetType().toUpperCase() !=
                      "NSECURR") {
                int qty = int.parse(orderDetails.qty ?? '0');
                int tempLot = (widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .lot!);
                var lot = qty ~/ tempLot;
                /*  orderDetails.lot = widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .lot
                    .toString(); */
                orderDetails.lot = lot.toString();
              } /* else {
                orderDetails.lot = quantityController.text;
              } */

              orderDetails.price = priceController.text;
              // orderDetails.amo = isSetAMO ? '1' : '0';
              if (valid_status) {
                if ((widget.placeOrderBloc!.orderMode !=
                    OrderMode.modiftyOrder)) {
                  if (isSetAMO) {
                    orderDetails.amo = "1";
                    orderDetails.offline = "0";
                  } else {
                    orderDetails.amo = "0";
                    orderDetails.offline = "1";
                  }
                }
              }

              // orderDetails.offline = '0'; // change on market status
              orderDetails.exchange = widget
                  .placeOrderBloc!
                  .orderResponseArray[
                      widget.placeOrderBloc!.currentExchangeIndex]!
                  .token!
                  .toExchange()
                  .toUpperCase();
              orderDetails.gtdExpiry =
                  (validitySelectedValue.toLowerCase().compareTo('gtd') == 0)
                      ? gtdSelectedDate
                      : '';
              // orderDetails.validity =
              //     '${validityDropdownValues.indexOf(validitySelectedValue)}'; //common in confirm nd new request
              orderDetails.gcid = AppConfig().gcid;

              //for Modify order
              orderDetails.gorderid_Modify =
                  widget.placeOrderBloc?.obj?.gorderid_Modify;
              orderDetails.lexchangeOrderNo1_Modify =
                  widget.placeOrderBloc?.obj?.lexchangeOrderNo1_Modify;
              orderDetails.pending_qty_Modify =
                  widget.placeOrderBloc?.obj?.pending_qty_Modify;
              orderDetails.eorderid_Modify =
                  widget.placeOrderBloc?.obj?.eorderid_Modify;
              orderDetails.qty_filled_today_Modify =
                  widget.placeOrderBloc?.obj?.qty_filled_today_Modify;
              orderDetails.lu_time_exchange_Modify =
                  widget.placeOrderBloc?.obj?.lu_time_exchange_Modify;
              orderDetails.iomRuleNo = widget.placeOrderBloc?.obj?.iomRuleNo;
              orderDetails.pending_disclosed_qty_Modify =
                  widget.placeOrderBloc?.obj?.pending_disclosed_qty_Modify;

              orderDetails.isModifyObj =
                  (widget.placeOrderBloc!.orderMode == OrderMode.modiftyOrder);

              /*if (quantityController.text.isNotEmpty) {
              GreekDialogPopupView.confirmOrderDialog(
                context: context,
                obj: orderDetails,
                orderMode: widget.placeOrderBloc!.orderMode,
              );
            }*/
              GreekDialogPopupView.confirmOrderDialog(
                context: context,
                obj: orderDetails,
                orderMode: widget.placeOrderBloc!.orderMode,
              );
            } else {
              GreekDialogPopupView.messageDialog(context, "Market not allowed");
            }
          },
        ),
      );

  void validateMarketStatus() {
    valid_status = false;
    isPostOpen_status = false;
    isPreOpen_status = false;

    if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "NSE") &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "EQUITY") &&
        MarketStatusFlag.nse_eq_status) {
      log("In NSE eq");
      valid_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "BSE") &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "equity".toUpperCase()) &&
        MarketStatusFlag.bse_eq_status) {
      log("In BSE eq");
      valid_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "fno".toUpperCase()) &&
        MarketStatusFlag.nse_fno_status) {
      log("In NSE FO");
      valid_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "bse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "fno".toUpperCase()) &&
        MarketStatusFlag.bse_fno_status) {
      log("In BSE FNO");
      valid_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "currency".toUpperCase()) &&
        MarketStatusFlag.nse_cd_status) {
      log("In NSE CD");
      valid_status = true;
    } else if (((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .token!
                    .toExchange()
                    .toUpperCase() ==
                "bse".toUpperCase()) ||
            (widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .token!
                    .toExchange()
                    .toUpperCase() ==
                "BSECURR".toUpperCase())) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "currency".toUpperCase()) &&
        MarketStatusFlag.bse_cd_status) {
      log("In BSE CD");
      valid_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "mcx".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "commodity".toUpperCase()) &&
        MarketStatusFlag.mcx_com_status) {
      log("In MCX");
      valid_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "ncdex".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "commodity".toUpperCase()) &&
        MarketStatusFlag.ncdex_com_status) {
      log("In ncdex");
      valid_status = true;
    }

    if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "equity".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_nse_eq) {
      log("In nSE eq");
      isPreOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "bse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "equity".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_bse_eq) {
      log("In bSE eq");
      isPreOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "fno".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_nse_fno) {
      log("In nSE fno");
      isPreOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "bse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "fno".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_bse_fno) {
      log("In bSE fno");
      isPreOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "currency".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_nse_cd) {
      isPreOpen_status = true;
    } else if (((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .token!
                    .toExchange()
                    .toUpperCase() ==
                "bse".toUpperCase()) ||
            (widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .token!
                    .toExchange()
                    .toUpperCase() ==
                "BSECURR".toUpperCase())) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "currency".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_bse_cd) {
      isPreOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "mcx".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "commodity".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_mcx_com) {
      isPreOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "ncdex".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "commodity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_ncdex_com) {
      isPreOpen_status = true;
    }

    if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "equity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_nse_eq) {
      isPostOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "bse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "equity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_bse_eq) {
      isPostOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "fno".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_nse_fno) {
      isPostOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "bse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "fno".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_bse_fno) {
      isPostOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "Nse".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "currency".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_nse_cd) {
      isPostOpen_status = true;
    } else if (((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .token!
                    .toExchange()
                    .toUpperCase() ==
                "bse".toUpperCase()) ||
            (widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]!
                    .token!
                    .toExchange()
                    .toUpperCase() ==
                "BSECURR".toUpperCase())) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "currency".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_bse_cd) {
      isPostOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "mcx".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "commodity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_mcx_com) {
      isPostOpen_status = true;
    } else if ((widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toExchange()
                .toUpperCase() ==
            "ncdex".toUpperCase()) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[
                    widget.placeOrderBloc!.currentExchangeIndex]!
                .token!
                .toAssetType()
                .toUpperCase() ==
            "commodity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_ncdex_com) {
      isPostOpen_status = true;
    }
  }

//  =================================================

  void amoEnable(bool enable) {
    setState(() {
      isSetAMO = enable;
      limitClicked();
      // _orderTypeIndex = 0;
      //quantityFocusNode?.requestFocus();
      isPriceEnable = true;
    });
  }

//  =================================================

  void productBtnClick(int index) {
    if (widget.placeOrderBloc!.orderMode == OrderMode.newOrder) {
      //for dilivery
      if (index == 0) {
        setState(() {
          diliveryClicked();
        });
      }

      //for Intraday
      else if (index == 1) {
        setState(() {
          intradayClicked();
        });
      }

      //for MTF
      else if (index == 2) {
        setState(() {
          mtfClicked();
        });
      }
    }
  }

  void orderTypeBtnClick(int index) {
    if (widget.placeOrderBloc!.orderMode == OrderMode.squareoffOrder) {
      if (index == 0) {
        setState(() {
          limitClicked();
        });
      } else if (index == 1) {
        setState(() {
          marketClicked();
        });
      }
    } else {
      if (index == 0) {
        setState(() {
          limitClicked();
        });
      } else if (index == 1) {
        setState(() {
          marketClicked();
        });
      } else if (index == 2) {
        setState(() {
          slClicked();
        });
      } else if (index == 3) {
        setState(() {
          slmClicked();
        });
      }
    }
  }

  void diliveryClicked() {
    //quantityFocusNode?.requestFocus();
    discQtyEnable = true;
    _orderTypeIndex = 0;
    validitySelectedValue = 'Day';
    gtdVisible = false;
    _productIndex = 0;
    slTriggerController.text = '';
    setTargetController.text = '';
    setSLPriceController.text = '';
    getInitialPrice();
  }

  void intradayClicked() {
    //quantityFocusNode?.requestFocus();
    getInitialPrice();
    discQtyEnable = true;
    _orderTypeIndex = 0;
    validitySelectedValue = 'Day';
    gtdVisible = false;
    _productIndex = 1;
    slTriggerController.text = '';
    setTargetController.text = '';
    setSLPriceController.text = '';
  }

  void mtfClicked() {
    //quantityFocusNode?.requestFocus();
    discQtyEnable = true;
    _orderTypeIndex = 0;
    validitySelectedValue = 'Day';
    gtdVisible = false;
    slTriggerController.text = '';
    setTargetController.text = '';
    setSLPriceController.text = '';
    _productIndex = 2;
    getInitialPrice();
  }

  void limitClicked() {
    if (widget.placeOrderBloc?.orderMode == OrderMode.modiftyOrder) {
      // slTriggerController.clear();
      slTriggerController.text = '';
      setTargetController.text = '';
      setSLPriceController.text = '';
      _orderTypeIndex = 0;
      getInitialPrice();
      if (!validityDropdownValues.contains("IOC")) {
        validityDropdownValues.insert(1, 'IOC');
      }
    } else {
      slTriggerController.clear();
      //quantityFocusNode?.requestFocus();
      isPriceEnable = true;
      _orderTypeIndex = 0;
      validitySelectedValue = 'Day';
      gtdVisible = false;

      getInitialPrice();
      // isSLTriggerPriceEnable = false;
      if (!validityDropdownValues.contains("IOC")) {
        validityDropdownValues.insert(1, 'IOC');
      }
    }
  }

  void marketClicked() {
    if (widget.placeOrderBloc?.orderMode == OrderMode.modiftyOrder) {
      priceController.text = '';
      slTriggerController.text = '';
      setTargetController.text = '';
      setSLPriceController.text = '';
      _orderTypeIndex = 1;
      if (!validityDropdownValues.contains("IOC")) {
        validityDropdownValues.insert(1, 'IOC');
      }
    } else {
      priceController.text = '';
      slTriggerController.text = '';
      setTargetController.text = '';
      setSLPriceController.text = '';
      //quantityFocusNode?.requestFocus();
      validitySelectedValue = 'Day';
      gtdVisible = false;
      _orderTypeIndex = 1;
      if (!validityDropdownValues.contains("IOC")) {
        validityDropdownValues.insert(1, 'IOC');
      }
      // QuantityController;
      // isSLTriggerPriceEnable = false;
    }
  }

  void slClicked() {
    if (widget.placeOrderBloc?.orderMode == OrderMode.modiftyOrder) {
      slTriggerFocusNode?.requestFocus();
      if (isSetAMO) {
        isSetAMO = false;
      }
      if (validityDropdownValues.contains('IOC')) {
        validityDropdownValues.remove('IOC');
      }
      isPriceEnable = true;
      if (validitySelectedValue.toLowerCase() == 'gtd') {
        gtdVisible = true;
      }
      _orderTypeIndex = 2;
    } else {
      getInitialPrice();
      slTriggerFocusNode?.requestFocus();
      if (isSetAMO) {
        isSetAMO = false;
      }
      if (validityDropdownValues.contains("IOC")) {
        validitySelectedValue = 'Day';
        validityDropdownValues.remove("IOC");
      }
      if (validitySelectedValue.toLowerCase() == 'gtd') {
        gtdVisible = true;
      }
      isPriceEnable = true;
      gtdVisible = false;
      _orderTypeIndex = 2;
    }
  }

  void slmClicked() {
    // getInitialPrice();
    if (widget.placeOrderBloc?.orderMode == OrderMode.modiftyOrder) {
      priceController.text = '';
      slTriggerController.text = '';
      setTargetController.text = '';
      setSLPriceController.text = '';
      slTriggerFocusNode?.requestFocus();
      if (isSetAMO) {
        isSetAMO = false;
      }
      isPriceEnable = false;
      if (validitySelectedValue.toLowerCase() == 'gtd') {
        gtdVisible = true;
      }
      if (validityDropdownValues.contains('IOC')) {
        validityDropdownValues.remove('IOC');
      }
      _orderTypeIndex = 3;
    } else {
      priceController.text = '';
      slTriggerController.text = '';
      setTargetController.text = '';
      setSLPriceController.text = '';
      slTriggerFocusNode?.requestFocus();

      // slTriggerFocusNode?.requestFocus();
      if (isSetAMO) {
        isSetAMO = false;
      }
      isPriceEnable = false;
      if (validityDropdownValues.contains("IOC")) {
        validitySelectedValue = 'Day';
        validityDropdownValues.remove("IOC");
      }
      if (validitySelectedValue.toLowerCase() == 'gtd') {
        gtdVisible = true;
      } else {
        gtdVisible = false;
      }
      _orderTypeIndex = 3;
    }
  }

  void _closeKeyboard() {
    FocusScope.of(context).unfocus();
  }

  void validateAllowedMarket() {
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "NSE" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "equity") &&
        GreekBase().marketSegments.contains(MarketSegment.nseeq)) {
      allowed_market = true;
    }

    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "NSE" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "fno") &&
        GreekBase().marketSegments.contains(MarketSegment.nsefo)) {
      allowed_market = true;
    }
    if (((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]
                    ?.token
                    ?.toExchange()) ==
                "NSECURR" ||
            ((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]
                    ?.token
                    ?.toExchange()) ==
                "NSECURR")) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "currency") &&
        GreekBase().marketSegments.contains(MarketSegment.nsecd)) {
      allowed_market = true;
    }
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "BSE" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "equity") &&
        GreekBase().marketSegments.contains(MarketSegment.bseeq)) {
      allowed_market = true;
    }
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "BSE" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "fno") &&
        GreekBase().marketSegments.contains(MarketSegment.bsefo)) {
      allowed_market = true;
    }
    if (((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]
                    ?.token
                    ?.toExchange()) ==
                "BSE" ||
            ((widget
                    .placeOrderBloc!
                    .orderResponseArray[
                        widget.placeOrderBloc!.currentExchangeIndex]
                    ?.token
                    ?.toExchange()) ==
                "BSECURR")) &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "currency") &&
        GreekBase().marketSegments.contains(MarketSegment.bsecd)) {
      allowed_market = true;
    }
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "MCX" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "commodity") &&
        GreekBase().marketSegments.contains(MarketSegment.mcx)) {
      allowed_market = true;
    }
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "NCDEX" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "commodity") &&
        GreekBase().marketSegments.contains(MarketSegment.ncdex)) {
      allowed_market = true;
    }
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "NSECOMM" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "commodity") &&
        GreekBase().marketSegments.contains(MarketSegment.nsecomm)) {
      allowed_market = true;
    }
    if ((widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toExchange()) ==
            "BSECOMM" &&
        (widget
                .placeOrderBloc!
                .orderResponseArray[widget.placeOrderBloc!.currentExchangeIndex]
                ?.token
                ?.toAssetType() ==
            "commodity") &&
        GreekBase().marketSegments.contains(MarketSegment.bsecomm)) {
      allowed_market = true;
    }

    for (var item in GreekBase().marketSegments) {
      if (item == MarketSegment.nseeq ||
          item == MarketSegment.nsefo ||
          item == MarketSegment.nsecd ||
          item == MarketSegment.nsecomm) {}

      if (item == MarketSegment.bseeq ||
          item == MarketSegment.bsefo ||
          item == MarketSegment.bsecd ||
          item == MarketSegment.bsecomm) {}

      if (item == MarketSegment.mcx || item == MarketSegment.ncdex) {}

      if (item == MarketSegment.ncdex) {}
    }
  }
}
