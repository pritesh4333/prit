import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/portfolio_bloc.dart';
import 'package:greek_ibt_app/Screens/Portfolio/models/holding_response_data_new_model.dart'
    as holding;
import 'package:greek_ibt_app/Screens/Portfolio/models/np_details_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:rxdart/rxdart.dart';

import '../models/holding_response_data_new_model.dart';

class PortfolioScreen extends StatefulWidget {
  const PortfolioScreen({Key? key}) : super(key: key);

  @override
  _PortfolioScreenState createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends State<PortfolioScreen> {
  int selectedIndex = 0;
  List<String> selectedDropDownValues = ['LTP', 'Alphabetically', '% Change'];
  var selectedDropDownItem = "";
  bool isltpacending = false;
  bool isaphabetascending = false;
  bool isperchangeAsending = false;
  List<holding.StockDetails>? listHoldingData;
  final PortfolioBloc _portfolioBloc = PortfolioBloc();
  var finalTotalInvested = 0.00;
  var finalCurrentValue = 0.00;
  var finalPreviousValue = 0.00;
  var finalDaysPnL = 0.00;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      SocketIOManager().holdingDataListRequest();
      // SocketIOManager().npDetailsRequest();
      /* Future.delayed(const Duration(seconds: 2))
          .then((value) => SocketIOManager().holdingDataListRequest());*/
    });
    PortfolioBloc.searchWidgitVisiblity.sink.add(false);
    GreekBase.portfolioStateObject = PortfolioScreenState.holding;

    super.initState();
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  void dispose() {
    _portfolioBloc.searchTextFieldController.clear();
    _portfolioBloc.hideSearchandtexFieldDispose();
    PortfolioBloc.searchWidgitVisiblity.sink.add(false);

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_portfolioBloc.searchTextFieldController.text.isNotEmpty) {
      _portfolioBloc.searchTextFieldController.clear();
      _portfolioBloc.hideSearchandtexFieldDispose();
      PortfolioBloc.searchWidgitVisiblity.sink.add(true);
    }
    return DefaultTabController(
      initialIndex: 0,
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            onPressed: () => GreekBase().drawerKey.currentState?.openDrawer(),
            icon: const Icon(Icons.menu_rounded),
            iconSize: 30.0,
            color: ConstantColors.black,
          ),
          title: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              ConstantMessages.PORTFOLIO_HEADER_TXT,
              style: GreekTextStyle.headline2,
            ),
          ),
          bottom: TabBar(
            tabs: const [
              Tab(
                text: ConstantMessages.GREEK_HOLDING_NAME,
              ),
              Tab(
                text: ConstantMessages.GREEK_POSITION_NAME,
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                GreekBase.portfolioStateObject = PortfolioScreenState.holding;
                selectedDropDownValues = [];
                selectedDropDownValues = ['LTP', 'Alphabetically', '% Change'];
                setState(() {
                  selectedIndex = 0;
                  _portfolioBloc.selectedIndexGlobal = 0;
                  SocketIOManager().holdingDataListRequest();
                  _portfolioBloc.hideSearchandtexFieldDispose();
                });
              } else {
                GreekBase.portfolioStateObject = PortfolioScreenState.position;
                selectedDropDownValues = [];
                selectedDropDownValues = ['LTP', 'Alphabetically'];
                setState(() {
                  selectedIndex = 1;
                  _portfolioBloc.selectedIndexGlobal = 1;
                  SocketIOManager().npDetailsRequest();
                  _portfolioBloc.hideSearchandtexFieldDispose();
                });
              }
            },
            labelStyle: GreekTextStyle.selected_portfolio_tab_label_blue,
            labelColor: GreekTextStyle.selected_tab_label_blue.color,
            unselectedLabelStyle:
                GreekTextStyle.unselected_portfolio_tab_label_blue,
            unselectedLabelColor:
                GreekTextStyle.unselected_tab_label_blue.color,
            labelPadding: EdgeInsets.zero,
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            _cardView(),
            StreamBuilder<bool>(
                stream: selectedIndex == 0
                    ? _portfolioBloc.hasHoldingData.stream
                    : _portfolioBloc.hasPositionData.stream,
                builder: (context, snapshot) {
                  if (snapshot.hasData && snapshot.data == true) {
                    return searchFillter();
                  } else {
                    return const SizedBox.shrink();
                  }
                }),
            Flexible(
              fit: FlexFit.loose,
              child: _listOrder(),
            ),
          ],
        ),
      ),
    );
  }

  Widget searchFillter() {
    return Container(
      padding: const EdgeInsets.only(top: 5, bottom: 0),
      child: Column(
        children: [
          StreamBuilder<bool>(
              stream: PortfolioBloc.searchWidgitVisiblity,
              builder: (context, snapshot) {
                if (snapshot.hasData && snapshot.data == false) {
                  return Row(children: [
                    Container(
                      padding: const EdgeInsets.only(top: 15, left: 10),
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {
                              PortfolioBloc.searchWidgitVisiblity.sink
                                  .add(false);
                            },
                            child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 10, top: 0, bottom: 0),
                                child: Image.asset(
                                  'lib/Resources/Icons/search_icon.png',
                                  fit: BoxFit.fitWidth,
                                  width: 22.0,
                                  height: 22.0,
                                )),
                          ),
                          InkWell(
                            onTap: () {
                              PortfolioBloc.searchWidgitVisiblity.sink
                                  .add(true);
                            },
                            child: const Padding(
                              padding:
                                  EdgeInsets.only(left: 10, top: 0, bottom: 0),
                              child: Text("Search",
                                  style: TextStyle(
                                    fontSize: 15,
                                  )),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              setState(() {});
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 17, top: 0, bottom: 0),
                              child: Image.asset(
                                'lib/Resources/Icons/watchlist_filter.png',
                                fit: BoxFit.fitWidth,
                                width: 22.0,
                                height: 22.0,
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {},
                            child: Column(
                              children: [
                                PopupMenuButton<String>(
                                  offset: const Offset(-5.0, 28),
                                  itemBuilder: (context) {
                                    return selectedDropDownValues
                                        .toSet()
                                        .map((str) {
                                      return PopupMenuItem(
                                        value: str,
                                        child: Row(
                                          children: [
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Image.asset(getImage(str)),
                                              // child: Image.asset(
                                              //   /*  str == "LTP"
                                              //       ? isltpacending
                                              //           ? 'assets/images/up_arrow_sort.png'
                                              //           : "assets/images/down_arrow_sort.png"
                                              //       : */
                                              //   isaphabetascending
                                              //       ? 'assets/images/up_arrow_sort.png'
                                              //       : "assets/images/down_arrow_sort.png",
                                              //   fit: BoxFit.fitWidth,
                                              //   width: 15.0,
                                              //   height: 15.0,
                                              // ),
                                            ),
                                            Text(
                                              str,
                                              style: GreekTextStyle
                                                  .marketStatisticsDropdownTextStyle,
                                            ),
                                          ],
                                        ),
                                      );
                                    }).toList();
                                  },
                                  child: const Padding(
                                    padding: EdgeInsets.only(
                                        left: 10, top: 5, bottom: 0),
                                    child: Text("Filter",
                                        style: TextStyle(
                                          fontSize: 15,
                                        )),
                                  ),
                                  onSelected: (data) {
                                    if (data.isNotEmpty) {
                                      selectedDropDownItem = data;
                                      _portfolioBloc
                                          .filterpopup(selectedDropDownItem);
                                      setState(() {
                                        selectedDropDownItem == "LTP"
                                            ? isltpacending = !isltpacending
                                            : selectedDropDownItem ==
                                                    "Alphabetically"
                                                ? isaphabetascending
                                                    ? isaphabetascending = false
                                                    : isaphabetascending = true
                                                : selectedDropDownItem ==
                                                        "% Change"
                                                    ? isperchangeAsending
                                                        ? isperchangeAsending =
                                                            false
                                                        : isperchangeAsending =
                                                            true
                                                    : null;
                                      });
                                    }
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]);
                } else {
                  return Row(
                    children: [
                      Flexible(
                        fit: FlexFit.tight,
                        child: Container(
                          height: 55,
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.only(left: 8, right: 8),
                          child: Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            elevation: 5.0,
                            child: TextField(
                              onChanged:
                                  _portfolioBloc.filterOrderListBySearchText,
                              controller:
                                  _portfolioBloc.searchTextFieldController,
                              autofocus: true,
                              maxLength: 20,
                              inputFormatters: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp("[0-9a-zA-Z]")),
                              ],
                              style: GreekTextStyle.headline1,
                              decoration: InputDecoration(
                                counterText: "",
                                border: InputBorder.none,
                                hintText: ConstantMessages.SEARCH_ORDER_MSG,
                                prefixIcon: Icon(
                                  Icons.search,
                                  color: Colors.black.withOpacity(0.45),
                                  size: 28.0,
                                ),
                                suffixIcon: IconButton(
                                  icon: const Icon(Icons.cancel_rounded),
                                  highlightColor: Colors.transparent,
                                  splashColor: Colors.transparent,
                                  onPressed: () {
                                    FocusScope.of(context).unfocus();
                                    PortfolioBloc.searchWidgitVisiblity.sink
                                        .add(false);

                                    _portfolioBloc.searchTextFieldController
                                        .clear();
                                    if (_portfolioBloc.selectedIndexGlobal ==
                                        0) {
                                      _portfolioBloc.actualHoldingDataList =
                                          _portfolioBloc
                                              .tempactualHoldingDataList;
                                      _portfolioBloc.holdingDataStream =
                                          _portfolioBloc
                                              .tempactualHoldingDataList
                                              .map((e) =>
                                                  BehaviorSubject.seeded(e))
                                              .toList();
                                      _portfolioBloc.mainStream.sink.add(true);
                                      setState(() {});
                                    } else {
                                      _portfolioBloc
                                              .actualportfolipositionlist =
                                          _portfolioBloc
                                              .tempactualportfolipositionlist;
                                      _portfolioBloc.positionStream =
                                          _portfolioBloc
                                              .tempactualportfolipositionlist
                                              .map((e) =>
                                                  BehaviorSubject.seeded(e))
                                              .toList();
                                      _portfolioBloc.mainStream.sink.add(true);
                                      setState(() {});
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }
              }),
          Container(
            height: 1,
            color: Colors.grey,
            margin:
                const EdgeInsets.only(left: 17, right: 17, top: 10, bottom: 10),
          ),
        ],
      ),
    );
  }

  String getImage(String imgType) {
    if (imgType == "LTP") {
      if (isltpacending) {
        return 'assets/images/up_arrow_sort.png';
      } else {
        return 'assets/images/down_arrow_sort.png';
      }
    } else if (imgType == "Alphabetically") {
      if (isaphabetascending) {
        return 'assets/images/up_arrow_sort.png';
      } else {
        return 'assets/images/down_arrow_sort.png';
      }
    } else if (imgType == "% Change") {
      if (isperchangeAsending) {
        return 'assets/images/up_arrow_sort.png';
      } else {
        return 'assets/images/down_arrow_sort.png';
      }
    }
    return 'assets/images/up_arrow_sort.png';
  }

  Widget _listOrder() {
    if (selectedIndex == 0) {
      return StreamBuilder<bool>(
          stream: _portfolioBloc.mainStream.stream,
          builder: (context, snapshot) {
            if (snapshot.hasData == true) {
              if (_portfolioBloc.actualHoldingDataList.isNotEmpty) {
                _portfolioBloc.hasHoldingData.sink.add(true);
                return SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: 500,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: _portfolioBloc.actualHoldingDataList.length,
                    itemBuilder: (context, index) {
                      finalTotalInvested = 0.00;
                      finalCurrentValue = 0.00;
                      finalPreviousValue = 0.00;
                      finalDaysPnL = 0.0;
                      for (int i = 0;
                          i < _portfolioBloc.actualHoldingDataList.length;
                          i++) {
                        var totalInvested = double.parse(_portfolioBloc
                                .actualHoldingDataList[i].hPrice
                                .toString()) *
                            double.parse(_portfolioBloc
                                .actualHoldingDataList[i].qty
                                .toString());
                        finalTotalInvested += totalInvested;
                        var currentValue = double.parse(_portfolioBloc
                                .actualHoldingDataList[i].ltp
                                .toString()) *
                            double.parse(_portfolioBloc
                                .actualHoldingDataList[i].qty
                                .toString());
                        // var previousValue = double.parse(_portfolioBloc.actualHoldingDataList[i].close.toString()) * double.parse(_portfolioBloc.actualHoldingDataList[i].qty.toString());
                        var mtm = (double.parse(_portfolioBloc
                                    .actualHoldingDataList[i].ltp
                                    .toString()) -
                                double.parse(_portfolioBloc
                                    .actualHoldingDataList[i].hPrice
                                    .toString())) *
                            int.parse(_portfolioBloc
                                .actualHoldingDataList[i].qty
                                .toString());
                        var daysmtm = (double.parse(_portfolioBloc
                                    .actualHoldingDataList[i].ltp
                                    .toString()) -
                                double.parse(_portfolioBloc
                                    .actualHoldingDataList[i].close
                                    .toString())) *
                            int.parse(_portfolioBloc
                                .actualHoldingDataList[i].qty
                                .toString());
                        finalCurrentValue = (finalCurrentValue) + currentValue;
                        // finalPreviousValue += previousValue;
                        finalDaysPnL = finalDaysPnL + daysmtm;
                        finalPreviousValue = (finalPreviousValue) + (mtm);
                      }
                      var balance = double.parse(finalCurrentValue.toString()) -
                          double.parse(finalTotalInvested.toString());
                      // var todays-PnL = double.parse(finalCurrentValue.toString()) - double.parse(finalPreviousValue.toString());
                      var todaysPnL = finalDaysPnL.toString();
                      _portfolioBloc.totalInvested.sink
                          .add(finalTotalInvested.toString());
                      _portfolioBloc.currentValue.sink
                          .add(finalCurrentValue.toString());
                      _portfolioBloc.currentBalance.sink
                          .add(balance.toString());
                      _portfolioBloc.todaysPnL.sink.add(todaysPnL.toString());
                      return StreamBuilder<holding.StockDetails>(
                          stream:
                              _portfolioBloc.holdingDataStream[index].stream,
                          builder: (context, snapshot) {
                            _portfolioBloc.update.sink.add("");
                            var invetstmentvalue =
                                double.parse(snapshot.data?.hPrice ?? "0") *
                                    double.parse(snapshot.data?.qty ?? "0");

                            var percentagevalue = ((double.parse(
                                            snapshot.data?.ltp ?? '0.00') -
                                        double.parse(
                                            snapshot.data?.hPrice ?? '0.00')) /
                                    double.parse(
                                        snapshot.data?.hPrice ?? "0.00")) *
                                100;
                            if (percentagevalue.toString().toLowerCase() ==
                                "infinity") {
                              percentagevalue = double.parse("0.00");
                            }
                            snapshot.data?.perchange = percentagevalue;

                            return Dismissible(
                              key: Key(index.toString()),
                              background: Container(
                                color: ConstantColors.buyColor,
                                padding: const EdgeInsets.only(left: 20.0),
                                margin: const EdgeInsets.only(
                                    top: 15.0, bottom: 25),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    'BUY',
                                    style: GreekTextStyle.heading16,
                                  ),
                                ),
                              ),
                              direction: DismissDirection.horizontal,
                              secondaryBackground: Container(
                                color: ConstantColors.sellColor,
                                padding: const EdgeInsets.only(right: 20.0),
                                margin: const EdgeInsets.only(
                                    top: 15.0, bottom: 25),
                                child: Align(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    'SELL',
                                    style: GreekTextStyle.heading16,
                                  ),
                                ),
                              ),
                              confirmDismiss:
                                  (DismissDirection direction) async {
                                // watchBloc?.unSubscribeLTPInfo();

                                await callBuySellForHolding(
                                    snapshot, context, direction);
                                return null;

                                // print('tokennnnnn ==== ${snapshot.data?.nSEToken ?? ''}');

                                /* if (popResult == PopAction.rebuildWidget) {
                                              watchBloc?.getWatchListDataByGroupName();
                                            }*/
                              },
                              child: TextButton(
                                  onPressed: () async {
                                    //  print('Clicked Here: ${snapshot.data}');

                                    // var nsetoken = int.parse(snapshot.data!.nSEToken.toString());
                                    // var bsetoken = int.parse(snapshot.data!.bSEToken.toString());
                                    // String token = ((nsetoken > 0)
                                    //         ? nsetoken.toString()
                                    //         : (bsetoken > 0)
                                    //             ? bsetoken
                                    //             : '0')
                                    //     .toString();
                                    // int tokenType = int.parse(token);

                                    // _portfolioBloc.showBottomSheetForHoldingDetailsInfo(context, _portfolioBloc.actualHoldingDataList[index], _portfolioBloc, index);
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(0.0),
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          height: 75.0,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  top: 1,
                                                  left: 12.0,
                                                  right: 12.0,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Text(
                                                          "Qty",
                                                          style: GreekTextStyle
                                                              .position_row_text_style,
                                                        ),
                                                        Text(
                                                          " ${snapshot.data?.qty ?? '0'}",
                                                          style: GreekTextStyle
                                                              .position_row_text_style,
                                                        ),
                                                        Text(
                                                          " @ Avg ${double.parse(snapshot.data?.hPrice ?? '0.00').toStringAsFixed(2)} ",
                                                          style: GreekTextStyle
                                                              .position_row_text_style,
                                                        ),
                                                      ],
                                                    ),
                                                    Text(
                                                      "${double.parse(percentagevalue.toString()) > 0 ? "+" + double.parse(percentagevalue.toString()).toStringAsFixed(2) : double.parse(percentagevalue.toString()).toStringAsFixed(2)}%",
                                                      style: GreekTextStyle
                                                          .position_row_text_style,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  top: 10,
                                                  left: 12.0,
                                                  right: 12.0,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      (snapshot.data?.symbol ??
                                                              '') +
                                                          '  ' +
                                                          (snapshot.data
                                                                  ?.instrument ??
                                                              ''),
                                                      style: GreekTextStyle
                                                          .heading19,
                                                    ),
                                                    Text(
                                                      (((double.parse(snapshot
                                                                          .data
                                                                          ?.ltp ??
                                                                      '0.00')) -
                                                                  (double.parse(snapshot
                                                                          .data
                                                                          ?.hPrice ??
                                                                      '0.00'))) *
                                                              (int.parse(snapshot
                                                                      .data
                                                                      ?.qty ??
                                                                  '0')))
                                                          .toStringAsFixed(2),
                                                      style: TextStyle(
                                                        color: getColor((((double
                                                                    .parse(snapshot
                                                                            .data
                                                                            ?.ltp ??
                                                                        '0.00')) -
                                                                (double.parse(snapshot
                                                                        .data
                                                                        ?.hPrice ??
                                                                    '0.00'))) *
                                                            (int.parse(snapshot
                                                                    .data
                                                                    ?.qty ??
                                                                '0')))),
                                                        fontSize: 15.0,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 12.0,
                                                    right: 12.0,
                                                    top: 5.0),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      "Invested ${invetstmentvalue.toStringAsFixed(2)}",
                                                      style: GreekTextStyle
                                                          .position_row_text_style,
                                                    ),
                                                    Text(
                                                      "LTP  ${double.parse(snapshot.data?.ltp ?? '0.00').toStringAsFixed(2)}",
                                                      style: GreekTextStyle
                                                          .position_row_text_style,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.only(
                                              top: 10, left: 10, right: 10),
                                          height: 0.5,
                                          color: const Color(0xFF707070),
                                        )
                                      ],
                                    ),
                                  )),
                            );
                          });
                    },
                  ),
                );
              } else {
                if (_portfolioBloc.searchTextFieldController.text.isNotEmpty) {
                  _portfolioBloc.hasHoldingData.sink.add(true);
                } else {
                  _portfolioBloc.hasHoldingData.sink.add(false);
                }
                return SizedBox(
                  height: MediaQuery.of(context).size.height / 2,
                  child: Center(child: GreekBase().noDataAvailableView()),
                );
              }
            } else {
              _portfolioBloc.hasHoldingData.sink.add(false);
              return SizedBox(
                height: MediaQuery.of(context).size.height / 2,
                child: Center(child: GreekBase().noDataAvailableView()),
              );
            }
          });
    } else {
      return StreamBuilder<bool>(
          stream: _portfolioBloc.mainStream.stream,
          builder: (context, snapshot) {
            if (snapshot.hasData == true) {
              if (_portfolioBloc.actualportfolipositionlist.isNotEmpty) {
                _portfolioBloc.hasPositionData.sink.add(true);
                return SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: 500,
                  child: ListView.builder(
                      shrinkWrap: true,
                      itemCount:
                          _portfolioBloc.actualportfolipositionlist.length,
                      itemBuilder: (context, index) {
                        _portfolioBloc.update.sink.add("");
                        return StreamBuilder<StockDetailss>(
                            stream: _portfolioBloc.positionStream[index].stream,
                            builder: (context, snapshot) {
                              //calculate mtm and price start
                              if (snapshot.hasData) {
                                var productType = _portfolioBloc
                                    .getProductType(snapshot.data?.productType);

                                double mtm = _portfolioBloc.calculateMTM(index);
                                var investment = double.parse(
                                        snapshot.data!.buysellqty.toString()) *
                                    (snapshot.data!.netAvg.toString() ==
                                            "Infinity"
                                        ? double.parse("0.00")
                                        : double.parse(
                                            snapshot.data!.netAvg.toString()));

                                //calculate mtm and price close
                                _portfolioBloc.update.sink.add("");

                                return Dismissible(
                                  key: Key(index.toString()),
                                  background: Container(
                                    color: ConstantColors.buyColor,
                                    padding: const EdgeInsets.only(left: 20.0),
                                    margin: const EdgeInsets.only(
                                        top: 15.0, bottom: 25),
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        'BUY',
                                        style: GreekTextStyle.heading16,
                                      ),
                                    ),
                                  ),
                                  direction: DismissDirection.horizontal,
                                  secondaryBackground: Container(
                                    color: ConstantColors.sellColor,
                                    padding: const EdgeInsets.only(left: 20.0),
                                    margin: const EdgeInsets.only(
                                        top: 15.0, bottom: 25),
                                    child: Align(
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        'SELL',
                                        style: GreekTextStyle.heading16,
                                      ),
                                    ),
                                  ),
                                  confirmDismiss:
                                      (DismissDirection direction) async {
                                    // watchBloc?.unSubscribeLTPInfo();

                                    await callBuySellForPosition(
                                        snapshot, context, direction);
                                    return null;

                                    // print('tokennnnnn ==== ${snapshot.data?.nSEToken ?? ''}');

                                    /* if (popResult == PopAction.rebuildWidget) {
                                                watchBloc?.getWatchListDataByGroupName();
                                              }*/
                                  },
                                  child: TextButton(
                                    onPressed: () {
                                      // GreekBase().productChangeParm = Tuple3(_portfolioBloc.actualportfolipositionlist[index], index, _portfolioBloc.positionStream);
                                      // GreekBase().commonListenObserver.sink.add(CommonListenID.productChnage);
                                      _portfolioBloc
                                          .showPositionDetailBottomSheet(
                                              context,
                                              _portfolioBloc
                                                      .actualportfolipositionlist[
                                                  index],
                                              index);
                                    },
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          height: 75.0,
                                          child: Column(
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  top: 1,
                                                  left: 12.0,
                                                  right: 12.0,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Text(
                                                          "Qty",
                                                          style: GreekTextStyle
                                                              .position_row_text_style,
                                                        ),
                                                        Text(
                                                          " ${double.parse(snapshot.data?.buysellqty ?? '0').toStringAsFixed(0)}",
                                                          style: GreekTextStyle
                                                              .position_row_text_style,
                                                        ),
                                                        Text(
                                                          " @ ${snapshot.data?.buyselltext} -  ${int.parse(snapshot.data?.token ?? "0").toAssetType().toString() != "currency" ? snapshot.data?.netAvg.toString() == "Infinity" ? "0.00" : double.parse(snapshot.data?.netAvg ?? '0.00').toStringAsFixed(2) : double.parse(snapshot.data?.netAvg ?? '0.00').toStringAsFixed(4)} ",
                                                          style: GreekTextStyle
                                                              .position_row_text_style,
                                                        ),
                                                      ],
                                                    ),
                                                    Text(
                                                      productType,
                                                      style: GreekTextStyle
                                                          .position_row_text_style,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  top: 10,
                                                  left: 12.0,
                                                  right: 12.0,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      "${snapshot.data?.tradeSymbol ?? ''} " +
                                                          int.parse(snapshot
                                                                      .data
                                                                      ?.token ??
                                                                  "0")
                                                              .toExchange()
                                                              .toString(),
                                                      style: GreekTextStyle
                                                          .heading19,
                                                    ),
                                                    Text(
                                                      (int.parse(snapshot.data
                                                                          ?.token ??
                                                                      "0")
                                                                  .toAssetType()
                                                                  .toString() !=
                                                              "currency"
                                                          ? double.parse(mtm
                                                                  .toString())
                                                              .toStringAsFixed(
                                                                  2)
                                                          : double.parse(mtm
                                                                  .toString())
                                                              .toStringAsFixed(
                                                                  4)),
                                                      style: TextStyle(
                                                        color: getColor(
                                                            (double.parse(mtm
                                                                .toString()))),
                                                        fontSize: 15.0,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  top: 10,
                                                  left: 12.0,
                                                  right: 12.0,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      "Invested  ${int.parse(snapshot.data?.token ?? "0").toAssetType().toString() != "currency" ? double.parse(investment.toString()).toStringAsFixed(2) : double.parse(investment.toString()).toStringAsFixed(4)} ",
                                                      style: GreekTextStyle
                                                          .position_row_text_style,
                                                    ),
                                                    Text(
                                                      "LTP ${int.parse(snapshot.data?.token ?? "0").toAssetType().toString() != "currency" ? double.parse(snapshot.data?.ltp ?? '0.00').toStringAsFixed(2) : double.parse(snapshot.data?.ltp ?? '0.00').toStringAsFixed(4)}",
                                                      style: GreekTextStyle
                                                          .position_row_text_style,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.only(
                                              top: 5, left: 10, right: 10),
                                          height: 0.5,
                                          color: const Color(0xFF707070),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              } else {
                                return Container();
                              }
                            });
                      }),
                );
              } else {
                if (_portfolioBloc.searchTextFieldController.text.isNotEmpty) {
                  _portfolioBloc.hasPositionData.sink.add(true);
                } else {
                  _portfolioBloc.hasPositionData.sink.add(false);
                }

                return SizedBox(
                  height: MediaQuery.of(context).size.height / 2,
                  child: Center(child: GreekBase().noDataAvailableView()),
                );
              }
            } else {
              _portfolioBloc.hasPositionData.sink.add(false);
              return SizedBox(
                height: MediaQuery.of(context).size.height / 2,
                child: Center(child: GreekBase().noDataAvailableView()),
              );
            }
          });
    }
  }

  Widget _cardView() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
      child: (Card(
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: StreamBuilder<Object>(
            stream: _portfolioBloc.update.stream,
            builder: (context, snapshot) {
              if (_portfolioBloc.selectedIndexGlobal == 1) {
                finalTotalInvested = 0.00;
                finalCurrentValue = 0.00;
                finalPreviousValue = 0.00;
                finalDaysPnL = 0.0;
                for (int i = 0;
                    i < _portfolioBloc.actualportfolipositionlist.length;
                    i++) {
                  var previousValue = _portfolioBloc.calculateMTM(i);
                  finalPreviousValue += previousValue;
                }
                //var todays_PnL = double.parse(finalDaysPnL.toStringAsFixed(2));

                _portfolioBloc.positionPnL.sink
                    .add(finalPreviousValue.toStringAsFixed(2));
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(25),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Container(
                              alignment: Alignment.centerRight,
                              child: Text(
                                "P&L",
                                style: GreekTextStyle.unselected_tab_label_blue,
                              ),
                            ),
                          ),
                          Container(
                            width: 75,
                            height: 20,
                            alignment: Alignment.center,
                            child: const Text(
                              "-",
                            ),
                          ),
                          Expanded(
                            child: Container(
                              alignment: Alignment.centerLeft,
                              child: StreamBuilder<String>(
                                stream: _portfolioBloc.positionPnL.stream,
                                builder: (context, snapshot) {
                                  return Text(
                                    snapshot.data.toString(),
                                    style: TextStyle(
                                      fontFamily: 'CenturyGothic',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                      color: getColor(double.parse(
                                          snapshot.data?.toString() ?? '0.00')),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              } else {
                finalTotalInvested = 0.00;
                finalCurrentValue = 0.00;
                finalPreviousValue = 0.00;
                finalDaysPnL = 0.0;
                for (int i = 0;
                    i < _portfolioBloc.actualHoldingDataList.length;
                    i++) {
                  var totalInvested = double.parse(_portfolioBloc
                          .actualHoldingDataList[i].hPrice
                          .toString()) *
                      double.parse(_portfolioBloc.actualHoldingDataList[i].qty
                          .toString());
                  finalTotalInvested += totalInvested;
                  var currentValue = double.parse(_portfolioBloc
                          .actualHoldingDataList[i].ltp
                          .toString()) *
                      double.parse(_portfolioBloc.actualHoldingDataList[i].qty
                          .toString());
                  // var previousValue = double.parse(_portfolioBloc.actualHoldingDataList[i].close.toString()) * double.parse(_portfolioBloc.actualHoldingDataList[i].qty.toString());
                  var totalMTM = (double.parse(_portfolioBloc
                              .actualHoldingDataList[i].ltp
                              .toString()) -
                          double.parse(_portfolioBloc
                              .actualHoldingDataList[i].hPrice
                              .toString())) *
                      int.parse(_portfolioBloc.actualHoldingDataList[i].qty
                          .toString());
                  var daysMTM = (double.parse(_portfolioBloc
                              .actualHoldingDataList[i].ltp
                              .toString()) -
                          double.parse(_portfolioBloc
                              .actualHoldingDataList[i].close
                              .toString())) *
                      int.parse(_portfolioBloc.actualHoldingDataList[i].qty
                          .toString());

                  finalCurrentValue = (finalCurrentValue) + (currentValue);
                  // finalPreviousValue += previousValue;
                  finalPreviousValue = (finalPreviousValue) + (totalMTM);
                  finalDaysPnL = finalDaysPnL + daysMTM;
                }
                var balance = double.parse(finalCurrentValue.toString()) -
                    double.parse(finalTotalInvested.toString());
                // var todays_PnL = double.parse(finalCurrentValue.toString()) - double.parse(finalPreviousValue.toString());
                var todaysPnL = finalDaysPnL;
                _portfolioBloc.totalInvested.sink
                    .add(finalTotalInvested.toStringAsFixed(2));
                _portfolioBloc.currentValue.sink
                    .add(finalCurrentValue.toStringAsFixed(2));
                _portfolioBloc.currentBalance.sink
                    .add(balance.toStringAsFixed(2));
                _portfolioBloc.todaysPnL.sink.add(todaysPnL.toStringAsFixed(2));

                return SizedBox(
                  height: 170,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 18, left: 12.0, right: 12.0, bottom: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "TOTAL INVESTED",
                                  style:
                                      GreekTextStyle.unselected_tab_label_blue,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: Text(
                                  "CURRENT VALUE",
                                  style:
                                      GreekTextStyle.unselected_tab_label_blue,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 8, left: 12.0, right: 12.0, bottom: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              alignment: Alignment.centerLeft,
                              child: StreamBuilder<String>(
                                stream: _portfolioBloc.totalInvested.stream,
                                builder: (context, snapshot) {
                                  return Text(
                                    double.parse(snapshot.data ?? '0.00')
                                        .toStringAsFixed(2),
                                    style: GreekTextStyle.headline1,
                                  );
                                },
                              ),
                            ),
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: StreamBuilder<String>(
                                  stream: _portfolioBloc.currentValue.stream,
                                  builder: (context, snapshot) {
                                    return Text(
                                      double.parse(snapshot.data ?? '0.00')
                                          .toStringAsFixed(2),
                                      style: GreekTextStyle.headline1,
                                    );
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 8, left: 12.0, right: 12.0, bottom: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "DAY'S P&L",
                                  style:
                                      GreekTextStyle.unselected_tab_label_blue,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: Text(
                                  "OVERALL P&L",
                                  style:
                                      GreekTextStyle.unselected_tab_label_blue,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 8, left: 12.0, right: 12.0, bottom: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerLeft,
                                child: StreamBuilder<String>(
                                  stream: _portfolioBloc.todaysPnL.stream,
                                  builder: (context, snapshot) {
                                    return Text(
                                      double.parse(snapshot.data ?? '0.00')
                                          .toStringAsFixed(2),
                                      style: TextStyle(
                                        fontFamily: 'CenturyGothic',
                                        fontSize: 15.0,
                                        fontWeight: FontWeight.bold,
                                        color: getColor(double.parse(
                                            snapshot.data?.toString() ??
                                                '0.00')),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                alignment: Alignment.centerRight,
                                child: StreamBuilder<String>(
                                  stream: _portfolioBloc.currentBalance.stream,
                                  builder: (context, snapshot) {
                                    return Text(
                                      double.parse(snapshot.data ?? '0.00')
                                          .toStringAsFixed(2),
                                      style: GreekTextStyle.headline1,
                                    );
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }
            }),
      )),
    );
  }

  Future<void> callBuySellForHolding(AsyncSnapshot<StockDetails> snapshot,
      BuildContext streamContext, DismissDirection direction) async {
    if (snapshot.data?.nSEToken != '' && snapshot.data?.bSEToken != '') {
      if ((snapshot.data?.nSEToken != '0') &&
          (snapshot.data?.nSEToken != '0')) {
        if ((snapshot.data?.nSEToken?.startsWith('101') == false) &&
            (snapshot.data?.bSEToken?.startsWith('101') == false)) {
          await GreekNavigator.pushNamed(
            context: streamContext,
            routeName: GreekScreenNames.place_order,
            arguments: [
              int.parse(snapshot.data?.nSEToken ?? '0'),
              (direction == DismissDirection.startToEnd)
                  ? OrderAction.buy
                  : OrderAction.sell,
              OrderMode.newOrder,
              ScriptInfoTab.order.index,
            ],
          );
        } else if ((snapshot.data?.nSEToken?.startsWith('201') == false) &&
            (snapshot.data?.bSEToken?.startsWith('201') == false)) {
          await GreekNavigator.pushNamed(
            context: streamContext,
            routeName: GreekScreenNames.place_order,
            arguments: [
              int.parse(snapshot.data?.bSEToken ?? '0'),
              (direction == DismissDirection.startToEnd)
                  ? OrderAction.buy
                  : OrderAction.sell,
              OrderMode.newOrder,
              ScriptInfoTab.order.index,
            ],
          );
        } else {
          GreekDialogPopupView.selectExchangeForHolding(
              context, snapshot, direction);
        }
      } else if (snapshot.data?.nSEToken == "0") {
        await GreekNavigator.pushNamed(
          context: streamContext,
          routeName: GreekScreenNames.place_order,
          arguments: [
            int.parse(snapshot.data?.bSEToken ?? '0'),
            (direction == DismissDirection.startToEnd)
                ? OrderAction.buy
                : OrderAction.sell,
            OrderMode.newOrder,
            ScriptInfoTab.order.index,
          ],
        );
      } else if (snapshot.data?.bSEToken == "0") {
        await GreekNavigator.pushNamed(
          context: streamContext,
          routeName: GreekScreenNames.place_order,
          arguments: [
            int.parse(snapshot.data?.nSEToken ?? '0'),
            (direction == DismissDirection.startToEnd)
                ? OrderAction.buy
                : OrderAction.sell,
            OrderMode.newOrder,
            ScriptInfoTab.order.index,
          ],
        );
      }
    }
  }

  Future<void> callBuySellForPosition(AsyncSnapshot<StockDetailss> snapshot,
      BuildContext streamContext, DismissDirection direction) async {
    /*    if (snapshot.data?.nSEToken != '' && snapshot.data?.bSEToken != '') {
      if ((snapshot.data?.nSEToken != '0') && (snapshot.data?.nSEToken != '0')) {
        if ((snapshot.data?.nSEToken?.startsWith('101') == false) && (snapshot.data?.bSEToken?.startsWith('101') == false)) {
          await GreekNavigator.pushNamed(
            context: streamContext,
            routeName: GreekScreenNames.place_order,
            arguments: [
              int.parse(snapshot.data?.nSEToken ?? '0'),
              (direction == DismissDirection.startToEnd) ? OrderAction.buy : OrderAction.sell,
              OrderMode.newOrder,
              ScriptInfoTab.order.index,
            ],
          );
        } 
        else if ((snapshot.data?.nSEToken?.startsWith('201') == false) && (snapshot.data?.bSEToken?.startsWith('201') == false)) {
          await GreekNavigator.pushNamed(
            context: streamContext,
            routeName: GreekScreenNames.place_order,
            arguments: [
              int.parse(snapshot.data?.bSEToken ?? '0'),
              (direction == DismissDirection.startToEnd) ? OrderAction.buy : OrderAction.sell,
              OrderMode.newOrder,
              ScriptInfoTab.order.index,
            ],
          );
        } 
        else {
          GreekDialogPopupView.selectExchangeForPosition(context, snapshot, direction);
        }
      } 
      else if (snapshot.data?.nSEToken == "0") {
        await GreekNavigator.pushNamed(
          context: streamContext,
          routeName: GreekScreenNames.place_order,
          arguments: [
            int.parse(snapshot.data?.bSEToken ?? '0'),
            (direction == DismissDirection.startToEnd) ? OrderAction.buy : OrderAction.sell,
            OrderMode.newOrder,
            ScriptInfoTab.order.index,
          ],
        );
      } 
      else if (snapshot.data?.bSEToken == "0") {
        await GreekNavigator.pushNamed(
          context: streamContext,
          routeName: GreekScreenNames.place_order,
          arguments: [
            int.parse(snapshot.data?.nSEToken ?? '0'),
            (direction == DismissDirection.startToEnd) ? OrderAction.buy : OrderAction.sell,
            OrderMode.newOrder,
            ScriptInfoTab.order.index,
          ],
        );
      }
    } */

    await GreekNavigator.pushNamed(
      context: streamContext,
      routeName: GreekScreenNames.place_order,
      arguments: [
        int.parse(snapshot.data?.token ?? '0'),
        (direction == DismissDirection.startToEnd)
            ? OrderAction.buy
            : OrderAction.sell,
        OrderMode.newOrder,
        ScriptInfoTab.order.index,
      ],
    );
  }
}

Color getColor(number) {
  if (number > 0) {
    return ConstantColors.buyColor;
  } else {
    return ConstantColors.sellColor;
  }
}
