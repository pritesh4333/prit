import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';

class WatchlistFilterDialog extends StatefulWidget {
  final WatchListBloc _watchListBloc;
  const WatchlistFilterDialog(BuildContext popContext, this._watchListBloc,
      {Key? key})
      : super(key: key);

  @override
  State<WatchlistFilterDialog> createState() => _WatchlistFilterDialogState();
}

class _WatchlistFilterDialogState extends State<WatchlistFilterDialog> {
  // final bool _isIndexVisiable = false;
  bool showsorting = true;
  bool isChangeChecked = false;
  bool isAlphabeticallyChecked = false;
  bool isLTPChecked = false;

  bool isascendingpchange = false;

  List<String> sortingListValues = ['NSE', 'BSE'];

  bool isltpuparrow = false;
  bool isltpdownarrow = false;
  bool isltpclick = true;

  bool isalphabetup = false;
  bool isalphabetdown = false;
  bool isalphabetclick = true;

  bool ispchangeup = false;
  bool ispchangedown = false;

  @override
  Widget build(BuildContext context) {
    sortingListValues = [];

    for (var item in GreekBase().marketSegments) {
      if (item == MarketSegment.nseeq ||
          item == MarketSegment.nsefo ||
          item == MarketSegment.nsecd ||
          item == MarketSegment.nsecomm) {
        if (!sortingListValues.contains("NSE")) {
          sortingListValues.add("NSE");
        }
      }

      if (item == MarketSegment.bseeq ||
          item == MarketSegment.bsefo ||
          item == MarketSegment.bsecd ||
          item == MarketSegment.bsecomm) {
        if (!sortingListValues.contains("BSE")) {
          sortingListValues.add("BSE");
        }
      }

      if (item == MarketSegment.mcx) {
        if (!sortingListValues.contains("MCX")) {
          sortingListValues.add("MCX");
        }
      }

      if (item == MarketSegment.ncdex) {
        if (!sortingListValues.contains("NCDEX")) {
          sortingListValues.add("NCDEX");
        }
      }
    }

    return Container(
      height: 320,
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Filter',
                style: GreekTextStyle.watchlistFilterText,
              ),
              TextButton(
                  onPressed: () {
                    GreekNavigator.pop(context: context);
                    /*    if (isChangeChecked == true) {
                      setState(() {
                        widget._watchListBloc.sortByChange = true;
                        widget._watchListBloc.sortAlphabetically = false;
                        widget._watchListBloc.sortByLTP = false;
                        widget._watchListBloc.pchangeascending =
                            isascendingpchange;

                        widget._watchListBloc.alphabetascending = false;

                        widget._watchListBloc.lastascending = false;

                        widget._watchListBloc.preparSymbolList();
                      });
                    } else */
                    /*  if (isAlphabeticallyChecked == true) {
                      setState(() {
                        widget._watchListBloc.sortAlphabetically = true;
                        widget._watchListBloc.sortByChange = false;
                        widget._watchListBloc.sortByLTP = false;

                        widget._watchListBloc.alphabetascending =
                            widget._watchListBloc.isacendingalphabet;

                        widget._watchListBloc.preparSymbolList();
                      });
                    } else */
                    /*    if (isLTPChecked == true) {
                      setState(() {
                        widget._watchListBloc.sortByLTP = true;
                        widget._watchListBloc.sortAlphabetically = false;
                        widget._watchListBloc.sortByChange = false;
                        widget._watchListBloc.lastascending =
                            widget._watchListBloc.isacendingLTP;
                        widget._watchListBloc.preparSymbolList();
                      });
                    } */ /* else {
                                                _watchListBloc
                                                        ?.sortAlphabetically =
                                                    false;
                                                _watchListBloc?.sortByChange =
                                                    false;
                                                _watchListBloc?.sortByLTP =
                                                    false;
                                                _watchListBloc
                                                        ?.alphabetascending =
                                                    isacendingalphabet;
                                                _watchListBloc
                                                    ?.preparSymbolList();
                                              } */
                  },
                  child: Text(
                    'Apply',
                    style: GreekTextStyle.watchlistFilterText_blue,
                  )),
            ],
          ),
          Container(
            height: 30,
            margin: const EdgeInsets.only(top: 30.0),
            alignment: Alignment.centerLeft,
            child: ListView.builder(
              itemCount: sortingListValues.length,
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemBuilder: (BuildContext context, index) {
                return Container(
                  height: 30,
                  width: 60,
                  margin: const EdgeInsets.only(left: 5.0, right: 5.0),
                  decoration: BoxDecoration(
                    color: widget._watchListBloc.sortValueIndex == index
                        ? Colors.blue
                        : Colors.white,
                    borderRadius: BorderRadius.circular(8.0),
                    border: Border.all(
                      color: Colors.black,
                      width: 0.5,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.grey,
                        blurRadius: 2.0,
                      ),
                    ],
                  ),
                  child: TextButton(
                      onPressed: () {
                        setState(() {
                          showsorting = false;
                        });

                        if (sortingListValues[index] == "NSE") {
                          setState(() {
                            widget._watchListBloc.sortValueIndex = index;
                            widget._watchListBloc.filterClick = true;
                            widget._watchListBloc.nseclick = true;
                            widget._watchListBloc.bseclick = false;
                            widget._watchListBloc.mcxclick = false;
                            widget._watchListBloc.ncdexclick = false;
                            widget._watchListBloc.preparSymbolList();
                          });
                        } else if (sortingListValues[index] == "BSE") {
                          setState(() {
                            widget._watchListBloc.sortValueIndex = index;
                            // sortValueIndex = 0;
                            widget._watchListBloc.filterClick = true;
                            widget._watchListBloc.bseclick = true;
                            widget._watchListBloc.nseclick = false;

                            widget._watchListBloc.mcxclick = false;
                            widget._watchListBloc.ncdexclick = false;
                            widget._watchListBloc.preparSymbolList();
                          });
                        } else if (sortingListValues[index] == "MCX") {
                          setState(() {
                            widget._watchListBloc.sortValueIndex = index;
                            // sortValueIndex = 0;
                            widget._watchListBloc.filterClick = true;
                            widget._watchListBloc.mcxclick = true;
                            widget._watchListBloc.nseclick = false;
                            widget._watchListBloc.bseclick = false;
                            widget._watchListBloc.ncdexclick = false;

                            widget._watchListBloc.preparSymbolList();
                          });
                        } else if (sortingListValues[index] == "NCDEX") {
                          setState(() {
                            widget._watchListBloc.sortValueIndex = index;
                            // sortValueIndex = 0;
                            widget._watchListBloc.filterClick = true;
                            widget._watchListBloc.mcxclick = false;
                            widget._watchListBloc.nseclick = false;
                            widget._watchListBloc.bseclick = false;
                            widget._watchListBloc.ncdexclick = true;

                            widget._watchListBloc.preparSymbolList();
                          });
                        }
                      },
                      child: Text(
                        sortingListValues[index],
                        style: TextStyle(
                            color: widget._watchListBloc.sortValueIndex == index
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.normal,
                            fontSize: 12),
                      )),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          const Divider(
            height: 2,
            color: Colors.black,
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Sort',
                style: GreekTextStyle.watchlistFilterText,
              ),
            ],
          ),
          Column(
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    widget._watchListBloc.filterClick = false;
                    isChangeChecked = true;
                    isAlphabeticallyChecked = false;
                    isLTPChecked = false;
                    widget._watchListBloc.isacendingchange == false
                        ? widget._watchListBloc.isacendingchange = true
                        : widget._watchListBloc.isacendingchange = false;

                    /*  isascendingpchange == false
                        ? isascendingpchange = true
                        : isascendingpchange = false; */

                    widget._watchListBloc.isacendingalphabet = false;
                    widget._watchListBloc.isacendingLTP = false;

                    if (isChangeChecked == true) {
                      widget._watchListBloc.sortByChange = true;
                      widget._watchListBloc.sortAlphabetically = false;
                      widget._watchListBloc.sortByLTP = false;
                      widget._watchListBloc.pchangeascending =
                          widget._watchListBloc.isacendingchange;

                      widget._watchListBloc.alphabetascending = false;

                      widget._watchListBloc.lastascending = false;

                      widget._watchListBloc.preparSymbolList();
                    }
                  });

                  GreekNavigator.pop(context: context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      icon: (widget._watchListBloc.isacendingchange)
                          ? Image.asset(
                              'assets/images/up_arrow_sort.png',
                              fit: BoxFit.fitWidth,
                            )
                          : Image.asset(
                              'assets/images/down_arrow_sort.png',
                              fit: BoxFit.fitWidth,
                            ),
                      onPressed: () {},
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "% Change",
                        style: GreekTextStyle.headline21,
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  setState(() {
                    widget._watchListBloc.filterClick = false;
                    isChangeChecked = false;
                    isAlphabeticallyChecked = true;
                    isLTPChecked = false;
                    widget._watchListBloc.isacendingalphabet == false
                        ? widget._watchListBloc.isacendingalphabet = true
                        : widget._watchListBloc.isacendingalphabet = false;

                    if (isAlphabeticallyChecked == true) {
                      widget._watchListBloc.sortAlphabetically = true;
                      widget._watchListBloc.sortByChange = false;
                      widget._watchListBloc.sortByLTP = false;

                      widget._watchListBloc.alphabetascending =
                          widget._watchListBloc.isacendingalphabet;

                      widget._watchListBloc.preparSymbolList();
                    }
                  });

                  GreekNavigator.pop(context: context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    /* Checkbox(
                                            checkColor: Colors.white,
                                            fillColor:
                                                MaterialStateProperty.resolveWith(
                                                    getColor),
                                            value: isAlphabeticallyChecked,
                                            onChanged: (value) {
                                              setState(
                                                () {
                                                  isAlphabeticallyChecked = true;
                                                  isChangeChecked = false;
                                                  isLTPChecked = false;
                                                },
                                              );
                                            },
                                          ), */
                    IconButton(
                      icon: (widget._watchListBloc.isacendingalphabet)
                          ? Image.asset(
                              'assets/images/up_arrow_sort.png',
                              fit: BoxFit.fitWidth,
                            )
                          : Image.asset(
                              'assets/images/down_arrow_sort.png',
                              fit: BoxFit.fitWidth,
                            ),
                      onPressed: () {
                        setState(() {
                          isChangeChecked = false;
                          isAlphabeticallyChecked = true;
                          isLTPChecked = false;
                          widget._watchListBloc.isacendingalphabet == false
                              ? widget._watchListBloc.isacendingalphabet = true
                              : widget._watchListBloc.isacendingalphabet =
                                  false;
                        });
                      },
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Alphabetically",
                          style: GreekTextStyle.headline21,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  setState(() {
                    widget._watchListBloc.filterClick = false;
                    isLTPChecked = true;
                    isChangeChecked = false;
                    isAlphabeticallyChecked = false;
                    widget._watchListBloc.isacendingLTP =
                        !(widget._watchListBloc.isacendingLTP);
                    if (isLTPChecked == true) {
                      widget._watchListBloc.sortByLTP = true;
                      widget._watchListBloc.sortAlphabetically = false;
                      widget._watchListBloc.sortByChange = false;
                      widget._watchListBloc.lastascending =
                          widget._watchListBloc.isacendingLTP;
                      widget._watchListBloc.preparSymbolList();
                    }
                  });

                  GreekNavigator.pop(context: context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    /*  Checkbox(
                                            checkColor: Colors.white,
                                            fillColor:
                                                MaterialStateProperty.resolveWith(
                                                    getColor),
                                            value: isLTPChecked,
                                            onChanged: (value) {
                                              setState(() {
                                                isLTPChecked = true;
                                                isChangeChecked = false;
                                                isAlphabeticallyChecked = false;
                                              });
                                            },
                                          ), */

                    IconButton(
                      icon: (widget._watchListBloc.isacendingLTP)
                          ? Image.asset(
                              'assets/images/up_arrow_sort.png',
                              fit: BoxFit.fitWidth,
                            )
                          : Image.asset(
                              'assets/images/down_arrow_sort.png',
                              fit: BoxFit.fitWidth,
                            ),
                      onPressed: () {
                        isLTPChecked = true;
                        isChangeChecked = false;
                        isAlphabeticallyChecked = false;
                        widget._watchListBloc.isacendingLTP =
                            !(widget._watchListBloc.isacendingLTP);
                      },
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Last Traded Price",
                          style: GreekTextStyle.headline21,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
