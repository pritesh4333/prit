import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/streaming_data_source.dart';
import 'package:greek_ibt_app/Network_Manager/Socket-IO/socket_io_manager.dart';
import 'package:greek_ibt_app/Screens/Portfolio/bloc/watch_list_bloc.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/indian_indicesdata_response_model.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/models/watchlist_response_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:rxdart/rxdart.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';

class WatchListScreen extends StatefulWidget {
  const WatchListScreen({Key? key}) : super(key: key);

  @override
  _WatchListScreenState createState() => _WatchListScreenState();
}

class _WatchListScreenState extends State<WatchListScreen> with WidgetsBindingObserver {
  WatchListBloc? _watchListBloc;

  bool _isIndexVisiable = false;
  bool isChangeChecked = false;
  bool isAlphabeticallyChecked = false;
  bool isLTPChecked = false;

  bool isascendingpchange = false;

  bool isacendingalphabet = false;
  bool isacendingchange = false;

  List<String> sortingListValues = ['NSE', 'BSE', 'NFO'];
  int? sortValueIndex;
  final ScrollController _scrollController = ScrollController();

  bool isltpuparrow = false;
  bool isltpdownarrow = false;
  bool isltpclick = true;

  bool isalphabetup = false;
  bool isalphabetdown = false;
  bool isalphabetclick = true;

  bool ispchangeup = false;
  bool ispchangedown = false;
  bool ispchangeclick = false;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    switch (state) {
      case AppLifecycleState.resumed:
        _watchListBloc?.getWatchListDataByGroupName();
        break;

      default:
        _watchListBloc?.unSubscribeLTPInfo();
        break;
    }
  }

  @override
  void dispose() {
    _watchListBloc?.disposeBloc();
    _watchListBloc = null;
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      log('----------------------- Watch List - addPostFrameCallback -----------------------');
      _watchListBloc?.getWatchListGroupNames();
    });

    SocketIOManager().reconnectStatusObservable?.listen((status) {
      log('----------------------- Watch List - reconnectStatusObservable - ${status.toString()} -----------------------');

      if (status.first) {
        //_watchListBloc?.subscribeLTPInfo();
        _watchListBloc?.onChangeListViewScroll(null);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _watchListBloc ??= WatchListBloc(context);
    // //_watchListBloc?.subscribeLTPInfo(List.generate(10, (index) => index));

    return Scaffold(
      appBar: AppBar(
        elevation: 1,
        backgroundColor: ConstantColors.white,
        leading: IconButton(
          onPressed: () => GreekBase().drawerKey.currentState?.openDrawer(),
          icon: const Icon(Icons.menu_rounded),
          iconSize: 30.0,
          color: ConstantColors.black,
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                ConstantMessages.MARKET_WATCHLIST_HEADER_TXT,
                style: GreekTextStyle.headline2,
              ),
              MaterialButton(
                minWidth: 0.0,
                padding: const EdgeInsets.only(right: 20.0),
                splashColor: Colors.transparent,
                highlightColor: Colors.transparent,
                child: _isIndexVisiable
                    ? const Icon(
                        Icons.keyboard_arrow_up_rounded,
                        color: Colors.black,
                        size: 40.0,
                      )
                    : const Icon(
                        Icons.keyboard_arrow_down_rounded,
                        color: Colors.black,
                        size: 40.0,
                      ),
                onPressed: () => setState(() => _isIndexVisiable = !_isIndexVisiable),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Column(
                children: [
                  Center(
                    child: Visibility(
                      visible: _isIndexVisiable,
                      child: _showIndicesIndexView(),
                    ),
                  ),
                  watchlistNameTabcontrol(),
                  _searchSymbolView(context),
                  _listView(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  SizedBox watchlistNameTabcontrol() {
    double widthTabTitle = 140.0;
    return SizedBox(
      height: 50.0,
      child: StreamBuilder<List<String>>(
        stream: _watchListBloc?.defaultWatchlistObservable,
        builder: (context, snapshot1) {
          if (snapshot1.hasData) {
            return ListView(
              padding: const EdgeInsets.all(4.0),
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              controller: _scrollController,
              children: <Widget>[
                GestureDetector(
                  onLongPress: () {
                    _watchListBloc?.isFromWatchTab = 0;
                    GreekBase().userActionForWatchListRenameObserver.sink.add(snapshot1.data![0]);
                  },
                  onTap: () {
                    //Check if watchlist is created or not
                    if (_watchListBloc?.arrGroupNames != null) {
                      if (_watchListBloc!.arrGroupNames.isNotEmpty) {
                        //Fetching the data from Watchlist
                        _watchListBloc?.filterClick = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByLTP = false;
                        _watchListBloc?.sortValueIndex = null;
                        _watchListBloc?.defaultGroupName = snapshot1.data![0];

                        GreekBase().userActionForWatchListSelectObserver.sink.add(0);
                      }
                    }

                    _watchListBloc?.watchlistColorStream1.sink.add(ConstantColors.primaryColorVitt);
                    _watchListBloc?.watchlistColorStream2.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream3.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream4.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream5.sink.add(Colors.grey);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: widthTabTitle,
                    child: StreamBuilder<Color>(
                      stream: _watchListBloc?.watchlistColorStream1.stream,
                      builder: (context, snapshot) {
                        //This is resetting the scroll back to zero once rename happens.
                        if (_watchListBloc?.isRenameCalled == true) {
                          _scrollController.animateTo(0, duration: const Duration(seconds: 2), curve: Curves.ease);
                          _watchListBloc?.isRenameCalled = false;
                        }
                        return Text(
                          snapshot1.data![0],
                          style: TextStyle(
                            fontFamily: 'CenturyGothic',
                            color: snapshot.data,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                            letterSpacing: 1.5,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                GestureDetector(
                  onLongPress: () {
                    _watchListBloc?.isFromWatchTab = 1;
                    GreekBase().userActionForWatchListRenameObserver.sink.add(snapshot1.data![1]);
                  },
                  onTap: () {
                    //Check if watchlist is created or not
                    if (_watchListBloc?.arrGroupNames != null) {
                      if (_watchListBloc!.arrGroupNames.isNotEmpty) {
                        //Fetching the data from Watchlist
                        _watchListBloc?.defaultGroupName = snapshot1.data![1];
                        _watchListBloc?.filterClick = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByLTP = false;
                        _watchListBloc?.sortValueIndex = null;

                        GreekBase().userActionForWatchListSelectObserver.sink.add(1);
                      }
                    }

                    _watchListBloc?.watchlistColorStream1.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream2.sink.add(ConstantColors.primaryColorVitt);
                    _watchListBloc?.watchlistColorStream3.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream4.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream5.sink.add(Colors.grey);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: widthTabTitle,
                    child: StreamBuilder<Color>(
                      stream: _watchListBloc?.watchlistColorStream2.stream,
                      builder: (context, snapshot) {
                        return Text(
                          snapshot1.data![1],
                          style: TextStyle(
                            fontFamily: 'CenturyGothic',
                            color: snapshot.data,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                GestureDetector(
                  onLongPress: () {
                    _watchListBloc?.isFromWatchTab = 2;
                    GreekBase().userActionForWatchListRenameObserver.sink.add(snapshot1.data![2]);
                  },
                  onTap: () {
                    //Check if watchlist is created or not
                    if (_watchListBloc?.arrGroupNames != null) {
                      if (_watchListBloc!.arrGroupNames.isNotEmpty) {
                        //Fetching the data from Watchlist
                        _watchListBloc?.filterClick = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByLTP = false;
                        _watchListBloc?.sortValueIndex = null;
                        _watchListBloc?.defaultGroupName = snapshot1.data![2];
                        GreekBase().userActionForWatchListSelectObserver.sink.add(2);
                      }
                    }
                    _watchListBloc?.watchlistColorStream1.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream2.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream3.sink.add(ConstantColors.primaryColorVitt);
                    _watchListBloc?.watchlistColorStream4.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream5.sink.add(Colors.grey);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: widthTabTitle,
                    child: StreamBuilder<Color>(
                      stream: _watchListBloc?.watchlistColorStream3.stream,
                      builder: (context, snapshot) {
                        return Text(
                          snapshot1.data![2],
                          style: TextStyle(
                            fontFamily: 'CenturyGothic',
                            color: snapshot.data,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                GestureDetector(
                  onLongPress: () {
                    _watchListBloc?.isFromWatchTab = 3;
                    GreekBase().userActionForWatchListRenameObserver.sink.add(snapshot1.data![3]);
                  },
                  onTap: () {
                    //Check if watchlist is created or not
                    if (_watchListBloc?.arrGroupNames != null) {
                      if (_watchListBloc!.arrGroupNames.isNotEmpty) {
                        _watchListBloc?.filterClick = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByLTP = false;
                        _watchListBloc?.sortValueIndex = null;
                        //Fetching the data from Watchlist
                        _watchListBloc?.defaultGroupName = snapshot1.data![3];
                        GreekBase().userActionForWatchListSelectObserver.sink.add(3);
                      }
                    }

                    _watchListBloc?.watchlistColorStream1.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream2.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream3.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream4.sink.add(ConstantColors.primaryColorVitt);
                    _watchListBloc?.watchlistColorStream5.sink.add(Colors.grey);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: widthTabTitle,
                    child: StreamBuilder<Color>(
                      stream: _watchListBloc?.watchlistColorStream4.stream,
                      builder: (context, snapshot) {
                        return Text(
                          snapshot1.data![3],
                          style: TextStyle(
                            fontFamily: 'CenturyGothic',
                            color: snapshot.data,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                GestureDetector(
                  onLongPress: () {
                    _watchListBloc?.isFromWatchTab = 4;
                    GreekBase().userActionForWatchListRenameObserver.sink.add(snapshot1.data![4]);
                  },
                  onTap: () {
                    //Check if watchlist is created or not
                    if (_watchListBloc?.arrGroupNames != null) {
                      if (_watchListBloc!.arrGroupNames.isNotEmpty) {
                        _watchListBloc?.filterClick = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByChange = false;
                        _watchListBloc?.sortByLTP = false;
                        _watchListBloc?.sortValueIndex = null;
                        //Fetching the data from Watchlist
                        _watchListBloc?.defaultGroupName = snapshot1.data![4];
                        GreekBase().userActionForWatchListSelectObserver.sink.add(4);
                      }
                    }

                    _watchListBloc?.watchlistColorStream1.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream2.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream3.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream4.sink.add(Colors.grey);
                    _watchListBloc?.watchlistColorStream5.sink.add(ConstantColors.primaryColorVitt);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: widthTabTitle,
                    child: StreamBuilder<Color>(
                      stream: _watchListBloc?.watchlistColorStream5.stream,
                      builder: (context, snapshot) {
                        return Text(
                          snapshot1.data![4],
                          style: TextStyle(
                            fontFamily: 'CenturyGothic',
                            color: snapshot.data,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }

  _showIndicesIndexView() {
    // return StreamBuilder<List<BehaviorSubject<IndianIndicesResponseModel?>?>?>(
    //     stream: GreekBase().indicesSubject.stream,
    //     builder: (context, mainSnapshot) {
    //       if ((mainSnapshot.hasData) &&
    //           (mainSnapshot.data?.isNotEmpty ?? false)) {
    //         return Container(
    //           height: 100.0,
    //           padding: const EdgeInsets.all(5.0),
    //           child: ListView.builder(
    //             scrollDirection: Axis.horizontal,
    //             itemCount: mainSnapshot.data?.length,
    //             itemBuilder: (context, index) {
    //               return StreamBuilder<IndianIndicesResponseModel?>(
    //                   stream: mainSnapshot.data?[index]?.stream,
    //                   builder: (context, innerSnapshot) {
    return StreamBuilder<List<BehaviorSubject<IndianIndicesResponseModel>>>(
      stream: GreekBase().indicesSubject.stream,
      builder: (streamContext, snapshot) {
        if ((snapshot.data != null) && (snapshot.data!.isNotEmpty)) {
          return GreekBase().indicesListView(
            watchListBloc: _watchListBloc,
            dataList: snapshot.data ?? [],
          );
        }

        return SizedBox(
          height: MediaQuery.of(context).size.height / 2,
          child: Center(child: GreekBase().noDataAvailableView()),
        );
      },
    );
  }

  _searchSymbolView(BuildContext searchContext) => Padding(
        padding: EdgeInsets.zero,
        child: Card(
          child: Container(
            height: 56.0,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.4),
                  spreadRadius: 3,
                  blurRadius: 7,
                  offset: const Offset(0, 1.5),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8.0, top: 8.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset(
                      'lib/Resources/Icons/search_icon.png',
                      fit: BoxFit.fitWidth,
                      width: 22.0,
                      height: 22.0,
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.centerLeft,
                      child: MaterialButton(
                        splashColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        child: Row(
                          children: [
                            Text(
                              ConstantMessages.SEARCH_SYMBOL_MSG,
                              style: GreekTextStyle.searchSymbolTextStyle,
                            ),
                          ],
                        ),
                        onPressed: () async {
                          _watchListBloc?.clearSearchResult();
                          _watchListBloc?.unSubscribeLTPInfo();
                          final popResult = await GreekNavigator.pushNamed(
                            context: searchContext,
                            routeName: GreekScreenNames.searchSymbol,
                            arguments: _watchListBloc,
                          );

                          if (popResult == PopAction.rebuildWidget) {
                            setState(() => _watchListBloc?.getWatchListDataByGroupName());
                          }
                        },
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Image.asset(
                      'lib/Resources/Icons/watchlist_filter.png',
                      fit: BoxFit.contain,
                      height: 22.0,
                      width: 22.0,
                    ),
                    //iconSize: 40.0,
                    splashColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onPressed: () {
                      GreekDialogPopupView.watchListFilterPoup(popContext: context, watchlistBloc: _watchListBloc);
                      /* showModalBottomSheet(
                          context: context,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15.0),
                                topRight: Radius.circular(15.0)),
                          ),
                          builder: (context) {
                            return StatefulBuilder(
                                builder: (context, StateSetter mystate) {
                              return Container(
                                height: 320,
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "", //'Filter',
                                          style: GreekTextStyle
                                              .watchlistFilterText,
                                        ),
                                        TextButton(
                                            onPressed: () {
                                              GreekNavigator.pop(
                                                  context: context);
                                              if (isChangeChecked == true) {
                                                setState(() {
                                                  _watchListBloc?.sortByChange =
                                                      true;
                                                  _watchListBloc
                                                          ?.sortAlphabetically =
                                                      false;
                                                  _watchListBloc?.sortByLTP =
                                                      false;
                                                  _watchListBloc
                                                          ?.pchangeascending =
                                                      isascendingpchange;

                                                  _watchListBloc
                                                          ?.alphabetascending =
                                                      false;

                                                  _watchListBloc
                                                      ?.lastascending = false;

                                                  _watchListBloc
                                                      ?.preparSymbolList();
                                                });
                                              } else if (isAlphabeticallyChecked ==
                                                  true) {
                                                setState(() {
                                                  _watchListBloc
                                                          ?.sortAlphabetically =
                                                      true;
                                                  _watchListBloc?.sortByChange =
                                                      false;
                                                  _watchListBloc?.sortByLTP =
                                                      false;

                                                  _watchListBloc
                                                          ?.alphabetascending =
                                                      isacendingalphabet;

                                                  _watchListBloc
                                                      ?.preparSymbolList();
                                                });
                                              } else if (isLTPChecked == true) {
                                                setState(() {
                                                  _watchListBloc?.sortByLTP =
                                                      true;
                                                  _watchListBloc
                                                          ?.sortAlphabetically =
                                                      false;
                                                  _watchListBloc?.sortByChange =
                                                      false;
                                                  _watchListBloc
                                                          ?.lastascending =
                                                      isacendingchange;
                                                  _watchListBloc
                                                      ?.preparSymbolList();
                                                });
                                              } /* else {
                                                _watchListBloc
                                                        ?.sortAlphabetically =
                                                    false;
                                                _watchListBloc?.sortByChange =
                                                    false;
                                                _watchListBloc?.sortByLTP =
                                                    false;
                                                _watchListBloc
                                                        ?.alphabetascending =
                                                    isacendingalphabet;
                                                _watchListBloc
                                                    ?.preparSymbolList();
                                              } */
                                            },
                                            child: Text(
                                              'Apply',
                                              style: GreekTextStyle
                                                  .watchlistFilterText_blue,
                                            )),
                                      ],
                                    ),
                                    /*    Container(
                                      height: 30,
                                      margin: const EdgeInsets.only(top: 30.0),
                                      alignment: Alignment.centerLeft,
                                      child: ListView.builder(
                                        itemCount: sortingListValues.length,
                                        shrinkWrap: true,
                                        scrollDirection: Axis.horizontal,
                                        itemBuilder:
                                            (BuildContext context, index) {
                                          return Container(
                                            height: 30,
                                            width: 60,
                                            margin: const EdgeInsets.only(
                                                left: 5.0, right: 5.0),
                                            decoration: BoxDecoration(
                                              color: sortValueIndex == index
                                                  ? Colors.blue
                                                  : Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                              border: Border.all(
                                                color: Colors.black,
                                                width: 0.5,
                                              ),
                                              boxShadow: const [
                                                BoxShadow(
                                                  color: Colors.grey,
                                                  blurRadius: 2.0,
                                                ),
                                              ],
                                            ),
                                            child: TextButton(
                                                onPressed: () {
                                                  if (index == 0) {
                                                    mystate(() {
                                                      sortValueIndex = 0;
                                                    });
                                                  } else if (index == 1) {
                                                    mystate(() {
                                                      sortValueIndex = 1;
                                                    });
                                                  } else if (index == 2) {
                                                    mystate(() {
                                                      sortValueIndex = 2;
                                                    });
                                                  }
                                                },
                                                child: Text(
                                                  sortingListValues[index],
                                                  style: TextStyle(
                                                      color: sortValueIndex ==
                                                              index
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      fontSize: 12),
                                                )),
                                          );
                                        },
                                      ),
                                    ),
   */
                                    const SizedBox(height: 10),
                                    const Divider(
                                      height: 2,
                                      color: Colors.black,
                                    ),
                                    const SizedBox(height: 10),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Sort',
                                          style: GreekTextStyle
                                              .watchlistFilterText,
                                        ),
                                      ],
                                    ),
                                    InkWell(
                                      onTap: () {
                                        mystate(() {
                                          isChangeChecked = true;
                                          isAlphabeticallyChecked = false;
                                          isLTPChecked = false;
                                          ispchangeclick == false
                                              ? ispchangeclick = true
                                              : ispchangeclick = false;

                                          isascendingpchange == false
                                              ? isascendingpchange = true
                                              : isascendingpchange = false;

                                          isacendingalphabet = false;
                                          isacendingchange = false;
                                        });
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          IconButton(
                                            icon: (ispchangeclick)
                                                ? Image.asset(
                                                    'assets/images/up_arrow_sort.png',
                                                    fit: BoxFit.fitWidth,
                                                  )
                                                : Image.asset(
                                                    'assets/images/down_arrow_sort.png',
                                                    fit: BoxFit.fitWidth,
                                                  ),
                                            onPressed: () {},
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              "% Change",
                                              style: GreekTextStyle.headline21,
                                              textAlign: TextAlign.left,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        mystate(() {
                                          isChangeChecked = false;
                                          isAlphabeticallyChecked = true;
                                          isLTPChecked = false;
                                          isacendingalphabet == false
                                              ? isacendingalphabet = true
                                              : isacendingalphabet = false;
                                        });
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          /* Checkbox(
                                            checkColor: Colors.white,
                                            fillColor:
                                                MaterialStateProperty.resolveWith(
                                                    getColor),
                                            value: isAlphabeticallyChecked,
                                            onChanged: (value) {
                                              mystate(
                                                () {
                                                  isAlphabeticallyChecked = true;
                                                  isChangeChecked = false;
                                                  isLTPChecked = false;
                                                },
                                              );
                                            },
                                          ), */
                                          IconButton(
                                            icon: (isacendingalphabet)
                                                ? Image.asset(
                                                    'assets/images/up_arrow_sort.png',
                                                    fit: BoxFit.fitWidth,
                                                  )
                                                : Image.asset(
                                                    'assets/images/down_arrow_sort.png',
                                                    fit: BoxFit.fitWidth,
                                                  ),
                                            onPressed: () {
                                              mystate(() {
                                                isChangeChecked = false;
                                                isAlphabeticallyChecked = true;
                                                isLTPChecked = false;
                                                isacendingalphabet == false
                                                    ? isacendingalphabet = true
                                                    : isacendingalphabet =
                                                        false;
                                              });
                                            },
                                          ),
                                          Expanded(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Alphabetically",
                                                style:
                                                    GreekTextStyle.headline21,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        mystate(() {
                                          isLTPChecked = true;
                                          isChangeChecked = false;
                                          isAlphabeticallyChecked = false;
                                          isacendingchange == false
                                              ? isacendingchange = true
                                              : isacendingchange = false;
                                        });
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          /*  Checkbox(
                                            checkColor: Colors.white,
                                            fillColor:
                                                MaterialStateProperty.resolveWith(
                                                    getColor),
                                            value: isLTPChecked,
                                            onChanged: (value) {
                                              mystate(() {
                                                isLTPChecked = true;
                                                isChangeChecked = false;
                                                isAlphabeticallyChecked = false;
                                              });
                                            },
                                          ), */

                                          IconButton(
                                            icon: (isacendingchange)
                                                ? Image.asset(
                                                    'assets/images/up_arrow_sort.png',
                                                    fit: BoxFit.fitWidth,
                                                  )
                                                : Image.asset(
                                                    'assets/images/down_arrow_sort.png',
                                                    fit: BoxFit.fitWidth,
                                                  ),
                                            onPressed: () {
                                              isLTPChecked = true;
                                              isChangeChecked = false;
                                              isAlphabeticallyChecked = false;
                                              isacendingchange == false
                                                  ? isacendingchange = true
                                                  : isacendingchange = false;
                                            },
                                          ),
                                          Expanded(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Last Traded Price",
                                                style:
                                                    GreekTextStyle.headline21,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            });
                          });
 */
                      /* showFlexibleBottomSheet(
                        minHeight: 0,
                        initHeight: 0.5,
                        maxHeight: 1,
                        context: context,
                        builder: _watchlistFilterBottomSheet,
                        anchors: [0, 0.5, 1],
                      ); */
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      );

  _listView() => StreamBuilder(
        stream: _watchListBloc?.symbolListObservable,
        builder: (BuildContext streamContext, AsyncSnapshot<List<SymbolList>> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.isNotEmpty) {
              final symbolDataList = <StreamingDataModel>[];

              for (final item in (snapshot.data ?? <SymbolList>[])) {
                if ((item.token ?? 0) > 0) {
                  final obj = StreamingDataModel(
                    token: item.token,
                    symbol: (item.token?.toAssetType().toLowerCase() == "equity") ? "${item.description} - ${item.seriesName}" : item.description,
                    ltp: item.ltp,
                    change: item.change,
                    preChange: item.pChange,
                  );

                  symbolDataList.add(obj);
                }
              }

              return Flexible(
                fit: FlexFit.tight,
                child: GreekBase().scriptListView(scripContext: streamContext, dataList: symbolDataList, isFrom: "watchlist"),
              );
            } else {
              return SizedBox(
                height: MediaQuery.of(context).size.height / 2,
                child: Center(
                  child: GreekBase().noDataAvailableView(),
                ),
              );
            }
          } else {
            return const SizedBox.shrink();
          }
        },
      );

  /*_listView() => StreamBuilder(
        stream: _watchListBloc?.symbolListObservable,
        builder:
            (BuildContext context, AsyncSnapshot<List<SymbolList>> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.isNotEmpty) {
              return NotificationListener<ScrollNotification>(
                onNotification: _watchListBloc?.onChangeListViewScroll,
                child: RectGetter(
                  key: _watchListBloc!.listViewRectKey,
                  child: Expanded(
                    child: GreekBase().scriptListView(
                      dataList: _watchListBloc?.ltpInfoStream ?? [],
                      watchBloc: _watchListBloc,
                    ),
                  ),
                ),
              );
            } else {
              return GreekBase().noDataAvailableView();
            }
          }

          return Container();
        },
      );*/
}
