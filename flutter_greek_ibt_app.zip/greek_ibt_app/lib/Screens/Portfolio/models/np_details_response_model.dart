class NpDetailsResponseModel {
  String? noofrecords;
  String? islast;
  List<StockDetailss>? stockDetails;

  NpDetailsResponseModel({this.noofrecords, this.islast, this.stockDetails});

  NpDetailsResponseModel.fromJson(Map<String, dynamic> json) {
    noofrecords = json['noofrecords'];
    islast = json['islast'];
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetailss>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetailss.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['noofrecords'] = noofrecords;
    data['islast'] = islast;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetailss {
  String? nSEToken;
  String? bSEToken;
  String? token;
  String? buyQty;
  String? buyAmt;
  String? sellQty;
  String? sellAmt;
  String? preNetQty;
  String? pAmt;
  String? productType;
  String? symbol;
  String? isin;
  String? instrument;
  String? tradeSymbol;
  String? lotQty;
  String? sqoffToken;
  String? account;
  String? multiplier;
  String? tickSize;
  String? expiryDate;
  String? optionType;
  String? strikePrice;
  String? ltp;
  String? close;
  String? priceMultiplier;
  String? netQty;
  String? dayNetAmt;
  String? netAvg;
  String? buyAvg;
  String? sellAvg;
  String? todayprofitandloss;
  String? buysellqty;
  String? buysellamount;
  String? buyselltext = "";
  double? perchange;

  StockDetailss(
      {this.nSEToken,
      this.bSEToken,
      this.token,
      this.buyQty,
      this.buyAmt,
      this.sellQty,
      this.sellAmt,
      this.preNetQty,
      this.pAmt,
      this.productType,
      this.symbol,
      this.isin,
      this.instrument,
      this.tradeSymbol,
      this.lotQty,
      this.sqoffToken,
      this.account,
      this.multiplier,
      this.tickSize,
      this.expiryDate,
      this.optionType,
      this.strikePrice,
      this.ltp,
      this.close,
      this.priceMultiplier,
      this.netQty,
      this.dayNetAmt,
      this.netAvg,
      this.buyAvg,
      this.sellAvg,
      this.todayprofitandloss,
      this.buysellqty,
      this.buysellamount,
      this.buyselltext,
      this.perchange});

  StockDetailss.fromJson(Map<String, dynamic> json) {
    nSEToken = json['NSEToken'];
    bSEToken = json['BSEToken'];
    token = json['token'];
    buyQty = json['buyQty'];
    buyAmt = json['buyAmt'];
    sellQty = json['sellQty'];
    sellAmt = json['sellAmt'];
    preNetQty = json['preNetQty'];
    pAmt = json['PAmt'];
    productType = json['ProductType'];
    symbol = json['symbol'];
    isin = json['isin'];
    instrument = json['instrument'];
    tradeSymbol = json['tradeSymbol'];
    lotQty = json['lotQty'];
    sqoffToken = json['sqoffToken'];
    account = json['account'];
    multiplier = json['multiplier'];
    tickSize = json['tickSize'];
    expiryDate = json['expiry_date'];
    optionType = json['option_type'];
    strikePrice = json['strike_price'];
    ltp = json['ltp'];
    close = json['close'];
    priceMultiplier = json['price_multiplier'];
    netQty = json['netQty'];
    dayNetAmt = json['DayNetAmt'];
    netAvg = json['netAvg'];
    buyAvg = json['buyAvg'];
    sellAvg = json['sellAvg'];
    todayprofitandloss = json['todayprofitandloss'];
    perchange = json['perchange'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['NSEToken'] = nSEToken;
    data['BSEToken'] = bSEToken;
    data['token'] = token;
    data['buyQty'] = buyQty;
    data['buyAmt'] = buyAmt;
    data['sellQty'] = sellQty;
    data['sellAmt'] = sellAmt;
    data['preNetQty'] = preNetQty;
    data['PAmt'] = pAmt;
    data['ProductType'] = productType;
    data['symbol'] = symbol;
    data['isin'] = isin;
    data['instrument'] = instrument;
    data['tradeSymbol'] = tradeSymbol;
    data['lotQty'] = lotQty;
    data['sqoffToken'] = sqoffToken;
    data['account'] = account;
    data['multiplier'] = multiplier;
    data['tickSize'] = tickSize;
    data['expiry_date'] = expiryDate;
    data['option_type'] = optionType;
    data['strike_price'] = strikePrice;
    data['ltp'] = ltp;
    data['close'] = close;
    data['price_multiplier'] = priceMultiplier;
    data['netQty'] = netQty;
    data['DayNetAmt'] = dayNetAmt;
    data['netAvg'] = netAvg;
    data['buyAvg'] = buyAvg;
    data['sellAvg'] = sellAvg;
    data['todayprofitandloss'] = todayprofitandloss;
    data['perchange'] = perchange;
    return data;
  }
}
