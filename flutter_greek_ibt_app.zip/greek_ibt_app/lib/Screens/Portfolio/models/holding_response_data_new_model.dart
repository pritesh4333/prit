class HoldinResponseDataNewModel {
  int? noofrecords;
  int? islast;
  List<StockDetails>? stockDetails;

  HoldinResponseDataNewModel({this.noofrecords, this.islast, this.stockDetails});

  HoldinResponseDataNewModel.fromJson(Map<String, dynamic> json) {
    noofrecords = int.parse(json['noofrecords']?.toString() ?? "-1");
    islast = int.parse(json['islast']?.toString() ?? "-1");
    if (json['stockDetails'] != null) {
      stockDetails = <StockDetails>[];
      json['stockDetails'].forEach((v) {
        stockDetails!.add(StockDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['noofrecords'] = noofrecords;
    data['islast'] = islast;
    if (stockDetails != null) {
      data['stockDetails'] = stockDetails!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class StockDetails {
  String? nSEToken;
  String? bSEToken;
  String? qty;
  String? ltp;
  String? hPrice;
  String? close;
  String? symbol;
  String? isin;
  String? instrument;
  String? scripName;
  String? lotSize;
  double calTotalInvested = 0.0;
  double calCurrentValue = 0.0;
  double calPreviousValue = 0.0;
  double? perchange;

  StockDetails({
    this.nSEToken,
    this.bSEToken,
    this.qty,
    this.ltp,
    this.hPrice,
    this.close,
    this.symbol,
    this.isin,
    this.instrument,
    this.scripName,
    this.lotSize,
    this.perchange,
  });

  StockDetails.fromJson(Map<String, dynamic> json) {
    nSEToken = json['NSEToken'];
    bSEToken = json['BSEToken'];
    qty = json['Qty'];
    ltp = json['Ltp'];
    hPrice = json['HPrice'];
    close = json['Close'];
    symbol = json['symbol'];
    isin = json['isin'];
    instrument = json['instrument'];
    scripName = json['ScripName'];
    lotSize = json['LotSize'];
    perchange = json['perchange'];

    calTotalInvested = double.parse(hPrice!) * double.parse(qty!);
    calCurrentValue = double.parse(ltp!) * double.parse(qty!);
    calPreviousValue = double.parse(close!) * double.parse(qty!);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['NSEToken'] = nSEToken;
    data['BSEToken'] = bSEToken;
    data['Qty'] = qty;
    data['Ltp'] = ltp;
    data['HPrice'] = hPrice;
    data['Close'] = close;
    data['symbol'] = symbol;
    data['isin'] = isin;
    data['instrument'] = instrument;
    data['ScripName'] = scripName;
    data['LotSize'] = lotSize;
    data['perchange'] = perchange;
    return data;
  }
}
