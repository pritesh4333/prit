import 'package:intl/intl.dart';

class GraphResponseModel {
  String? lToken;
  String? lOpen;
  String? lHigh;
  String? lLow;
  String? lClose;
  String? lDate;
  String? lTradedVol;
  String? lATP;
  String? sDate;

  //DateTime? lDateConverted;
  String? lDateConverted;

  GraphResponseModel({
    this.lToken,
    this.lOpen,
    this.lHigh,
    this.lLow,
    this.lClose,
    this.lDate,
    this.lTradedVol,
    this.lATP,
    this.sDate,
    this.lDateConverted,
  });

  GraphResponseModel.fromJson(Map<String, dynamic> json) {
    lToken = json['lToken'].toString();
    lOpen = json['lOpen'].toString();
    lHigh = json['lHigh'].toString();
    lLow = json['lLow'].toString();
    lClose = json['lClose'].toString();
    lDate = json['lDate'].toString();
    lTradedVol = json['lTradedVol'].toString();
    lATP = json['lATP'].toString();
    sDate = json['sDate'].toString();
    int timeStamp = int.parse(lDate!);
    int charLength = lDate?.length ?? 0;
    if (charLength > 8) {
      // final date = DateFormat('HH:mm').format(DateTime.fromMillisecondsSinceEpoch((timeStamp + 315513000) * 1000));
      final date = DateFormat('yyyy-MM-dd HH:mm').format(
          DateTime.fromMillisecondsSinceEpoch((timeStamp + 315513000) * 1000));
      //lDateConverted = DateTime.parse(date);
      //Check for Volume
      var volume =
          ((double.parse(lTradedVol ?? '0.0')) / 1000).toString() + "K";
      lDateConverted = date + " Vol." + volume;
    } else {
      lDateConverted = lDate;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lToken'] = lToken;
    data['lOpen'] = lOpen;
    data['lHigh'] = lHigh;
    data['lLow'] = lLow;
    data['lClose'] = lClose;
    data['lDate'] = lDate;
    data['lTradedVol'] = lTradedVol;
    data['lATP'] = lATP;
    data['sDate'] = sDate;
    return data;
  }
}
