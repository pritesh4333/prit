class HoldingScripDetailsInfoResponseModel {
  String? gscid;
  String? token;
  String? netHoldingQty;
  String? netHoldingPrice;
  String? dPQty;
  String? dPPrice;
  String? poolQty;
  String? poolPrice;
  String? mTFQty;
  String? mTFPrice;
  String? actualDPQty;
  String? actualDPPrice;
  String? actualPoolQty;
  String? actualPoolPrice;
  String? actualMTFQty;
  String? actualMTFPrice;
  String? pendingAmount;
  String? pendingQty;
  String? riskBlockQty;
  String? soldQty;
  String? todayBuyQty;
  String? todayBuyATP;
  String? todaySellQty;
  String? todaySellATP;
  String? todayNetQty;
  String? dPReleaseQty;
  String? poolReleaseQty;
  String? mTFReleaseQty;
  String? scripName;
  String? symbol;
  String? isin;
  String? instrument;
  String? freeHOldingQty;

  HoldingScripDetailsInfoResponseModel(
      {this.gscid,
      this.token,
      this.netHoldingQty,
      this.netHoldingPrice,
      this.dPQty,
      this.dPPrice,
      this.poolQty,
      this.poolPrice,
      this.mTFQty,
      this.mTFPrice,
      this.actualDPQty,
      this.actualDPPrice,
      this.actualPoolQty,
      this.actualPoolPrice,
      this.actualMTFQty,
      this.actualMTFPrice,
      this.pendingAmount,
      this.pendingQty,
      this.riskBlockQty,
      this.soldQty,
      this.todayBuyQty,
      this.todayBuyATP,
      this.todaySellQty,
      this.todaySellATP,
      this.todayNetQty,
      this.dPReleaseQty,
      this.poolReleaseQty,
      this.mTFReleaseQty,
      this.scripName,
      this.symbol,
      this.isin,
      this.instrument,
      this.freeHOldingQty});

  HoldingScripDetailsInfoResponseModel.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    token = json['token'];
    netHoldingQty = json['NetHoldingQty'];
    netHoldingPrice = json['NetHoldingPrice'];
    dPQty = json['DPQty'];
    dPPrice = json['DPPrice'];
    poolQty = json['PoolQty'];
    poolPrice = json['PoolPrice'];
    mTFQty = json['MTFQty'];
    mTFPrice = json['MTFPrice'];
    actualDPQty = json['ActualDPQty'];
    actualDPPrice = json['ActualDPPrice'];
    actualPoolQty = json['ActualPoolQty'];
    actualPoolPrice = json['ActualPoolPrice'];
    actualMTFQty = json['ActualMTFQty'];
    actualMTFPrice = json['ActualMTFPrice'];
    pendingAmount = json['PendingAmount'];
    pendingQty = json['PendingQty'];
    riskBlockQty = json['RiskBlockQty'];
    soldQty = json['SoldQty'];
    todayBuyQty = json['TodayBuyQty'];
    todayBuyATP = json['TodayBuyATP'];
    todaySellQty = json['TodaySellQty'];
    todaySellATP = json['TodaySellATP'];
    todayNetQty = json['TodayNetQty'];
    dPReleaseQty = json['DPReleaseQty'];
    poolReleaseQty = json['PoolReleaseQty'];
    mTFReleaseQty = json['MTFReleaseQty'];
    scripName = json['scripName'];
    symbol = json['symbol'];
    isin = json['isin'];
    instrument = json['instrument'];
    freeHOldingQty = json['FreeHOldingQty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    data['token'] = token;
    data['NetHoldingQty'] = netHoldingQty;
    data['NetHoldingPrice'] = netHoldingPrice;
    data['DPQty'] = dPQty;
    data['DPPrice'] = dPPrice;
    data['PoolQty'] = poolQty;
    data['PoolPrice'] = poolPrice;
    data['MTFQty'] = mTFQty;
    data['MTFPrice'] = mTFPrice;
    data['ActualDPQty'] = actualDPQty;
    data['ActualDPPrice'] = actualDPPrice;
    data['ActualPoolQty'] = actualPoolQty;
    data['ActualPoolPrice'] = actualPoolPrice;
    data['ActualMTFQty'] = actualMTFQty;
    data['ActualMTFPrice'] = actualMTFPrice;
    data['PendingAmount'] = pendingAmount;
    data['PendingQty'] = pendingQty;
    data['RiskBlockQty'] = riskBlockQty;
    data['SoldQty'] = soldQty;
    data['TodayBuyQty'] = todayBuyQty;
    data['TodayBuyATP'] = todayBuyATP;
    data['TodaySellQty'] = todaySellQty;
    data['TodaySellATP'] = todaySellATP;
    data['TodayNetQty'] = todayNetQty;
    data['DPReleaseQty'] = dPReleaseQty;
    data['PoolReleaseQty'] = poolReleaseQty;
    data['MTFReleaseQty'] = mTFReleaseQty;
    data['scripName'] = scripName;
    data['symbol'] = symbol;
    data['isin'] = isin;
    data['instrument'] = instrument;
    data['FreeHOldingQty'] = freeHOldingQty;
    return data;
  }
}
