class HoldingValueResponseModel {
  String? gscid;
  String? hValue;
  String? cValue;

  HoldingValueResponseModel({this.gscid, this.hValue, this.cValue});

  HoldingValueResponseModel.fromJson(Map<String, dynamic> json) {
    gscid = json['gscid'];
    hValue = json['HValue'];
    cValue = json['CValue'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['gscid'] = gscid;
    data['HValue'] = hValue;
    data['CValue'] = cValue;
    return data;
  }
}
