import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Extension_Enum/marketStatus_flag.dart';
import 'package:greek_ibt_app/Helper/constant_colors.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Screens/Order/bloc/order_bloc.dart';
import 'package:greek_ibt_app/Screens/Order/models/order_detail_response_model.dart';
import 'package:greek_ibt_app/Screens/Place%20Order/model/order_details_model.dart';
import 'package:greek_ibt_app/Utilities/greek_dialog_popup_view.dart';
import 'package:greek_ibt_app/Utilities/greek_textstyle.dart';
import 'package:greek_ibt_app/Extension_Enum/int_extension.dart';
import 'package:marquee/marquee.dart';

class OrderScreen extends StatefulWidget {
  const OrderScreen({Key? key}) : super(key: key);

  @override
  _OrderScreenState createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen>
    with SingleTickerProviderStateMixin {
  OrderBloc? _orderBloc;
  bool validStatus = false;
  bool isPostOpenStatus = false;
  bool isPreOpenStatus = false;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        _orderBloc?.getOrderResultBySelectedTabIndex(tabIndex: 0);
        /*    _orderBloc?.getOrderResultBySelectedTabIndex(tabIndex: 1);
        _orderBloc?.getOrderResultBySelectedTabIndex(tabIndex: 2);
        _orderBloc?.getOrderResultBySelectedTabIndex(tabIndex: 3); */
      },
    );
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  void dispose() {
    // PortfolioBloc.searchWidgitVisiblity.sink.add(false);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _orderBloc ??= OrderBloc(context);
    _orderBloc?.tabController ??= TabController(
      length: (_orderBloc?.tabLabels.length ?? 0),
      vsync: this,
    );

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          backgroundColor: ConstantColors.white,
          leading: IconButton(
            onPressed: () {
              GreekBase().drawerKey.currentState?.openDrawer();
            },
            icon: const Icon(Icons.menu_rounded),
            iconSize: 30.0,
            color: ConstantColors.black,
          ),
          title: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              ConstantMessages.ORDERS_HEADER_TXT,
              style: GreekTextStyle.headline2,
            ),
          ),
          bottom: TabBar(
            controller: _orderBloc?.tabController,
            labelStyle: GreekTextStyle.selected_tab_label_blue,
            labelColor: GreekTextStyle.selected_tab_label_blue.color,
            unselectedLabelStyle: GreekTextStyle.unselected_tab_label_blue,
            unselectedLabelColor:
                GreekTextStyle.unselected_tab_label_blue.color,
            labelPadding: EdgeInsets.zero,
            tabs: _orderBloc?.tabLabels ?? [],
            onTap: (tabIndex) => _orderBloc?.getOrderResultBySelectedTabIndex(
                tabIndex: tabIndex),
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 15.0),
            SizedBox(
              height: 60.0,
              child: Container(
                padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                alignment: Alignment.centerLeft,
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  elevation: 5.0,
                  child: TextField(
                    onChanged: _orderBloc?.filterOrderListBySearchText,
                    controller: _orderBloc?.searchTextFieldController,
                    style: GreekTextStyle.headline1,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: ConstantMessages.SEARCH_ORDER_MSG,
                      prefixIcon: Icon(
                        Icons.search,
                        color: Colors.black.withOpacity(0.45),
                        size: 28.0,
                      ),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.cancel_rounded),
                        highlightColor: Colors.transparent,
                        splashColor: Colors.transparent,
                        onPressed: _orderBloc?.clearButtonTapped,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 15.0),
            StreamBuilder<List<OrderDetailResponseModel>>(
              stream: _orderBloc?.orderResultObserver,
              builder: (streamContext, snapshot) {
                if (snapshot.hasData) {
                  if (snapshot.data?.isNotEmpty ?? false) {
                    return Expanded(
                      child: ListView.separated(
                        itemCount: snapshot.data!.length,
                        itemBuilder: (itemContext, index) => _cardBox(
                            itemContext, snapshot.data!.elementAt(index)),
                        separatorBuilder: (separatorContext, index) => Divider(
                          thickness: 1.0,
                          color: ConstantColors.dividerColor.withOpacity(0.5),
                        ),
                      ),
                    );
                  }
                }
                return Container(
                  margin: const EdgeInsets.only(top: 250),
                  // color: Colors.red,
                  height: 50,
                  child: Center(
                    child: GreekBase().noDataAvailableView(
                      msg: _orderBloc?.noDataAvailableMsg.elementAt(
                        (_orderBloc?.selectedTabIndex ?? 0),
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _cardBox(BuildContext cardContext, OrderDetailResponseModel obj) {
    ;
    var orderType = "LIMIT";
    if (obj.bookType.toString() == "50") {
      orderType = "BRACKET";
    } else if (obj.bookType.toString() == "1") {
      int.parse(obj.orderFlags.toString());
      if (GreekBase().getBitResult(int.parse(obj.orderFlags.toString())) == 1) {
        if (obj.price == 0) {
          orderType = "MARKET";
        } else {
          orderType = "LIMIT";
        }
      }
    } else if (obj.bookType.toString() == "3") {
      if (GreekBase().getBitResult(int.parse(obj.orderFlags.toString())) == 1) {
        orderType = "SLM";
      } else {
        if (double.parse(obj.price.toString()) == 0.00) {
          orderType = "SLM";
        } else {
          orderType = "SL";
        }
      }
    }
    return Container(
      height: 100.0,
      padding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
      child: InkWell(
        highlightColor: Colors.transparent,
        splashColor: Colors.transparent,
        onTap: () => _showOrderDetailBottomSheet(
          orderDetailContext: cardContext,
          obj: obj,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 40,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.only(left: 8),
                      child: Row(
                        children: [
                          Text(
                            obj.action?.toUpperCase() ?? '',
                            style:
                                (obj.action?.toUpperCase().compareTo("BUY") ==
                                        0)
                                    ? GreekTextStyle.order_buy_textstyle
                                    : GreekTextStyle.order_sell_textstyle,
                          ),
                          const SizedBox(width: 10.0),
                          Text(
                            obj.token?.toExchange().toUpperCase() != "MCX" &&
                                    obj.token?.toExchange().toUpperCase() !=
                                        "NCDEX"
                                ? '${(_orderBloc!.selectedTabIndex == 1) ? obj.trdQty : (_orderBloc!.selectedTabIndex == 0) ? obj.pendingQty : (_orderBloc!.selectedTabIndex == 3) ? obj.pendingQty : obj.qty} / ${(_orderBloc!.selectedTabIndex == 2) ? obj.qty! : obj.pendingQty! + obj.trdQty!}'
                                : '${(_orderBloc!.selectedTabIndex == 1) ? (((obj.trdQty ?? 0) / (obj.lotSize ?? 0))).toStringAsFixed(0) : (_orderBloc!.selectedTabIndex == 0) ? (((obj.pendingQty ?? 0) / (obj.lotSize ?? 0))).toStringAsFixed(0) : (_orderBloc!.selectedTabIndex == 3) ? ((obj.pendingQty ?? 0) / (obj.lotSize ?? 0)).toStringAsFixed(0) : (((obj.qty ?? 0) / (obj.lotSize ?? 0))).toStringAsFixed(0)} / ${(_orderBloc!.selectedTabIndex == 2) ? (((obj.qty ?? 0) / (obj.lotSize ?? 0))).toStringAsFixed(0) : ((obj.pendingQty! + obj.trdQty!) / (obj.lotSize ?? 0)).toStringAsFixed(0)}',
                            style: GreekTextStyle.order_qty_textstyle,
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: Visibility(
                      visible: (_orderBloc?.selectedTabIndex == 0),
                      child: IconButton(
                        color: const Color(0xFF333333),
                        icon: Image.asset(
                          "lib/Resources/Icons/edit.png",
                          fit: BoxFit.contain,
                          width: 40,
                          height: 40,
                        ),
                        highlightColor: Colors.transparent,
                        splashColor: Colors.transparent,
                        onPressed: () {
                          OrderDetailsModel orderDetails = OrderDetailsModel();
                          orderDetails.gcid = AppConfig().gcid;
                          orderDetails.gorderid_Modify = obj.uniqueID;
                          orderDetails.lexchangeOrderNo1_Modify = obj.ordID;
                          orderDetails.trigger_price = obj.trigPrice.toString();
                          orderDetails.orderAction =
                              obj.action.toString().toUpperCase() == 'BUY'
                                  ? OrderAction.buy
                                  : OrderAction.sell;
                          orderDetails.pending_qty_Modify =
                              obj.pendingQty.toString();
                          orderDetails.iomRuleNo = obj.lIOMRuleNo;
                          orderDetails.gtoken = obj.token.toString();
                          orderDetails.exchange = obj.token!.toExchange();
                          orderDetails.eorderid_Modify = obj.uniqueOrderID;
                          orderDetails.qty = obj.pendingQty.toString();
                          if (obj.token?.toAssetType().toLowerCase() ==
                              "commodity") {
                            orderDetails.lot =
                                (obj.qty! / obj.lotSize!).toStringAsFixed(0);
                          } else {
                            obj.lotSize.toString();
                          }
                          orderDetails.pending_disclosed_qty_Modify =
                              obj.pendingdiscQty.toString();
                          orderDetails.tradeSymbol = obj.tradeSymbol.toString();
                          orderDetails.qty_filled_today_Modify =
                              obj.trdQty.toString();
                          orderDetails.gtdExpiry = obj.lgoodtilldate.toString();

/*  if (orderBookData.getOtype().equalsIgnoreCase("5")) {

                            bundle.putString("otype", "offline");
                        } else if (orderBookData.getOtype().equalsIgnoreCase("6")) {

                            bundle.putString("otype", "amo");
                        } else {
                            bundle.putString("otype", "normal");
                        } */

                          if (obj.otype.toString() == "5") {
                            orderDetails.offline = "1";
                            orderDetails.amo = "0";
                          } else if (obj.otype.toString() == "6") {
                            orderDetails.amo = "1";
                            orderDetails.offline = "0";
                          } else {
                            orderDetails.offline = "0";
                            orderDetails.amo = "0";
                          }
                          orderDetails.lu_time_exchange_Modify = obj.ordModTime;
                          orderDetails.productType = obj.product.toString();
                          orderDetails.validity = obj.lgoodtilldate?.toString();
                          orderDetails.OrderStatuse = obj.status;
                          orderDetails.trigger_price = "${obj.trigPrice}";

                          /*  GreekBase()
                                .getValidityFromBitwiseOprater(
                                    goodTillDate: int.parse(
                                        obj.lgoodtilldate?.toString() ?? '0'),
                                    validity: obj.orderFlags ?? 0)
                                .toString(); */

                          orderDetails.disclosed_qty =
                              ((obj.discQty != null) && (obj.discQty! > 0))
                                  ? obj.discQty.toString()
                                  : '';
                          orderDetails.price = obj.price.toString();
                          if (double.parse(obj.orderType.toString()) == 3) {
                            if (double.parse(obj.price.toString()) == 0.00) {
                              orderDetails.order_type = "4";
                            } else {
                              orderDetails.order_type =
                                  obj.orderType.toString();
                            }
                          } else if (double.parse(obj.orderType.toString()) ==
                              1) {
                            if (double.parse(obj.price.toString()) == 0.00) {
                              orderDetails.order_type = "2";
                            } else {
                              orderDetails.order_type =
                                  obj.orderType.toString();
                            }
                          }

                          GreekNavigator.pushNamed(
                            context: cardContext,
                            routeName: GreekScreenNames.place_order,
                            arguments: [
                              int.parse(obj.token.toString()),
                              orderDetails.orderAction,
                              OrderMode.modiftyOrder,
                              ScriptInfoTab.order.index,
                              orderDetails,
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: Visibility(
                      visible: (_orderBloc?.selectedTabIndex == 0),
                      child: IconButton(
                        color: const Color(0xFF333333),
                        icon: Image.asset(
                          "lib/Resources/Icons/cancel_order_.png",
                          fit: BoxFit.contain,
                          width: 40,
                          height: 40,
                        ),
                        highlightColor: Colors.transparent,
                        splashColor: Colors.transparent,
                        onPressed: () {
                          // GreekNavigator.pop(context: context);
                          validateMarketStatus(obj);
                          OrderDetailsModel orderDetails = OrderDetailsModel();
                          // orderDetails.tradeSymbol = '${tradeSymbol}';
                          orderDetails.gcid = AppConfig().gcid;
                          orderDetails.trigger_price = obj.trigPrice.toString();
                          orderDetails.orderAction =
                              obj.action.toString().toUpperCase() == 'BUY'
                                  ? OrderAction.buy
                                  : OrderAction.sell;
                          orderDetails.gtoken = obj.token.toString();
                          orderDetails.is_preopen_order = '1';
                          orderDetails.exchange = obj.token!.toExchange();
                          orderDetails.is_post_closed = '0';
                          orderDetails.amo = '0';
                          orderDetails.qty = obj.qty.toString();
                          orderDetails.lot = obj.lotSize.toString();
                          orderDetails.tradeSymbol = obj.tradeSymbol;
                          /* if (!validStatus) {
                            orderDetails.offline = '0';
                          } else {
                            orderDetails.offline = '1';
                          } */

                          if ((obj.status.toString().toLowerCase())
                              .contains("unconfirmed")) {
                            if (obj.otype.toString() == "6") {
                              orderDetails.amo == "1";
                              orderDetails.offline = "0";
                            } else if (obj.otype.toString() == "5") {
                              orderDetails.offline = "1";
                              orderDetails.amo == "0";
                            }
                          } else {
                            orderDetails.amo == "0";
                            orderDetails.offline = "0";
                          }

                          if (isPreOpenStatus) {
                            orderDetails.is_preopen_order == "1";
                          } else {
                            orderDetails.is_preopen_order == "0";
                          }

                          if (isPostOpenStatus) {
                            orderDetails.is_post_closed == "1";
                          } else {
                            orderDetails.is_post_closed == "0";
                          }
                          orderDetails.gtdExpiry = obj.lgoodtilldate.toString();
                          orderDetails.validity = GreekBase()
                              .getValidityTypeFromValidityName(GreekBase()
                                  .getValidityFromBitwiseOprater(
                                      goodTillDate: int.parse(
                                          obj.lgoodtilldate?.toString() ?? '0'),
                                      validity: obj.orderFlags ??
                                          0)); //obj.ordLife.toString();
                          orderDetails.productType = obj.product.toString();
                          orderDetails.order_type = obj.orderType.toString();
                          orderDetails.disclosed_qty = obj.discQty.toString();
                          orderDetails.price = obj.price.toString();
                          orderDetails.gorderid_Cancel =
                              obj.uniqueID.toString();
                          orderDetails.lexchangeOrderNo1_Cancel = obj.ordID;
                          orderDetails.pending_qty_Cancel =
                              obj.pendingQty.toString();
                          orderDetails.eorderid_Cancel =
                              obj.uniqueOrderID.toString();
                          orderDetails.qty_filled_today_Cancel =
                              obj.trdQty.toString();
                          orderDetails.lu_time_exchange_Cancel =
                              obj.ordModTime.toString();
                          orderDetails.pending_disclosed_qty_Cancel =
                              obj.pendingdiscQty.toString();
                          GreekDialogPopupView.cancelOrderDialog(
                            popContext: GreekBase().drawerKey.currentContext,
                            obj: orderDetails,
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
            //const SizedBox(height: 8.0),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Flexible(
                    fit: FlexFit.loose,
                    child: Container(
                      padding: const EdgeInsets.only(left: 8),
                      child: SizedBox(
                        width: 190.0,
                        child: (obj.description?.length ?? 0) >= 20
                            ? Marquee(
                                text: obj.description ?? '',
                                style: GreekTextStyle
                                    .order_description_ltp_textstyle,
                                pauseAfterRound: const Duration(seconds: 5),
                                blankSpace: 30.0,
                              )
                            : Text(
                                obj.description ?? '',
                                style: GreekTextStyle
                                    .order_description_ltp_textstyle,
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10.0),
                  Container(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      double.parse(obj.price.toString())
                          .toFormateDicemalPoint(token: obj.token),
                      style: GreekTextStyle.order_description_ltp_textstyle,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8.0),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.only(left: 8),
                    child: Text(
                      '${obj.token!.toExchange()} | ${GreekBase().getProductNameFromProductToken(obj.product!)} | $orderType',
                      style: GreekTextStyle.order_status_textstyle,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      obj.status!.toUpperCase(),
                      style: GreekTextStyle.order_status_textstyle,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showOrderDetailBottomSheet({
    required BuildContext orderDetailContext,
    required OrderDetailResponseModel obj,
  }) {
    var orderType = "LIMIT";
    if (obj.bookType.toString() == "50") {
      orderType = "BRACKET";
    } else if (obj.bookType.toString() == "1") {
      if (GreekBase().getBitResult(int.parse(obj.orderFlags.toString())) == 1) {
        if (double.parse(obj.price.toString()) == 0.00) {
          orderType = "MARKET";
        } else {
          orderType = "LIMIT";
        }
      }
    } else if (obj.bookType.toString() == "3") {
      if (GreekBase().getBitResult(int.parse(obj.orderFlags.toString())) == 1) {
        orderType = "SLM";
      } else {
        if (double.parse(obj.price.toString()) == 0.00) {
          orderType = "SLM";
        } else {
          orderType = "SL";
        }
      }
    }

    showModalBottomSheet(
      isScrollControlled: true,
      context: orderDetailContext,
      builder: (sheetContex) {
        return SafeArea(
          child: Container(
            height: ((_orderBloc?.selectedTabIndex ?? 0) == 0) ? 380 : 350,
            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 50,
                  color: ConstantColors.primaryColorLight,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(
                          obj.description!,
                          style: GreekTextStyle.headline2,
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        obj.token!.toExchange(),
                        style: GreekTextStyle.headline4,
                      ),
                      Expanded(
                        child: IconButton(
                            onPressed: () {
                              GreekNavigator.pop(context: context);
                            },
                            alignment: Alignment.centerRight,
                            icon: const Icon(Icons.cancel)),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  fit: FlexFit.loose,
                  child: ListView(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    children: [
                      const SizedBox(height: 16.0),
                      Container(
                        height: 40.0,
                        margin: const EdgeInsets.all(5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Traded Quantity",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.trdQty.toString(),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Traded Price",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    ((_orderBloc?.selectedTabIndex ?? 0) == 1)
                                        ? obj.price.toString()
                                        : '-',
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Pending Quantity",
                                    textAlign: TextAlign.center,
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.pendingQty.toString(),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      Container(
                        height: 40.0,
                        margin: const EdgeInsets.all(5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Order Quantity",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.qty.toString(),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Order Price",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.price.toString(),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Trigger Price",
                                    textAlign: TextAlign.center,
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.trigPrice.toString(),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      Container(
                        height: 40.0,
                        margin: const EdgeInsets.all(5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Order Type ",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    /* GreekBase().getOrderNameFromOrderToken(
                                      obj.otype ?? 0,
                                    ) */
                                    orderType,
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Product Type",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    GreekBase().getProductNameFromProductToken(
                                        int.parse(obj.product.toString())),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Validity",
                                    textAlign: TextAlign.center,
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    GreekBase().getValidityFromBitwiseOprater(
                                        goodTillDate: int.parse(
                                            obj.lgoodtilldate?.toString() ??
                                                '0'),
                                        validity: obj.orderFlags ?? 0),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      Container(
                        height: 40.0,
                        margin: const EdgeInsets.all(5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Disclosed Qty",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.discQty.toString(),
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Order Status",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.status!,
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Order place by",
                                    textAlign: TextAlign.center,
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.ordTime ?? '',
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      Container(
                        height: 40.0,
                        margin: const EdgeInsets.all(5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Order No",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.uniqueID!,
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                            Expanded(child: Container()),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    "Exchange Order No",
                                    style: GreekTextStyle.headline23,
                                  ),
                                  Text(
                                    obj.uniqueOrderID!,
                                    style: GreekTextStyle.heading7,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      Visibility(
                        visible: ((_orderBloc?.selectedTabIndex ?? 0) == 0),
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10, bottom: 25.0),
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: SizedBox(
                              height: 40, //height of button
                              width: 200,
                              child: ElevatedButton(
                                child: const Text(
                                  'Cancel Order',
                                ),
                                onPressed: () {
                                  // GreekNavigator.pop(context: context);
                                  validateMarketStatus(obj);
                                  OrderDetailsModel orderDetails =
                                      OrderDetailsModel();
                                  // orderDetails.tradeSymbol = '${tradeSymbol}';
                                  orderDetails.gcid = AppConfig().gcid;
                                  orderDetails.trigger_price =
                                      obj.trigPrice.toString();
                                  orderDetails.orderAction =
                                      obj.action.toString().toUpperCase() ==
                                              'BUY'
                                          ? OrderAction.buy
                                          : OrderAction.sell;
                                  orderDetails.gtoken = obj.token.toString();
                                  orderDetails.is_preopen_order = '1';
                                  orderDetails.exchange =
                                      obj.token!.toExchange();
                                  orderDetails.is_post_closed = '0';
                                  orderDetails.amo = '0';

                                  orderDetails.qty = obj.qty.toString();
                                  orderDetails.lot = obj.lotSize.toString();
                                  orderDetails.tradeSymbol = obj.tradeSymbol;
                                  if (!validStatus) {
                                    orderDetails.offline = '0';
                                  } else {
                                    orderDetails.offline = '1';
                                  }

                                  if ((obj.status.toString().toLowerCase())
                                      .contains("unconfirmed")) {
                                    if (obj.otype.toString() == "6") {
                                      orderDetails.amo == "1";
                                      orderDetails.offline = "0";
                                    } else if (obj.otype.toString() == "5") {
                                      orderDetails.offline = "1";
                                      orderDetails.amo == "0";
                                    }
                                  } else {
                                    orderDetails.amo == "0";
                                    orderDetails.offline = "0";
                                  }

                                  if (isPreOpenStatus) {
                                    orderDetails.is_preopen_order == "1";
                                  } else {
                                    orderDetails.is_preopen_order == "0";
                                  }

                                  if (isPostOpenStatus) {
                                    orderDetails.is_post_closed == "1";
                                  } else {
                                    orderDetails.is_post_closed == "0";
                                  }
                                  orderDetails.gtdExpiry =
                                      obj.lgoodtilldate.toString();
                                  orderDetails.validity = GreekBase()
                                      .getValidityTypeFromValidityName(GreekBase()
                                          .getValidityFromBitwiseOprater(
                                              goodTillDate: int.parse(obj
                                                      .lgoodtilldate
                                                      ?.toString() ??
                                                  '0'),
                                              validity: obj.orderFlags ??
                                                  0)); //obj.ordLife.toString();
                                  orderDetails.productType =
                                      obj.product.toString();
                                  orderDetails.order_type =
                                      obj.orderType.toString();
                                  orderDetails.disclosed_qty =
                                      obj.discQty.toString();
                                  orderDetails.price = obj.price.toString();
                                  orderDetails.gorderid_Cancel =
                                      obj.uniqueID.toString();
                                  orderDetails.lexchangeOrderNo1_Cancel =
                                      obj.ordID;
                                  orderDetails.pending_qty_Cancel =
                                      obj.pendingQty.toString();
                                  orderDetails.eorderid_Cancel =
                                      obj.uniqueOrderID.toString();
                                  orderDetails.qty_filled_today_Cancel =
                                      obj.trdQty.toString();
                                  orderDetails.lu_time_exchange_Cancel =
                                      obj.ordModTime.toString();
                                  orderDetails.pending_disclosed_qty_Cancel =
                                      obj.pendingdiscQty.toString();
                                  GreekNavigator.pop(
                                      context: orderDetailContext);
                                  GreekDialogPopupView.cancelOrderDialog(
                                    popContext:
                                        GreekBase().drawerKey.currentContext,
                                    obj: orderDetails,
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void validateMarketStatus(OrderDetailResponseModel obj) {
    validStatus = false;
    isPostOpenStatus = false;
    isPreOpenStatus = false;

    if ((obj.token?.toExchange().toUpperCase() == "NSE") &&
        (obj.token?.toAssetType().toUpperCase() == "EQUITY") &&
        MarketStatusFlag.nse_eq_status) {
      log("In NSE eq");
      validStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "BSE") &&
        (obj.token?.toAssetType().toUpperCase() == "equity".toUpperCase()) &&
        MarketStatusFlag.bse_eq_status) {
      log("In BSE eq");
      validStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "fno".toUpperCase()) &&
        MarketStatusFlag.nse_fno_status) {
      log("In NSE FO");
      validStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "bse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "fno".toUpperCase()) &&
        MarketStatusFlag.bse_fno_status) {
      log("In BSE FNO");
      validStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "currency".toUpperCase()) &&
        MarketStatusFlag.nse_cd_status) {
      log("In NSE CD");
      validStatus = true;
    } else if (((obj.token?.toExchange().toUpperCase() ==
                "bse".toUpperCase()) ||
            (obj.token?.toExchange().toUpperCase() ==
                "BSECURR".toUpperCase())) &&
        (obj.token?.toAssetType().toUpperCase() == "currency".toUpperCase()) &&
        MarketStatusFlag.bse_cd_status) {
      log("In BSE CD");
      validStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "mcx".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "commodity".toUpperCase()) &&
        MarketStatusFlag.mcx_com_status) {
      log("In MCX");
      validStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() ==
            "ncdex".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "commodity".toUpperCase()) &&
        MarketStatusFlag.ncdex_com_status) {
      log("In ncdex");
      validStatus = true;
    }

    if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "equity".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_nse_eq) {
      log("In nSE eq");
      isPreOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "bse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "equity".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_bse_eq) {
      log("In bSE eq");
      isPreOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "fno".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_nse_fno) {
      log("In nSE fno");
      isPreOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "bse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "fno".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_bse_fno) {
      log("In bSE fno");
      isPreOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "currency".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_nse_cd) {
      isPreOpenStatus = true;
    } else if (((obj.token?.toExchange().toUpperCase() ==
                "bse".toUpperCase()) ||
            (obj.token?.toExchange().toUpperCase() ==
                "BSECURR".toUpperCase())) &&
        (obj.token?.toAssetType().toUpperCase() == "currency".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_bse_cd) {
      isPreOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "mcx".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "commodity".toUpperCase()) &&
        MarketStatusFlag.isPreOpen_mcx_com) {
      isPreOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() ==
            "ncdex".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "commodity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_ncdex_com) {
      isPreOpenStatus = true;
    }

    if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "equity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_nse_eq) {
      isPostOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "bse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "equity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_bse_eq) {
      isPostOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "fno".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_nse_fno) {
      isPostOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "bse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "fno".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_bse_fno) {
      isPostOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "Nse".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "currency".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_nse_cd) {
      isPostOpenStatus = true;
    } else if (((obj.token?.toExchange().toUpperCase() ==
                "bse".toUpperCase()) ||
            obj.token?.toExchange().toUpperCase() == "BSECURR".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "currency".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_bse_cd) {
      isPostOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() == "mcx".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "commodity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_mcx_com) {
      isPostOpenStatus = true;
    } else if ((obj.token?.toExchange().toUpperCase() ==
            "ncdex".toUpperCase()) &&
        (obj.token?.toAssetType().toUpperCase() == "commodity".toUpperCase()) &&
        MarketStatusFlag.isPostClosed_ncdex_com) {
      isPostOpenStatus = true;
    }
  }
}
