import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/Order/models/order_detail_response_model.dart';
import 'package:greek_ibt_app/Network_Manager/Network/Enums/api_network_enums.dart';
import 'package:greek_ibt_app/Network_Manager/Network/network_manager.dart';

class OrderRepository {
  Future<List<OrderDetailResponseModel>> callOrderAPI(
    BuildContext context, {
    required String gscid,
    required String gcid,
    required String orderStatus,
  }) async {
    final requestQuery =
        'exchangeType=All&ClientCode=$gcid&Order_Status=$orderStatus&Ordertype=All&gscid=$gscid';

    final val = await NetworkManager().getAPIEncrypted(
      //context: context,
      apiName: APIName.getOrderBookDetailWithLegV2,
      query: requestQuery,
    );

    List<OrderDetailResponseModel> objList = <OrderDetailResponseModel>[];

    if (val is List) {
      objList = val
          .map(
            (e) => OrderDetailResponseModel.fromJson(e),
          )
          .toList();
    }

    return objList;
  }
}
