import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/app_config.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Helper/constant_messages.dart';
import 'package:greek_ibt_app/Helper/greek_base.dart';
import 'package:greek_ibt_app/Helper/greek_bloc.dart';
import 'package:greek_ibt_app/Screens/Order/models/order_detail_response_model.dart';
import 'package:greek_ibt_app/Screens/Order/repository/order_repository.dart';
import 'package:rxdart/subjects.dart';

class OrderBloc extends GreekBlocs {
  final BuildContext _orderContext;
  final _orderRepository = OrderRepository();

  int selectedTabIndex = 0;
  TabController? tabController;

  final _orderResultSubject = BehaviorSubject<List<OrderDetailResponseModel>>();
  Stream<List<OrderDetailResponseModel>> get orderResultObserver =>
      _orderResultSubject.stream;

  final noDataAvailableMsg = [
    ConstantMessages.NO_PENDING_ORDER,
    ConstantMessages.NO_EXECUTED_ORDER,
    ConstantMessages.NO_REJECTED_ORDER,
    ConstantMessages.NO_CANCEL_ORDER,
  ];
  final tabLabels = [
    ConstantMessages.PENDING_HEADER_TXT,
    ConstantMessages.EXECUTED_HEADER_TXT,
    ConstantMessages.REJECTED_HEADER_TXT,
    ConstantMessages.CANCELLED_HEADER_TXT
  ]
      .map(
        (e) => Tab(
          text: e,
        ),
      )
      .toList();

  final _orderStatus = [
    'PENDING_BAJAJ',
    'TRADED',
    'RMS REJECTED',
    'CANCELLED',
  ];
  bool isFromConstructor = true;

  OrderBloc(this._orderContext) {
    GreekBase().orderScreenState?.listen((value) {
      if (!isFromConstructor) {
        switch (value) {
          case OrderScreenState.unknown:
            break;

          case OrderScreenState.pending:
            getOrderResultBySelectedTabIndex(tabIndex: 0, isChangeTab: true);
            break;
          case OrderScreenState.tradeed:
            getOrderResultBySelectedTabIndex(tabIndex: 1, isChangeTab: true);
            break;
          case OrderScreenState.rejected:
            getOrderResultBySelectedTabIndex(tabIndex: 2, isChangeTab: true);
            break;
          case OrderScreenState.canceled:
            getOrderResultBySelectedTabIndex(tabIndex: 3, isChangeTab: true);
            break;
        }
      }
      isFromConstructor = false;
    });
  }

  final searchTextFieldController = TextEditingController();
  List<OrderDetailResponseModel> _currentOrderList =
      <OrderDetailResponseModel>[];

  @override
  void disposeBloc() {
    searchTextFieldController.dispose();
    _orderResultSubject.close();
  }

  void getOrderResultBySelectedTabIndex(
      {required int tabIndex, bool isChangeTab = false}) {
    //FocusScope.of(_orderContext).unfocus();
    searchTextFieldController.clear();

    selectedTabIndex = tabIndex;

    if (isChangeTab) {
      tabController?.animateTo(selectedTabIndex);
    }

    _orderRepository
        .callOrderAPI(
      _orderContext,
      gscid: AppConfig().gscid,
      gcid: AppConfig().gcid,
      orderStatus: _orderStatus[selectedTabIndex],
    )
        .then(
      (result) {
        _currentOrderList = result;
        _orderResultSubject.sink.add(_currentOrderList);
      },
    );
  }

  void filterOrderListBySearchText(String searchText) {
    if (searchText.isEmpty) {
      _orderResultSubject.sink.add(_currentOrderList);
    } else {
      final resultList = _currentOrderList
          .where((element) => (element.description
                  ?.toLowerCase()
                  .contains(searchText.toLowerCase()) ??
              false))
          .toList();
      _orderResultSubject.sink.add(resultList);
    }
  }

  void clearButtonTapped() {
    FocusScope.of(_orderContext).unfocus();
    searchTextFieldController.clear();
    _orderResultSubject.sink.add(_currentOrderList);
  }
}
