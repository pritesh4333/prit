class OrderDetailResponseModel {
  String? ordLiveDays;
  String? ordTime;
  String? uniqueID;
  int? product;
  String? ordID;
  String? exchange;
  int? trdQty;
  String? remarks;
  String? isCancellable;
  String? amount;
  int? token;
  int? discQty;
  String? uniqueOrderID;
  String? multiplier;
  int? qty;
  String? isEditable;
  int? orderType;
  String? lastModBy;
  int? ordLife;
  String? assetType;
  double? trigPrice;
  int? lotSize;
  String? ordModTime;
  String? tradeSymbol;
  double? tickSize;
  int? pendingQty;
  String? status;
  String? clientCode;
  double? price;
  String? action;
  String? description;
  String? userID;
  String? tmplotSize;
  String? filterKey;
  String? flowType;
  int? pendingdiscQty;
  String? logTime;
  int? bookType;
  int? orderFlags;
  String? instrument;
  String? lgoodtilldate;
  String? errorCode;
  String? optionType;
  double? strikePrice;
  String? expiryDate;
  int? otype;
  String? scripName;
  double? dSLPrice;
  double? dTargetPrice;
  double? dSLTPrice;
  String? lIOMRuleNo;
  String? iStrategyId;
  String? cPANNumber;
  int? noOfLegs;
  //Null strategyName;
  String? tag;
  //List<Null> legInfo;

  OrderDetailResponseModel({
    this.ordLiveDays,
    this.ordTime,
    this.uniqueID,
    this.product,
    this.ordID,
    this.exchange,
    this.trdQty,
    this.remarks,
    this.isCancellable,
    this.amount,
    this.token,
    this.discQty,
    this.uniqueOrderID,
    this.multiplier,
    this.qty,
    this.isEditable,
    this.orderType,
    this.lastModBy,
    this.ordLife,
    this.assetType,
    this.trigPrice,
    this.lotSize,
    this.ordModTime,
    this.tradeSymbol,
    this.tickSize,
    this.pendingQty,
    this.status,
    this.clientCode,
    this.price,
    this.action,
    this.description,
    this.userID,
    this.tmplotSize,
    this.filterKey,
    this.flowType,
    this.pendingdiscQty,
    this.logTime,
    this.bookType,
    this.orderFlags,
    this.instrument,
    this.lgoodtilldate,
    this.errorCode,
    this.optionType,
    this.strikePrice,
    this.expiryDate,
    this.otype,
    this.scripName,
    this.dSLPrice,
    this.dTargetPrice,
    this.dSLTPrice,
    this.lIOMRuleNo,
    this.iStrategyId,
    this.cPANNumber,
    this.noOfLegs,
    //this.strategyName,
    this.tag,
  });

  OrderDetailResponseModel.fromJson(Map<String, dynamic> json) {
    ordLiveDays = json['ordLiveDays'].toString();
    ordTime = json['ordTime'].toString();
    uniqueID = json['uniqueID'].toString();
    product = int.parse(json['product'].toString());
    ordID = json['ordID'].toString();
    exchange = json['exchange'].toString();
    trdQty = int.parse(json['trdQty'].toString());
    remarks = json['remarks'].toString();
    isCancellable = json['isCancellable'].toString();
    amount = json['amount'].toString();
    token = int.parse(json['token'].toString());
    discQty = int.parse(json['discQty'].toString());
    uniqueOrderID = json['uniqueOrderID'].toString();
    multiplier = json['multiplier'].toString();
    qty = int.parse(json['qty'].toString());
    isEditable = json['isEditable'].toString();
    orderType = int.parse(json['orderType'].toString());
    lastModBy = json['lastModBy'].toString();
    ordLife = int.parse(json['ordLife'].toString());
    assetType = json['assetType'].toString();
    trigPrice = double.parse(json['trigPrice'].toString());
    lotSize = int.parse(json['lotSize'].toString());
    ordModTime = json['ordModTime'].toString();
    tradeSymbol = json['tradeSymbol'].toString();
    tickSize = double.parse(json['tickSize'].toString());
    pendingQty = int.parse(json['pendingQty'].toString());
    status = json['status'].toString();
    clientCode = json['clientCode'].toString();
    price = double.parse(json['price'].toString());
    action = (int.parse(json['action'].toString()) == 1) ? 'Buy' : 'Sell';
    description = json['description'].toString();
    userID = json['userID'].toString();
    tmplotSize = json['tmplotSize'].toString();
    filterKey = json['filterKey'].toString();
    flowType = json['flowType'].toString();
    pendingdiscQty = int.tryParse(json['pendingdiscQty']?.toString() ?? '0') ?? 0;
    logTime = json['LogTime'].toString();
    bookType = int.parse(json['BookType'].toString());
    orderFlags = int.parse(json['OrderFlags'].toString());
    instrument = json['instrument'].toString();
    lgoodtilldate = json['lgoodtilldate'].toString();
    errorCode = json['errorCode'].toString();
    optionType = json['optionType'].toString();
    strikePrice = double.parse(json['strikePrice'].toString());
    expiryDate = json['expiryDate'].toString();
    otype = int.parse(json['otype'].toString());
    scripName = json['scripName'].toString();
    dSLPrice = double.parse(json['dSLPrice'].toString());
    dTargetPrice = double.parse(json['dTargetPrice'].toString());
    dSLTPrice = double.parse(json['dSLTPrice'].toString());
    lIOMRuleNo = json['lIOMRuleNo'].toString();
    iStrategyId = json['iStrategyId'].toString();
    cPANNumber = json['cPANNumber'].toString();
    noOfLegs = int.parse(json['NoOfLegs'].toString());
    //strategyName = json['strategyName'].toString();
    tag = json['tag'].toString();
    /*if (json['LegInfo'] != null) {
      legInfo = List<Null>
      json['LegInfo'].forEach((v) {
        if
      });
    }*/
  }
}
