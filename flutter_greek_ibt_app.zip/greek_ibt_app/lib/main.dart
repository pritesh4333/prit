import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Configuration/greek_navigation.dart';

void main() {
  runApp(
    MaterialApp(
      useInheritedMediaQuery: true,
      debugShowCheckedModeBanner: false,
      initialRoute: GreekScreenNames.splash,
      routes: GreekNavigator.appRoutes,
      builder: (context, child) => MediaQuery(
        data: MediaQueryData.fromWindow(WidgetsBinding.instance.window).copyWith(boldText: false, textScaleFactor: 1.0),
        child: child ?? Container(color: Colors.red),
      ),
    ),
  );
}
