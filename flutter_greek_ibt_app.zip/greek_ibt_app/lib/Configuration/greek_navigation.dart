// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';
import 'package:greek_ibt_app/Screens/1_Splash%20Screen/ui/splash_screen.dart';
import 'package:greek_ibt_app/Screens/2_LandingPage/ui/landing_tabbar_view.dart';
import 'package:greek_ibt_app/Screens/Alerts/ui/alert_search_screen.dart';
import 'package:greek_ibt_app/Screens/Edis/edis_dashboard_screen.dart';
import 'package:greek_ibt_app/Screens/Edis/edis_webview_cdsl.dart';
import 'package:greek_ibt_app/Screens/Edis/edis_webview_nsdl.dart';
import 'package:greek_ibt_app/Screens/Edis/ui/margin_webview_nsdl.dart';
import 'package:greek_ibt_app/Screens/Login/ui/login_view_screen.dart';
import 'package:greek_ibt_app/Screens/M-Pin/ui/mpin_view_screen.dart';
import 'package:greek_ibt_app/Screens/OTP/ui/OTPScreen.dart';
import 'package:greek_ibt_app/Screens/Order/ui/order_screen.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/ui/change_password.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/ui/forget_password.dart';
import 'package:greek_ibt_app/Screens/Password%20Screens/ui/reset_password.dart';
import 'package:greek_ibt_app/Screens/Portfolio/ui/place_order_screen.dart';
import 'package:greek_ibt_app/Screens/Watch%20List/ui/search_symbol_view.dart';
import 'package:greek_ibt_app/Screens/Portfolio/ui/watch_list_screen.dart';

class GreekScreenNames {
  static const splash = '/';
  static const login = '/login';
  static const forgot_password = '/forgot_password';
  static const change_password = '/change_password';
  static const reset_password = '/reset_password';
  static const mpin = '/mpin';
  static const otp = '/otp';
  static const landing = '/landing';
  static const watchlist = '/watchlist';
  static const searchSymbol = '/search_symbol';
  static const market = '/market';
  static const order = '/order';
  static const place_order = '/place_order';
  static const edis_dashboard = '/edis_dashboard';
  static const edis_webviewnsdl = '/edis_webviewnsdl';
  static const edis_webviewcdsl = '/edis_webviewcdsl';
  static const edis_marginwebviewnsdl = '/margin_webview_nsdl';
  static const alert_search_screen = '/alert_search_screen';
}

class GreekNavigator {
  static final appRoutes = <String, WidgetBuilder>{
    GreekScreenNames.splash: (BuildContext context) => const SplashScreen(),
    GreekScreenNames.login: (BuildContext context) => const LoginScreen(),
    GreekScreenNames.change_password: (BuildContext context) => const ChangePassword(),
    GreekScreenNames.forgot_password: (BuildContext context) => const ForgetPassword(),
    GreekScreenNames.reset_password: (BuildContext context) => const ResetPassword(),
    GreekScreenNames.mpin: (BuildContext context) => const MPinScreen(),
    GreekScreenNames.otp: (BuildContext context) => const OTPScren(),
    GreekScreenNames.landing: (BuildContext context) => const LandingTabBarView(),
    GreekScreenNames.watchlist: (BuildContext context) => const WatchListScreen(),
    GreekScreenNames.searchSymbol: (BuildContext context) => const SearchSymbolScreen(),
    GreekScreenNames.order: (BuildContext context) => const OrderScreen(),
    GreekScreenNames.place_order: (BuildContext context) => const PlaceOrderScreen(),
    GreekScreenNames.edis_dashboard: (BuildContext context) => const EdisDashboardScreen(),
    GreekScreenNames.edis_webviewnsdl: (BuildContext context) => const EdisWebviewNSDL(),
    GreekScreenNames.edis_webviewcdsl: (BuildContext context) => const EdisWebviewCDSL(),
    GreekScreenNames.edis_marginwebviewnsdl: (BuildContext context) => const MarginWebViewNSDL(),
    GreekScreenNames.alert_search_screen: (BuildContext context) => const AlertSearchScreen(),
  };

  static Future<Object?> pushNamed({
    required BuildContext context,
    required String routeName,
    Object? arguments,
  }) async {
    var result = await Navigator.of(context).pushNamed(
      routeName,
      arguments: arguments,
    );
    return result;
  }

  static Future<Object?> pushReplacementNamed({
    required BuildContext context,
    required String routeName,
    Object? arguments,
  }) async {
    var result = await Navigator.of(context).pushReplacementNamed(
      routeName,
      arguments: arguments,
    );
    return result;
  }

  static Future<Object?> pushNamedAndRemoveUntil({
    required BuildContext context,
    required String newRouteName,
    Object? arguments,
  }) async {
    var result = await Navigator.of(context).pushNamedAndRemoveUntil(
      newRouteName,
      (route) {
        return true;
      },
      arguments: arguments,
    );
    return result;
  }

  static void pop({required BuildContext context, dynamic popArguments}) {
    Navigator.of(context).pop(context);
  }

  static Future<Object?> popAndPushNamed({
    required BuildContext context,
    required String routeName,
    Object? arguments,
  }) async {
    var result = await Navigator.of(context).popAndPushNamed(
      routeName,
      arguments: arguments,
    );
    return result;
  }

  static void popUntil({required BuildContext context, required String routeName}) {
    Navigator.of(context).popUntil(
      ModalRoute.withName(routeName),
    );
  }
}
