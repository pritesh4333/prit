// ignore_for_file: file_names, constant_identifier_names, non_constant_identifier_names

import 'dart:io' show Platform;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';
import 'package:greek_ibt_app/Utilities/greek_urls.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppConfig {
  // Singleton object
  static final AppConfig _singleton = AppConfig._internal();

  bool islogoff = false;

  factory AppConfig() {
    return _singleton;
  }

  AppConfig._internal() {
    if (kIsWeb) {
      currentPlatform = AppPlatform.web;

      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      deviceInfo.webBrowserInfo.then(
        (info) {
          deviceDetails = info.userAgent!;
          deviceType = '1';
        },
      );
    } else {
      if (Platform.isIOS) {
        currentPlatform = AppPlatform.iOS;

        DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
        deviceInfo.iosInfo.then(
          (info) {
            deviceDetails =
                '${info.model!} ${info.systemName!} ${info.systemVersion!}';
            deviceType = '2';
          },
        );
      } else if (Platform.isAndroid) {
        currentPlatform = AppPlatform.android;

        DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
        deviceInfo.androidInfo.then(
          (info) {
            deviceDetails =
                '${info.manufacturer!.toUpperCase()} ${info.model!.toUpperCase()} ${info.version.sdkInt!}';
            deviceType = '0';
          },
        );
      } else {
        currentPlatform = AppPlatform.none;
        deviceDetails = 'unknown';
        deviceType = '-1';
      }
    }
  }

  void saveUser(String data1, String data2) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.setString('username', data1);
    prefs.setString('password', data2);
  }

  void saveDefaultScreen({String data = 'Market'}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('defaultscreen', data);
  }

  getDefaultScreen() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String stringValue = prefs.getString('defaultscreen') ?? '';
    return stringValue;
  }

  void saveMPIN(String data1, String data2) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.setString('gscid', data1);
    prefs.setString('mpin', data2);
  }

  deleteUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final deleteUser = prefs.remove('username');
    final deletePassword = prefs.remove('password');
    return {deleteUser, deletePassword};
  }

  getUsername() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String stringValue = prefs.getString('username') ?? '';
    return stringValue;
  }

  void saveotpDate(String data1) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('otpsaveDate', data1);
  }

  Future<dynamic> getOTPdate() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String stringValue = prefs.getString('otpsaveDate') ?? '';
    return stringValue;
  }

  void saveotp(String data1, String data2) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.setString('username', data1);
    prefs.setString('userotp', data2);
  }

  getOTP() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String stringValue = prefs.getString('userotp') ?? '';
    return stringValue;
  }

  deleteOTP() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final deleteUser = prefs.remove('username');
    final deleteOTP = prefs.remove('userotp');
    return {deleteUser, deleteOTP};
  }

  getClientName() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String clientName = preferences.getString('clientname') ?? '';
    return clientName;
  }

  getPassword() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String stringValue = prefs.getString('password') ?? '';
    return stringValue;
  }

  AppPlatform? currentPlatform;

  // final appName = ClientEnvironment.Vitt.toStringValue();
  final appName = 'वित्त';
  final internalVersionNO = '1.0.1.10';
  var deviceID = 'D572727E85A5';
  var mobdeviceid = _getId();
  String deviceType = '';
  String? deviceDetails;
  final version_no = "1.0.1.10";

  var serverInfo = GreekURLs.currentServerInfo;

  int heartBeatInterval = 10;
  int reconnection_attempts = 180;

  String gscid = '';
  String gcid = '';
  String sessionID = '';

  String storedUsername = '';
  String storedPassword = '';

  bool isMPinSet = false;
  bool isSecureGlobal = false;

  String clientName = '';

  //Prepare URL to Fetch Profile Image
  String getProfileUrl() {
    var isSecure = AppConfig().serverInfo.item1 ? 'https://' : 'http://';
    var arachneIp = AppConfig().serverInfo.item2.toString();
    var port = AppConfig().serverInfo.item3.toString();

    final profileUrl = isSecure +
        arachneIp +
        ':$port/' +
        'downloadFileV2?imageName=ClientImage$gscid.jpeg';
    return profileUrl;
  }

  //Upload Image to Server From Profile

  void uploadImageFromProfile() {}
}

Future<String?> _getId() async {
  var deviceInfo = DeviceInfoPlugin();
  if (Platform.isIOS) {
    // import 'dart:io'
    var iosDeviceInfo = await deviceInfo.iosInfo;
    return iosDeviceInfo.identifierForVendor; // unique ID on iOS
  } else if (Platform.isAndroid) {
    var androidDeviceInfo = await deviceInfo.androidInfo;
    return androidDeviceInfo.androidId; // unique ID on Android
  }
}
