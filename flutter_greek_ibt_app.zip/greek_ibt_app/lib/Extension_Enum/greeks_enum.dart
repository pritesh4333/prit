// ignore_for_file: constant_identifier_names

enum ClientEnvironment {
  Greek,
  Vishwash,
  Trade_on_go,
  Marwadi,
  Vitt,
}

var vittMarathi = "वित्त";

enum AppPlatform {
  iOS,
  android,
  web,
  none,
}

enum MpinViewState {
  create,
  validated,
  forget,
  validatedOTP,
}

enum MarketSegment {
  nseeq,
  nsefo,
  nsecd,
  nsecomm,
  bseeq,
  bsefo,
  bsecd,
  bsecomm,
  mcx,
  ncdex,
}

enum CommonListenID {
  showWatchlistGroupNameBottomSheet,
  navigateFundScreen,
}

enum FundScreenUserAction { portfolio, add_fund }

/* enum WatchListActionID {
  createGroup,
  selectGroup,
  deleteGroup,
}

typedef WatchlistUserActionCallBack = void Function(
  BuildContext context,
  WatchListActionID actionID,
  String? groupName,
); */

enum OrderAction { buy, sell }

enum OrderMode { newOrder, modiftyOrder, squareoffOrder }

enum ScriptInfoTab { order, overview, chart, optionchain, futures, fundamentals, news }

enum PopAction { rebuildWidget }

enum OrderScreenState { unknown, pending, tradeed, rejected, canceled }

enum PortfolioScreenState { unknown, holding, position }

enum FiiDiiType {
  FII_Cash,
  DII_Cash,
  FII_Index_Futures,
  FII_Stock_Futures,
  FII_Index_Options,
  FII_Stock_Options,
}

extension FiiDiiTypeExtension on FiiDiiType {
  String toStringValue() => toString().split(".").last.replaceAll('_', ' ');
}

enum FiiDiiInterval { Daily, Monthly, Yearly }

extension FiiDiiIntervalExtension on FiiDiiInterval {
  String toStringValue() => toString().split(".").last;
}
