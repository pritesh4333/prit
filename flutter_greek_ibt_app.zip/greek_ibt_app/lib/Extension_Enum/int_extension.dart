import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';

extension IntExtension on int {
  String toExchange() {
    final token = this;

    if (((token >= 101000000) &&
            (token <=
                102999999)) /* ||
        ((token >= 502000000) && (token <= 502999999)) */
        ) {
      return "NSE";
    } else if (((token >= 403000000) && (token <= 403999999))) {
      return "NCDEX";
    } else if (((token >= 303000000) && (token <= 303999999))) {
      return "MCX";
    } else if ((token >= 1903000000) && (token <= 1903999999)) {
      return " ";
    } else if ((token >= 2003000000) && (token <= 2003999999)) {
      return "BSECOMM";
    } else if ((token >= 502000000) && (token <= 502999999)) {
      return "NSECURR";
    } else if ((token >= 1302000000) && (token <= 1302999999)) {
      return "BSECURR";
    } else {
      return "BSE";
    }
  }

  String toAssetType() {
    final token = this;

    if (((token >= 101000000) && (token <= 101999999)) ||
        ((token >= 201000000) && (token <= 201999999))) {
      return "equity";
    } else if (((token >= 102000000) && (token <= 102999999)) ||
        ((token >= 202000000) && (token <= 202999999))) {
      return "fno";
    } else if (((token >= 403000000) && (token <= 403999999)) ||
        ((token >= 303000000) && (token <= 303999999))) {
      return "commodity";
    } else {
      return "currency";
    }
  }
}

extension DoubleExtension on double {
  String toFormateDicemalPoint({required int? token}) {
    final isCurrency =
        (token?.toAssetType().toLowerCase().compareTo("currency") == 0);
    if (isCurrency) {
      return toStringAsFixed(4);
    } else {
      return toStringAsFixed(2);
    }
  }
}

extension StringExtension on String {
  FiiDiiType toFiiDiiType() {
    // final s1 = replaceAll(' ', '_');
    for (var item in FiiDiiType.values) {
      if (item.toStringValue() == this) return item;
    }

    return FiiDiiType.FII_Cash;
  }

  FiiDiiInterval toFiiDiiInterval() {
    for (var item in FiiDiiInterval.values) {
      if (item.toStringValue() == this) return item;
    }

    return FiiDiiInterval.Daily;
  }
}
