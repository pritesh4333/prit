// ignore_for_file: file_names, non_constant_identifier_names

class MarketStatusFlag {
  static bool nse_eq_status = true;
  static bool bse_eq_status = true;
  static bool nse_fno_status = true;
  static bool bse_fno_status = true;
  static bool nse_cd_status = true;
  static bool bse_cd_status = true;
  static bool mcx_com_status = true;
  static bool ncdex_com_status = true;
  static bool nse_com_status = true;
  static bool bse_com_status = true;

  static bool eq_post_close =false;

  static bool isPreOpen_nse_eq = false;
  static bool isPreOpen_bse_eq = false;
  static bool isPreOpen_nse_fno = false;
  static bool isPreOpen_bse_fno = false;
  static bool isPreOpen_nse_cd = false;
  static bool isPreOpen_bse_cd = false;
  static bool isPreOpen_mcx_com = false;
  static bool isPreOpen_ncdex_com = false;
  static bool isPreOpen_nse_com = false;
  static bool isPreOpen_bse_com = false;

  static bool isPostClosed_nse_eq = false;
  static bool isPostClosed_bse_eq = false;
  static bool isPostClosed_nse_fno = false;
  static bool isPostClosed_bse_fno = false;
  static bool isPostClosed_nse_cd = false;
  static bool isPostClosed_bse_cd = false;
  static bool isPostClosed_mcx_com = false;
  static bool isPostClosed_ncdex_com = false;
  static bool isPostClosed_nse_com = false;
  static bool isPostClosed_bse_com = false;

  static bool allowedmarket_nse = false;
  static bool allowedmarket_nfo = false;
  static bool allowedmarket_ncd = false;
  static bool allowedmarket_bse = false;
  static bool allowedmarket_bfo = false;
  static bool allowedmarket_bcd = false;
  static bool allowedmarket_ncdex = false;
  static bool allowedmarket_mcx = false;
  static bool allowedmarket_nCOM = false;
  static bool allowedmarket_bCOM = false;
}
