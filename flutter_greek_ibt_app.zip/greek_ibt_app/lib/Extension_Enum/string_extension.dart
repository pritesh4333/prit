// ignore_for_file: import_of_legacy_library_into_null_safe

import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:greek_ibt_app/Extension_Enum/greeks_enum.dart';

extension StringExtension on String {
  String toMD5String() => md5.convert(utf8.encode(this)).toString();
}

extension ClientEnvironmentExtension on ClientEnvironment {
  String toStringValue() => toString().split(".").last;
}
