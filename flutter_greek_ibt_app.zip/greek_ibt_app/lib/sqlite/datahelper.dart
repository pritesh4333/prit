import 'dart:developer';
import 'package:greek_ibt_app/Screens/2_LandingPage/models/contract_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBHelper {
  static const _tableName = 'contractsdata';
  static Database? _database;

  static createDatabase() async {
    String databasesPath = await getDatabasesPath();
    String dbPath = join(databasesPath, 'flutter_db.db');
    log("databasepath>> $databasesPath >>>> dabpath >> $dbPath");

    _database = await openDatabase(dbPath, version: 1, onCreate: populateDb);
    return _database;
  }

  static void populateDb(Database database, int version) async {
    await database.execute('Drop table IF EXISTS $_tableName');
    await database.execute("CREATE TABLE $_tableName ("
        "id INTEGER PRIMARY KEY autoincrement,"
        "description TEXT,"
        "expiry_date TEXT,"
        "expiry_timestamp TEXT,"
        "option_type TEXT,"
        "series_name TEXT,"
        "strike_price TEXT,"
        "symbol TEXT,"
        "scripname TEXT,"
        "token TEXT"
        ")");
  }

  static Future<bool> insertContractTableData(List<ContractDataModel> contract) async {
    createDatabase();
    Batch? batch = _database?.batch();
    await _database?.execute('DELETE FROM $_tableName');
    for (var contractDataModel in contract) {
      batch?.insert(
        _tableName,
        contractDataModel.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }

    final insertedList = await batch?.commit(
      continueOnError: true,
    );

    return (insertedList?.isNotEmpty ?? false);
  }

  static searchSymbolByCode({required String symbolCode}) async {
    final splitArray = symbolCode.split(' ');
    // var first = DateTime.now().millisecondsSinceEpoch;
    // print("1->   ${DateTime.now().millisecondsSinceEpoch}");
    // var descriptionCode;
    // bool seriesNameFound = false;
    // var seriesName;
    var queryString = '';
    var whereclause = "";
    var whereclause2 = "";
    var queryString2 = '';
    var index = 0;
    for (var str in splitArray) {
      if (str.isEmpty) {
        splitArray.removeAt(index);
        break;
      } else {
        index++;
      }
    }

    var count = splitArray.length;
    for (var str in splitArray) {
      if (str.isNotEmpty) {
        if (count > 0 && count != splitArray.length) {
          whereclause += " and ";
          whereclause2 += " and ";
        }
        /* whereclause += "(symbol LIKE '" +
            str +
            "%' OR series_name LIKE '" +
            str +
            "%' OR strike_price LIKE '" +
            str +
            "%' OR option_type LIKE '" +
            str +
            "%' OR expiry_date LIKE '%" +
            str +
            "%')";
        */
        /// this code is for selection sample minimization
        whereclause += "(symbol LIKE '" + str + "%' OR strike_price LIKE '" + str + "%' OR expiry_date LIKE '%" + str + "%'";
        whereclause2 += "(symbol LIKE '" + str + "%' OR scripname LIKE '" + str + "%' OR strike_price LIKE '" + str + "%' OR expiry_date LIKE '%" + str + "%'";

        if (splitArray.length > 1) {
          whereclause += " OR option_type LIKE '" + str + "%' OR series_name LIKE '" + str + "%'";
          whereclause2 += " OR option_type LIKE '" + str + "%' OR series_name LIKE '" + str + "%'";
        }
        whereclause += ")";
        whereclause2 += ")";
      }
      count--;
    }

    queryString = "SELECT * ,(token/1000000)%10 as market,token/100000000 as exchange FROM $_tableName WHERE " + whereclause + " ORDER BY symbol,market,series_name,expiry_timestamp,exchange ,  description limit 100";
    queryString2 = "SELECT * ,(token/1000000)%10 as market,token/100000000 as exchange FROM $_tableName WHERE " + whereclause2 + " ORDER BY symbol,market,series_name,expiry_timestamp,exchange ,  description limit 100";
/*
    for (var str in splitArray) {
        if (str.isNotEmpty) {
          if ((str.toString().toUpperCase().contains('FUT')) ||
              (str.toString().toUpperCase().contains('OPT'))) {
            seriesName = "$str%";
            seriesNameFound = true;
          } else {
            descriptionCode = "$str%";
          }
        }
      }

    if (seriesNameFound) {
      if (splitArray.length > 1) {
        queryString = "SELECT * FROM $_tableName WHERE (description LIKE '" +
            descriptionCode +
            "' AND series_name LIKE '" +
            seriesName +
            "') ORDER BY token, description, series_name";
/*         console.log(
            "\n--------------------- Flutter App SQL Query ---------------------\n" +
                queryString +
                ";\n----------------------------------------------------\n"); */
      } else {
        queryString = "SELECT * FROM $_tableName WHERE series_name LIKE '" +
            seriesName +
            "%' ORDER BY token, description, series_name";
        /*  console.log(
            "\n--------------------- Flutter App SQL Query ---------------------\n" +
                queryString +
                ";\n----------------------------------------------------\n"); */
      }
    } else {
      if ((splitArray.length == 1) &&
          (!isNumeric((splitArray[0].toString())))) {
        queryString = "SELECT * FROM $_tableName WHERE (description LIKE '" +
            descriptionCode +
            "' OR symbol LIKE '" +
            descriptionCode +
            "') ORDER BY token, description, series_name";
        /*  console.log(
            "\n--------------------- Flutter App SQL Query ---------------------\n" +
                queryString +
                ";\n----------------------------------------------------\n"); */
      } else {
        queryString = "SELECT * FROM $_tableName WHERE (description LIKE '" +
            descriptionCode +
            "' OR symbol LIKE '" +
            descriptionCode +
            "') ORDER BY token, description, series_name";
        /*   console.log(
            "\n--------------------- Flutter App SQL Query ---------------------\n" +
                queryString +
                ";\n----------------------------------------------------\n"); */
      }
    }
*/

    log("queryString :: query result  $queryString");
    final result = await _database?.rawQuery(queryString);
    log("length of string ${result?.length}");
    log("length of string ${result.toString()}");
    if (result!.length < 2) {
      // checking for larsen toubro scrip.
      log("queryString2 :: query result  $queryString2");
      final result2 = await _database?.rawQuery(queryString2);
      log("length of string2 ${result2?.length}");
      log("length of string2 ${result2.toString()}");
      return result2;
    }

    return result;

    /* var queryString = "SELECT * FROM $_tableName WHERE (description LIKE '" +
        descriptionCode +
        "' OR symbol LIKE '" +
        descriptionCode +
        "') ORDER BY token, description, series_name";

    final result = await _database?.rawQuery(queryString);
    print("2->   ${DateTime.now().millisecondsSinceEpoch - first}");
    log(result.toString());
    log("length of string ${result?.length}"); */
  }

  static bool isNumeric(String strarray) {
    if (strarray.isEmpty) {
      return false;
    }
    return double.parse(strarray, (e) => null ?? 0.00) != null;
  }
}
